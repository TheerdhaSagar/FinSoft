CREATE TABLE balances_load (
    client_id            VARCHAR(255),
    row_nbr              VARCHAR(255),
    mj_rcd_nbr           VARCHAR(255),
    block_nbr            VARCHAR(255),
    rcd_nbr              VARCHAR(255),
    paygroup             VARCHAR(255),
    file_nbr             VARCHAR(255),
    subrecord            VARCHAR(255),
    id_1                  VARCHAR(255),
    mod_1                 VARCHAR(255),
    amount_1              VARCHAR(255),
    id_2                  VARCHAR(255),
    mod_2                 VARCHAR(255),
    amount_2              varchar(255),
    id_3                  VARCHAR(255),
    mod_3                 VARCHAR(255),
    amount_3              VARCHAR(255),
    termination          VARCHAR(255),
    status               VARCHAR2(100),
    created_date         DATE DEFAULT SYSDATE,
    recent_update_date   DATE DEFAULT SYSDATE,
    created_id           NUMBER(10),
    additional_info1     VARCHAR(100),
    additional_info2     VARCHAR(100),
    additional_info3     VARCHAR(100),
    additional_info4     VARCHAR(100),
    additional_info5     VARCHAR(100)
);


CREATE TABLE balances_log (
    client_id            NUMBER,
    last_run_by          VARCHAR2(200),
    status               VARCHAR2(100),
    created_date         DATE DEFAULT SYSDATE,
    recent_update_date   DATE DEFAULT SYSDATE,
    created_id           NUMBER(10),
    additional_info1     VARCHAR(100),
    additional_info2     VARCHAR(100),
    additional_info3     VARCHAR(100),
    additional_info4     VARCHAR(100),
    additional_info5     VARCHAR(100)
);


CREATE TABLE INPUT_CODES (
    id                   VARCHAR2(50),
    mod                  VARCHAR2(50),
    client_id            NUMBER,
    created_date         DATE DEFAULT SYSDATE,
    recent_update_date   DATE DEFAULT SYSDATE,
    created_id           NUMBER(10),
    additional_info1     VARCHAR(100),
    additional_info2     VARCHAR(100),
    additional_info3     VARCHAR(100),
    additional_info4     VARCHAR(100),
    additional_info5     VARCHAR(100)
);

CREATE TABLE MJ_ASP_DECON (
    ROW_NBR          NUMBER,
    MJ_RCD_NBR       NUMBER,
    BLOCK_NBR        NUMBER,
    RCD_NBR          NUMBER,
    PAYGROUP         VARCHAR2(255),
    FILE_NBR         VARCHAR2(255),
    QUARTER          VARCHAR2(255),
    CHECK_DT         VARCHAR2(255),
    WORK_STATE       VARCHAR2(255),
    LIVED_ST         VARCHAR2(255),
    SUI              VARCHAR2(255),
    LOCAL1           VARCHAR2(255),
    LOCAL2           VARCHAR2(255),
    OH_SDIT          VARCHAR2(255),
    LOCAL4           VARCHAR2(255),
    LOCAL5           VARCHAR2(255),
    ID               VARCHAR2(255),
    MOD              VARCHAR2(255),
    AMOUNT           NUMBER,
    CLIENT_ID        VARCHAR2(255)
);

CREATE TABLE balances_report_count (
    client_id            VARCHAR(255),
    earnings_gross		 NUMBER,
	pre_audit			 NUMBER,
	asp_paygroup		 NUMBER,
	asp_emp     		 NUMBER,
	asp_jurisdiction     NUMBER,
	recalc				 NUMBER,
    created_date         DATE DEFAULT SYSDATE,
    recent_update_date   DATE DEFAULT SYSDATE,
    created_id           NUMBER(10),
    additional_info1     VARCHAR(100),
    additional_info2     VARCHAR(100),
    additional_info3     VARCHAR(100),
    additional_info4     VARCHAR(100),
    additional_info5     VARCHAR(100)
);


CREATE OR REPLACE VIEW MJ_ASP_DECON as
WITH KEY_FIELDS
     AS (SELECT TO_NUMBER (SRC_ASP.MJ_RCD_NBR) MJ_RCD_NBR,
                SRC_ASP.PAYGROUP               PAYGROUP,
                SRC_ASP.FILE_NBR               FILE_NBR,
                SRC_ASP.ID_1                    ID,
                SRC_ASP.MOD_1                   MOD,
                SRC_ASP.AMOUNT_1                AMOUNT
           FROM BALANCES_LOAD SRC_ASP
          WHERE SRC_ASP.ID_1 = '45' OR SRC_ASP.ID_1 = 'LT'
         UNION
         SELECT TO_NUMBER (SRC_ASP.MJ_RCD_NBR) MJ_RCD_NBR,
                SRC_ASP.PAYGROUP               PAYGROUP,
                SRC_ASP.FILE_NBR               FILE_NBR,
                SRC_ASP.ID_2                    ID,
                SRC_ASP.MOD_2                   MOD,
                SRC_ASP.AMOUNT_2                AMOUNT
           FROM BALANCES_LOAD SRC_ASP
          WHERE SRC_ASP.ID_2 = '45' OR SRC_ASP.ID_2 = 'LT'
         UNION
         SELECT TO_NUMBER (SRC_ASP.MJ_RCD_NBR) MJ_RCD_NBR,
                SRC_ASP.PAYGROUP               PAYGROUP,
                SRC_ASP.FILE_NBR               FILE_NBR,
                SRC_ASP.ID_3                    ID,
                SRC_ASP.MOD_3                   MOD,
                SRC_ASP.AMOUNT_3                AMOUNT
           FROM BALANCES_LOAD SRC_ASP
          WHERE SRC_ASP.ID_3 = '45' OR SRC_ASP.ID_3 = 'LT')
SELECT TO_NUMBER (PROC_DATA.ROW_NBR)    AS ROW_NBR,
       TO_NUMBER (PROC_DATA.MJ_RCD_NBR) MJ_RCD_NBR,
       TO_NUMBER (PROC_DATA.BLOCK_NBR)  BLOCK_NBR,
       TO_NUMBER (PROC_DATA.RCD_NBR)    RCD_NBR,
       PROC_DATA.PAYGROUP               PAYGROUP,
       PROC_DATA.FILE_NBR               FILE_NBR,
       QTR.AMOUNT                        AS QUARTER,
       EFFDT.AMOUNT                      AS CHECK_DT,
       WS.AMOUNT                         AS WORK_STATE,
       LS.AMOUNT                         AS LIVED_ST,
       SUI.AMOUNT                        AS SUI,
       L1.AMOUNT                         AS LOCAL1,
       L2.AMOUNT                         AS LOCAL2,
       SDIT.AMOUNT                       AS OH_SDIT,
       L4.AMOUNT                         AS LOCAL4,
       L5.AMOUNT                         AS LOCAL5,
       PROC_DATA.ID_1                    ID,
       PROC_DATA.MOD_1                   MOD,
	   PROC_DATA.CLIENT_ID              CLIENT_ID,
       CASE
          WHEN SUBSTR (TRIM (PROC_DATA.AMOUNT_1), -1) = 'Ð'
          THEN
             (  TO_NUMBER (
                      SUBSTR (TRIM (PROC_DATA.AMOUNT_1),
                              1,
                              LENGTH (TRIM (PROC_DATA.AMOUNT_1)) - 1)
                   || '0')
              / -100)
          WHEN SUBSTR (TRIM (PROC_DATA.AMOUNT_1), -1) = '}'
          THEN
             (  TO_NUMBER (
                      SUBSTR (TRIM (PROC_DATA.AMOUNT_1),
                              1,
                              LENGTH (TRIM (PROC_DATA.AMOUNT_1)) - 1)
                   || '0')
              / -100)
          WHEN     SUBSTR (TRIM (PROC_DATA.AMOUNT_1), -1) = 'J'
               AND TRIM (PROC_DATA.AMOUNT_1) = 'J'
          THEN
             -.01
          WHEN     SUBSTR (TRIM (PROC_DATA.AMOUNT_1), -1) = 'K'
               AND TRIM (PROC_DATA.AMOUNT_1) = 'K'
          THEN
             -.02
          WHEN     SUBSTR (TRIM (PROC_DATA.AMOUNT_1), -1) = 'L'
               AND TRIM (PROC_DATA.AMOUNT_1) = 'L'
          THEN
             -.03
          WHEN     SUBSTR (TRIM (PROC_DATA.AMOUNT_1), -1) = 'M'
               AND TRIM (PROC_DATA.AMOUNT_1) = 'M'
          THEN
             -.04
          WHEN     SUBSTR (TRIM (PROC_DATA.AMOUNT_1), -1) = 'N'
               AND TRIM (PROC_DATA.AMOUNT_1) = 'N'
          THEN
             -.05
          WHEN     SUBSTR (TRIM (PROC_DATA.AMOUNT_1), -1) = 'O'
               AND TRIM (PROC_DATA.AMOUNT_1) = 'O'
          THEN
             -.06
          WHEN     SUBSTR (TRIM (PROC_DATA.AMOUNT_1), -1) = 'P'
               AND TRIM (PROC_DATA.AMOUNT_1) = 'P'
          THEN
             -.07
          WHEN     SUBSTR (TRIM (PROC_DATA.AMOUNT_1), -1) = 'Q'
               AND TRIM (PROC_DATA.AMOUNT_1) = 'Q'
          THEN
             -.08
          WHEN     SUBSTR (TRIM (PROC_DATA.AMOUNT_1), -1) = 'R'
               AND TRIM (PROC_DATA.AMOUNT_1) = 'R'
          THEN
             -.09
          WHEN SUBSTR (TRIM (PROC_DATA.AMOUNT_1), -1) = 'J'
          THEN
             (  TO_NUMBER (
                      SUBSTR (TRIM (PROC_DATA.AMOUNT_1),
                              1,
                              LENGTH (TRIM (PROC_DATA.AMOUNT_1)) - 1)
                   || '1')
              / -100)
          WHEN SUBSTR (TRIM (PROC_DATA.AMOUNT_1), -1) = 'K'
          THEN
             (  TO_NUMBER (
                      SUBSTR (TRIM (PROC_DATA.AMOUNT_1),
                              1,
                              LENGTH (TRIM (PROC_DATA.AMOUNT_1)) - 1)
                   || '2')
              / -100)
          WHEN SUBSTR (TRIM (PROC_DATA.AMOUNT_1), -1) = 'L'
          THEN
             (  TO_NUMBER (
                      SUBSTR (TRIM (PROC_DATA.AMOUNT_1),
                              1,
                              LENGTH (TRIM (PROC_DATA.AMOUNT_1)) - 1)
                   || '3')
              / -100)
          WHEN SUBSTR (TRIM (PROC_DATA.AMOUNT_1), -1) = 'M'
          THEN
             (  TO_NUMBER (
                      SUBSTR (TRIM (PROC_DATA.AMOUNT_1),
                              1,
                              LENGTH (TRIM (PROC_DATA.AMOUNT_1)) - 1)
                   || '4')
              / -100)
          WHEN SUBSTR (TRIM (PROC_DATA.AMOUNT_1), -1) = 'N'
          THEN
             (  TO_NUMBER (
                      SUBSTR (TRIM (PROC_DATA.AMOUNT_1),
                              1,
                              LENGTH (TRIM (PROC_DATA.AMOUNT_1)) - 1)
                   || '5')
              / -100)
          WHEN SUBSTR (TRIM (PROC_DATA.AMOUNT_1), -1) = 'O'
          THEN
             (  TO_NUMBER (
                      SUBSTR (TRIM (PROC_DATA.AMOUNT_1),
                              1,
                              LENGTH (TRIM (PROC_DATA.AMOUNT_1)) - 1)
                   || '6')
              / -100)
          WHEN SUBSTR (TRIM (PROC_DATA.AMOUNT_1), -1) = 'P'
          THEN
             (  TO_NUMBER (
                      SUBSTR (TRIM (PROC_DATA.AMOUNT_1),
                              1,
                              LENGTH (TRIM (PROC_DATA.AMOUNT_1)) - 1)
                   || '7')
              / -100)
          WHEN SUBSTR (TRIM (PROC_DATA.AMOUNT_1), -1) = 'Q'
          THEN
             (  TO_NUMBER (
                      SUBSTR (TRIM (PROC_DATA.AMOUNT_1),
                              1,
                              LENGTH (TRIM (PROC_DATA.AMOUNT_1)) - 1)
                   || '8')
              / -100)
          WHEN SUBSTR (TRIM (PROC_DATA.AMOUNT_1), -1) = 'R'
          THEN
             (  TO_NUMBER (
                      SUBSTR (TRIM (PROC_DATA.AMOUNT_1),
                              1,
                              LENGTH (TRIM (PROC_DATA.AMOUNT_1)) - 1)
                   || '9')
              / -100)
          ELSE
             (TO_NUMBER (PROC_DATA.AMOUNT_1) / 100)
       END
          AS AMOUNT
  FROM BALANCES_LOAD PROC_DATA
       LEFT OUTER JOIN KEY_FIELDS QTR
          ON     QTR.MJ_RCD_NBR = PROC_DATA.MJ_RCD_NBR
             AND QTR.PAYGROUP = PROC_DATA.PAYGROUP
             AND QTR.FILE_NBR = PROC_DATA.FILE_NBR
             AND QTR.MOD = 'Q'
       LEFT OUTER JOIN KEY_FIELDS EFFDT
          ON     EFFDT.MJ_RCD_NBR = PROC_DATA.MJ_RCD_NBR
             AND EFFDT.PAYGROUP = PROC_DATA.PAYGROUP
             AND EFFDT.FILE_NBR = PROC_DATA.FILE_NBR
             AND EFFDT.MOD = 'D'
       LEFT OUTER JOIN KEY_FIELDS WS
          ON     WS.MJ_RCD_NBR = PROC_DATA.MJ_RCD_NBR
             AND WS.PAYGROUP = PROC_DATA.PAYGROUP
             AND WS.FILE_NBR = PROC_DATA.FILE_NBR
             AND WS.MOD = '2'
       LEFT OUTER JOIN KEY_FIELDS LS
          ON     LS.MJ_RCD_NBR = PROC_DATA.MJ_RCD_NBR
             AND LS.PAYGROUP = PROC_DATA.PAYGROUP
             AND LS.FILE_NBR = PROC_DATA.FILE_NBR
             AND LS.MOD = '6'
       LEFT OUTER JOIN KEY_FIELDS SUI
          ON     SUI.MJ_RCD_NBR = PROC_DATA.MJ_RCD_NBR
             AND SUI.PAYGROUP = PROC_DATA.PAYGROUP
             AND SUI.FILE_NBR = PROC_DATA.FILE_NBR
             AND SUI.MOD = '8'
       LEFT OUTER JOIN KEY_FIELDS L1
          ON     L1.MJ_RCD_NBR = PROC_DATA.MJ_RCD_NBR
             AND L1.PAYGROUP = PROC_DATA.PAYGROUP
             AND L1.FILE_NBR = PROC_DATA.FILE_NBR
             AND L1.MOD = '3'
       LEFT OUTER JOIN KEY_FIELDS L2
          ON     L2.MJ_RCD_NBR = PROC_DATA.MJ_RCD_NBR
             AND L2.PAYGROUP = PROC_DATA.PAYGROUP
             AND L2.FILE_NBR = PROC_DATA.FILE_NBR
             AND L2.MOD = '7'
       LEFT OUTER JOIN KEY_FIELDS SDIT
          ON     SDIT.MJ_RCD_NBR = PROC_DATA.MJ_RCD_NBR
             AND SDIT.PAYGROUP = PROC_DATA.PAYGROUP
             AND SDIT.FILE_NBR = PROC_DATA.FILE_NBR
             AND SDIT.MOD = 'A'
       LEFT OUTER JOIN KEY_FIELDS L4
          ON     L4.MJ_RCD_NBR = PROC_DATA.MJ_RCD_NBR
             AND L4.PAYGROUP = PROC_DATA.PAYGROUP
             AND L4.FILE_NBR = PROC_DATA.FILE_NBR
             AND L4.MOD = '4'
       LEFT OUTER JOIN KEY_FIELDS L5
          ON     L5.MJ_RCD_NBR = PROC_DATA.MJ_RCD_NBR
             AND L5.PAYGROUP = PROC_DATA.PAYGROUP
             AND L5.FILE_NBR = PROC_DATA.FILE_NBR
             AND L5.MOD = '5'
 WHERE PROC_DATA.ID_1 NOT IN ('45', 'LT')
UNION ALL
SELECT TO_NUMBER (PROC_DATA.ROW_NBR)    AS ROW_NBR,
       TO_NUMBER (PROC_DATA.MJ_RCD_NBR) MJ_RCD_NBR,
       TO_NUMBER (PROC_DATA.BLOCK_NBR)  BLOCK_NBR,
       TO_NUMBER (PROC_DATA.RCD_NBR)    RCD_NBR,
       PROC_DATA.PAYGROUP               PAYGROUP,
       PROC_DATA.FILE_NBR               FILE_NBR,
       QTR.AMOUNT                        AS QUARTER,
       EFFDT.AMOUNT                      AS CHECK_DT,
       WS.AMOUNT                         AS WORK_STATE,
       LS.AMOUNT                         AS LIVED_ST,
       SUI.AMOUNT                        AS SUI,
       L1.AMOUNT                         AS LOCAL1,
       L2.AMOUNT                         AS LOCAL2,
       SDIT.AMOUNT                       AS OH_SDIT,
       L4.AMOUNT                         AS LOCAL4,
       L5.AMOUNT                         AS LOCAL5,
       PROC_DATA.ID_2                    ID,
       PROC_DATA.MOD_2                   MOD,
	   PROC_DATA.CLIENT_ID              CLIENT_ID,
       CASE
          WHEN SUBSTR (TRIM (PROC_DATA.AMOUNT_2), -1) = 'Ð'
          THEN
             (  TO_NUMBER (
                      SUBSTR (TRIM (PROC_DATA.AMOUNT_1),
                              1,
                              LENGTH (TRIM (PROC_DATA.AMOUNT_1)) - 1)
                   || '0')
              / -100)
          WHEN SUBSTR (TRIM (PROC_DATA.AMOUNT_2), -1) = '}'
          THEN
             (  TO_NUMBER (
                      SUBSTR (TRIM (PROC_DATA.AMOUNT_2),
                              1,
                              LENGTH (TRIM (PROC_DATA.AMOUNT_2)) - 1)
                   || '0')
              / -100)
          WHEN     SUBSTR (TRIM (PROC_DATA.AMOUNT_2), -1) = 'J'
               AND TRIM (PROC_DATA.AMOUNT_2) = 'J'
          THEN
             -.01
          WHEN     SUBSTR (TRIM (PROC_DATA.AMOUNT_2), -1) = 'K'
               AND TRIM (PROC_DATA.AMOUNT_2) = 'K'
          THEN
             -.02
          WHEN     SUBSTR (TRIM (PROC_DATA.AMOUNT_2), -1) = 'L'
               AND TRIM (PROC_DATA.AMOUNT_2) = 'L'
          THEN
             -.03
          WHEN     SUBSTR (TRIM (PROC_DATA.AMOUNT_2), -1) = 'M'
               AND TRIM (PROC_DATA.AMOUNT_2) = 'M'
          THEN
             -.04
          WHEN     SUBSTR (TRIM (PROC_DATA.AMOUNT_2), -1) = 'N'
               AND TRIM (PROC_DATA.AMOUNT_2) = 'N'
          THEN
             -.05
          WHEN     SUBSTR (TRIM (PROC_DATA.AMOUNT_2), -1) = 'O'
               AND TRIM (PROC_DATA.AMOUNT_2) = 'O'
          THEN
             -.06
          WHEN     SUBSTR (TRIM (PROC_DATA.AMOUNT_2), -1) = 'P'
               AND TRIM (PROC_DATA.AMOUNT_2) = 'P'
          THEN
             -.07
          WHEN     SUBSTR (TRIM (PROC_DATA.AMOUNT_2), -1) = 'Q'
               AND TRIM (PROC_DATA.AMOUNT_2) = 'Q'
          THEN
             -.08
          WHEN     SUBSTR (TRIM (PROC_DATA.AMOUNT_2), -1) = 'R'
               AND TRIM (PROC_DATA.AMOUNT_2) = 'R'
          THEN
             -.09
          WHEN SUBSTR (TRIM (PROC_DATA.AMOUNT_2), -1) = 'J'
          THEN
             (  TO_NUMBER (
                      SUBSTR (TRIM (PROC_DATA.AMOUNT_2),
                              1,
                              LENGTH (TRIM (PROC_DATA.AMOUNT_2)) - 1)
                   || '1')
              / -100)
          WHEN SUBSTR (TRIM (PROC_DATA.AMOUNT_2), -1) = 'K'
          THEN
             (  TO_NUMBER (
                      SUBSTR (TRIM (PROC_DATA.AMOUNT_2),
                              1,
                              LENGTH (TRIM (PROC_DATA.AMOUNT_2)) - 1)
                   || '2')
              / -100)
          WHEN SUBSTR (TRIM (PROC_DATA.AMOUNT_2), -1) = 'L'
          THEN
             (  TO_NUMBER (
                      SUBSTR (TRIM (PROC_DATA.AMOUNT_2),
                              1,
                              LENGTH (TRIM (PROC_DATA.AMOUNT_2)) - 1)
                   || '3')
              / -100)
          WHEN SUBSTR (TRIM (PROC_DATA.AMOUNT_2), -1) = 'M'
          THEN
             (  TO_NUMBER (
                      SUBSTR (TRIM (PROC_DATA.AMOUNT_2),
                              1,
                              LENGTH (TRIM (PROC_DATA.AMOUNT_2)) - 1)
                   || '4')
              / -100)
          WHEN SUBSTR (TRIM (PROC_DATA.AMOUNT_2), -1) = 'N'
          THEN
             (  TO_NUMBER (
                      SUBSTR (TRIM (PROC_DATA.AMOUNT_2),
                              1,
                              LENGTH (TRIM (PROC_DATA.AMOUNT_2)) - 1)
                   || '5')
              / -100)
          WHEN SUBSTR (TRIM (PROC_DATA.AMOUNT_2), -1) = 'O'
          THEN
             (  TO_NUMBER (
                      SUBSTR (TRIM (PROC_DATA.AMOUNT_2),
                              1,
                              LENGTH (TRIM (PROC_DATA.AMOUNT_2)) - 1)
                   || '6')
              / -100)
          WHEN SUBSTR (TRIM (PROC_DATA.AMOUNT_2), -1) = 'P'
          THEN
             (  TO_NUMBER (
                      SUBSTR (TRIM (PROC_DATA.AMOUNT_2),
                              1,
                              LENGTH (TRIM (PROC_DATA.AMOUNT_2)) - 1)
                   || '7')
              / -100)
          WHEN SUBSTR (TRIM (PROC_DATA.AMOUNT_2), -1) = 'Q'
          THEN
             (  TO_NUMBER (
                      SUBSTR (TRIM (PROC_DATA.AMOUNT_2),
                              1,
                              LENGTH (TRIM (PROC_DATA.AMOUNT_2)) - 1)
                   || '8')
              / -100)
          WHEN SUBSTR (TRIM (PROC_DATA.AMOUNT_2), -1) = 'R'
          THEN
             (  TO_NUMBER (
                      SUBSTR (TRIM (PROC_DATA.AMOUNT_2),
                              1,
                              LENGTH (TRIM (PROC_DATA.AMOUNT_2)) - 1)
                   || '9')
              / -100)
          ELSE
             (TO_NUMBER (PROC_DATA.AMOUNT_2) / 100)
       END
          AS AMOUNT
  FROM BALANCES_LOAD PROC_DATA
       LEFT OUTER JOIN KEY_FIELDS QTR
          ON     QTR.MJ_RCD_NBR = PROC_DATA.MJ_RCD_NBR
             AND QTR.PAYGROUP = PROC_DATA.PAYGROUP
             AND QTR.FILE_NBR = PROC_DATA.FILE_NBR
             AND QTR.MOD = 'Q'
       LEFT OUTER JOIN KEY_FIELDS EFFDT
          ON     EFFDT.MJ_RCD_NBR = PROC_DATA.MJ_RCD_NBR
             AND EFFDT.PAYGROUP = PROC_DATA.PAYGROUP
             AND EFFDT.FILE_NBR = PROC_DATA.FILE_NBR
             AND EFFDT.MOD = 'D'
       LEFT OUTER JOIN KEY_FIELDS WS
          ON     WS.MJ_RCD_NBR = PROC_DATA.MJ_RCD_NBR
             AND WS.PAYGROUP = PROC_DATA.PAYGROUP
             AND WS.FILE_NBR = PROC_DATA.FILE_NBR
             AND WS.MOD = '2'
       LEFT OUTER JOIN KEY_FIELDS LS
          ON     LS.MJ_RCD_NBR = PROC_DATA.MJ_RCD_NBR
             AND LS.PAYGROUP = PROC_DATA.PAYGROUP
             AND LS.FILE_NBR = PROC_DATA.FILE_NBR
             AND LS.MOD = '6'
       LEFT OUTER JOIN KEY_FIELDS SUI
          ON     SUI.MJ_RCD_NBR = PROC_DATA.MJ_RCD_NBR
             AND SUI.PAYGROUP = PROC_DATA.PAYGROUP
             AND SUI.FILE_NBR = PROC_DATA.FILE_NBR
             AND SUI.MOD = '8'
       LEFT OUTER JOIN KEY_FIELDS L1
          ON     L1.MJ_RCD_NBR = PROC_DATA.MJ_RCD_NBR
             AND L1.PAYGROUP = PROC_DATA.PAYGROUP
             AND L1.FILE_NBR = PROC_DATA.FILE_NBR
             AND L1.MOD = '3'
       LEFT OUTER JOIN KEY_FIELDS L2
          ON     L2.MJ_RCD_NBR = PROC_DATA.MJ_RCD_NBR
             AND L2.PAYGROUP = PROC_DATA.PAYGROUP
             AND L2.FILE_NBR = PROC_DATA.FILE_NBR
             AND L2.MOD = '7'
       LEFT OUTER JOIN KEY_FIELDS SDIT
          ON     SDIT.MJ_RCD_NBR = PROC_DATA.MJ_RCD_NBR
             AND SDIT.PAYGROUP = PROC_DATA.PAYGROUP
             AND SDIT.FILE_NBR = PROC_DATA.FILE_NBR
             AND SDIT.MOD = 'A'
       LEFT OUTER JOIN KEY_FIELDS L4
          ON     L4.MJ_RCD_NBR = PROC_DATA.MJ_RCD_NBR
             AND L4.PAYGROUP = PROC_DATA.PAYGROUP
             AND L4.FILE_NBR = PROC_DATA.FILE_NBR
             AND L4.MOD = '4'
       LEFT OUTER JOIN KEY_FIELDS L5
          ON     L5.MJ_RCD_NBR = PROC_DATA.MJ_RCD_NBR
             AND L5.PAYGROUP = PROC_DATA.PAYGROUP
             AND L5.FILE_NBR = PROC_DATA.FILE_NBR
             AND L5.MOD = '5'
 WHERE PROC_DATA.ID_2 NOT IN ('45', 'LT')
UNION ALL
SELECT TO_NUMBER (PROC_DATA.ROW_NBR)    AS ROW_NBR,
       TO_NUMBER (PROC_DATA.MJ_RCD_NBR) MJ_RCD_NBR,
       TO_NUMBER (PROC_DATA.BLOCK_NBR)  BLOCK_NBR,
       TO_NUMBER (PROC_DATA.RCD_NBR)    RCD_NBR,
       PROC_DATA.PAYGROUP               PAYGROUP,
       PROC_DATA.FILE_NBR               FILE_NBR,
       QTR.AMOUNT                        AS QUARTER,
       EFFDT.AMOUNT                      AS CHECK_DT,
       WS.AMOUNT                         AS WORK_STATE,
       LS.AMOUNT                         AS LIVED_ST,
       SUI.AMOUNT                        AS SUI,
       L1.AMOUNT                         AS LOCAL1,
       L2.AMOUNT                         AS LOCAL2,
       SDIT.AMOUNT                       AS OH_SDIT,
       L4.AMOUNT                         AS LOCAL4,
       L5.AMOUNT                         AS LOCAL5,
       PROC_DATA.ID_3                    ID,
       PROC_DATA.MOD_3                   MOD,
	   PROC_DATA.CLIENT_ID              CLIENT_ID,
       CASE
          WHEN SUBSTR (TRIM (PROC_DATA.AMOUNT_3), -1) = 'Ð'
          THEN
             (  TO_NUMBER (
                      SUBSTR (TRIM (PROC_DATA.AMOUNT_1),
                              1,
                              LENGTH (TRIM (PROC_DATA.AMOUNT_1)) - 1)
                   || '0')
              / -100)
          WHEN SUBSTR (TRIM (PROC_DATA.AMOUNT_3), -1) = '}'
          THEN
             (  TO_NUMBER (
                      SUBSTR (TRIM (PROC_DATA.AMOUNT_3),
                              1,
                              LENGTH (TRIM (PROC_DATA.AMOUNT_3)) - 1)
                   || '0')
              / -100)
          WHEN     SUBSTR (TRIM (PROC_DATA.AMOUNT_3), -1) = 'J'
               AND TRIM (PROC_DATA.AMOUNT_3) = 'J'
          THEN
             -.01
          WHEN     SUBSTR (TRIM (PROC_DATA.AMOUNT_3), -1) = 'K'
               AND TRIM (PROC_DATA.AMOUNT_3) = 'K'
          THEN
             -.02
          WHEN     SUBSTR (TRIM (PROC_DATA.AMOUNT_3), -1) = 'L'
               AND TRIM (PROC_DATA.AMOUNT_3) = 'L'
          THEN
             -.03
          WHEN     SUBSTR (TRIM (PROC_DATA.AMOUNT_3), -1) = 'M'
               AND TRIM (PROC_DATA.AMOUNT_3) = 'M'
          THEN
             -.04
          WHEN     SUBSTR (TRIM (PROC_DATA.AMOUNT_3), -1) = 'N'
               AND TRIM (PROC_DATA.AMOUNT_3) = 'N'
          THEN
             -.05
          WHEN     SUBSTR (TRIM (PROC_DATA.AMOUNT_3), -1) = 'O'
               AND TRIM (PROC_DATA.AMOUNT_3) = 'O'
          THEN
             -.06
          WHEN     SUBSTR (TRIM (PROC_DATA.AMOUNT_3), -1) = 'P'
               AND TRIM (PROC_DATA.AMOUNT_3) = 'P'
          THEN
             -.07
          WHEN     SUBSTR (TRIM (PROC_DATA.AMOUNT_3), -1) = 'Q'
               AND TRIM (PROC_DATA.AMOUNT_3) = 'Q'
          THEN
             -.08
          WHEN     SUBSTR (TRIM (PROC_DATA.AMOUNT_3), -1) = 'R'
               AND TRIM (PROC_DATA.AMOUNT_3) = 'R'
          THEN
             -.09
          WHEN SUBSTR (TRIM (PROC_DATA.AMOUNT_3), -1) = 'J'
          THEN
             (  TO_NUMBER (
                      SUBSTR (TRIM (PROC_DATA.AMOUNT_3),
                              1,
                              LENGTH (TRIM (PROC_DATA.AMOUNT_3)) - 1)
                   || '1')
              / -100)
          WHEN SUBSTR (TRIM (PROC_DATA.AMOUNT_3), -1) = 'K'
          THEN
             (  TO_NUMBER (
                      SUBSTR (TRIM (PROC_DATA.AMOUNT_3),
                              1,
                              LENGTH (TRIM (PROC_DATA.AMOUNT_3)) - 1)
                   || '2')
              / -100)
          WHEN SUBSTR (TRIM (PROC_DATA.AMOUNT_3), -1) = 'L'
          THEN
             (  TO_NUMBER (
                      SUBSTR (TRIM (PROC_DATA.AMOUNT_3),
                              1,
                              LENGTH (TRIM (PROC_DATA.AMOUNT_3)) - 1)
                   || '3')
              / -100)
          WHEN SUBSTR (TRIM (PROC_DATA.AMOUNT_3), -1) = 'M'
          THEN
             (  TO_NUMBER (
                      SUBSTR (TRIM (PROC_DATA.AMOUNT_3),
                              1,
                              LENGTH (TRIM (PROC_DATA.AMOUNT_3)) - 1)
                   || '4')
              / -100)
          WHEN SUBSTR (TRIM (PROC_DATA.AMOUNT_3), -1) = 'N'
          THEN
             (  TO_NUMBER (
                      SUBSTR (TRIM (PROC_DATA.AMOUNT_3),
                              1,
                              LENGTH (TRIM (PROC_DATA.AMOUNT_3)) - 1)
                   || '5')
              / -100)
          WHEN SUBSTR (TRIM (PROC_DATA.AMOUNT_3), -1) = 'O'
          THEN
             (  TO_NUMBER (
                      SUBSTR (TRIM (PROC_DATA.AMOUNT_3),
                              1,
                              LENGTH (TRIM (PROC_DATA.AMOUNT_3)) - 1)
                   || '6')
              / -100)
          WHEN SUBSTR (TRIM (PROC_DATA.AMOUNT_3), -1) = 'P'
          THEN
             (  TO_NUMBER (
                      SUBSTR (TRIM (PROC_DATA.AMOUNT_3),
                              1,
                              LENGTH (TRIM (PROC_DATA.AMOUNT_3)) - 1)
                   || '7')
              / -100)
          WHEN SUBSTR (TRIM (PROC_DATA.AMOUNT_3), -1) = 'Q'
          THEN
             (  TO_NUMBER (
                      SUBSTR (TRIM (PROC_DATA.AMOUNT_3),
                              1,
                              LENGTH (TRIM (PROC_DATA.AMOUNT_3)) - 1)
                   || '8')
              / -100)
          WHEN SUBSTR (TRIM (PROC_DATA.AMOUNT_3), -1) = 'R'
          THEN
             (  TO_NUMBER (
                      SUBSTR (TRIM (PROC_DATA.AMOUNT_3),
                              1,
                              LENGTH (TRIM (PROC_DATA.AMOUNT_3)) - 1)
                   || '9')
              / -100)
          ELSE
             (TO_NUMBER (PROC_DATA.AMOUNT_3) / 100)
       END
          AS AMOUNT
  FROM BALANCES_LOAD PROC_DATA
       LEFT OUTER JOIN KEY_FIELDS QTR
          ON     QTR.MJ_RCD_NBR = PROC_DATA.MJ_RCD_NBR
             AND QTR.PAYGROUP = PROC_DATA.PAYGROUP
             AND QTR.FILE_NBR = PROC_DATA.FILE_NBR
             AND QTR.MOD = 'Q'
       LEFT OUTER JOIN KEY_FIELDS EFFDT
          ON     EFFDT.MJ_RCD_NBR = PROC_DATA.MJ_RCD_NBR
             AND EFFDT.PAYGROUP = PROC_DATA.PAYGROUP
             AND EFFDT.FILE_NBR = PROC_DATA.FILE_NBR
             AND EFFDT.MOD = 'D'
       LEFT OUTER JOIN KEY_FIELDS WS
          ON     WS.MJ_RCD_NBR = PROC_DATA.MJ_RCD_NBR
             AND WS.PAYGROUP = PROC_DATA.PAYGROUP
             AND WS.FILE_NBR = PROC_DATA.FILE_NBR
             AND WS.MOD = '2'
       LEFT OUTER JOIN KEY_FIELDS LS
          ON     LS.MJ_RCD_NBR = PROC_DATA.MJ_RCD_NBR
             AND LS.PAYGROUP = PROC_DATA.PAYGROUP
             AND LS.FILE_NBR = PROC_DATA.FILE_NBR
             AND LS.MOD = '6'
       LEFT OUTER JOIN KEY_FIELDS SUI
          ON     SUI.MJ_RCD_NBR = PROC_DATA.MJ_RCD_NBR
             AND SUI.PAYGROUP = PROC_DATA.PAYGROUP
             AND SUI.FILE_NBR = PROC_DATA.FILE_NBR
             AND SUI.MOD = '8'
       LEFT OUTER JOIN KEY_FIELDS L1
          ON     L1.MJ_RCD_NBR = PROC_DATA.MJ_RCD_NBR
             AND L1.PAYGROUP = PROC_DATA.PAYGROUP
             AND L1.FILE_NBR = PROC_DATA.FILE_NBR
             AND L1.MOD = '3'
       LEFT OUTER JOIN KEY_FIELDS L2
          ON     L2.MJ_RCD_NBR = PROC_DATA.MJ_RCD_NBR
             AND L2.PAYGROUP = PROC_DATA.PAYGROUP
             AND L2.FILE_NBR = PROC_DATA.FILE_NBR
             AND L2.MOD = '7'
       LEFT OUTER JOIN KEY_FIELDS SDIT
          ON     SDIT.MJ_RCD_NBR = PROC_DATA.MJ_RCD_NBR
             AND SDIT.PAYGROUP = PROC_DATA.PAYGROUP
             AND SDIT.FILE_NBR = PROC_DATA.FILE_NBR
             AND SDIT.MOD = 'A'
       LEFT OUTER JOIN KEY_FIELDS L4
          ON     L4.MJ_RCD_NBR = PROC_DATA.MJ_RCD_NBR
             AND L4.PAYGROUP = PROC_DATA.PAYGROUP
             AND L4.FILE_NBR = PROC_DATA.FILE_NBR
             AND L4.MOD = '4'
       LEFT OUTER JOIN KEY_FIELDS L5
          ON     L5.MJ_RCD_NBR = PROC_DATA.MJ_RCD_NBR
             AND L5.PAYGROUP = PROC_DATA.PAYGROUP
             AND L5.FILE_NBR = PROC_DATA.FILE_NBR
             AND L5.MOD = '5'
 WHERE PROC_DATA.ID_3 NOT IN ('45', 'LT')
ORDER BY MJ_RCD_NBR, BLOCK_NBR, RCD_NBR



-----------------------------------------------------------


-----------------------------------------------------------



------------------------------------------------------------






CREATE OR REPLACE VIEW ASP_PRE_AUDIT_V20190625_VIEW AS
select
		'DEDUCTION WITH NO MOD' AS ISSUE,
		MJ_ASP_DECON.MJ_RCD_NBR MJ_RCD_NBR,
		MJ_ASP_DECON.BLOCK_NBR BLOCK_NBR,
		MJ_ASP_DECON.RCD_NBR RCD_NBR,
		MJ_ASP_DECON.PAYGROUP PAYGROUP,
		MJ_ASP_DECON.FILE_NBR FILE_NBR,
		MJ_ASP_DECON.QUARTER QUARTER,
		MJ_ASP_DECON.CHECK_DT CHECK_DT,
		MJ_ASP_DECON.WORK_STATE WORK_STATE,
		MJ_ASP_DECON.LIVED_ST LIVED_ST,
		MJ_ASP_DECON.SUI SUI,
		MJ_ASP_DECON.LOCAL1 LOCAL1,
		MJ_ASP_DECON.LOCAL2 LOCAL2,
		MJ_ASP_DECON.OH_SDIT OH_SDIT,
		MJ_ASP_DECON.LOCAL4 LOCAL4,
		MJ_ASP_DECON.LOCAL5 LOCAL5,
		MJ_ASP_DECON.ID ID,
		MJ_ASP_DECON.MOD MOD,
		MJ_ASP_DECON.CLIENT_ID  CLIENT_ID,
		MJ_ASP_DECON.AMOUNT AMOUNT
from MJ_ASP_DECON
WHERE MJ_ASP_DECON.ID = 'S'
AND TRIM(MJ_ASP_DECON.MOD) IS NULL
UNION
--ID CHECK ADDED 20190507
select
		'INVALID ID' AS ISSUE,
		MJ_ASP_DECON.MJ_RCD_NBR MJ_RCD_NBR,
		MJ_ASP_DECON.BLOCK_NBR BLOCK_NBR,
		MJ_ASP_DECON.RCD_NBR RCD_NBR,
		MJ_ASP_DECON.PAYGROUP PAYGROUP,
		MJ_ASP_DECON.FILE_NBR FILE_NBR,
		MJ_ASP_DECON.QUARTER QUARTER,
		MJ_ASP_DECON.CHECK_DT CHECK_DT,
		MJ_ASP_DECON.WORK_STATE WORK_STATE,
		MJ_ASP_DECON.LIVED_ST LIVED_ST,
		MJ_ASP_DECON.SUI SUI,
		MJ_ASP_DECON.LOCAL1 LOCAL1,
		MJ_ASP_DECON.LOCAL2 LOCAL2,
		MJ_ASP_DECON.OH_SDIT OH_SDIT,
		MJ_ASP_DECON.LOCAL4 LOCAL4,
		MJ_ASP_DECON.LOCAL5 LOCAL5,
		MJ_ASP_DECON.ID ID,
		MJ_ASP_DECON.MOD MOD,
		MJ_ASP_DECON.CLIENT_ID  CLIENT_ID,
		MJ_ASP_DECON.AMOUNT AMOUNT
from MJ_ASP_DECON
WHERE MJ_ASP_DECON.ID NOT IN ('01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15', '19', 'AC', 'LB', 'S', '60')
UNION
--MEM_ID_MOD_CHK AS (
select
		'MEMO WITH NO MOD' AS ISSUE,
		MJ_ASP_DECON.MJ_RCD_NBR MJ_RCD_NBR,
		MJ_ASP_DECON.BLOCK_NBR BLOCK_NBR,
		MJ_ASP_DECON.RCD_NBR RCD_NBR,
		MJ_ASP_DECON.PAYGROUP PAYGROUP,
		MJ_ASP_DECON.FILE_NBR FILE_NBR,
		MJ_ASP_DECON.QUARTER QUARTER,
		MJ_ASP_DECON.CHECK_DT CHECK_DT,
		MJ_ASP_DECON.WORK_STATE WORK_STATE,
		MJ_ASP_DECON.LIVED_ST LIVED_ST,
		MJ_ASP_DECON.SUI SUI,
		MJ_ASP_DECON.LOCAL1 LOCAL1,
		MJ_ASP_DECON.LOCAL2 LOCAL2,
		MJ_ASP_DECON.OH_SDIT OH_SDIT,
		MJ_ASP_DECON.LOCAL4 LOCAL4,
		MJ_ASP_DECON.LOCAL5 LOCAL5,
		MJ_ASP_DECON.ID ID,
		MJ_ASP_DECON.MOD MOD,
		MJ_ASP_DECON.CLIENT_ID  CLIENT_ID,
		MJ_ASP_DECON.AMOUNT AMOUNT
from MJ_ASP_DECON
WHERE MJ_ASP_DECON.ID = '19'
AND TRIM(MJ_ASP_DECON.MOD) IS NULL
UNION
--EARN_ID_MOD_CHK AS (
select
		'HOURS/EARNINGS WITH NO MOD' AS ISSUE,
		MJ_ASP_DECON.MJ_RCD_NBR MJ_RCD_NBR,
		MJ_ASP_DECON.BLOCK_NBR BLOCK_NBR,
		MJ_ASP_DECON.RCD_NBR RCD_NBR,
		MJ_ASP_DECON.PAYGROUP PAYGROUP,
		MJ_ASP_DECON.FILE_NBR FILE_NBR,
		MJ_ASP_DECON.QUARTER QUARTER,
		MJ_ASP_DECON.CHECK_DT CHECK_DT,
		MJ_ASP_DECON.WORK_STATE WORK_STATE,
		MJ_ASP_DECON.LIVED_ST LIVED_ST,
		MJ_ASP_DECON.SUI SUI,
		MJ_ASP_DECON.LOCAL1 LOCAL1,
		MJ_ASP_DECON.LOCAL2 LOCAL2,
		MJ_ASP_DECON.OH_SDIT OH_SDIT,
		MJ_ASP_DECON.LOCAL4 LOCAL4,
		MJ_ASP_DECON.LOCAL5 LOCAL5,
		MJ_ASP_DECON.ID ID,
		MJ_ASP_DECON.MOD MOD,
		MJ_ASP_DECON.CLIENT_ID  CLIENT_ID,
		MJ_ASP_DECON.AMOUNT AMOUNT
from MJ_ASP_DECON
WHERE MJ_ASP_DECON.ID IN ('03', '04', '07', '08')
AND TRIM(MJ_ASP_DECON.MOD) IS NULL
UNION
--TAX_TO_NONTAXING1 AS (
select
		'TAX TO NON_TAXING WORK STATE' AS ISSUE,
		MJ_ASP_DECON.MJ_RCD_NBR MJ_RCD_NBR,
		MJ_ASP_DECON.BLOCK_NBR BLOCK_NBR,
		MJ_ASP_DECON.RCD_NBR RCD_NBR,
		MJ_ASP_DECON.PAYGROUP PAYGROUP,
		MJ_ASP_DECON.FILE_NBR FILE_NBR,
		MJ_ASP_DECON.QUARTER QUARTER,
		MJ_ASP_DECON.CHECK_DT CHECK_DT,
		MJ_ASP_DECON.WORK_STATE WORK_STATE,
		MJ_ASP_DECON.LIVED_ST LIVED_ST,
		MJ_ASP_DECON.SUI SUI,
		MJ_ASP_DECON.LOCAL1 LOCAL1,
		MJ_ASP_DECON.LOCAL2 LOCAL2,
		MJ_ASP_DECON.OH_SDIT OH_SDIT,
		MJ_ASP_DECON.LOCAL4 LOCAL4,
		MJ_ASP_DECON.LOCAL5 LOCAL5,
		MJ_ASP_DECON.ID ID,
		MJ_ASP_DECON.MOD MOD,
		MJ_ASP_DECON.CLIENT_ID  CLIENT_ID,
		MJ_ASP_DECON.AMOUNT AMOUNT
from MJ_ASP_DECON
WHERE MJ_ASP_DECON.ID = '12'
AND TRIM(MJ_ASP_DECON.MOD) IS NULL
AND MJ_ASP_DECON.WORK_STATE IN ('10','42','69','16','48','58','51','52','53','06','54','55')
UNION
--TAX_TO_NONTAXING2 AS (
select
		'TAX TO NON_TAXING LIVED STATE' AS ISSUE,
		MJ_ASP_DECON.MJ_RCD_NBR MJ_RCD_NBR,
		MJ_ASP_DECON.BLOCK_NBR BLOCK_NBR,
		MJ_ASP_DECON.RCD_NBR RCD_NBR,
		MJ_ASP_DECON.PAYGROUP PAYGROUP,
		MJ_ASP_DECON.FILE_NBR FILE_NBR,
		MJ_ASP_DECON.QUARTER QUARTER,
		MJ_ASP_DECON.CHECK_DT CHECK_DT,
		MJ_ASP_DECON.WORK_STATE WORK_STATE,
		MJ_ASP_DECON.LIVED_ST LIVED_ST,
		MJ_ASP_DECON.SUI SUI,
		MJ_ASP_DECON.LOCAL1 LOCAL1,
		MJ_ASP_DECON.LOCAL2 LOCAL2,
		MJ_ASP_DECON.OH_SDIT OH_SDIT,
		MJ_ASP_DECON.LOCAL4 LOCAL4,
		MJ_ASP_DECON.LOCAL5 LOCAL5,
		MJ_ASP_DECON.ID ID,
		MJ_ASP_DECON.MOD MOD,
		MJ_ASP_DECON.CLIENT_ID  CLIENT_ID,
		MJ_ASP_DECON.AMOUNT AMOUNT
from MJ_ASP_DECON
WHERE MJ_ASP_DECON.ID = '12'
AND TRIM(MJ_ASP_DECON.MOD) ='2'
AND MJ_ASP_DECON.LIVED_ST IN ('10','42','69','16','48','58','51','52','53','06','54','55')
UNION
--NON_WHOLE_DOLLAR1 AS (
select
		'NON-WHOLE_DOLLAR WHERE RQUIRED WORKED STATE' AS ISSUE,
		MJ_ASP_DECON.MJ_RCD_NBR MJ_RCD_NBR,
		MJ_ASP_DECON.BLOCK_NBR BLOCK_NBR,
		MJ_ASP_DECON.RCD_NBR RCD_NBR,
		MJ_ASP_DECON.PAYGROUP PAYGROUP,
		MJ_ASP_DECON.FILE_NBR FILE_NBR,
		MJ_ASP_DECON.QUARTER QUARTER,
		MJ_ASP_DECON.CHECK_DT CHECK_DT,
		MJ_ASP_DECON.WORK_STATE WORK_STATE,
		MJ_ASP_DECON.LIVED_ST LIVED_ST,
		MJ_ASP_DECON.SUI SUI,
		MJ_ASP_DECON.LOCAL1 LOCAL1,
		MJ_ASP_DECON.LOCAL2 LOCAL2,
		MJ_ASP_DECON.OH_SDIT OH_SDIT,
		MJ_ASP_DECON.LOCAL4 LOCAL4,
		MJ_ASP_DECON.LOCAL5 LOCAL5,
		MJ_ASP_DECON.ID ID,
		MJ_ASP_DECON.MOD MOD,
		MJ_ASP_DECON.CLIENT_ID  CLIENT_ID,
		MJ_ASP_DECON.AMOUNT AMOUNT
from MJ_ASP_DECON
WHERE MJ_ASP_DECON.ID = '12'
AND TRIM(MJ_ASP_DECON.MOD) IS NULL
AND MJ_ASP_DECON.WORK_STATE IN (/*'15',*/ '12', '22', '36', '26', '40', '46', '41', '29')
AND MJ_ASP_DECON.AMOUNT <> ROUND(MJ_ASP_DECON.AMOUNT)
UNION
--NON_WHOLE_DOLLAR2
select
		'NON-WHOLE_DOLLAR WHERE RQUIRED LIVED STATE' AS ISSUE,
		MJ_ASP_DECON.MJ_RCD_NBR MJ_RCD_NBR,
		MJ_ASP_DECON.BLOCK_NBR BLOCK_NBR,
		MJ_ASP_DECON.RCD_NBR RCD_NBR,
		MJ_ASP_DECON.PAYGROUP PAYGROUP,
		MJ_ASP_DECON.FILE_NBR FILE_NBR,
		MJ_ASP_DECON.QUARTER QUARTER,
		MJ_ASP_DECON.CHECK_DT CHECK_DT,
		MJ_ASP_DECON.WORK_STATE WORK_STATE,
		MJ_ASP_DECON.LIVED_ST LIVED_ST,
		MJ_ASP_DECON.SUI SUI,
		MJ_ASP_DECON.LOCAL1 LOCAL1,
		MJ_ASP_DECON.LOCAL2 LOCAL2,
		MJ_ASP_DECON.OH_SDIT OH_SDIT,
		MJ_ASP_DECON.LOCAL4 LOCAL4,
		MJ_ASP_DECON.LOCAL5 LOCAL5,
		MJ_ASP_DECON.ID ID,
		MJ_ASP_DECON.MOD MOD,
		MJ_ASP_DECON.CLIENT_ID  CLIENT_ID,
		MJ_ASP_DECON.AMOUNT AMOUNT
from MJ_ASP_DECON
WHERE MJ_ASP_DECON.ID = '12'
AND TRIM(MJ_ASP_DECON.MOD) ='2'
AND MJ_ASP_DECON.LIVED_ST IN (/*'15',*/ '12', '22', '36', '26', '40', '46', '41', '29')
AND MJ_ASP_DECON.AMOUNT <> ROUND(MJ_ASP_DECON.AMOUNT)
UNION
--STATE2 AMOUNT WITHOUT LIVED STATE JURISDICTION
select
		'STATE2 AMOUNT WITHOUT LIVED STATE JURISDICTION' AS ISSUE,
		MJ_ASP_DECON.MJ_RCD_NBR MJ_RCD_NBR,
		MJ_ASP_DECON.BLOCK_NBR BLOCK_NBR,
		MJ_ASP_DECON.RCD_NBR RCD_NBR,
		MJ_ASP_DECON.PAYGROUP PAYGROUP,
		MJ_ASP_DECON.FILE_NBR FILE_NBR,
		MJ_ASP_DECON.QUARTER QUARTER,
		MJ_ASP_DECON.CHECK_DT CHECK_DT,
		MJ_ASP_DECON.WORK_STATE WORK_STATE,
		MJ_ASP_DECON.LIVED_ST LIVED_ST,
		MJ_ASP_DECON.SUI SUI,
		MJ_ASP_DECON.LOCAL1 LOCAL1,
		MJ_ASP_DECON.LOCAL2 LOCAL2,
		MJ_ASP_DECON.OH_SDIT OH_SDIT,
		MJ_ASP_DECON.LOCAL4 LOCAL4,
		MJ_ASP_DECON.LOCAL5 LOCAL5,
		MJ_ASP_DECON.ID ID,
		MJ_ASP_DECON.MOD MOD,
		MJ_ASP_DECON.CLIENT_ID  CLIENT_ID,
		MJ_ASP_DECON.AMOUNT AMOUNT
from MJ_ASP_DECON
WHERE MJ_ASP_DECON.ID = '12'
AND TRIM(MJ_ASP_DECON.MOD) ='2'
AND TRIM(MJ_ASP_DECON.LIVED_ST) IS NULL
UNION
--LOCAL1 AMOUNT WITHOUT LOCAL1 JURISDICTION
select
		'LOCAL1 AMOUNT WITHOUT LOCAL1 JURISDICTION' AS ISSUE,
		MJ_ASP_DECON.MJ_RCD_NBR MJ_RCD_NBR,
		MJ_ASP_DECON.BLOCK_NBR BLOCK_NBR,
		MJ_ASP_DECON.RCD_NBR RCD_NBR,
		MJ_ASP_DECON.PAYGROUP PAYGROUP,
		MJ_ASP_DECON.FILE_NBR FILE_NBR,
		MJ_ASP_DECON.QUARTER QUARTER,
		MJ_ASP_DECON.CHECK_DT CHECK_DT,
		MJ_ASP_DECON.WORK_STATE WORK_STATE,
		MJ_ASP_DECON.LIVED_ST LIVED_ST,
		MJ_ASP_DECON.SUI SUI,
		MJ_ASP_DECON.LOCAL1 LOCAL1,
		MJ_ASP_DECON.LOCAL2 LOCAL2,
		MJ_ASP_DECON.OH_SDIT OH_SDIT,
		MJ_ASP_DECON.LOCAL4 LOCAL4,
		MJ_ASP_DECON.LOCAL5 LOCAL5,
		MJ_ASP_DECON.ID ID,
		MJ_ASP_DECON.MOD MOD,
		MJ_ASP_DECON.CLIENT_ID  CLIENT_ID,
		MJ_ASP_DECON.AMOUNT AMOUNT
from MJ_ASP_DECON
WHERE MJ_ASP_DECON.ID = '13'
AND TRIM(MJ_ASP_DECON.MOD) IS NULL
AND TRIM(MJ_ASP_DECON.LOCAL1) IS NULL
UNION
--LOCAL2 AMOUNT WITHOUT LOCAL2 JURISDICTION
select
		'LOCAL2 AMOUNT WITHOUT LOCAL2 JURISDICTION' AS ISSUE,
		MJ_ASP_DECON.MJ_RCD_NBR MJ_RCD_NBR,
		MJ_ASP_DECON.BLOCK_NBR BLOCK_NBR,
		MJ_ASP_DECON.RCD_NBR RCD_NBR,
		MJ_ASP_DECON.PAYGROUP PAYGROUP,
		MJ_ASP_DECON.FILE_NBR FILE_NBR,
		MJ_ASP_DECON.QUARTER QUARTER,
		MJ_ASP_DECON.CHECK_DT CHECK_DT,
		MJ_ASP_DECON.WORK_STATE WORK_STATE,
		MJ_ASP_DECON.LIVED_ST LIVED_ST,
		MJ_ASP_DECON.SUI SUI,
		MJ_ASP_DECON.LOCAL1 LOCAL1,
		MJ_ASP_DECON.LOCAL2 LOCAL2,
		MJ_ASP_DECON.OH_SDIT OH_SDIT,
		MJ_ASP_DECON.LOCAL4 LOCAL4,
		MJ_ASP_DECON.LOCAL5 LOCAL5,
		MJ_ASP_DECON.ID ID,
		MJ_ASP_DECON.MOD MOD,
		MJ_ASP_DECON.CLIENT_ID  CLIENT_ID,
		MJ_ASP_DECON.AMOUNT AMOUNT
from MJ_ASP_DECON
WHERE MJ_ASP_DECON.ID = '13'
AND TRIM(MJ_ASP_DECON.MOD) ='2'
AND TRIM(MJ_ASP_DECON.LOCAL2) IS NULL
UNION
--OH SDIT AMOUNT WITHOUT OH SDIT JURISDICTION
select
		'OH SDIT AMOUNT WITHOUT OH SDIT JURISDICTION' AS ISSUE,
		MJ_ASP_DECON.MJ_RCD_NBR MJ_RCD_NBR,
		MJ_ASP_DECON.BLOCK_NBR BLOCK_NBR,
		MJ_ASP_DECON.RCD_NBR RCD_NBR,
		MJ_ASP_DECON.PAYGROUP PAYGROUP,
		MJ_ASP_DECON.FILE_NBR FILE_NBR,
		MJ_ASP_DECON.QUARTER QUARTER,
		MJ_ASP_DECON.CHECK_DT CHECK_DT,
		MJ_ASP_DECON.WORK_STATE WORK_STATE,
		MJ_ASP_DECON.LIVED_ST LIVED_ST,
		MJ_ASP_DECON.SUI SUI,
		MJ_ASP_DECON.LOCAL1 LOCAL1,
		MJ_ASP_DECON.LOCAL2 LOCAL2,
		MJ_ASP_DECON.OH_SDIT OH_SDIT,
		MJ_ASP_DECON.LOCAL4 LOCAL4,
		MJ_ASP_DECON.LOCAL5 LOCAL5,
		MJ_ASP_DECON.ID ID,
		MJ_ASP_DECON.MOD MOD,
		MJ_ASP_DECON.CLIENT_ID  CLIENT_ID,
		MJ_ASP_DECON.AMOUNT AMOUNT
from MJ_ASP_DECON
WHERE TRIM(MJ_ASP_DECON.ID) = 'S'
AND TRIM(MJ_ASP_DECON.MOD) ='OHS'
AND TRIM(MJ_ASP_DECON.OH_SDIT) IS NULL
UNION
--LOCAL4 AMOUNT WITHOUT LOCAL4 JURISDICTION
select
		'LOCAL4 AMOUNT WITHOUT LOCAL4 JURISDICTION' AS ISSUE,
		MJ_ASP_DECON.MJ_RCD_NBR MJ_RCD_NBR,
		MJ_ASP_DECON.BLOCK_NBR BLOCK_NBR,
		MJ_ASP_DECON.RCD_NBR RCD_NBR,
		MJ_ASP_DECON.PAYGROUP PAYGROUP,
		MJ_ASP_DECON.FILE_NBR FILE_NBR,
		MJ_ASP_DECON.QUARTER QUARTER,
		MJ_ASP_DECON.CHECK_DT CHECK_DT,
		MJ_ASP_DECON.WORK_STATE WORK_STATE,
		MJ_ASP_DECON.LIVED_ST LIVED_ST,
		MJ_ASP_DECON.SUI SUI,
		MJ_ASP_DECON.LOCAL1 LOCAL1,
		MJ_ASP_DECON.LOCAL2 LOCAL2,
		MJ_ASP_DECON.OH_SDIT OH_SDIT,
		MJ_ASP_DECON.LOCAL4 LOCAL4,
		MJ_ASP_DECON.LOCAL5 LOCAL5,
		MJ_ASP_DECON.ID ID,
		MJ_ASP_DECON.MOD MOD,
		MJ_ASP_DECON.CLIENT_ID  CLIENT_ID,
		MJ_ASP_DECON.AMOUNT AMOUNT
from MJ_ASP_DECON
WHERE TRIM(MJ_ASP_DECON.ID) = 'LB'
AND TRIM(MJ_ASP_DECON.MOD) ='4'
AND TRIM(MJ_ASP_DECON.LOCAL4) IS NULL
UNION
--SUI AMOUNT WITHOUT SUI JURISDICTION
select
		'SUI AMOUNT WITHOUT SUI JURISDICTION' AS ISSUE,
		MJ_ASP_DECON.MJ_RCD_NBR MJ_RCD_NBR,
		MJ_ASP_DECON.BLOCK_NBR BLOCK_NBR,
		MJ_ASP_DECON.RCD_NBR RCD_NBR,
		MJ_ASP_DECON.PAYGROUP PAYGROUP,
		MJ_ASP_DECON.FILE_NBR FILE_NBR,
		MJ_ASP_DECON.QUARTER QUARTER,
		MJ_ASP_DECON.CHECK_DT CHECK_DT,
		MJ_ASP_DECON.WORK_STATE WORK_STATE,
		MJ_ASP_DECON.LIVED_ST LIVED_ST,
		MJ_ASP_DECON.SUI SUI,
		MJ_ASP_DECON.LOCAL1 LOCAL1,
		MJ_ASP_DECON.LOCAL2 LOCAL2,
		MJ_ASP_DECON.OH_SDIT OH_SDIT,
		MJ_ASP_DECON.LOCAL4 LOCAL4,
		MJ_ASP_DECON.LOCAL5 LOCAL5,
		MJ_ASP_DECON.ID ID,
		MJ_ASP_DECON.MOD MOD,
		MJ_ASP_DECON.CLIENT_ID  CLIENT_ID,
		MJ_ASP_DECON.AMOUNT AMOUNT
from MJ_ASP_DECON
WHERE TRIM(MJ_ASP_DECON.ID) = '15'
AND TRIM(MJ_ASP_DECON.MOD) IS NULL
AND TRIM(MJ_ASP_DECON.SUI) IS NULL
UNION
--NO SUI TEMP JUR
select
		'NO SUI TEMP JUR' AS ISSUE,
		MJ_ASP_DECON.MJ_RCD_NBR MJ_RCD_NBR,
		MJ_ASP_DECON.BLOCK_NBR BLOCK_NBR,
		MJ_ASP_DECON.RCD_NBR RCD_NBR,
		MJ_ASP_DECON.PAYGROUP PAYGROUP,
		MJ_ASP_DECON.FILE_NBR FILE_NBR,
		MJ_ASP_DECON.QUARTER QUARTER,
		MJ_ASP_DECON.CHECK_DT CHECK_DT,
		MJ_ASP_DECON.WORK_STATE WORK_STATE,
		MJ_ASP_DECON.LIVED_ST LIVED_ST,
		MJ_ASP_DECON.SUI SUI,
		MJ_ASP_DECON.LOCAL1 LOCAL1,
		MJ_ASP_DECON.LOCAL2 LOCAL2,
		MJ_ASP_DECON.OH_SDIT OH_SDIT,
		MJ_ASP_DECON.LOCAL4 LOCAL4,
		MJ_ASP_DECON.LOCAL5 LOCAL5,
		MJ_ASP_DECON.ID ID,
		MJ_ASP_DECON.MOD MOD,
		MJ_ASP_DECON.CLIENT_ID  CLIENT_ID,
		MJ_ASP_DECON.AMOUNT AMOUNT
from MJ_ASP_DECON
WHERE TRIM(MJ_ASP_DECON.SUI) IS NULL
UNION
--NO STATE1 TEMP JUR
select
		'NO STATE1 TEMP JUR' AS ISSUE,
		MJ_ASP_DECON.MJ_RCD_NBR MJ_RCD_NBR,
		MJ_ASP_DECON.BLOCK_NBR BLOCK_NBR,
		MJ_ASP_DECON.RCD_NBR RCD_NBR,
		MJ_ASP_DECON.PAYGROUP PAYGROUP,
		MJ_ASP_DECON.FILE_NBR FILE_NBR,
		MJ_ASP_DECON.QUARTER QUARTER,
		MJ_ASP_DECON.CHECK_DT CHECK_DT,
		MJ_ASP_DECON.WORK_STATE WORK_STATE,
		MJ_ASP_DECON.LIVED_ST LIVED_ST,
		MJ_ASP_DECON.SUI SUI,
		MJ_ASP_DECON.LOCAL1 LOCAL1,
		MJ_ASP_DECON.LOCAL2 LOCAL2,
		MJ_ASP_DECON.OH_SDIT OH_SDIT,
		MJ_ASP_DECON.LOCAL4 LOCAL4,
		MJ_ASP_DECON.LOCAL5 LOCAL5,
		MJ_ASP_DECON.ID ID,
		MJ_ASP_DECON.MOD MOD,
		MJ_ASP_DECON.CLIENT_ID  CLIENT_ID,
		MJ_ASP_DECON.AMOUNT AMOUNT
from MJ_ASP_DECON
WHERE TRIM(MJ_ASP_DECON.WORK_STATE) IS NULL





---------------------------------------------------------



---------------------------------------------------------




---------------------------------------------------------



-----------------------------------------------------------



CREATE OR REPLACE VIEW ASP_EARNINGS_MATCH_GROSS as
WITH EARNS
     AS (  SELECT MJ_ASP_DECON.PAYGROUP   PAYGROUP,
                  MJ_ASP_DECON.FILE_NBR   FILE_NBR,
                  MJ_ASP_DECON.QUARTER    QUARTER,
                  MJ_ASP_DECON.CHECK_DT   CHECK_DT,
                  MJ_ASP_DECON.WORK_STATE WORK_STATE,
                  MJ_ASP_DECON.LIVED_ST   LIVED_ST,
                  MJ_ASP_DECON.SUI        SUI,
                  MJ_ASP_DECON.LOCAL1     LOCAL1,
                  MJ_ASP_DECON.LOCAL2     LOCAL2,
                  MJ_ASP_DECON.OH_SDIT    OH_SDIT,
                  MJ_ASP_DECON.LOCAL4     LOCAL4,
                  MJ_ASP_DECON.LOCAL5     LOCAL5,
				  MJ_ASP_DECON.CLIENT_ID   CLIENT_ID,
                  SUM (MJ_ASP_DECON.AMOUNT) EARNINGS_SUM
             FROM MJ_ASP_DECON
            WHERE TRIM (MJ_ASP_DECON.ID) IN ('05',
                                             '06',
                                             '07',
                                             '08',
                                             '09')
         GROUP BY MJ_ASP_DECON.PAYGROUP,
                  MJ_ASP_DECON.FILE_NBR,
                  MJ_ASP_DECON.QUARTER,
                  MJ_ASP_DECON.CHECK_DT,
                  MJ_ASP_DECON.WORK_STATE,
                  MJ_ASP_DECON.LIVED_ST,
                  MJ_ASP_DECON.SUI,
                  MJ_ASP_DECON.LOCAL1,
                  MJ_ASP_DECON.LOCAL2,
                  MJ_ASP_DECON.OH_SDIT,
                  MJ_ASP_DECON.LOCAL4,
                  MJ_ASP_DECON.LOCAL5,
				  MJ_ASP_DECON.CLIENT_ID),
     GROSS
     AS (  SELECT MJ_ASP_DECON.PAYGROUP   PAYGROUP,
                  MJ_ASP_DECON.FILE_NBR   FILE_NBR,
                  MJ_ASP_DECON.QUARTER    QUARTER,
                  MJ_ASP_DECON.CHECK_DT   CHECK_DT,
                  MJ_ASP_DECON.WORK_STATE WORK_STATE,
                  MJ_ASP_DECON.LIVED_ST   LIVED_ST,
                  MJ_ASP_DECON.SUI        SUI,
                  MJ_ASP_DECON.LOCAL1     LOCAL1,
                  MJ_ASP_DECON.LOCAL2     LOCAL2,
                  MJ_ASP_DECON.OH_SDIT    OH_SDIT,
                  MJ_ASP_DECON.LOCAL4     LOCAL4,
                  MJ_ASP_DECON.LOCAL5     LOCAL5,
				  MJ_ASP_DECON.CLIENT_ID   CLIENT_ID,
                  SUM (MJ_ASP_DECON.AMOUNT) GROSS_SUM
             FROM MJ_ASP_DECON
            WHERE TRIM (MJ_ASP_DECON.ID) IN ('10')
         GROUP BY MJ_ASP_DECON.PAYGROUP,
                  MJ_ASP_DECON.FILE_NBR,
                  MJ_ASP_DECON.QUARTER,
                  MJ_ASP_DECON.CHECK_DT,
                  MJ_ASP_DECON.WORK_STATE,
                  MJ_ASP_DECON.LIVED_ST,
                  MJ_ASP_DECON.SUI,
                  MJ_ASP_DECON.LOCAL1,
                  MJ_ASP_DECON.LOCAL2,
                  MJ_ASP_DECON.OH_SDIT,
                  MJ_ASP_DECON.LOCAL4,
                  MJ_ASP_DECON.LOCAL5,
				  MJ_ASP_DECON.CLIENT_ID)
SELECT DISTINCT MJ_ASP_DECON.PAYGROUP                PAYGROUP,
                MJ_ASP_DECON.FILE_NBR                FILE_NBR,
                MJ_ASP_DECON.QUARTER                 QUARTER,
                MJ_ASP_DECON.CHECK_DT                CHECK_DT,
                MJ_ASP_DECON.WORK_STATE              WORK_STATE,
                MJ_ASP_DECON.LIVED_ST                LIVED_ST,
                MJ_ASP_DECON.SUI                     SUI,
                MJ_ASP_DECON.LOCAL1                  LOCAL1,
                MJ_ASP_DECON.LOCAL2                  LOCAL2,
                MJ_ASP_DECON.OH_SDIT                 OH_SDIT,
                MJ_ASP_DECON.LOCAL4                  LOCAL4,
                MJ_ASP_DECON.LOCAL5                  LOCAL5,
                EARNS.EARNINGS_SUM                   EARNINGS,
                GROSS.GROSS_SUM                      GROSS,
				MJ_ASP_DECON.CLIENT_ID   CLIENT_ID,
                GROSS.GROSS_SUM - EARNS.EARNINGS_SUM AS DELTA
  FROM MJ_ASP_DECON
       LEFT OUTER JOIN EARNS
          ON     COALESCE (MJ_ASP_DECON.PAYGROUP, 'X') =
                    COALESCE (EARNS.PAYGROUP, 'X')
             AND COALESCE (MJ_ASP_DECON.FILE_NBR, 'X') =
                    COALESCE (EARNS.FILE_NBR, 'X')
             AND COALESCE (MJ_ASP_DECON.QUARTER, 'X') =
                    COALESCE (EARNS.QUARTER, 'X')
             AND COALESCE (MJ_ASP_DECON.CHECK_DT, 'X') =
                    COALESCE (EARNS.CHECK_DT, 'X')
             AND COALESCE (MJ_ASP_DECON.WORK_STATE, 'X') =
                    COALESCE (EARNS.WORK_STATE, 'X')
             AND COALESCE (MJ_ASP_DECON.LIVED_ST, 'X') =
                    COALESCE (EARNS.LIVED_ST, 'X')
             AND COALESCE (MJ_ASP_DECON.SUI, 'X') = COALESCE (EARNS.SUI, 'X')
             AND COALESCE (MJ_ASP_DECON.LOCAL1, 'X') =
                    COALESCE (EARNS.LOCAL1, 'X')
             AND COALESCE (MJ_ASP_DECON.LOCAL2, 'X') =
                    COALESCE (EARNS.LOCAL2, 'X')
             AND COALESCE (MJ_ASP_DECON.OH_SDIT, 'X') =
                    COALESCE (EARNS.OH_SDIT, 'X')
             AND COALESCE (MJ_ASP_DECON.LOCAL4, 'X') =
                    COALESCE (EARNS.LOCAL4, 'X')
             AND COALESCE (MJ_ASP_DECON.LOCAL5, 'X') =
                    COALESCE (EARNS.LOCAL5, 'X')
       LEFT OUTER JOIN GROSS
          ON     COALESCE (MJ_ASP_DECON.PAYGROUP, 'X') =
                    COALESCE (GROSS.PAYGROUP, 'X')
             AND COALESCE (MJ_ASP_DECON.FILE_NBR, 'X') =
                    COALESCE (GROSS.FILE_NBR, 'X')
             AND COALESCE (MJ_ASP_DECON.QUARTER, 'X') =
                    COALESCE (GROSS.QUARTER, 'X')
             AND COALESCE (MJ_ASP_DECON.CHECK_DT, 'X') =
                    COALESCE (GROSS.CHECK_DT, 'X')
             AND COALESCE (MJ_ASP_DECON.WORK_STATE, 'X') =
                    COALESCE (GROSS.WORK_STATE, 'X')
             AND COALESCE (MJ_ASP_DECON.LIVED_ST, 'X') =
                    COALESCE (GROSS.LIVED_ST, 'X')
             AND COALESCE (MJ_ASP_DECON.SUI, 'X') = COALESCE (GROSS.SUI, 'X')
             AND COALESCE (MJ_ASP_DECON.LOCAL1, 'X') =
                    COALESCE (GROSS.LOCAL1, 'X')
             AND COALESCE (MJ_ASP_DECON.LOCAL2, 'X') =
                    COALESCE (GROSS.LOCAL2, 'X')
             AND COALESCE (MJ_ASP_DECON.OH_SDIT, 'X') =
                    COALESCE (GROSS.OH_SDIT, 'X')
             AND COALESCE (MJ_ASP_DECON.LOCAL4, 'X') =
                    COALESCE (GROSS.LOCAL4, 'X')
             AND COALESCE (MJ_ASP_DECON.LOCAL5, 'X') =
                    COALESCE (GROSS.LOCAL5, 'X')
 WHERE EARNS.EARNINGS_SUM <> GROSS.GROSS_SUM;

Create table balance_tax_wages
(
CO_CODE          VARCHAR2(200),
FILENUMBER          VARCHAR2(200),
EMP_NAME          VARCHAR2(200),
PR_DEPT          VARCHAR2(200),
SSN          VARCHAR2(200),
GENDER          VARCHAR2(200),
DATA_CONTROL          VARCHAR2(200),
STATE_TAX_CD          VARCHAR2(200),
SUI_TAX_CD          VARCHAR2(200),
LOCAL_TAX_CD          VARCHAR2(200),
QUALIFIED_PENSION          VARCHAR2(200),
SDIT_TAX_CD          VARCHAR2(200),
EMPL_STATUS          VARCHAR2(200),
STATE2_TAX_CD          VARCHAR2(200),
LOCAL2_TAX_CD          VARCHAR2(200),
CORP_CODE          VARCHAR2(200),
FILLER1          VARCHAR2(200),
FICA_TAXABLE_BLK          VARCHAR2(200),
SUI_TAXABLE_BLK          VARCHAR2(200),
FUTA_TAXABLE_BLK          VARCHAR2(200),
FED_TAXABLE_BLK          VARCHAR2(200),
STATE_TAXABLE_BLK          VARCHAR2(200),
LOCAL_TAXABLE_BLK          VARCHAR2(200),
OPTIONS_PART1          VARCHAR2(200),
OPTIONS_PART2          VARCHAR2(200),
ADDL_BLK          VARCHAR2(200),
FED_EXEMPTIONS          VARCHAR2(200),
HOUSEHOLD_EMPLOYEE          VARCHAR2(200),
FILLER2          VARCHAR2(200),
COUNTY_TAX_CD          VARCHAR2(200),
GROSS_EARNINGS_QTD          VARCHAR2(200),
GROSS_EARNINGS_YTD          VARCHAR2(200),
SOSEC_WAGES_QTD          VARCHAR2(200),
SOSEC_WAGES_YTD          VARCHAR2(200),
MCARE_WAGES_QTD          VARCHAR2(200),
MCARE_WAGES_YTD          VARCHAR2(200),
TTL_ER_SUI_WAGES_QTD          VARCHAR2(200),
TTL_ER_SUI_WAGES_YTD          VARCHAR2(200),
STATE_WAGES_QTD          VARCHAR2(200),
STATE_WAGES_YTD          VARCHAR2(200),
UNCOLL_MCARE_TAX_QTD          VARCHAR2(200),
UNCOLL_MCARE_TAX_YTD          VARCHAR2(200),
GTL_QTD          VARCHAR2(200),
GTL_YTD          VARCHAR2(200),
TXBL_FRINGE_BEN_QTD          VARCHAR2(200),
TXBL_FRINGE_BEN_YTD          VARCHAR2(200),
ER_SDI_WAGES_QTD          VARCHAR2(200),
ER_SDI_WAGES_YTD          VARCHAR2(200),
FED_WAGES_QTD          VARCHAR2(200),
FED_WAGES_YTD          VARCHAR2(200),
SOSEC_TAX_QTD          VARCHAR2(200),
SOSEC_TAX_YTD          VARCHAR2(200),
MCARE_TAX_QTD          VARCHAR2(200),
MCARE_TAX_YTD          VARCHAR2(200),
ER_SUI_WAGES_QTD          VARCHAR2(200),
ER_SUI_WAGES_YTD          VARCHAR2(200),
STATE_TAX_QTD          VARCHAR2(200),
STATE_TAX_YTD          VARCHAR2(200),
LOCAL_TAX_QTD          VARCHAR2(200),
LOCAL_TAX_YTD          VARCHAR2(200),
DEP_CARE_BEN_YTD          VARCHAR2(200),
THRD_PRTY_TXBL_QTD          VARCHAR2(200),
THRD_PRTY_TXBL_YTD          VARCHAR2(200),
DEF_COMP_401K_QTD          VARCHAR2(200),
DEF_COMP_401K_YTD          VARCHAR2(200),
ER_PROV_TRNSPRT_QTD          VARCHAR2(200),
ER_PROV_TRNSPRT_YTD          VARCHAR2(200),
FED_TAX_QTD          VARCHAR2(200),
FED_TAX_YTD          VARCHAR2(200),
UNCOLL_SOSEC_TAX_QTD          VARCHAR2(200),
UNCOLL_SOSEC_TAX_YTD          VARCHAR2(200),
FUTA_TAXABLE_QTD          VARCHAR2(200),
FUTA_TAXABLE_YTD          VARCHAR2(200),
SUI_TAX_QTD          VARCHAR2(200),
SUI_TAX_YTD          VARCHAR2(200),
SDI_TAX_QTD          VARCHAR2(200),
SDI_TAX_YTD          VARCHAR2(200),
LOCAL_WAGES_QTD          VARCHAR2(200),
LOCAL_WAGES_YTD          VARCHAR2(200),
THRDPTY_SOSEC_WH_QTD          VARCHAR2(200),
THRDPTY_SOSEC_WH_YTD          VARCHAR2(200),
THRD_PRTY_NON_TXBL          VARCHAR2(200),
THRDPTY_MCARE_WH_QTD          VARCHAR2(200),
THRDPTY_MCARE_WH_YTD          VARCHAR2(200),
WEEKS_WORKED          VARCHAR2(200),
EE_SDI_WAGES_QTD          VARCHAR2(200),
EE_SDI_WAGES_YTD          VARCHAR2(200),
OTHER_1099_COMP_QTD          VARCHAR2(200),
OTHER_1099_COMP_YTD          VARCHAR2(200),
LOCAL2_WAGES_QTD          VARCHAR2(200),
LOCAL2_WAGES_YTD          VARCHAR2(200),
LOCAL2_TAX_QTD          VARCHAR2(200),
LOCAL2_TAX_YTD          VARCHAR2(200),
STATE2_WAGES_QTD          VARCHAR2(200),
STATE2_WAGES_YTD          VARCHAR2(200),
STATE2_TAX_QTD          VARCHAR2(200),
STATE2_TAX_YTD          VARCHAR2(200),
EIC_QTD          VARCHAR2(200),
EIC_YTD          VARCHAR2(200),
HOURS_WORKED          VARCHAR2(200),
LA_TAXABLE_SUI24_QTD          VARCHAR2(200),
LA_TAXABLE_SUI24_YTD          VARCHAR2(200),
MA_HEALTH_SUI_02_QTD          VARCHAR2(200),
MA_HEALTH_SUI_02_YTD          VARCHAR2(200),
RENTS          VARCHAR2(200),
ROYALTIES          VARCHAR2(200),
DEF_COMP_457_QTD          VARCHAR2(200),
DEF_COMP_457_YTD          VARCHAR2(200),
DEF_COMP_501C_QTD          VARCHAR2(200),
DEF_COMP_501C_YTD          VARCHAR2(200),
DEF_COMP_403B_QTD          VARCHAR2(200),
DEF_COMP_403B_YTD          VARCHAR2(200),
SOSEC_TIPS_QTD          VARCHAR2(200),
SOSEC_TIPS_YTD          VARCHAR2(200),
ALLOCATION_TIPS          VARCHAR2(200),
EE_BUS_EXPENSE_QTD          VARCHAR2(200),
EE_BUS_EXPENSE_YTD          VARCHAR2(200),
EXCL_MOVING_REIMB          VARCHAR2(200),
MSA          VARCHAR2(200),
SIMPLE_PLAN_408P_QTD          VARCHAR2(200),
SIMPLE_PLAN_408P_YTD          VARCHAR2(200),
ADOPTION_ASSIST          VARCHAR2(200),
SDIT_TAX_QTD          VARCHAR2(200),
SDIT_TAX_YTD          VARCHAR2(200),
CA_VPDI_YTD          VARCHAR2(200),
GOV_PENSION_QTD          VARCHAR2(200),
GOV_PENSION_YTD          VARCHAR2(200),
AUTO_USE_TXBL_FRINGE          VARCHAR2(200),
NJ_UI_ACCT_NUMBER          VARCHAR2(200),
MO_INDIVID_MED_ACCTS          VARCHAR2(200),
CLIENT_OPT1_LITERAL          VARCHAR2(200),
CLIENT_OPT1_AMOUNT          VARCHAR2(200),
CLIENT_OPT2_LITERAL          VARCHAR2(200),
CLIENT_OPT2_AMOUNT          VARCHAR2(200),
CLIENT_OPT3_LITERAL          VARCHAR2(200),
CLIENT_OPT3_AMOUNT          VARCHAR2(200),
SPEC_INDICATOR1_YTD          VARCHAR2(200),
SPEC_INDICATOR2_YTD          VARCHAR2(200),
SPEC_INDICATOR3_YTD          VARCHAR2(200),
SPEC_INDICATOR4_YTD          VARCHAR2(200),
SPEC_INDICATOR1_QTD          VARCHAR2(200),
SPEC_INDICATOR2_QTD          VARCHAR2(200),
SPEC_INDICATOR3_QTD          VARCHAR2(200),
SPEC_INDICATOR4_QTD          VARCHAR2(200),
COUNTY_TAX_YTD          VARCHAR2(200),
COUNTY_WAGES_QTD          VARCHAR2(200),
COUNTY_WAGES_YTD          VARCHAR2(200),
THRD_PRTY_FED_WH_QTD          VARCHAR2(200),
THRD_PRTY_FED_WH_YTD          VARCHAR2(200),
THRDPTY_STATE_WH_QTD          VARCHAR2(200),
THRDPTY_STATE_WH_YTD          VARCHAR2(200),
THRD_PRTY_SUI_WH_QTD          VARCHAR2(200),
THRD_PRTY_SUI_WH_YTD          VARCHAR2(200),
DECLARED_TIPS_QTD          VARCHAR2(200),
DECLARED_TIPS_YTD          VARCHAR2(200),
TIP_CREDITS_QTD          VARCHAR2(200),
TIP_CREDITS_YTD          VARCHAR2(200),
EXCLUD_SICK_PAY_QTD          VARCHAR2(200),
EXCLUD_SICK_PAY_YTD          VARCHAR2(200),
MEALS_QTD          VARCHAR2(200),
MEALS_YTD          VARCHAR2(200),
TAX_SHELT_ANNUIT_QTD          VARCHAR2(200),
TAX_SHELT_ANNUIT_YTD          VARCHAR2(200),
OTHER_1099_COMP_QTD_1          VARCHAR2(200),
OTHER_1099_COMP_YTD_1          VARCHAR2(200),
FLEX_TAX_LIMIT_QTD          VARCHAR2(200),
FLEX_TAX_LIMIT_YTD          VARCHAR2(200),
X_408K_QTD          VARCHAR2(200),
X_408K_YTD          VARCHAR2(200),
TAXABLE_TIPS_QTD          VARCHAR2(200),
PRIZES_1099          VARCHAR2(200),
MED_PAYMENTS_1099          VARCHAR2(200),
NON_RES_LOCAL_PCT          VARCHAR2(200),
NON_RES_STATE_PCT          VARCHAR2(200),
NONQUAL_PLANS_457          VARCHAR2(200),
NONQUAL_PLANS_OTHER          VARCHAR2(200),
CAFE125_DEP_CARE_QTD          VARCHAR2(200),
CAFE125_DEP_CARE_YTD          VARCHAR2(200),
C125_MED_FLX_ACT_QTD          VARCHAR2(200),
C125_MED_FLX_ACT_YTD          VARCHAR2(200),
C125_TTL_EXEMPT_QTD          VARCHAR2(200),
C125_TTL_EXEMPT_YTD          VARCHAR2(200),
OR_WC_HOURS          VARCHAR2(200),
OR_WC_TAX_QTD          VARCHAR2(200),
OR_WC_TAX_YTD          VARCHAR2(200),
WEEKS_WORKD_REPRTBLE          VARCHAR2(200),
PR_PENS_ANNUIT_YTD          VARCHAR2(200),
PR_COMMISSIONS_YTD          VARCHAR2(200),
PR_ALLOWANCES_YTD          VARCHAR2(200),
PR_REIMB_EXP_YTD          VARCHAR2(200),
PR_RETIRE_FUND_YTD          VARCHAR2(200),
PR_CODE_CONTRIB_YTD          VARCHAR2(200),
WY_WC_WAGES_QTD          VARCHAR2(200),
WY_WC_WAGES_YTD          VARCHAR2(200),
WY_WC_TAX_QTD          VARCHAR2(200),
WY_WC_TAX_YTD          VARCHAR2(200),
OTHER_WAGES_QTD          VARCHAR2(200),
OTHER_WAGES_YTD          VARCHAR2(200),
SEVERANCE_PAY_QTD          VARCHAR2(200),
SEVERANCE_PAY_YTD          VARCHAR2(200),
MOVING_EXPENSE_QTD          VARCHAR2(200),
MOVING_EXPENSE_YTD          VARCHAR2(200),
ER_PAID_SUI_TAX_QTD          VARCHAR2(200),
ER_PAID_SUI_TAX_YTD          VARCHAR2(200),
ER_PAID_ADOPT_QTD          VARCHAR2(200),
ER_PAID_ADOPT_YTD          VARCHAR2(200),
EE_PAID_MSA_QTD          VARCHAR2(200),
EE_PAID_MSA_YTD          VARCHAR2(200),
ER_PAID_MSA_QTD          VARCHAR2(200),
ER_PAID_MSA_YTD          VARCHAR2(200),
C125_ADOPT_QTD          VARCHAR2(200),
C125_ADOPT_YTD          VARCHAR2(200),
NON_RES_LOCAL2_PCT          VARCHAR2(200),
SEP_CON_QTD          VARCHAR2(200),
SEP_CON_YTD          VARCHAR2(200),
ATT_GROSS_1099_YTD          VARCHAR2(200),
EPP_1099_YTD          VARCHAR2(200),
AWD_PRIZES_GIFTS_QTD          VARCHAR2(200),
AWD_PRIZES_GIFTS_YTD          VARCHAR2(200),
AWD_SERV_SAFETY_QTD          VARCHAR2(200),
AWD_SERV_SAFETY_YTD          VARCHAR2(200),
BELOW_MKT_LN_10K_QTD          VARCHAR2(200),
BELOW_MKT_LN_10K_YTD          VARCHAR2(200),
CMP_CAR_FULL_USE_QTD          VARCHAR2(200),
CMP_CAR_FULL_USE_YTD          VARCHAR2(200),
EE_PROV_ENTERTAI_QTD          VARCHAR2(200),
EE_PROV_ENTERTAI_YTD          VARCHAR2(200),
EDUC_ASSETT_INCL_QTD          VARCHAR2(200),
EDUC_ASSETT_INCL_YTD          VARCHAR2(200),
GROUP_LEGAL_QTD          VARCHAR2(200),
GROUP_LEGAL_YTD          VARCHAR2(200),
HEALTH_ACC_PLANS_QTD          VARCHAR2(200),
HEALTH_ACC_PLANS_YTD          VARCHAR2(200),
ER_PD_LMTD_PREM_QTD          VARCHAR2(200),
ER_PD_LMTD_PREM_YTD          VARCHAR2(200),
OTHER_FRINGE_BEN_QTD          VARCHAR2(200),
OTHER_FRINGE_BEN_YTD          VARCHAR2(200),
ER_PAID_TRNSPRT_QTD          VARCHAR2(200),
ER_PAID_TRNSPRT_YTD          VARCHAR2(200),
TRNSPRT_REDUCT_QTD          VARCHAR2(200),
TRNSPRT_REDUCT_YTD          VARCHAR2(200),
RELOC_TO_3RD_PTY_QTD          VARCHAR2(200),
RELOC_TO_3RD_PTY_YTD          VARCHAR2(200),
STOCK_OPTIONS_QTD          VARCHAR2(200),
STOCK_OPTIONS_YTD          VARCHAR2(200),
DIST_457_1099R_YTD          VARCHAR2(200),
EE_PAID_HSA_QTD          VARCHAR2(200),
EE_PAID_HSA_YTD          VARCHAR2(200),
ER_PAID_HSA_QTD          VARCHAR2(200),
ER_PAID_HSA_YTD          VARCHAR2(200),
SCK_PAY_NON_TXBL_QTD          VARCHAR2(200),
SCK_PAY_NON_TXBL_YTD          VARCHAR2(200),
CAFE125_HSA_QTD          VARCHAR2(200),
CAFE125_HSA_YTD          VARCHAR2(200),
NJ_MMI_PAA_QTD          VARCHAR2(200),
NJ_MMI_PAA_YTD          VARCHAR2(200),
W2_409A_DEFERRED_QTD          VARCHAR2(200),
W2_409A_DEFERRED_YTD          VARCHAR2(200),
W2_409A_INCOME_QTD          VARCHAR2(200),
W2_409A_INCOME_YTD          VARCHAR2(200),
DEF_409A_1099_QTD          VARCHAR2(200),
DEF_409A_1099_YTD          VARCHAR2(200),
INCOME_409A_1099_QTD          VARCHAR2(200),
INCOME_409A_1099_YTD          VARCHAR2(200),
PR_ACT_324_QTD          VARCHAR2(200),
PR_ACT_324_YTD          VARCHAR2(200),
ROTH_UNDER_401K_QTD          VARCHAR2(200),
ROTH_UNDER_401K_YTD          VARCHAR2(200),
ROTH_UNDER_403B_QTD          VARCHAR2(200),
ROTH_UNDER_403B_YTD          VARCHAR2(200),
CLIENT_DEF_LTRL4_AMT          VARCHAR2(200),
CLIENT_DEF_LTRL5_AMT          VARCHAR2(200),
CLIENT_DEF_LTRL6_AMT          VARCHAR2(200),
ER_403B_MATCH_QTD          VARCHAR2(200),
ER_403B_MATCH_YTD          VARCHAR2(200),
ER_408P_MATCH_QTD          VARCHAR2(200),
ER_408P_MATCH_YTD          VARCHAR2(200),
ER_408K_MATCH_QTD          VARCHAR2(200),
ER_408K_MATCH_YTD          VARCHAR2(200),
RTH_403B_ER_MTCH_QTD          VARCHAR2(200),
RTH_403B_ER_MTCH_YTD          VARCHAR2(200),
LOCAL4_WAGES_QTD          VARCHAR2(200),
LOCAL4_WAGES_YTD          VARCHAR2(200),
LOCAL4_TAX_QTD          VARCHAR2(200),
LOCAL4_TAX_YTD          VARCHAR2(200),
LOCAL5_WAGES_QTD          VARCHAR2(200),
LOCAL5_WAGES_YTD          VARCHAR2(200),
LOCAL5_TAX_QTD          VARCHAR2(200),
LOCAL5_TAX_YTD          VARCHAR2(200),
VPFLI_SNT_YTD          VARCHAR2(200),
COBRA_CREDIT_QTD          VARCHAR2(200),
COBRA_CREDIT_YTD          VARCHAR2(200),
COBRA_COUNT_QTD          VARCHAR2(200),
COBRA_COUNT_YTD          VARCHAR2(200),
PRIOR_SOSEC_WAGES          VARCHAR2(200),
PRIOR_SOSEC_TAX          VARCHAR2(200),
PRIOR_MCARE_WAGES          VARCHAR2(200),
PRIOR_MCARETAX          VARCHAR2(200),
PRIOR_FUTA_WAGES          VARCHAR2(200),
PRIOR_SUI_WAGES          VARCHAR2(200),
PRIOR_SUI_TAX          VARCHAR2(200),
PRIOR_SDI_WAGES          VARCHAR2(200),
PRIOR_SDI_TAX          VARCHAR2(200),
PRIOR_LOCAL_TAX          VARCHAR2(200),
PRIOR_LOCAL2_TAX          VARCHAR2(200),
PRIOR_401K          VARCHAR2(200),
PRIOR_MA_HEALTH          VARCHAR2(200),
PRIOR_EIC          VARCHAR2(200),
EXEMPT_FED_TAX_QTD          VARCHAR2(200),
EXEMPT_FED_TAX_YTD          VARCHAR2(200),
EXMPT_SOSEC_WAGE_QTD          VARCHAR2(200),
EXMPT_SOSEC_WAGE_YTD          VARCHAR2(200),
EXEMPT_SOSEC_TAX_QTD          VARCHAR2(200),
EXEMPT_SOSEC_TAX_YTD          VARCHAR2(200),
EXMPT_MCARE_WAGE_QTD          VARCHAR2(200),
EXMPT_MCARE_WAGE_YTD          VARCHAR2(200),
EXEMPT_MCARE_TAX_QTD          VARCHAR2(200),
EXEMPT_MCARE_TAX_YTD          VARCHAR2(200),
EXMPT_FUTA_WAGES_QTD          VARCHAR2(200),
EXMPT_FUTA_WAGES_YTD          VARCHAR2(200),
EXEMPT_STATE_TAX_QTD          VARCHAR2(200),
EXEMPT_STATE_TAX_YTD          VARCHAR2(200),
EXMPT_STATE2_TAX_QTD          VARCHAR2(200),
EXMPT_STATE2_TAX_YTD          VARCHAR2(200),
EXEMPT_SUI_WAGES_QTD          VARCHAR2(200),
EXEMPT_SUI_WAGES_YTD          VARCHAR2(200),
EXMPT_EE_SUI_TAX_QTD          VARCHAR2(200),
EXMPT_EE_SUI_TAX_YTD          VARCHAR2(200),
EXEMPT_SDI_WAGES_QTD          VARCHAR2(200),
EXEMPT_SDI_WAGES_YTD          VARCHAR2(200),
EXMPT_EE_SDI_TAX_QTD          VARCHAR2(200),
EXMPT_EE_SDI_TAX_YTD          VARCHAR2(200),
EXEMPT_LOCAL_TAX_QTD          VARCHAR2(200),
EXEMPT_LOCAL_TAX_YTD          VARCHAR2(200),
EXMPT_LOCAL2_TAX_QTD          VARCHAR2(200),
EXMPT_LOCAL2_TAX_YTD          VARCHAR2(200),
FEDERAL_EIN          VARCHAR2(200),
BATCH_NBR          VARCHAR2(200),
QUARTER_END_DATE          VARCHAR2(200),
FED_JURIS_INDICATOR          VARCHAR2(200),
STATE_JURIS_INDIC          VARCHAR2(200),
STATE2_JURIS_INDIC          VARCHAR2(200),
SUI_JURIS_INDICATOR          VARCHAR2(200),
SDI_JURIS_INDICATOR          VARCHAR2(200),
LOCAL_JURIS_INDIC          VARCHAR2(200),
LOCAL2_JURIS_INDIC          VARCHAR2(200),
COUNTY_JURIS_INDIC          VARCHAR2(200),
SDIT_JURIS_INDICATOR          VARCHAR2(200),
SOSEC_TAX_CRDT_INDIC          VARCHAR2(200),
QTR1_JOB_CREDIT          VARCHAR2(200),
SOSEC_JOB_CREDIT_QTD          VARCHAR2(200),
SOSEC_JOB_CREDIT_YTD          VARCHAR2(200),
TXBL_HLTH_FED_QTD          VARCHAR2(200),
TXBL_HLTH_FED_YTD          VARCHAR2(200),
TXBL_HLTH_STL_QTD          VARCHAR2(200),
TXBL_HLTH_STL_YTD          VARCHAR2(200),
TXBL_HLTH_ALL_QTD          VARCHAR2(200),
TXBL_HLTH_ALL_YTD          VARCHAR2(200),
W2_REPORTING_ER_COST          VARCHAR2(200),
NEG_SS_JOB_CRDT_QTD          VARCHAR2(200),
BIKE_ER_PD_TRNS_QTD          VARCHAR2(200),
BIKE_ER_PD_TRNS_YTD          VARCHAR2(200),
NY_MTA_TAX_QTD          VARCHAR2(200),
NY_MTA_TAX_YTD          VARCHAR2(200),
NY_MTA_WAGES_QTD          VARCHAR2(200),
NY_MTA_WAGES_YTD          VARCHAR2(200),
PRIOR_LOCAL4_TAXES          VARCHAR2(200),
PRIOR_LOCAL5_TAXES          VARCHAR2(200),
ROTH_UNDER_457_QTD          VARCHAR2(200),
ROTH_UNDER_457_YTD          VARCHAR2(200),
PA_LOC_ER_EXP_QTD          VARCHAR2(200),
PA_LOC_ER_EXP_YTD          VARCHAR2(200),
PA_LOC_PSD1_CODE          VARCHAR2(200),
PA_LOC_PSD2_CODE          VARCHAR2(200),
PA_LOC2_RMT_TAX_QTD          VARCHAR2(200),
PA_LOC2_RMT_TAX_YTD          VARCHAR2(200),
PA_LOC2_RMT_WAGE_QTD          VARCHAR2(200),
PA_LOC2_RMT_WAGE_YTD          VARCHAR2(200),
IRR_DISTRIBUTION_YTD          VARCHAR2(200),
SSN_VALIDITY_SWITCH          VARCHAR2(200),
EIN_VALIDITY_SWITCH          VARCHAR2(200),
ROTH_CONTRIB_DATE          VARCHAR2(200),
ESTABLISHMENT_NBR          VARCHAR2(200),
PRIOR_EE_MCARE_SRTX          VARCHAR2(200),
EE_WP_MCARE_SRTX_QTD          VARCHAR2(200),
EE_WP_MCARE_SRTX_YTD          VARCHAR2(200),
EE_MCARE_SURTAX_QTD          VARCHAR2(200),
EE_MCARE_SURTAX_YTD          VARCHAR2(200),
UNCOL_MCARE_SRTX_QTD          VARCHAR2(200),
UNCOL_MCARE_SRTX_YTD          VARCHAR2(200),
THRDP_MCARE_SRTX_QTD          VARCHAR2(200),
THRDP_MCARE_SRTX_YTD          VARCHAR2(200),
KY_LCL_SUB_WAGE_QTD          VARCHAR2(200),
KY_LCL_SUB_WAGE_YTD          VARCHAR2(200),
KY_LCL2_SUB_WAGE_QTD          VARCHAR2(200),
KY_LCL2_SUB_WAGE_YTD          VARCHAR2(200),
EE_SAME_SEX_BEN_YTD          VARCHAR2(200),
EE_SAME_SEX_BEN_QTD          VARCHAR2(200),
ER_SAME_SEX_BEN_YTD          VARCHAR2(200),
ER_SAME_SEX_BEN_QTD          VARCHAR2(200),
VPDI_TAX_QTD          VARCHAR2(200),
VPDI_WAGES_QTD          VARCHAR2(200),
VPDI_WAGES_YTD          VARCHAR2(200),
PRIOR_VPDI_TAX          VARCHAR2(200),
PRIOR_WPDI_WAGES          VARCHAR2(200),
MISC_1099_INDICATOR          VARCHAR2(200),
MISC_1099_2ND_NOTICE          VARCHAR2(200),
DC_SUI_WRKR_REL_CODE          VARCHAR2(200),
DC_SUI_BRD_MBR          VARCHAR2(200),
LA_SUI_SOC_CODE          VARCHAR2(200),
LA_SUI_JOB_TITLE1          VARCHAR2(200),
LA_SUI_JOB_TITLE2          VARCHAR2(200),
LA_SUI_JOB_TITLE3          VARCHAR2(200),
LA_SUI_JOB_TITLE4          VARCHAR2(200),
PRIOR_SUI_WAGE_SPEC          VARCHAR2(200),
PR_YOUTH_EXEMPT_YTD          VARCHAR2(200),
PR_YOUTH_EXEMPT_QTD          VARCHAR2(200),
PR_YOUTH_EXMPT_PRIOR          VARCHAR2(200),
PR_YOUTH_EXMT_OPTOUT          VARCHAR2(200),
VT_ST1_EMPL_TYPE          VARCHAR2(200),
VT_SUI_EMPL_TYPE          VARCHAR2(200),
VT_ST2_EMPL_TYPE          VARCHAR2(200),
HLTH_REIMB_ARR_YTD          VARCHAR2(200),
HLTH_REIMB_ARR_QTD          VARCHAR2(200),
EMPL_DISASTER_YTD          VARCHAR2(200),
VLFI_QTD          VARCHAR2(200),
VLFI_YTD          VARCHAR2(200),
VLFI_WAGES_QTD          VARCHAR2(200),
VLFI_WAGES_YTD          VARCHAR2(200),
VLFI_TAX_PRIOR          VARCHAR2(200),
FLI_TAX_BLOCK          VARCHAR2(200),
LOCAL4_TAX_CD          VARCHAR2(200),
LOCAL5_TAX_CD          VARCHAR2(200),
NYFLI_EARLY_ADOPT           VARCHAR2(200),
OR_TRN_BLOCK          VARCHAR2(200),
OR_TRN_QTD          VARCHAR2(200),
OR_TRN_YTD          VARCHAR2(200),
OR_TRN_WAGES_QTD          VARCHAR2(200),
OR_TRN_WAGES_YTD          VARCHAR2(200),
OR_TRN_TAX_TOT          VARCHAR2(200),
QEG_W_DEF_QTD          VARCHAR2(200),
QEG_W_DEF_YTD          VARCHAR2(200),
QEG_QTD          VARCHAR2(200),
QEG_YTD          VARCHAR2(200),
FLI_SUBJ_WAGES_QTD          VARCHAR2(200),
FLI_SUBJ_WAGES_YTD          VARCHAR2(200),
FLI_TXBL_WAGES_QTD          VARCHAR2(200),
FLI_TXBL_WAGES_YTD          VARCHAR2(200),
FLI_TXBL_WAGES_PRIOR          VARCHAR2(200),
FLI_TAX_QTD          VARCHAR2(200),
FLI_TAX_YTD          VARCHAR2(200),
FLI_TAX_PRIOR          VARCHAR2(200),
MLI_SUBJ_WAGES_QTD          VARCHAR2(200),
MLI_SUBJ_WAGES_YTD          VARCHAR2(200),
MLI_TXBL_WAGES_QTD          VARCHAR2(200),
MLI_TXBL_WAGES_YTD          VARCHAR2(200),
MLI_TXBL_WAGES_PRIOR          VARCHAR2(200),
MLI_TAX_QTD          VARCHAR2(200),
MLI_TAX_YTD          VARCHAR2(200),
MLI_TAX_PRIOR          VARCHAR2(200),
FLI_MLI_HOURS          VARCHAR2(200),
ER_PAID_FLI_QTD          VARCHAR2(200),
ER_PAID_FLI_YTD          VARCHAR2(200),
ER_PAID_MNLI_QTD          VARCHAR2(200),
ER_PAID_FLM_YTD          VARCHAR2(200),
MLI_TAXABLE_BLOCK          VARCHAR2(200),
TRNST_WAGE_XMPT_YTD          VARCHAR2(200),
TRNST_WAGE_XMPT_QTD          VARCHAR2(200),
FLIMLI_WAGE_XMPT_YTD          VARCHAR2(200),
FLIMLI_WAGE_XMPT_QTD          VARCHAR2(200),
EPSL_TXBL_QTD          VARCHAR2(200),
EPSL_TXBL_YTD          VARCHAR2(200),
FML_TXBL_QTD          VARCHAR2(200),
FML_TXBL_YTD          VARCHAR2(200),
EPSL_WAGE_CREDT_QTD          VARCHAR2(200),
EPSL_WAGE_CREDT_YTD          VARCHAR2(200),
FML_WAGE_CREDIT_QTD          VARCHAR2(200),
FML_WAGE_CREDIT_YTD          VARCHAR2(200),
FFCRAEPSL_MED_CR_QTD          VARCHAR2(200),
FFCRAEPSL_MED_CR_YTD          VARCHAR2(200),
FFCRAFML_MED_CR_QTD          VARCHAR2(200),
FFCRAFML_MED_CR_YTD          VARCHAR2(200),
FFCRA_HCARE_CR_QTD          VARCHAR2(200),
FFCRA_HCARE_CR_YTD          VARCHAR2(200),
FFCRA_RETN_WG_CR_QTD          VARCHAR2(200),
FFCRA_RETN_WG_CR_YTD          VARCHAR2(200),
FFCRA_RETN_WG_HC_QTD          VARCHAR2(200),
FFCRA_RETN_WG_HC_YTD		  VARCHAR2(200),
File_END		  VARCHAR2(200),
additiional_info1 varchar2(200),
client_id   VARCHAR2(100) );

ALTER TABLE balance_tax_wages
ADD EMP_1099_NEC_BOX_1 VARCHAR2(200);

ALTER TABLE balance_tax_wages
ADD EMP_SSDEF_Y093_QTD VARCHAR2(200);

ALTER TABLE balance_tax_wages
ADD EMP_SSDEF_Y093_YTD VARCHAR2(200);

ALTER TABLE balance_tax_wages
ADD EMP_SSDEF_PRIOR VARCHAR2(200);

ALTER TABLE balance_tax_wages
ADD EMP_1099_NEC_BOX_1 VARCHAR2(200);

ALTER TABLE balance_tax_wages
ADD EMP_LOC_ER_TAX_QWB VARCHAR2(200);

ALTER TABLE balance_tax_wages
ADD EMP_LOC_ER_TAX_YWB VARCHAR2(200);

ALTER TABLE balance_tax_wages
ADD EMP_ER_PD_SDI_QTD VARCHAR2(200);

ALTER TABLE balance_tax_wages
ADD EMP_ER_PD_SDI_YTD VARCHAR2(200);

ALTER TABLE balance_tax_wages
ADD EMP_3PSP_FLI_QTD VARCHAR2(200);

ALTER TABLE balance_tax_wages
ADD EMP_3PSP_FLI_YTD VARCHAR2(200);

ALTER TABLE balance_tax_wages
ADD EMP_3PSP_FLI_ADJ_QTD VARCHAR2(200);

ALTER TABLE balance_tax_wages
ADD EMP_3PSP_FLI_ADJ_YTD VARCHAR2(200);

ALTER TABLE balance_tax_wages
ADD EMP_UNCOL_LOC_QTD VARCHAR2(200);

ALTER TABLE balance_tax_wages
ADD EMP_UNCOL_LOC_YTD VARCHAR2(200);

ALTER TABLE balance_tax_wages
ADD EMP_UNCOL_LOC2_QTD VARCHAR2(200);

ALTER TABLE balance_tax_wages
ADD EMP_UNCOL_LOC2_YTD VARCHAR2(200);

CREATE TABLE balance_audit_log (
    client_id            VARCHAR2(200),
    client_name          VARCHAR2(200),
    last_run_by          VARCHAR2(200),
    status               VARCHAR2(100),
    audit_type           VARCHAR2(100),
    created_date         DATE DEFAULT SYSDATE,
    recent_update_date   DATE DEFAULT SYSDATE,
    created_id           NUMBER(10),
    additional_info1     VARCHAR(100),
    additional_info2     VARCHAR(100),
    additional_info3     VARCHAR(100),
    additional_info4     VARCHAR(100),
    additional_info5     VARCHAR(100)
);


CREATE TABLE balances_control_totals (
    paygroup     		 VARCHAR2(200),
	file_nbr			 VARCHAR2(200),
	tax_category 	     VARCHAR2(200),
	code        		 VARCHAR2(200),
	tax_amt              VARCHAR2(200),
	taxable              VARCHAR2(200),
	client_id            VARCHAR(100),
    created_date         DATE DEFAULT SYSDATE,
    recent_update_date   DATE DEFAULT SYSDATE,
    created_id           NUMBER(10),
    additional_info1     VARCHAR(100),
    additional_info2     VARCHAR(100),
    additional_info3     VARCHAR(100),
    additional_info4     VARCHAR(100),
    additional_info5     VARCHAR(100)
);

CREATE GLOBAL TEMPORARY TABLE gtt_balances_control_totals (
    paygroup     		 VARCHAR2(200),
	file_nbr			 VARCHAR2(200),
	tax_category 	     VARCHAR2(200),
	code        		 VARCHAR2(200),
	tax_amt              VARCHAR2(200),
	taxable              VARCHAR2(200),
	client_id            VARCHAR(100),
    created_date         DATE DEFAULT SYSDATE,
    recent_update_date   DATE DEFAULT SYSDATE,
    created_id           NUMBER(10),
    additional_info1     VARCHAR(100),
    additional_info2     VARCHAR(100),
    additional_info3     VARCHAR(100),
    additional_info4     VARCHAR(100),
    additional_info5     VARCHAR(100)
)
ON COMMIT DELETE ROWS;

CREATE TABLE balance_xlat_paygroup (
    source_value         VARCHAR2(200),
    xlat_value          VARCHAR2(200),
    client_id            VARCHAR2(200),
    created_date         DATE DEFAULT SYSDATE,
    recent_update_date   DATE DEFAULT SYSDATE,
    created_id           NUMBER(10),
    additional_info1     VARCHAR(100),
    additional_info2     VARCHAR(100),
    additional_info3     VARCHAR(100),
    additional_info4     VARCHAR(100),
    additional_info5     VARCHAR(100)
);

CREATE GLOBAL TEMPORARY TABLE gtt_balance_xlat_paygroup (
    source_value         VARCHAR2(200),
    xlat_value          VARCHAR2(200),
    client_id            VARCHAR2(200),
    created_date         DATE DEFAULT SYSDATE,
    recent_update_date   DATE DEFAULT SYSDATE,
    created_id           NUMBER(10),
    additional_info1     VARCHAR(100),
    additional_info2     VARCHAR(100),
    additional_info3     VARCHAR(100),
    additional_info4     VARCHAR(100),
    additional_info5     VARCHAR(100)
)
ON COMMIT DELETE ROWS;


CREATE TABLE balance_xlat_filenbr (
    emplid               VARCHAR2(200),
    paygroup             VARCHAR2(200),
    file_nbr             VARCHAR2(200),
    client_id            VARCHAR2(200),
    created_date         DATE DEFAULT SYSDATE,
    recent_update_date   DATE DEFAULT SYSDATE,
    created_id           NUMBER(10),
    additional_info1     VARCHAR(100),
    additional_info2     VARCHAR(100),
    additional_info3     VARCHAR(100),
    additional_info4     VARCHAR(100),
    additional_info5     VARCHAR(100)
);

CREATE GLOBAL TEMPORARY TABLE gtt_balance_xlat_filenbr (
    emplid               VARCHAR2(200),
    paygroup             VARCHAR2(200),
    file_nbr             VARCHAR2(200),
    client_id            VARCHAR2(200),
    created_date         DATE DEFAULT SYSDATE,
    recent_update_date   DATE DEFAULT SYSDATE,
    created_id           NUMBER(10),
    additional_info1     VARCHAR(100),
    additional_info2     VARCHAR(100),
    additional_info3     VARCHAR(100),
    additional_info4     VARCHAR(100),
    additional_info5     VARCHAR(100)
)
ON COMMIT DELETE ROWS;

CREATE TABLE balance_xlat_state (
    source_value         VARCHAR2(200),
    xlat_value          VARCHAR2(200),
    client_id            VARCHAR2(200),
    created_date         DATE DEFAULT SYSDATE,
    recent_update_date   DATE DEFAULT SYSDATE,
    created_id           NUMBER(10),
    additional_info1     VARCHAR(100),
    additional_info2     VARCHAR(100),
    additional_info3     VARCHAR(100),
    additional_info4     VARCHAR(100),
    additional_info5     VARCHAR(100)
);

CREATE GLOBAL TEMPORARY TABLE gtt_balance_xlat_state (
    source_value         VARCHAR2(200),
    xlat_value          VARCHAR2(200),
    client_id            VARCHAR2(200),
    created_date         DATE DEFAULT SYSDATE,
    recent_update_date   DATE DEFAULT SYSDATE,
    created_id           NUMBER(10),
    additional_info1     VARCHAR(100),
    additional_info2     VARCHAR(100),
    additional_info3     VARCHAR(100),
    additional_info4     VARCHAR(100),
    additional_info5     VARCHAR(100)
)
ON COMMIT DELETE ROWS;

CREATE TABLE balance_xlat_sui (
    source_value         VARCHAR2(200),
    xlat_value          VARCHAR2(200),
    client_id            VARCHAR2(200),
    created_date         DATE DEFAULT SYSDATE,
    recent_update_date   DATE DEFAULT SYSDATE,
    created_id           NUMBER(10),
    additional_info1     VARCHAR(100),
    additional_info2     VARCHAR(100),
    additional_info3     VARCHAR(100),
    additional_info4     VARCHAR(100),
    additional_info5     VARCHAR(100)
);


CREATE TABLE balance_xlat_local1 (
    source_value         VARCHAR2(200),
    xlat_value          VARCHAR2(200),
    client_id            VARCHAR2(200),
    created_date         DATE DEFAULT SYSDATE,
    recent_update_date   DATE DEFAULT SYSDATE,
    created_id           NUMBER(10),
    additional_info1     VARCHAR(100),
    additional_info2     VARCHAR(100),
    additional_info3     VARCHAR(100),
    additional_info4     VARCHAR(100),
    additional_info5     VARCHAR(100)
);

CREATE TABLE balance_xlat_local2 (
    source_value         VARCHAR2(200),
    xlat_value          VARCHAR2(200),
    client_id            VARCHAR2(200),
    created_date         DATE DEFAULT SYSDATE,
    recent_update_date   DATE DEFAULT SYSDATE,
    created_id           NUMBER(10),
    additional_info1     VARCHAR(100),
    additional_info2     VARCHAR(100),
    additional_info3     VARCHAR(100),
    additional_info4     VARCHAR(100),
    additional_info5     VARCHAR(100)
);



CREATE TABLE balance_xlat_oh_sd (
    source_value         VARCHAR2(200),
    xlat_value          VARCHAR2(200),
    client_id            VARCHAR2(200),
    created_date         DATE DEFAULT SYSDATE,
    recent_update_date   DATE DEFAULT SYSDATE,
    created_id           NUMBER(10),
    additional_info1     VARCHAR(100),
    additional_info2     VARCHAR(100),
    additional_info3     VARCHAR(100),
    additional_info4     VARCHAR(100),
    additional_info5     VARCHAR(100)
);

CREATE TABLE balance_xlat_pa_lst (
    source_value         VARCHAR2(200),
    xlat_value          VARCHAR2(200),
    client_id            VARCHAR2(200),
    created_date         DATE DEFAULT SYSDATE,
    recent_update_date   DATE DEFAULT SYSDATE,
    created_id           NUMBER(10),
    additional_info1     VARCHAR(100),
    additional_info2     VARCHAR(100),
    additional_info3     VARCHAR(100),
    additional_info4     VARCHAR(100),
    additional_info5     VARCHAR(100)
);

-- report gtt tables


CREATE GLOBAL TEMPORARY TABLE gtt_bal_sq_rept_audit_tax (
PAYGROUP                    VARCHAR2(200),
FILE_NBR                    VARCHAR2(200),
CATEGORY                    VARCHAR2(200),
CODE                        VARCHAR2(200),
TAX_AMT                     NUMBER
)
ON COMMIT DELETE ROWS;


CREATE GLOBAL TEMPORARY TABLE gtt_bal_sq_rept_audit_taxable (
PAYGROUP                    VARCHAR2(200),
FILE_NBR                    VARCHAR2(200),
CATEGORY                    VARCHAR2(200),
CODE                        VARCHAR2(200),
TAXABLE                     NUMBER
)
ON COMMIT DELETE ROWS;


CREATE GLOBAL TEMPORARY TABLE gtt_bal_sq_rept_audit_wt_final (
PAYGROUP                    VARCHAR2(200),
FILE_NBR                    VARCHAR2(200),
CATEGORY                    VARCHAR2(200),
CODE                        VARCHAR2(200),
TAX_AMT                     NUMBER,
TAXABLE                     NUMBER
)
ON COMMIT DELETE ROWS;


CREATE GLOBAL TEMPORARY TABLE gtt_bal_sq_rpt_adt_emp_n_xlat (
DESCRIPTION                 VARCHAR2(200),
EMPLID                      VARCHAR2(200),
PAYGROUP                    VARCHAR2(200),
FILE_NBR                    VARCHAR2(200),
CATEGORY                    VARCHAR2(200),
CODE                        VARCHAR2(200),
WAGE_TAX_TAXABLE            NUMBER,
CONTROL_TAXABLE             NUMBER,
DELTA_TAXABLE               NUMBER,
WAGE_TAX_WITHHELD           NUMBER,
CONTROL_WITHHELD            NUMBER,
DELTA_TAX_WITHHELD          NUMBER
)
ON COMMIT DELETE ROWS;

-- report summary table

CREATE TABLE balance_emp_report_summary (
report_id                VARCHAR2(240),
report_name              VARCHAR2(240),
ANALYSIS                 VARCHAR2(240),
DESCRIPTION              VARCHAR2(100),
EMPLID                   VARCHAR2(200),
PAYGROUP                 VARCHAR2(200),
FILE_NBR                 VARCHAR2(200),
CATEGORY                 VARCHAR2(200),
WT_CODE                  VARCHAR2(200),
CT_CODE                  VARCHAR2(200),
WAGE_TAX_TAXABLE         NUMBER,
CONTROL_TAXABLE          NUMBER,
DELTA_TAXABLE            NUMBER,
WAGE_TAX_WITHHELD        NUMBER,
CONTROL_WITHHELD         NUMBER,
DELTA_TAX_WITHHELD       NUMBER
)


CREATE TABLE balance_emp_report_summary_log (
report_id                VARCHAR2(240),
report_name              VARCHAR2(240),
last_run_by          VARCHAR2(200),
status               VARCHAR2(100),
created_date         DATE DEFAULT SYSDATE,
recent_update_date   DATE DEFAULT SYSDATE,
tax_wage_client_id   VARCHAR2(100),
control_tot_client_id    VARCHAR2(100),
translate_client_id  VARCHAR2(100),
additional_info1     VARCHAR(100),
additional_info2     VARCHAR(100),
additional_info3     VARCHAR(100),
additional_info4     VARCHAR(100),
additional_info5     VARCHAR(100)
)

CREATE SEQUENCE balance_emp_report_log_s
START WITH 1
INCREMENT BY 1
NOCACHE;