
Create table nas_lobs(
        file_id             NUMBER(11),
        reference_id        NUMBER(11),
        file_name           varchar(240),
        file_content_type   varchar(240),
        entity_name         varchar(240),
        category_name       varchar(240),
        description         varchar(240),
        upload_date         TIMESTAMP,
        file_data           blob,
        LANGUAGE            varchar(50),
        oracle_charset      varchar(50),
        file_format         varchar(50),
		additional_info1    varchar(100),
		additional_info2    varchar(100),
		additional_info3    varchar(100),
		additional_info4    varchar(100),
		additional_info5    varchar(100));
);


create sequence nas_lobs_s
start with 1
increment by 1
nocache
nocycle;