/*=============================================================================+
 |                                                                             |
 | FILENAME                                                                    |
 |                                                                             |
 |    benefits_db_objects.sql                                                  |
 |                                                                             |
 |                                                                             |
 | DESCRIPTION                                                                 |
 |                                                                             |
 |    Creates Benefits allocations DB Objects                                  |
 |                                                                             |
 | MODIFICATION HISTORY                                                        |
 |                                                                             |
 | 06-Sep-18    Theerdha Sagar Nimmagadda     Created.                         |
 +=============================================================================*/


Create TABLE SCHEDULE_HEADERS(
        SCHEDULE_HEADER_ID        NUMBER(30),
		SCHEDULE_NAME             varchar2(500),
		TASK_ID                   NUMBER,
		FREQUENCY                 varchar2(50),
		EXCLUDE_WEEKEND           varchar2(50),
		DATE_FROM                 TIMESTAMP,
		DATE_TO                   TIMESTAMP,
		TIME_SLOT1                varchar2(100),
		TIME_SLOT2                varchar2(100),
		TIME_SLOT3                varchar2(100),
		TIME_SLOT4                varchar2(100),
        ORG_ID                    NUMBER,
		CREATION_DATE             TIMESTAMP DEFAULT systimestamp,
		ACTIVE_DATE               TIMESTAMP DEFAULT systimestamp,
		LAST_UPDATE_DATE	      TIMESTAMP,
		CREATED_BY                NUMBER(11),
		additional_info1          varchar2(100),
		additional_info2          varchar2(100),
		additional_info3          varchar2(100),
		additional_info4          varchar2(100),
		additional_info5          varchar2(100));


Create TABLE SCHEDULE_LINES(
        SCHEDULE_HEADER_ID   NUMBER(30),
		RUN_DATE             TIMESTAMP,
		TIME_SLOT            varchar2(50),
		GL_DATE              TIMESTAMP,
		STATUS               varchar2(20),
        ZONE                 varchar2(100),
        USER_ID               NUMBER,
		CREATION_DATE        TIMESTAMP,
		LAST_UPDATE_DATE     TIMESTAMP,
		CREATED_BY           NUMBER(11),
		SCHEDULE_LINE_ID    NUMBER(35),
		REQUEST_ID          NUMBER(20),
		DESCRIPTION         varchar2(1000),
		additional_info1    varchar2(100),
		additional_info2    varchar2(100),
		additional_info3    varchar2(100),
		additional_info4    varchar2(100),
		additional_info5    varchar2(100));


create sequence nas_scheduler_header_s
start with 1
increment by 1
nocache
nocycle;

create sequence nas_scheduler_lines_s
start with 1
increment by 1
nocache
nocycle;

create sequence nas_scheduler_header_s
start with 1
increment by 1
nocache
nocycle;

create sequence nas_scheduler_lines_s
start with 1
increment by 1
nocache
nocycle;


BEGIN
DBMS_SCHEDULER.create_job(
job_name => 'ws_notifications',
job_type => 'PLSQL_BLOCK',
job_action => 'declare
               BEGIN
               update wf_notifications set additional_info1 = ''Y'' where begin_date <= SYSDATE and additional_info1 <> ''Y'';
               commit;
               END;',
start_date  => SYSTIMESTAMP,
repeat_interval => 'freq=HOURLY/SECONDLY; interval = 6',
end_date        => NULL,
enabled         => TRUE,
comments        => 'updates user notifications in Scorpion');
END;


BEGIN
  dbms_scheduler.drop_job(job_name => 'ws_notifications');
END;
/

