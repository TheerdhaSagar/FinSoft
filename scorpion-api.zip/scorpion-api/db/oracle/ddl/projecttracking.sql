-- project_location can have Offshore & Onshore as its values

Create TABLE dc_pt_projects(
        project_id            NUMBER,
        project_reference    VARCHAR2(200),
        project_name         VARCHAR2(200),
        product_type         VARCHAR2(50),
        project_manager      VARCHAR2(100),
        delivery_manager     VARCHAR2(100),
        project_status       VARCHAR2(50),
        project_lead         NUMBER,
        project_start_date   DATE,
        project_end_date     DATE,
        project_golive_date  DATE,
        hours_allocated      NUMBER,
        hours_exhausted      NUMBER,
        project_location     VARCHAR2(100) DEFAULT 'OFFSHORE',
        RECENT_UPDATE_DATE   TIMESTAMP DEFAULT systimestamp,
        CREATED_DATE         TIMESTAMP DEFAULT systimestamp,
        recent_updated_user_id NUMBER,
        CREATED_ID           NUMBER(10),
        ref_value_perm       VARCHAR2(100),
		additional_info1     VARCHAR2(100),
		additional_info2     VARCHAR2(100),
		additional_info3     VARCHAR2(100),
		additional_info4     VARCHAR2(100),
		additional_info5     VARCHAR2(100));


create sequence dc_pt_projects_s
start with 1
increment by 1
nocache
nocycle;


Create TABLE dc_pt_project_assignments(
        project_id            NUMBER,
        user_id               NUMBER,
        assignment_description VARCHAR2(500),
        assignment_created_date   DATE,
        assignment_start_date     DATE,
        assignment_end_date  DATE,
        hours_allocated      NUMBER,
        hours_exhausted      NUMBER,
        RECENT_UPDATE_DATE   TIMESTAMP DEFAULT systimestamp,
        CREATED_DATE         TIMESTAMP DEFAULT systimestamp,
        recent_updated_user_id NUMBER,
        CREATED_ID           NUMBER(10),
        ref_value_perm       VARCHAR2(100),
		additional_info1     VARCHAR2(100),
		additional_info2     VARCHAR2(100),
		additional_info3     VARCHAR2(100),
		additional_info4     VARCHAR2(100),
		additional_info5     VARCHAR2(100));


create TABLE dc_pt_product_tasks(
        task_name            VARCHAR2(50),
        product_type         VARCHAR(100),
        task_order           NUMBER,
        task_hours           NUMBER,
        status               VARCHAR(50),
        CREATED_DATE         TIMESTAMP DEFAULT systimestamp,
        RECENT_UPDATE_DATE   TIMESTAMP DEFAULT systimestamp,
        recent_updated_user_id NUMBER,
        CREATED_ID           NUMBER(10),
        ref_value_perm       VARCHAR2(100),
		additional_info1     VARCHAR2(100),
		additional_info2     VARCHAR2(100),
		additional_info3     VARCHAR2(100),
		additional_info4     VARCHAR2(100),
		additional_info5     VARCHAR2(100));


Create TABLE dc_pt_project_rr(
        project_id            NUMBER,
        project_name          VARCHAR2(200),
        resource_user_id      NUMBER,
        created_by            VARCHAR2(500),
        rr_type               VARCHAR2(100),
        rr_created_date       DATE,
        rr_start_date         DATE,
        rr_end_date           DATE,
        hours_allocated      NUMBER,
        RECENT_UPDATE_DATE   TIMESTAMP DEFAULT systimestamp,
        CREATED_DATE         TIMESTAMP DEFAULT systimestamp,
        recent_updated_user_id NUMBER,
        CREATED_ID           NUMBER(10),
        ref_value_perm       VARCHAR2(100),
		additional_info1     VARCHAR2(100),
		additional_info2     VARCHAR2(100),
		additional_info3     VARCHAR2(100),
		additional_info4     VARCHAR2(100),
		additional_info5     VARCHAR2(100));


-- Notes can have General/Spike/Success stories types
Create TABLE dc_pt_notes(
        project_id            NUMBER,
        description          VARCHAR2(4000),
        notes_type           VARCHAR2(100) DEFAULT 'GENERAL',
        RECENT_UPDATE_DATE   TIMESTAMP DEFAULT systimestamp,
        CREATED_DATE         TIMESTAMP DEFAULT systimestamp,
        recent_updated_user_id NUMBER,
        CREATED_ID           NUMBER(10),
        ref_value_perm       VARCHAR2(100),
		additional_info1     VARCHAR2(100),
		additional_info2     VARCHAR2(100),
		additional_info3     VARCHAR2(100),
		additional_info4     VARCHAR2(100),
		additional_info5     VARCHAR2(100));
