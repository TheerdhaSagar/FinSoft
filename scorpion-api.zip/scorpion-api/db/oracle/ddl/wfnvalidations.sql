Create TABLE dc_wfn_setup(
        setup_id             NUMBER(11),
        client_id            VARCHAR2(50),
        setup_type           VARCHAR(100),
        companycode          VARCHAR(100),
        code                 VARCHAR(50),
        description          VARCHAR(500),
        status               VARCHAR(50),
        CREATED_DATE         TIMESTAMP DEFAULT systimestamp,
        RECENT_UPDATE_DATE   TIMESTAMP DEFAULT systimestamp,
        recent_updated_user_id NUMBER,
        CREATED_ID           NUMBER(10),
        ref_value_perm       varchar(100),
		additional_info1     varchar(100),
		additional_info2     varchar(100),
		additional_info3     varchar(100),
		additional_info4     varchar(100),
		additional_info5     varchar(100));

Create TABLE dc_wfn_headers_all(
        header_id             NUMBER(11),
        conversion           VARCHAR(200),
        column_name          VARCHAR(100),
        required_flag        VARCHAR2(10),
        default_value        VARCHAR2(10),
        min_column_length    NUMBER(10),
        max_column_length    NUMBER(10),
        CREATED_DATE         TIMESTAMP DEFAULT systimestamp,
        RECENT_UPDATE_DATE   TIMESTAMP DEFAULT systimestamp,
        recent_updated_user_id NUMBER,
        CREATED_ID           NUMBER(10),
        ref_value_perm       varchar(100),
		additional_info1     varchar(100),
		additional_info2     varchar(100),
		additional_info3     varchar(100),
		additional_info4     varchar(100),
		additional_info5     varchar(100));

CREATE TABLE dc_wfn_source_mf (
    source_id                        NUMBER,
    client_id                        VARCHAR2(50),
    associate_id                     VARCHAR2(100),
    position_id                      VARCHAR2(100),
    change_effective_on              VARCHAR2(100),
    is_paid_by_wfn                   VARCHAR2(50),
    position_uses_time               VARCHAR2(100),
    is_primary                       VARCHAR2(50),
    first_name                       VARCHAR2(100),
    middle_name                      VARCHAR2(100),
    last_name                        VARCHAR2(100),
    generation_suffix                VARCHAR2(50),
    preferred_name                   VARCHAR2(100),
    social_security_number           VARCHAR2(50),
    applied_for_ssn                  VARCHAR2(100),
    address_1_line_1                 VARCHAR2(100),
    address_1_line_2                 VARCHAR2(100),
    address_1_line_3                 VARCHAR2(100),
    address_1_city                   VARCHAR2(100),
    address_1_state_postal_code      VARCHAR2(100),
    address_1_zip_code               VARCHAR2(100),
    address_2_line_1                 VARCHAR2(100),
    address_2_line_2                 VARCHAR2(100),
    address_2_line_3                 VARCHAR2(100),
    address_2_city                   VARCHAR2(100),
    address_2_state_postal_code      VARCHAR2(100),
    address_2_zip_code               VARCHAR2(100),
    birth_date                       VARCHAR2(100),
    hire_date                        VARCHAR2(100),
    hire_reason                      VARCHAR2(100),
    employee_status                  VARCHAR2(100),
    pay_frequency_code               VARCHAR2(100),
    Compensation_change_reason       VARCHAR2(200),
    rate_type                        VARCHAR2(100),
    rate_1_amount                    VARCHAR2(100),
    reports_to_position_id           VARCHAR2(100),
    actual_marital_status            VARCHAR2(100),
    actual_number_of_dependents      VARCHAR2(100),
    eeo_ethnic_code                  VARCHAR2(100),
    home_area_code                   VARCHAR2(100),
    home_phone_number                VARCHAR2(100),
    personal_email_address           VARCHAR2(100),
    business_email_address           VARCHAR2(100),
    email_to_use_for_notification    VARCHAR2(50),
    business_area_code               VARCHAR2(50),
    business_extension               VARCHAR2(50),
    personal_cell_number             VARCHAR2(100),
    business_phone_number            VARCHAR2(50),
    seniority_date                   VARCHAR2(100),
    date_11                          VARCHAR2(100),
    date_12                          VARCHAR2(100),
    date_13                          VARCHAR2(100),
    date_14                          VARCHAR2(100),
    date_15                          VARCHAR2(100),
    clock                            VARCHAR2(100),
    employee_type                    VARCHAR2(100),
    gender                           VARCHAR2(50),
    ncalculate_medicare              VARCHAR2(100),
    ncalculate_social_security       VARCHAR2(100),
    federal_marital_status           VARCHAR2(50),
    federal_exemptions               VARCHAR2(50),
    ncalculate_federal_tax           VARCHAR2(50),
    federal_extra_tax_$              VARCHAR2(50),
    federal_extra_tax_p              VARCHAR2(50),
    worked_state_tax_code            VARCHAR2(50),
    w_state_marital_status           VARCHAR2(50),
    w_state_exemptions               VARCHAR2(50),
    exemptions_in_dollars            VARCHAR2(50),
    state_withholding_table          VARCHAR2(50),
    w_nstate_extra_tax_$             VARCHAR2(50),
    w_nstate_extra_tax_p             VARCHAR2(50),
    w_ncalculate_state_tax           VARCHAR2(50),
    w_ncalc_oregon_transit_tax       VARCHAR2(50),
    lived_state_tax_code             VARCHAR2(50),
    l_state_marital_status           VARCHAR2(50),
    l_state_exemptions               VARCHAR2(50),
    l_state_extra_tax_$              VARCHAR2(50),
    l_state_extra_tax_p              VARCHAR2(50),
    l_ncalculate_state_tax           VARCHAR2(50),
    l_ncalc_oregon_transit_tax       VARCHAR2(50),
    family_leave_insurance           VARCHAR2(50),
    medical_leave_insurance          VARCHAR2(50),
    suisdi_tax_jurisdiction_code     VARCHAR2(50),
    maryland_county_tax_percentage   VARCHAR2(50),
    ohio_local_school_district_tax   VARCHAR2(50),
    ncalc_school_district_tax        VARCHAR2(50),
    worked_local_tax_code            VARCHAR2(50),
    w_local_exemptions               VARCHAR2(50),
    lived_local_tax_code             VARCHAR2(50),
    l_local_exemptions               VARCHAR2(50),
    local_4_tax_code                 VARCHAR2(50),
    local_5_tax_code                 VARCHAR2(50),
    local_extra_tax_$                VARCHAR2(50),
    local_extra_tax_p                VARCHAR2(50),
    created_date                     TIMESTAMP DEFAULT systimestamp,
    recent_update_date               TIMESTAMP DEFAULT systimestamp,
    created_id                       NUMBER,
    recent_updated_user_id           NUMBER,
    additional_info1                 VARCHAR2(100),
    additional_info2                 VARCHAR2(100),
    additional_info3                 VARCHAR2(100),
    additional_info4                 VARCHAR2(100),
    additional_info5                 VARCHAR2(100)
);

Create TABLE DC_WFN_SOURCE_POSITION(
SOURCE_ID                        NUMBER,
CLIENT_ID                        VARCHAR2(50),
POSITION_ID                      VARCHAR2(100),
CHANGE_EFFECTIVE_ON              VARCHAR2(100),
BENEFITS_ELIGIBILITY_CLASS       VARCHAR2(100),
CORP_GROUP_CHANGE_REASON         VARCHAR2(100),
BUSINESS_UNIT                    VARCHAR2(100),
EEOC_JOB_CODE                    VARCHAR2(100),
EMPLOYEE_TYPE                    VARCHAR2(100),
FLSA_CODE                        VARCHAR2(100),
FTE                              VARCHAR2(100),
HOME_COST_NUMBER                 VARCHAR2(100),
HOME_DEPARTMENT                  VARCHAR2(100),
HOURS_PERIOD                     VARCHAR2(100),
JOB_CHANGE_REASON                VARCHAR2(100),
JOB_CLASS                        VARCHAR2(100),
JOB_FUNCTION                     VARCHAR2(100),
JOB_TITLE                        VARCHAR2(100),
LOCATION_CODE                    VARCHAR2(100),
EMPLOYEE_IS_SUPERVISOR           VARCHAR2(100),
NAICS_WORKERS_COMP_CODE          VARCHAR2(100),
SCHEDULED_HOURS                  VARCHAR2(100),
SHIFT                            VARCHAR2(100),
UNION_CODE                       VARCHAR2(100),
UNION_LOCAL                      VARCHAR2(100),
OFFICER_OWNER_INDICATOR          VARCHAR2(100),
EEO_ESTABLISHMENT                VARCHAR2(100),
HIRE_DATE                        VARCHAR2(100),
TERMINATION_DATE                 VARCHAR2(100),
LEAVE_OF_ABSENCE_START_DATE       VARCHAR2(100),
RATE_START_DATE                    VARCHAR2(100),
STATIC_DATE                       VARCHAR2(100),
EMPLOYEE_STATUS                   VARCHAR2(100),
CREATED_DATE                     TIMESTAMP DEFAULT systimestamp,
RECENT_UPDATE_DATE               TIMESTAMP DEFAULT systimestamp,
CREATED_ID                       NUMBER,
RECENT_UPDATED_USER_ID           NUMBER,
ADDITIONAL_INFO1                 VARCHAR2(100),
ADDITIONAL_INFO2                 VARCHAR2(100),
ADDITIONAL_INFO3                 VARCHAR2(100),
ADDITIONAL_INFO4                 VARCHAR2(100),
ADDITIONAL_INFO5                 VARCHAR2(100));


Create TABLE DC_WFN_SOURCE_PAYRATE(
SOURCE_ID                        NUMBER,
CLIENT_ID                        VARCHAR2(50),
POSITION_ID                      VARCHAR2(100),
CHANGE_EFFECTIVE_ON              VARCHAR2(100),
PAY_FREQUENCY_CODE               VARCHAR2(100),
STANDARD_HOURS                   VARCHAR2(100),
PAY_GROUP                        VARCHAR2(100),
RATE_TYPE                        VARCHAR2(100),
RATE_1_AMOUNT                    VARCHAR2(100),
RATE_2_AMOUNT                    VARCHAR2(100),
RATE_3_AMOUNT                    VARCHAR2(100),
RATE_4_AMOUNT                    VARCHAR2(100),
RATE_5_AMOUNT                    VARCHAR2(100),
RATE_6_AMOUNT                    VARCHAR2(100),
RATE_7_AMOUNT                    VARCHAR2(100),
RATE_8_AMOUNT                    VARCHAR2(100),
RATE_9_AMOUNT                    VARCHAR2(100),
ADDITIONAL_EARNINGS_CODE         VARCHAR2(100),
ADDITIONAL_EARNINGS_AMOUNT       VARCHAR2(100),
COMPENSATION_CHANGE_REASON       VARCHAR2(100),
HIRE_DATE                        VARCHAR2(100),
TERMINATION_DATE                 VARCHAR2(100),
LEAVE_OF_ABSENCE_START_DATE       VARCHAR2(100),
RATE_START_DATE                    VARCHAR2(100),
STATIC_DATE                       VARCHAR2(100),
EMPLOYEE_STATUS                   VARCHAR2(100),
CREATED_DATE                     TIMESTAMP DEFAULT systimestamp,
RECENT_UPDATE_DATE               TIMESTAMP DEFAULT systimestamp,
CREATED_ID                       NUMBER,
RECENT_UPDATED_USER_ID           NUMBER,
ADDITIONAL_INFO1                 VARCHAR2(100),
ADDITIONAL_INFO2                 VARCHAR2(100),
ADDITIONAL_INFO3                 VARCHAR2(100),
ADDITIONAL_INFO4                 VARCHAR2(100),
ADDITIONAL_INFO5                 VARCHAR2(100));


Create TABLE DC_WFN_SOURCE_DIR_DEP(
SOURCE_ID                        NUMBER,
CLIENT_ID                        VARCHAR2(50),
POSITION_ID                      VARCHAR2(100),
CHANGE_EFFECTIVE_ON              VARCHAR2(100),
BANK_DEPOSIT_DEDUCTION_CODE      VARCHAR2(100),
BANK_DEPOSIT_DEDUCTION_AMT       VARCHAR2(100),
BANK_DEPOSIT_PERCENT_NET         VARCHAR2(100),
BANK_DEPOSIT_ACCOUNT_NBR         VARCHAR2(100),
BANK_DEPOSIT_TRANSIT_ABA         VARCHAR2(100),
BANK_FULL_DEPOSIT_FLAG           VARCHAR2(100),
BANK_DEPOSIT_PRENOTE_CODE        VARCHAR2(100),
BANK_DEPOSIT_PRENOTE_DATE        VARCHAR2(100),
HIRE_DATE                        VARCHAR2(100),
TERMINATION_DATE                 VARCHAR2(100),
LEAVE_OF_ABSENCE_START_DATE       VARCHAR2(100),
JOB_START_DATE                    VARCHAR2(100),
STATIC_DATE                       VARCHAR2(100),
EMPLOYEE_STATUS                   VARCHAR2(100),
CREATED_DATE                     TIMESTAMP DEFAULT systimestamp,
RECENT_UPDATE_DATE               TIMESTAMP DEFAULT systimestamp,
CREATED_ID                       NUMBER,
RECENT_UPDATED_USER_ID           NUMBER,
ADDITIONAL_INFO1                 VARCHAR2(100),
ADDITIONAL_INFO2                 VARCHAR2(100),
ADDITIONAL_INFO3                 VARCHAR2(100),
ADDITIONAL_INFO4                 VARCHAR2(100),
ADDITIONAL_INFO5                 VARCHAR2(100));


Create TABLE DC_WFN_SOURCE_DEDUCTIONS(
SOURCE_ID                        NUMBER,
CLIENT_ID                        VARCHAR2(50),
POSITION_ID                      VARCHAR2(100),
CHANGE_EFFECTIVE_ON              VARCHAR2(100),
DEDUCTION_CODE                   VARCHAR2(100),
DEDUCTION_AMT                    VARCHAR2(100),
DEDUCTION_FACTOR                 VARCHAR2(100),
GOAL_DEDUCTION_CODE              VARCHAR2(100),
GOAL_POSITION_NBR                VARCHAR2(100),
GOAL_LIMIT                       VARCHAR2(100),
GOAL_ACCRUAL_ADJUSTMENT          VARCHAR2(100),
HIRE_DATE                        VARCHAR2(100),
TERMINATION_DATE                 VARCHAR2(100),
LEAVE_OF_ABSENCE_START_DATE      VARCHAR2(100),
JOB_START_DATE                   VARCHAR2(100),
STATIC_DATE                      VARCHAR2(100),
EMPLOYEE_STATUS                  VARCHAR2(100),
CREATED_DATE                     TIMESTAMP DEFAULT systimestamp,
RECENT_UPDATE_DATE               TIMESTAMP DEFAULT systimestamp,
CREATED_ID                       NUMBER,
RECENT_UPDATED_USER_ID           NUMBER,
ADDITIONAL_INFO1                 VARCHAR2(100),
ADDITIONAL_INFO2                 VARCHAR2(100),
ADDITIONAL_INFO3                 VARCHAR2(100),
ADDITIONAL_INFO4                 VARCHAR2(100),
ADDITIONAL_INFO5                 VARCHAR2(100));


Create TABLE DC_WFN_SOURCE_STATUS(
SOURCE_ID                        NUMBER,
CLIENT_ID                        VARCHAR2(50),
POSITION_ID                      VARCHAR2(100),
CHANGE_EFFECTIVE_ON              VARCHAR2(100),
EMPLOYEE_STATUS                  VARCHAR2(100),
TERMINATION_DATE                 VARCHAR2(100),
TERMINATION_REASON               VARCHAR2(100),
TERMINATION_COMMENTS             VARCHAR2(100),
ELIGIBLE_FOR_REHIRE              VARCHAR2(100),
LEAVE_OF_ABSENCE_START_DATE      VARCHAR2(100),
LEAVE_OF_ABSENCE_REASON          VARCHAR2(100),
LEAVE_OF_ABSENCE_IS_PAID         VARCHAR2(100),
LEAVE_OF_ABSENCE_EXP_RET_DATE    VARCHAR2(100),
LEAVE_OF_ABSENCE_RETURN_DATE     VARCHAR2(100),
LEAVE_OF_ABSENCE_RETURN_REASON   VARCHAR2(100),
HIRE_DATE                        VARCHAR2(100),
JOB_START_DATE                   VARCHAR2(100),
STATIC_DATE                      VARCHAR2(100),
CREATED_DATE                     TIMESTAMP DEFAULT systimestamp,
RECENT_UPDATE_DATE               TIMESTAMP DEFAULT systimestamp,
CREATED_ID                       NUMBER,
RECENT_UPDATED_USER_ID           NUMBER,
ADDITIONAL_INFO1                 VARCHAR2(100),
ADDITIONAL_INFO2                 VARCHAR2(100),
ADDITIONAL_INFO3                 VARCHAR2(100),
ADDITIONAL_INFO4                 VARCHAR2(100),
ADDITIONAL_INFO5                 VARCHAR2(100));


Create TABLE dc_client_info(
        client_id            VARCHAR2(50),
        client_name          VARCHAR2(100),
        project_manager      VARCHAR2(100),
        ic                   VARCHAR2(100),
        mft_details          VARCHAR2(100),
        shared_path          VARCHAR2(100),
        project_start_date   TIMESTAMP,
        go_live_date         TIMESTAMP,
        project_scope        VARCHAR2(100),
        product              VARCHAR(50),
        CREATED_DATE         TIMESTAMP DEFAULT systimestamp,
        RECENT_UPDATE_DATE   TIMESTAMP DEFAULT systimestamp,
        CREATED_ID           NUMBER(10),
        recent_updated_user_id NUMBER,
		additional_info1     varchar(100),
		additional_info2     varchar(100),
		additional_info3     varchar(100),
		additional_info4     varchar(100),
		additional_info5     varchar(100));


Create TABLE dc_wfn_validations_error_log(
        error_id             NUMBER,
        client_id            VARCHAR2(50),
        conversion_name      VARCHAR2(50),
        position_id          VARCHAR2(50),
        employee_name        VARCHAR2(100),
        field_name           VARCHAR2(100),
        field_value          VARCHAR2(100),
        error_type           VARCHAR2(100),
        error_level          VARCHAR2(100),
        error_message        VARCHAR2(1000),
        CREATED_DATE         TIMESTAMP DEFAULT systimestamp,
        RECENT_UPDATE_DATE   TIMESTAMP DEFAULT systimestamp,
        CREATED_ID           NUMBER(10),
        recent_updated_user_id NUMBER,
		additional_info1     varchar2(100),
		additional_info2     varchar2(100),
		additional_info3     varchar2(100),
		additional_info4     varchar2(100),
		additional_info5     varchar2(100));

Create TABLE nas_issue_tracker (
        issue_id             NUMBER(11),
        issue_task           VARCHAR(100),
        issue_sub_task       VARCHAR(100),
        error_message      CLOB,
        issue_desc         CLOB,
        issue_resolution   CLOB,
        ACTIVE_DATE          TIMESTAMP DEFAULT systimestamp,
        RECENT_UPDATE_DATE   TIMESTAMP DEFAULT systimestamp,
        recent_updated_user_id NUMBER,
        created_id           NUMBER(10),
        org_id             NUMBER(10),
		additional_info1     varchar(100),
		additional_info2     varchar(100),
		additional_info3     varchar(100),
		additional_info4     varchar(100),
		additional_info5     varchar(100));


CREATE TABLE wfn_log (
    client_id            VARCHAR2(50),
    conversion_name      VARCHAR2(100),
    last_run_by          VARCHAR2(200),
    status               VARCHAR2(100),
    created_date         DATE DEFAULT SYSDATE,
    recent_update_date   DATE DEFAULT SYSDATE,
    created_id           NUMBER(10),
    additional_info1     VARCHAR(100),
    additional_info2     VARCHAR(100),
    additional_info3     VARCHAR(100),
    additional_info4     VARCHAR(100),
    additional_info5     VARCHAR(100)
);


create sequence nas_client_info_s
start with 1
increment by 1
nocache
nocycle;

create sequence dc_wfn_setup_s
start with 1
increment by 1
nocache
nocycle;

create sequence dc_wfn_source_mf_s
start with 1
increment by 1
nocache
nocycle;

create sequence dc_wfn_source_position_s
start with 1
increment by 1
nocache
nocycle;

create sequence dc_wfn_source_pay_rate_s
start with 1
increment by 1
nocache
nocycle;

create sequence dc_wfn_source_direct_dip_s
start with 1
increment by 1
nocache
nocycle;

create sequence dc_wfn_source_deductions_s
start with 1
increment by 1
nocache
nocycle;

create sequence dc_wfn_source_status_s
start with 1
increment by 1
nocache
nocycle;

create sequence nas_issue_tracker_s
start with 1
increment by 1
nocache
nocycle;