/*=============================================================================+
 |                                                                             |
 | FILENAME                                                                    |
 |                                                                             |
 |    benefits_db_objects.sql                                                  |
 |                                                                             |
 |                                                                             |
 | DESCRIPTION                                                                 |
 |                                                                             |
 |    Creates Benefits allocations DB Objects                                  |
 |                                                                             |
 | MODIFICATION HISTORY                                                        |
 |                                                                             |
 | 06-Sep-18    Theerdha Sagar Nimmagadda    Created.                         |
 +=============================================================================*/



Create TABLE NAS_USERS(
        USER_ID             NUMBER(11),
		USER_NAME           varchar(100) PRIMARY KEY,
		FIRST_NAME          varchar(50),
		LAST_NAME           varchar(50),
		EMPLID              NUMBER(10),
		ES_ID               varchar(30),
		Team                varchar(20),
		ENCRYPTED_PASSWORD  varchar(100),
		Reporting_Manager   varchar(20),
		EMAIL_ADDRESS       varchar(100),
		Telephone           NUMBER(15),
		USER_DESCRIPTION    varchar(100),
		CREATED_DATE        TIMESTAMP DEFAULT systimestamp,
		ACTIVE_DATE         TIMESTAMP DEFAULT systimestamp,
		RECENT_UPDATE_DATE	 TIMESTAMP,
		INACTIVE_DATE       TIMESTAMP,
		LAST_LOGON_DATE     TIMESTAMP,
		STATUS              varchar(10) default 'A',
		DEBUG_FLAG          varchar(10) default 'N',
		CHANGE_FLAG         varchar(10) default 'Y',
		additional_info1    varchar(100),
		additional_info2    varchar(100),
		additional_info3    varchar(100),
		additional_info4    varchar(100),
		additional_info5    varchar(100));

Create TABLE nas_managers(
        user_id           NUMBER(11),
		full_name           varchar(50),
		EMAIL_ADDRESS       varchar(100),
		CREATED_DATE        TIMESTAMP DEFAULT systimestamp,
		ACTIVE_DATE         TIMESTAMP DEFAULT systimestamp,
		effective_end_date	TIMESTAMP,
		INACTIVE_DATE       TIMESTAMP,
		additional_info1    varchar(100),
		additional_info2    varchar(100),
		additional_info3    varchar(100),
		additional_info4    varchar(100),
		additional_info5    varchar(100));

Create TABLE ROLES(
        ROLE_ID             NUMBER(11),
        ROLE_CODE           VARCHAR(50),
        ROLE_DESCRIPTION    VARCHAR(100),
        CREATED_DATE        TIMESTAMP DEFAULT systimestamp,
        ACTIVE_DATE         TIMESTAMP,
        RECENT_UPDATE_DATE	TIMESTAMP,
        INACTIVE_DATE       TIMESTAMP,
        CREATED_ID          NUMBER(10),
		additional_info1    varchar(100),
		additional_info2    varchar(100),
		additional_info3    varchar(100),
		additional_info4    varchar(100),
		additional_info5    varchar(100));

Create TABLE PERMISSIONS(
        PERMISSION_ID             NUMBER(11),
        PERMISSION_CODE           VARCHAR(50),
        PERMISSION_DESCRIPTION    VARCHAR(100),
        CREATED_DATE              TIMESTAMP DEFAULT systimestamp,
        ACTIVE_DATE               TIMESTAMP,
		RECENT_UPDATE_DATE		  TIMESTAMP,
        INACTIVE_DATE             TIMESTAMP,
        CREATED_ID                NUMBER(10),
		additional_info1          varchar(100),
		additional_info2          varchar(100),
		additional_info3          varchar(100),
		additional_info4          varchar(100),
		additional_info5          varchar(100));

Create TABLE PERMISSIONS_LOOKUP(
        LOOKUP_CODE               VARCHAR(50),
        LOOKUP_MEANING            VARCHAR(100),
        CREATED_DATE              TIMESTAMP DEFAULT systimestamp,
		additional_info1          varchar(100),
		additional_info2          varchar(100),
		additional_info3          varchar(100),
		additional_info4          varchar(100),
		additional_info5          varchar(100));


Create TABLE ROLE_PERMISSIONS(
        ROLE_ID             NUMBER(11),
        PERMISSION_ID       NUMBER(11),
        PERMISSION_CODE     VARCHAR(50),
        ACTIVE_DATE               TIMESTAMP,
		RECENT_UPDATE_DATE		  TIMESTAMP,
        INACTIVE_DATE             TIMESTAMP,
        CREATED_ID                NUMBER(10),
        CREATED_DATE              TIMESTAMP,
		additional_info1    varchar(100),
		additional_info2    varchar(100),
		additional_info3    varchar(100),
		additional_info4    varchar(100),
		additional_info5    varchar(100));


Create TABLE USER_ROLES(
        USER_ID             NUMBER(11),
        ROLE_ID             NUMBER(11),
        ROLE_CODE           VARCHAR(50),
        ACTIVE_DATE         TIMESTAMP,
        RECENT_UPDATE_DATE  TIMESTAMP,
        INACTIVE_DATE       TIMESTAMP,
        CREATE_DATE         TIMESTAMP,
        CREATED_ID          NUMBER(10),
		additional_info1    varchar(100),
		additional_info2    varchar(100),
		additional_info3    varchar(100),
		additional_info4    varchar(100),
		additional_info5    varchar(100));

Create TABLE bs_api_management(
        client_id           NUMBER(11),
        api_key             VARCHAR(100),
        api_secret          VARCHAR(100),
        client_name         VARCHAR(100),
        ACTIVE_DATE         TIMESTAMP,
        RECENT_UPDATE_DATE  TIMESTAMP,
        INACTIVE_DATE       TIMESTAMP,
        CREATED_BY          VARCHAR(100),
        CREATED_ID          NUMBER(10),
		additional_info1    varchar(100),
		additional_info2    varchar(100),
		additional_info3    varchar(100),
		additional_info4    varchar(100),
		additional_info5    varchar(100));


Create TABLE nas_teams(
        team_id              NUMBER(11),
        team_name            VARCHAR(100),
        reporting_manager    VARCHAR(100),
        emailer_list         VARCHAR(1000),
        ACTIVE_DATE          TIMESTAMP DEFAULT systimestamp,
        RECENT_UPDATE_DATE   TIMESTAMP DEFAULT systimestamp,
        recent_updated_user_id NUMBER,
        REPORTING_MANAGER_ID NUMBER,
        INACTIVE_DATE        TIMESTAMP,
        CREATED_BY           VARCHAR(100),
        CREATED_ID           NUMBER(10),
        ref_value_perm       varchar(100),
		additional_info1     varchar(100),
		additional_info2     varchar(100),
		additional_info3     varchar(100),
		additional_info4     varchar(100),
		additional_info5     varchar(100));


Create TABLE task_manager_header(
        task_header_id      NUMBER(11),
        task_header_name    VARCHAR(100),
        task_description    VARCHAR(1000),
        status              VARCHAR(100),
        module              VARCHAR(100),
        team_id             NUMBER,
        TOTAL_TIME          NUMBER,
        task_owner          VARCHAR(200),
        ACTIVE_DATE         TIMESTAMP DEFAULT systimestamp,
        RECENT_UPDATE_DATE  TIMESTAMP DEFAULT systimestamp,
        recent_updated_user_id NUMBER,
        INACTIVE_DATE       TIMESTAMP,
        CREATED_BY          VARCHAR(100),
        CREATED_ID          NUMBER(10),
		additional_info1    varchar(100),
		additional_info2    varchar(100),
		additional_info3    varchar(100),
		additional_info4    varchar(100),
		additional_info5    varchar(100));


Create TABLE task_manager_lines(
        task_line_id        NUMBER(11),
        task_header_id      NUMBER(11),
        task_name           VARCHAR(100),
        task_description    VARCHAR(100),
        task_weight         NUMBER,
        task_hours          NUMBER,
        task_minutes        NUMBER,
        status              VARCHAR(100),
        ACTIVE_DATE         TIMESTAMP DEFAULT systimestamp,
        RECENT_UPDATE_DATE  TIMESTAMP DEFAULT systimestamp,
        recent_updated_user_id NUMBER,
        INACTIVE_DATE       TIMESTAMP,
        CREATED_BY          VARCHAR(100),
        CREATED_ID          NUMBER(10),
		additional_info1    varchar(100),
		additional_info2    varchar(100),
		additional_info3    varchar(100),
		additional_info4    varchar(100),
		additional_info5    varchar(100));

Create TABLE work_calendar(
        work_calendar_id    NUMBER(11),
        calendar_name       VARCHAR(100),
        log_in_time         VARCHAR(100),
        log_out_time        VARCHAR(100),
        week_offs           VARCHAR(100),
        team_id             NUMBER,
        status              VARCHAR(100) DEFAULT 'A',
        ACTIVE_DATE         TIMESTAMP DEFAULT systimestamp,
        RECENT_UPDATE_DATE  TIMESTAMP DEFAULT systimestamp,
        recent_updated_user_id NUMBER,
        INACTIVE_DATE       TIMESTAMP,
        CREATED_ID          NUMBER(10),
		additional_info1    varchar(100),
		additional_info2    varchar(100),
		additional_info3    varchar(100),
		additional_info4    varchar(100),
		additional_info5    varchar(100));


Create TABLE employee_work_calendar(
        work_calendar_id     NUMBER(11),
        user_id              NUMBER(11),
        RECENT_UPDATE_DATE  TIMESTAMP DEFAULT systimestamp,
        recent_updated_user_id NUMBER,
		additional_info1    varchar(100),
		additional_info2    varchar(100),
		additional_info3    varchar(100),
		additional_info4    varchar(100),
		additional_info5    varchar(100));

Create TABLE wf_notifications(
        NOTIFICATION_ID     NUMBER(11),
        MESSAGE_TYPE        VARCHAR(100),
        MESSAGE_NAME        VARCHAR(100),
        RECIPIENT_ROLE      VARCHAR(100),
        STATUS             VARCHAR(100),
        MAIL_STATUS         VARCHAR(100),
        PRIORITY            VARCHAR(100),
        BEGIN_DATE         TIMESTAMP DEFAULT systimestamp,
        END_DATE            TIMESTAMP,
        DUE_DATE            TIMESTAMP,
        RESPONDER            NUMBER,
        ORIGINAL_RECIPIENT  varchar(1000),
        FROM_USER           NUMBER,
        TO_USER             NUMBER,
        SUBJECT             varchar(2500),
        item_key            varchar2(100),
        USER_COMMENT        varchar(2000),
		additional_info1    varchar(100),
		additional_info2    varchar(100),
		additional_info3    varchar(100),
		additional_info4    varchar(100),
		additional_info5    varchar(100));

(NOTIFICATION_ID,GROUP_ID,MESSAGE_TYPE,MESSAGE_NAME,RECIPIENT_ROLE,STATUS,ACCESS_KEY,MAIL_STATUS,
PRIORITY,BEGIN_DATE,END_DATE,DUE_DATE,RESPONDER,USER_COMMENT,CALLBACK,CONTEXT,ORIGINAL_RECIPIENT,
FROM_USER,TO_USER,SUBJECT,LANGUAGE,MORE_INFO_ROLE,FROM_ROLE,SECURITY_GROUP_ID,USER_KEY,ITEM_KEY,
PROTECTED_TEXT_ATTRIBUTE1,PROTECTED_TEXT_ATTRIBUTE2,PROTECTED_TEXT_ATTRIBUTE3,PROTECTED_TEXT_ATTRIBUTE4,
PROTECTED_TEXT_ATTRIBUTE5,PROTECTED_TEXT_ATTRIBUTE6,PROTECTED_TEXT_ATTRIBUTE7,PROTECTED_TEXT_ATTRIBUTE8,
PROTECTED_TEXT_ATTRIBUTE9,PROTECTED_TEXT_ATTRIBUTE10,PROTECTED_FORM_ATTRIBUTE1,PROTECTED_FORM_ATTRIBUTE2,
PROTECTED_FORM_ATTRIBUTE3,PROTECTED_FORM_ATTRIBUTE4,PROTECTED_FORM_ATTRIBUTE5,PROTECTED_URL_ATTRIBUTE1,
PROTECTED_URL_ATTRIBUTE2,PROTECTED_URL_ATTRIBUTE3,PROTECTED_URL_ATTRIBUTE4,PROTECTED_URL_ATTRIBUTE5,
PROTECTED_DATE_ATTRIBUTE1,PROTECTED_DATE_ATTRIBUTE2,PROTECTED_DATE_ATTRIBUTE3,PROTECTED_DATE_ATTRIBUTE4,
PROTECTED_DATE_ATTRIBUTE5,PROTECTED_NUMBER_ATTRIBUTE1,PROTECTED_NUMBER_ATTRIBUTE2,
PROTECTED_NUMBER_ATTRIBUTE3,PROTECTED_NUMBER_ATTRIBUTE4,PROTECTED_NUMBER_ATTRIBUTE5,TEXT_ATTRIBUTE1,
TEXT_ATTRIBUTE2,TEXT_ATTRIBUTE3,TEXT_ATTRIBUTE4,TEXT_ATTRIBUTE5,TEXT_ATTRIBUTE6,TEXT_ATTRIBUTE7,
TEXT_ATTRIBUTE8,TEXT_ATTRIBUTE9,TEXT_ATTRIBUTE10,FORM_ATTRIBUTE1,FORM_ATTRIBUTE2,FORM_ATTRIBUTE3,
FORM_ATTRIBUTE4,FORM_ATTRIBUTE5,URL_ATTRIBUTE1,URL_ATTRIBUTE2,URL_ATTRIBUTE3,URL_ATTRIBUTE4,
URL_ATTRIBUTE5,DATE_ATTRIBUTE1,DATE_ATTRIBUTE2,DATE_ATTRIBUTE3,DATE_ATTRIBUTE4,DATE_ATTRIBUTE5,
NUMBER_ATTRIBUTE1,NUMBER_ATTRIBUTE2,NUMBER_ATTRIBUTE3,NUMBER_ATTRIBUTE4,NUMBER_ATTRIBUTE5)
values (1487345,1487345,'OMERROR','OMERROR_MSG','SYSADMIN','CLOSED','37212085548363871022234677400496679372','FAILED',50,
to_date('04-05-11','DD-MM-RR'),null,to_date('07-05-11','DD-MM-RR'),null,null,
'WF_ENGINE.CB','OMERROR:WF115747:177416','SYSADMIN',null,'SYSADMIN ALMO',
'OM Error in Workflow Order Type: IT Return No Credit, Return Order 127628 3120: Activity ''OEOH/176246'' has no performer.','US',
null,null,null,null,'WF115747',

create sequence nas_user_id_s
start with 1
increment by 1
nocache
nocycle;

create sequence nas_roles_s
start with 1
increment by 1
nocache
nocycle;

create sequence nas_permissions_s
start with 1
increment by 1
nocache
nocycle;

create sequence nas_teams_s
start with 1
increment by 1
nocache
nocycle;

create sequence task_manager_header_s
start with 1
increment by 1
nocache
nocycle;

create sequence task_manager_lines_s
start with 1
increment by 1
nocache
nocycle;

create sequence work_calendar_s
start with 1
increment by 1
nocache
nocycle;

create sequence wf_notifications_S
start with 1
increment by 1
nocache
nocycle;
