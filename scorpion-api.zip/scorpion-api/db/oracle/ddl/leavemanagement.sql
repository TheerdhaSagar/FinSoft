/*=============================================================================+
 |                                                                             |
 | FILENAME                                                                    |
 |                                                                             |
 |    NAS_db_objects_leave_management.sql                                     |
 |                                                                             |
 |                                                                             |
 |                                                                             |
 | MODIFICATION HISTORY                                                        |
 |                                                                             |
 | 5-Nov-18    Theerdha Sagar Nimmagadda     Created.                         |
 +=============================================================================*/


-- Leave management tables
CREATE TABLE NAS_LEAVE_MANAGEMENT
    (
        LEAVE_ID               NUMBER,
        LEAVE_TYPE_ID          NUMBER,
        FROM_DATE              TIMESTAMP(6),
        UPTO_DATE              TIMESTAMP(6),
        REASON                 VARCHAR2(1000),
        APPLIED_BY             NUMBER,
        ORG_ID                 NUMBER,
        CREATED_DATE           TIMESTAMP(6),
        RECENT_UPDATE_DATE     TIMESTAMP(6),
        STATUS                 VARCHAR2(20),
        MANAGER_USER_ID        NUMBER,
        RECENT_UPDATED_USER_ID NUMBER,
        ADDITIONAL_INFO_GROUP  VARCHAR2(60),
        ADDITIONAL_INFO_1      VARCHAR2(240),
        ADDITIONAL_INFO_2      VARCHAR2(240),
        ADDITIONAL_INFO_3      VARCHAR2(240),
        ADDITIONAL_INFO_4      VARCHAR2(240),
        ADDITIONAL_INFO_5      VARCHAR2(240),
        ADDITIONAL_INFO_6      VARCHAR2(240),
        ADDITIONAL_INFO_7      VARCHAR2(240),
        ADDITIONAL_INFO_8      VARCHAR2(240),
        ADDITIONAL_INFO_9      VARCHAR2(240),
        ADDITIONAL_INFO_10     VARCHAR2(240)
    );

CREATE TABLE NAS_LEAVE_DETAILS
    (
        LEAVE_ID               NUMBER ,
        LEAVE_DETAIL_ID        NUMBER ,
        LEAVE_DATE             DATE ,
        FULL_DAY               VARCHAR2(10) ,
        LEAVE_FROM_TIME        VARCHAR2(10) ,
        LEAVE_HOURS            VARCHAR2(10) ,
        CREATED_DATE           TIMESTAMP(6) ,
        CREATED_USER_ID        NUMBER ,
        RECENT_UDPATE_DATE     TIMESTAMP(6) ,
        RECENT_UPDATED_USER_ID NUMBER ,
        ADDITIONAL_INFO_1      VARCHAR2(240) ,
        ADDITIONAL_INFO_2      VARCHAR2(240) ,
        ADDITIONAL_INFO_3      VARCHAR2(240) ,
        ADDITIONAL_INFO_4      VARCHAR2(240) ,
        ADDITIONAL_INFO_5      VARCHAR2(240) ,
        ADDITIONAL_INFO_6      VARCHAR2(240) ,
        ADDITIONAL_INFO_7      VARCHAR2(240) ,
        ADDITIONAL_INFO_8      VARCHAR2(240) ,
        ADDITIONAL_INFO_9      VARCHAR2(240) ,
        ADDITIONAL_INFO_10     VARCHAR2(240)
    );

CREATE TABLE NAS_LEAVE_TYPES
    (
        LEAVE_TYPE_ID          NUMBER ,
        LEAVE_TYPE             VARCHAR2(50) ,
        DESCRIPTION            VARCHAR2(1000) ,
        ORG_ID                 NUMBER ,
        LEAVE_COUNT            NUMBER ,
        YEAR                   NUMBER ,
        ALLOW_HOURLY           VARCHAR2(10),
        CREATED_BY             NUMBER ,
        CREATED_DATE           TIMESTAMP(6) ,
        RECENT_UPDATE_DATE     TIMESTAMP(6) ,
        RECENT_UPDATED_USER_ID NUMBER ,
        ADDITIONAL_INFO_GROUP  VARCHAR2(60) ,
        ADDITIONAL_INFO_1      VARCHAR2(240) ,
        ADDITIONAL_INFO_2      VARCHAR2(240) ,
        ADDITIONAL_INFO_3      VARCHAR2(240) ,
        ADDITIONAL_INFO_4      VARCHAR2(240) ,
        ADDITIONAL_INFO_5      VARCHAR2(240) ,
        ADDITIONAL_INFO_6      VARCHAR2(240) ,
        ADDITIONAL_INFO_7      VARCHAR2(240) ,
        ADDITIONAL_INFO_8      VARCHAR2(240) ,
        ADDITIONAL_INFO_9      VARCHAR2(240) ,
        ADDITIONAL_INFO_10     VARCHAR2(240)
    );

CREATE TABLE NAS_HOLIDAY_CALENDER
    (
        HOLIDAY_ID             NUMBER ,
        HOLIDAY_NAME           VARCHAR2(100) ,
        DESCRIPTION            VARCHAR2(1000) ,
        ORG_ID                 NUMBER ,
        HOLIDAY_DATE           TIMESTAMP(6) ,
        YEAR                   NUMBER ,
        HOLIDAY_TO_DATE        TIMESTAMP(6),
        CREATED_BY             NUMBER ,
        CREATED_DATE           TIMESTAMP(6) ,
        RECENT_UPDATE_DATE     TIMESTAMP(6) ,
        RECENT_UPDATED_USER_ID NUMBER ,
        ADDITIONAL_INFO_GROUP  VARCHAR2(60) ,
        ADDITIONAL_INFO_1      VARCHAR2(240) ,
        ADDITIONAL_INFO_2      VARCHAR2(240) ,
        ADDITIONAL_INFO_3      VARCHAR2(240) ,
        ADDITIONAL_INFO_4      VARCHAR2(240) ,
        ADDITIONAL_INFO_5      VARCHAR2(240) ,
        ADDITIONAL_INFO_6      VARCHAR2(240) ,
        ADDITIONAL_INFO_7      VARCHAR2(240) ,
        ADDITIONAL_INFO_8      VARCHAR2(240) ,
        ADDITIONAL_INFO_9      VARCHAR2(240) ,
        ADDITIONAL_INFO_10     VARCHAR2(240)
    );

CREATE TABLE NAS_LEAVES_HISTORY
    (
        LEAVE_HISTORY_ID   NUMBER ,
        LEAVE_ID           NUMBER ,
        CHANGED_USER_ID    NUMBER ,
        CHANGED_DATE       TIMESTAMP(6) ,
        COMMENTS           VARCHAR2(1000) ,
        DESCRIPTION        VARCHAR2(1000) ,
        ADDITIONAL_INFO_1  VARCHAR2(240) ,
        ADDITIONAL_INFO_2  VARCHAR2(240) ,
        ADDITIONAL_INFO_3  VARCHAR2(240) ,
        ADDITIONAL_INFO_4  VARCHAR2(240) ,
        ADDITIONAL_INFO_5  VARCHAR2(240) ,
        ADDITIONAL_INFO_6  VARCHAR2(240) ,
        ADDITIONAL_INFO_7  VARCHAR2(240) ,
        ADDITIONAL_INFO_8  VARCHAR2(240) ,
        ADDITIONAL_INFO_9  VARCHAR2(240) ,
        ADDITIONAL_INFO_10 VARCHAR2(240)
    );



-- Leave Management sequences
CREATE SEQUENCE Nas_leave_management_s START WITH 1 INCREMENT BY 1 NOCACHE;

CREATE SEQUENCE Nas_holidays_list_s START WITH 1 INCREMENT BY 1 NOCACHE;

CREATE SEQUENCE Nas_leave_type_s START WITH 1 INCREMENT BY 1 NOCACHE;

CREATE SEQUENCE Nas_leave_details_s START WITH 1 INCREMENT BY 1 NOCACHE;

CREATE SEQUENCE Nas_leaves_history_s START WITH 1 INCREMENT BY 1 NOCACHE;
