CREATE TABLE rpo_resume_parser_summary_log (
resume_parser_id     NUMBER,
import_source        VARCHAR2(240),
candidate_status     VARCHAR2(240),
client_identifier    VARCHAR2(240),
req_number           VARCHAR2(240),
last_run_by          VARCHAR2(200),
status               VARCHAR2(100),
created_date         DATE DEFAULT SYSDATE,
recent_update_date   DATE DEFAULT SYSDATE,
additional_info1     VARCHAR(100),
additional_info2     VARCHAR(100),
additional_info3     VARCHAR(100),
additional_info4     VARCHAR(100),
additional_info5     VARCHAR(100)
);

CREATE SEQUENCE rpo_resume_parser_summary_s
START WITH 1
INCREMENT BY 1
NOCACHE;

CREATE TABLE rpo_parser_candidate_import (
resume_parser_id     NUMBER,
candidate_name       NVARCHAR2(240),
email                NVARCHAR2(200),
phone_nbr            NVARCHAR2(240),
landline             NVARCHAR2(240),
address_line1        NVARCHAR2(240),
address_line2        NVARCHAR2(240),
city                 NVARCHAR2(240),
zip                  VARCHAR2(240),
state                VARCHAR2(240),
country              VARCHAR2(240),
skills               NVARCHAR2(1000),
tags                 NVARCHAR2(1000),
status               VARCHAR2(100),
created_date         DATE DEFAULT SYSDATE,
recent_update_date   DATE DEFAULT SYSDATE,
additional_info1     VARCHAR(100),
additional_info2     VARCHAR(100),
additional_info3     VARCHAR(100),
additional_info4     VARCHAR(100),
additional_info5     VARCHAR(100)
);
