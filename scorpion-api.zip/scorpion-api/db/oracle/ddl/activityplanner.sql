 /*=============================================================================+
 |                                                                             |
 | FILENAME                                                                    |
 |                                                                             |
 |    activityplanner.sql                                                      |
 |                                                                             |
 |                                                                             |
 | DESCRIPTION                                                                 |
 |                                                                             |
 |    Creates Trip Planner DB Objects needed for Scorpion Products             |
 |                                                                             |
 | MODIFICATION HISTORY                                                        |
 |                                                                             |
 | 18-Jun-19    Theerdha Sagar Nimmagadda     Created.                         |
 +=============================================================================*/

CREATE TABLE nas_activity_trip_header
(
   trip_id                      NUMBER
  ,org_id                       NUMBER
  ,trip_description             NVARCHAR2(1000)
  ,status						NVARCHAR2(50)
  ,approver_id			    	NUMBER
  ,user_comments                NVARCHAR2(2000)
  ,approver_comments            NVARCHAR2(2000)
  ,start_date_time              TIMESTAMP(6)
  ,end_date_time                TIMESTAMP(6)
  ,google_event_id              NVARCHAR2(2000)
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);


CREATE TABLE nas_activity_task
(
   task_id                      NUMBER
  ,goal_id                      NUMBER
  ,org_id                       NUMBER
  ,task_description             NVARCHAR2(1000)
  ,task_location                NVARCHAR2(1000)
  ,start_date_time              timestamp
  ,end_date_time                timestamp
  ,goals                        NVARCHAR2(2000)
  ,results                      NVARCHAR2(2000)
  ,status						NVARCHAR2(50)
  ,approver_id			    	NUMBER
  ,user_comments                NVARCHAR2(2000)
  ,approver_comments            NVARCHAR2(2000)
  ,google_event_id              NVARCHAR2(2000)
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);


CREATE TABLE nas_activity_trip_lines
(
   line_id                      NUMBER
  ,trip_id                      NUMBER
  ,from_location                NVARCHAR2(200)
  ,to_location                  NVARCHAR2(200)
  ,start_date_time              timestamp
  ,end_date_time                timestamp
  ,goals                        NVARCHAR2(2000)
  ,results                      NVARCHAR2(2000)
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);

CREATE TABLE nas_trips_tasks
(
   trip_id                      NUMBER
  ,task_id                      NUMBER
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);


CREATE TABLE nas_activity_budget
(
  budget_id                     NUMBER
  ,line_id                      NUMBER
  ,trip_id                      NUMBER
  ,budget_type                  NVARCHAR2(240)
  ,currency_code                NVARCHAR2(100)
  ,budget_value                 NVARCHAR2(1000)
  ,expense_amount               NUMBER
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);

 CREATE TABLE nas_activity_attachments
(
   file_id                      NUMBER
  ,reference_id                 NUMBER
  ,reference_type               VARCHAR2(100)
  ,attachment_type              VARCHAR2(100)
  ,file_name                    VARCHAR2(100)
  ,file_type				    VARCHAR2(100)
  ,file_content			    	BLOB
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);

CREATE TABLE nas_activity_comments
(
   comment_id                   NUMBER
  ,comment_type                 VARCHAR2(100)
  ,comment_data                 NVARCHAR2(2000)
  ,parent_id				    NUMBER
  ,activity_id                  NUMBER
  ,activity_type                VARCHAR2(100)
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date           timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id       NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);

CREATE TABLE nas_activity_subtask
(
   sub_task_id                   NUMBER
  ,task_id                       NUMBER
  ,sub_task_title                NVARCHAR2(500)
  ,assigned_user_id	             NUMBER
  ,sub_task_description          NVARCHAR2(2000)
  ,sub_task_display_order        NUMBER
  ,sub_task_priority             VARCHAR2(100)
  ,due_date                      timestamp
  ,Created_id                    NUMBER
  ,Created_Date                  timestamp DEFAULT SYSDATE
  ,Recent_update_date            timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id        NUMBER
  ,Additional_info_group         VARCHAR2(60)
  ,Additional_info_1             VARCHAR2(240)
  ,Additional_info_2             VARCHAR2(240)
  ,Additional_info_3             VARCHAR2(240)
  ,Additional_info_4             VARCHAR2(240)
  ,Additional_info_5             VARCHAR2(240)
  ,Additional_info_6             VARCHAR2(240)
  ,Additional_info_7             VARCHAR2(240)
  ,Additional_info_8             VARCHAR2(240)
  ,Additional_info_9             VARCHAR2(240)
  ,Additional_info_10            VARCHAR2(240)
);

CREATE TABLE nas_activity_collaborators
(
   task_id                      NUMBER
  ,user_id                      NUMBER
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date            timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id        NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);

CREATE TABLE nas_activity_log
(
   task_id                      NUMBER
  ,log_message                  VARCHAR2(1500)
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date            timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id        NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);

CREATE TABLE nas_activity_task_order
(
   task_id                      NUMBER
  ,status                       VARCHAR2(1500)
  ,display_order                NUMBER
  ,user_id                      NUMBER
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date            timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id        NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);

 CREATE TABLE nas_activity_goals
(
   goal_id                      NUMBER
  ,goal_name                    VARCHAR2(150)
  ,goal_description             VARCHAR2(1500)
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date            timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id        NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);

 CREATE TABLE nas_activity_managers
(
   employee_id                      NUMBER
  ,manager_id                       NUMBER
  ,module_name                    VARCHAR2(150)
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date            timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id        NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);

 CREATE TABLE nas_activity_task_tags
(
   tag_id                      NUMBER
  ,tag_code                    VARCHAR2(100)
  ,tag_name                     VARCHAR2(200)
  ,tag_color                     VARCHAR2(100)
  ,Created_id                   NUMBER
  ,Created_Date                 timestamp DEFAULT SYSDATE
  ,Recent_update_date            timestamp DEFAULT SYSDATE
  ,Recent_updated_user_id        NUMBER
  ,Additional_info_group        VARCHAR2(60)
  ,Additional_info_1            VARCHAR2(240)
  ,Additional_info_2            VARCHAR2(240)
  ,Additional_info_3            VARCHAR2(240)
  ,Additional_info_4            VARCHAR2(240)
  ,Additional_info_5            VARCHAR2(240)
  ,Additional_info_6            VARCHAR2(240)
  ,Additional_info_7            VARCHAR2(240)
  ,Additional_info_8            VARCHAR2(240)
  ,Additional_info_9            VARCHAR2(240)
  ,Additional_info_10           VARCHAR2(240)
);

 CREATE SEQUENCE nas_activity_trip_header_s
START WITH 1
INCREMENT BY 1
NOCACHE;


 CREATE SEQUENCE nas_activity_task_s
START WITH 1
INCREMENT BY 1
NOCACHE;

 CREATE SEQUENCE nas_activity_trip_lines_s
START WITH 1
INCREMENT BY 1
NOCACHE;


 CREATE SEQUENCE nas_activity_budget_s
START WITH 1
INCREMENT BY 1
NOCACHE;

 CREATE SEQUENCE nas_activity_attachments_s
START WITH 1
INCREMENT BY 1
NOCACHE;

 CREATE SEQUENCE nas_activity_comments_s
START WITH 1
INCREMENT BY 1
NOCACHE;

 CREATE SEQUENCE nas_activity_subtask_s
START WITH 1
INCREMENT BY 1
NOCACHE;

 CREATE SEQUENCE nas_activity_goals_s
START WITH 1
INCREMENT BY 1
NOCACHE;


 Insert into nas_activity_task_tags (TAG_ID,TAG_CODE,TAG_NAME,TAG_COLOR) values (1,'HISTORY','History','#e34138');
Insert into nas_activity_task_tags (TAG_ID,TAG_CODE,TAG_NAME,TAG_COLOR) values (2,'NEW_LOGO','New Logo','#7dfab3');
Insert into nas_activity_task_tags (TAG_ID,TAG_CODE,TAG_NAME,TAG_COLOR) values (3,'WFN','Wfn','#38385d');
Insert into nas_activity_task_tags (TAG_ID,TAG_CODE,TAG_NAME,TAG_COLOR) values (4,'VANTAGE','Vantage','#7c395c');
Insert into nas_activity_task_tags (TAG_ID,TAG_CODE,TAG_NAME,TAG_COLOR) values (5,'BALANCES','Balances','#e4c449');
Insert into nas_activity_task_tags (TAG_ID,TAG_CODE,TAG_NAME,TAG_COLOR) values (6,'LAUNCHPAD','Launchpad','#e4c449');
Insert into nas_activity_task_tags (TAG_ID,TAG_CODE,TAG_NAME,TAG_COLOR) values (7,'MONARCH','Monarch','#7c7c38');
Insert into nas_activity_task_tags (TAG_ID,TAG_CODE,TAG_NAME,TAG_COLOR) values (8,'BENEFITS','Benefits','#73ed50');
Insert into nas_activity_task_tags (TAG_ID,TAG_CODE,TAG_NAME,TAG_COLOR) values (9,'TIME','Time','#be7c3a');
Insert into nas_activity_task_tags (TAG_ID,TAG_CODE,TAG_NAME,TAG_COLOR) values (10,'MIGRATIONS','Migrations','#3a5834');
Insert into nas_activity_task_tags (TAG_ID,TAG_CODE,TAG_NAME,TAG_COLOR) values (11,'INNOVATIONS','Innovations','#436188');
 ---------------------

Insert into nas_activity_task_tags (TAG_ID,TAG_CODE,TAG_NAME,TAG_COLOR) values (12,'QUALITY','Quality','#82d8da');
Insert into nas_activity_task_tags (TAG_ID,TAG_CODE,TAG_NAME,TAG_COLOR) values (13,'','','#e3a0ac');
