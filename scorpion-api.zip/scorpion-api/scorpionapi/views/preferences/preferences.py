from flask import Blueprint, request, Response
import ujson
# import time
from scorpionapi.utils.logdata import logger
from scorpionapi.models.login.login import Login
from scorpionapi.models.preferences.preferences import Preferences
from scorpionapi.plugins import auth
from scorpionapi.utils import auth_util

preference = Blueprint('preference', __name__,
                       url_prefix='/preferences')


# generate encrypted password
def hashPassword(new_password):
    return auth_util.encrypt(new_password)


@preference.route('/dateformat/', methods=['GET'])
def dateformats():
    logger.addinfo("@ [GET] views - preference - dateformats(+)")
    try:
        result = Preferences.get_dateformat()
        resp = Response(ujson.dumps(result), status=200,
                        mimetype='application/json')
    except Exception as error:
        logger.dthublog("""@ 27 EXCEPTION - views - preference -
             dateformats """ + str(error))
        final = dict()
        final['status'] = 1
        final['msg'] = str(error)
        resp = Response(ujson.dumps(final),
                        status=200, mimetype='application/json')
        return resp
    logger.addinfo("@ [GET] views - preference - dateformats(-)")
    return resp


@preference.route('/', methods=['POST'])
def post():
    logger.addinfo('@ [POST] views - preference - post(+)')
    json = ujson.loads(request.data)
    final = {}
    if json and json['user_id']:
        user_id = json['user_id']
        old_passwd = ""
        new_passwd = ""
        if "old_password" and "new_password" in json:
            old_passwd = json['old_password']
            new_passwd = json['new_password']
        new_preference = Preferences(FIRST_NAME=json['user_description'],
                                     EMAIL_ADDRESS=json['email_address'],
                                     TELEPHONE=json['phone'],
                                     REPORTING_MANAGER=json['reporting_manager'],
                                     TIME_ZONE=json['time_zone'])
        try:
            result = Preferences.save(new_preference, user_id,
                                      old_passwd, new_passwd)
            if result == "password":
                final['msg'] = "Please enter valid password"
                final['status'] = 1
            elif result == "user_id":
                final['msg'] = "User id has invalid data"
                final['status'] = 1
            elif result == "success":
                final['msg'] = 'Preferences updated successfully'
                final['status'] = 0
            else:
                final['msg'] = 'Preference update failed'
                final['status'] = 1
            response = Response(ujson.dumps(final),
                                status=200, mimetype='application/json')
        except Exception as error:
            logger.dthublog("""@ 77 EXCEPTION - views - preference -
                 post """ + str(error))
            final['status'] = 1
            final['msg'] = str(error)
            response = Response(ujson.dumps(final), status=200,
                                mimetype='application/json')
            return response
    else:
        final['status'] = 1
        final['msg'] = "Please enter valid data"
        response = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
    logger.addinfo('@ [POST] views - preference - post(-)')
    return response


@preference.route('/details/<string:user_id>/', methods=['GET'])
def getuser_details(user_id=None):
    logger.dthublog("@ [GET] views - preference - getuser_details(+)")
    try:
        result = Login.get_user_preferences(user_id)
        resp = Response(ujson.dumps(result), status=200,
                        mimetype='application/json')
    except Exception as error:
        logger.dthublog("""@ 102 EXCEPTION - views - preference -
             getuser_details """ + str(error))
        final = dict()
        final['status'] = 1
        final['msg'] = str(error)
        resp = Response(ujson.dumps(final), status=200,
                        mimetype='application/json')
        return resp
    logger.dthublog("@ [GET] views - preference - getuser_details(-)")
    return resp


@preference.route('/lookup/<int:lookup_id>/', methods=['GET'])
def getHome_Page_Look_up(lookup_id=None):
    logger.dthublog('@ [GET] views - preference - getHome_Page_Look_up(+)')
    try:
        result = Preferences.get_homepage_Lookup(lookup_id)
        resp = Response(ujson.dumps(result), status=200,
                        mimetype='application/json')
    except Exception as error:
        logger.dthublog("""@ 123 EXCEPTION - views - preference -
             getHome_Page_Look_up """ + str(error))
        final = final = dict()
        final['status'] = 1
        final['msg'] = str(error)
        resp = Response(ujson.dumps(final),
                        status=200, mimetype='application/json')
        return ujson.dumps(final)
    logger.dthublog('@ [GET] views - preference - getHome_Page_Look_up(-)')
    return resp


@preference.before_request
@auth.login_required
def before_request():
    pass
