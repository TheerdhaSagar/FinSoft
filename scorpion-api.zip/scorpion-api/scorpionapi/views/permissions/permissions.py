from flask import Blueprint, request, Response
import ujson
import datetime
from scorpionapi.utils.logdata import logger
from scorpionapi.plugins import auth
from scorpionapi.models.usermngmnt.permissions import Permissions

permissions = Blueprint('permissions', __name__, url_prefix='/permission')


@permissions.route('/', methods=['GET'])
@permissions.route('/id/<int:perm_id>/', methods=['GET'])
def get_permissions(perm_id=None):
    logger.addinfo("@ [GET] views - permission - get_permissions(+)")
    try:
        result = Permissions.get_permissions(perm_id)
        resp = Response(ujson.dumps(result), status=200,
                        mimetype='application/json')
    except Exception as error:
        logger.dthublog("""@ 21 EXCEPTION - views - permission -
             get_permissions """ + str(error))
        final = dict()
        final['status'] = 1
        final['msg'] = str(error)
        resp = Response(ujson.dumps(final),
                        status=200, mimetype='application/json')
        return ujson.dumps(final)
    logger.addinfo("@ [GET] views - permission - get_permissions(-)")
    return resp


@permissions.route('/types/', methods=['GET'])
def get_permissiontype():
    logger.addinfo("@ [GET] views - permission - get_permissiontype(+)")
    try:
        result = Permissions.get_permissiontypes()
        resp = Response(ujson.dumps(result),
                        status=200, mimetype='application/json')
    except Exception as error:
        logger.dthublog("""@ 42 EXCEPTION - models - permission -
             get_permissiontype """ + str(error.message))
        final = dict()
        final['status'] = 1
        final['msg'] = str(error)
        resp = Response(ujson.dumps(final),
                        status=200, mimetype='application/json')
        return ujson.dumps(final)
    logger.addinfo("@ [GET] views - permission - get_permissiontype(-)")
    return resp


@permissions.route('/validate/<string:value>/', methods=['GET'])
def get_referencevalue(value=None):
    logger.addinfo("@ [GET] views - permission - get_referencevalue(+)")
    try:
        result = Permissions.get_validation(value)
        resp = Response(ujson.dumps(result), status=200,
                        mimetype='application/json')
    except Exception as error:
        logger.addinfo("""@ 85 EXCEPTION - views - permission -
             get_referencevalue """ + str(error))
        final = dict()
        final['status'] = 1
        final['msg'] = str(error)
        resp = Response(ujson.dumps(final),
                        status=200, mimetype='application/json')
        return ujson.dumps(final)
    logger.addinfo("@ [GET] views - permission - get_referencevalue(-)")
    return resp


@permissions.route('/save/', methods=['POST'])
def save():
    logger.addinfo('@ [POST] views - permission - save(+)')
    jsond = ujson.loads(request.data)
    new_permission = Permissions()
    final = dict()
    if jsond:
        for key, value in jsond.items():
            setattr(new_permission, key, value)
        cur_date = datetime.date.today().strftime("%d,%B,%Y")
        setattr(new_permission, 'created_date', cur_date)
        setattr(new_permission, 'recent_update_date', cur_date)
        try:
            result = Permissions.save(new_permission)
        except Exception as error:
            logger.dthublog("""@ 113 EXCEPTION - views - permission -
                 save """ + str(error))
            final = dict()
            final['status'] = 1
            final['msg'] = str(error)
            resp = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
            return resp
        if result == "success":
            final['status'] = 0
            final['msg'] = "Permission created successfully"
            resp = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
        else:
            final['status'] = 1
            final['msg'] = "Permission creation failed"
            resp = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
        logger.addinfo('@ [POST] views - permission - save(-)')
        return resp


@permissions.route('/update/', methods=['POST'])
def permupdate():
    logger.addinfo('@ [POST] views - permission - permupdate(+)')
    jsond = ujson.loads(request.data)
    new_permission = Permissions()
    final = dict()
    if 'permission_id' in jsond:
        permissionid = jsond['permission_id']
        del jsond['permission_id']
        for key, value in jsond.items():
            setattr(new_permission, key, value)
        cur_date = datetime.date.today().strftime("%d,%B,%Y")
        setattr(new_permission, 'recent_update_date', cur_date)
        try:
            result = Permissions.update(new_permission, permissionid)
        except Exception as error:
            logger.dthublog("""@ 152 EXCEPTION - views - permission -
                 permupdate """ + str(error))
            final['status'] = 1
            final['msg'] = str(error)
            resp = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
            return resp
        if result == "success":
            final['status'] = 0
            final['msg'] = "Permission updated successfully"
        else:
            final['status'] = 1
            final['msg'] = "Permission update failed"
    else:
        final['status'] = 1
        final['msg'] = "Please enter valid data"
    resp = Response(ujson.dumps(final), status=200,
                    mimetype='application/json')
    logger.addinfo('@ [POST] views - permission - permupdate(-)')
    return resp


@permissions.before_request
@auth.login_required
def before_request():
    pass
