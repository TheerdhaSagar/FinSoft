from flask import Blueprint, Response, request
from scorpionapi.models.wfnpostvalidations.wfnpostvalidations import WfnPostValidations
from scorpionapi.plugins import auth
from scorpionapi.utils.common_utils import CommonUtils
import ujson
from scorpionapi.utils.constants import Status
from scorpionapi.utils.log_util import LogUtil

wfnpostvalidations = Blueprint('wfnpostvalidations', __name__, url_prefix='/wfnpostvalidations')


@wfnpostvalidations.route('/', methods=['POST'])
def insert_adpr_import_files():
    data = ujson.loads(request.data)
    try:
        wfn_post_validations_obj = WfnPostValidations()
        result_checker = wfn_post_validations_obj.report_checker(data)
        if result_checker['status'] == 0:
            result = wfn_post_validations_obj.insert_adpr_import_files(data)
        else:
            result = result_checker
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('wfnpostvalidations', 'insert_adpr_import_files', e)
    return response


@wfnpostvalidations.route('/dm/report/<int:report_id>/<string:conversion>/', methods=['GET'])
def get_dm_attachment(report_id=None, conversion=None):
    try:
        wfn_post_validations_obj = WfnPostValidations()
        user = request.args.get('user')
        result = wfn_post_validations_obj.get_dm_attachment(report_id, conversion, user)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('wfnpostvalidations', 'get_dm_attachment', e)
    return response


@wfnpostvalidations.route('/dm/report/summary/<int:user_id>/', methods=['GET'])
def get_report_dm_summary(user_id=None):
    try:
        wfn_post_validations_obj = WfnPostValidations()
        result = wfn_post_validations_obj.get_report_dm_summary(user_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('wfnpostvalidations', 'get_report_dm_summary', e)
    return response


@wfnpostvalidations.route('/dm/report/<int:report_id>/', methods=['DELETE'])
def delete_dm_report(report_id=None):
    try:
        wfn_post_validations_obj = WfnPostValidations()
        result = wfn_post_validations_obj.delete_dm_report(report_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('balances', 'delete_dm_report', e)
    return response


@wfnpostvalidations.before_request
@auth.login_required
@LogUtil.before_request
def before_request():
    pass


@wfnpostvalidations.after_request
@LogUtil.after_request
def after_request(response):
    return response
