from flask import Blueprint, request, Response
from scorpionapi.models.usermngmnt.calendar import Calendar
from scorpionapi.plugins import auth
from scorpionapi.utils.common_utils import CommonUtils
import ujson


calendar = Blueprint('calendar', __name__, url_prefix='/calendar')


@calendar.route('/add/', methods=['POST'])
def add_calendar():
    req_data = ujson.loads(request.data)
    try:
        leave_obj = Calendar()
        result = leave_obj.add_calendar(req_data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        response = CommonUtils.pass_error('calendar', 'add_calendar', e)
    return response


@calendar.route('/update/', methods=['POST'])
def update_calendar():
    req_data = ujson.loads(request.data)
    try:
        leave_obj = Calendar()
        result = leave_obj.update_calendar(req_data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        response = CommonUtils.pass_error('calendar', 'update_calendar', e)
    return response


@calendar.route('/delete/<int:work_calendar_id>/', methods=['DELETE'])
def delete_calendar(work_calendar_id=None):
    try:
        calender_obj = Calendar()
        result = calender_obj.delete_calendar(work_calendar_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        response = CommonUtils.pass_error('calendar', 'delete_calendar', e)
    return response


@calendar.route('/<int:team_id>/', methods=['GET'])
def get_calendar(team_id=None):
    try:
        leave_obj = Calendar()
        result = leave_obj.get_calendar(team_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        response = CommonUtils.pass_error('calendar', 'get_calendar', e)
    return response


@calendar.route('/all/<int:team_id>/', methods=['GET'])
def get_all_users_calendar(team_id=None):
    try:
        leave_obj = Calendar()
        result = leave_obj.get_all_users_calendar(team_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        response = CommonUtils.pass_error('calendar', 'get_all_users_calendar', e)
    return response


@calendar.route('/users/<int:team_id>/', methods=['GET'])
def get_users_calendar(team_id=None):
    try:
        leave_obj = Calendar()
        result = leave_obj.get_users_calendar(team_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        response = CommonUtils.pass_error('calendar', 'get_users_calendar', e)
    return response


@calendar.route('/details/<int:calendar_id>/', methods=['GET'])
def get_calendar_details(calendar_id=None):
    try:
        leave_obj = Calendar()
        result = leave_obj.get_calendar_details(calendar_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        response = CommonUtils.pass_error('calendar', 'get_calendar_details', e)
    return response


@calendar.before_request
@auth.login_required
def before_request():
    pass
