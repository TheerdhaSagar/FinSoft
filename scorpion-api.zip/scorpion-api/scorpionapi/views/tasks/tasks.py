from flask import Blueprint, request, Response
from scorpionapi.models.tasks.tasks import Tasks
from scorpionapi.plugins import auth
from scorpionapi.utils.common_utils import CommonUtils
import ujson

tasks = Blueprint('tasks', __name__, url_prefix='/tasks')


@tasks.route('/header/add/', methods=['POST'])
def add_header_tasks():
    req_data = ujson.loads(request.data)
    try:
        tasks_obj = Tasks()
        result = tasks_obj.add_header_tasks(req_data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        response = CommonUtils.pass_error('tasks', 'add_header_tasks', e)
    return response


@tasks.route('/header/add/', methods=['PUT'])
def update_header_tasks():
    req_data = ujson.loads(request.data)
    try:
        tasks_obj = Tasks()
        result = tasks_obj.update_header_tasks(req_data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        response = CommonUtils.pass_error('tasks', 'update_header_tasks', e)
    return response


@tasks.route('/headers/<int:team_id>/', methods=['GET'])
def get_header_tasks(team_id=None):
    try:
        tasks_obj = Tasks()
        result = tasks_obj.get_header_tasks(team_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        response = CommonUtils.pass_error('tasks', 'get_header_tasks', e)
    return response


@tasks.route('/headers/<int:task_header_id>/', methods=['DELETE'])
def delete_header_tasks(task_header_id=None):
    try:
        tasks_obj = Tasks()
        result = tasks_obj.delete_header_tasks(task_header_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        response = CommonUtils.pass_error('tasks', 'delete_header_tasks', e)
    return response


@tasks.route('/lines/add/', methods=['POST'])
def add_lines_tasks():
    req_data = ujson.loads(request.data)
    try:
        tasks_obj = Tasks()
        result = tasks_obj.add_lines_tasks(req_data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        response = CommonUtils.pass_error('tasks', 'add_lines_tasks', e)
    return response


@tasks.route('/lines/update/', methods=['POST'])
def update_lines_tasks():
    req_data = ujson.loads(request.data)
    try:
        tasks_obj = Tasks()
        result = tasks_obj.update_lines_tasks(req_data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        response = CommonUtils.pass_error('tasks', 'update_lines_tasks', e)
    return response


@tasks.route('/attachment/<int:attachment_id>/', methods=['GET'])
def attachment_data(attachment_id=None):
    try:
        trip_obj = Tasks()
        attachments = trip_obj.attachment_data(attachment_id)
        response = Response(ujson.dumps(attachments),
                            status=200,
                            mimetype='application/json')
    except Exception as e:
        response = CommonUtils.pass_error('tasks', 'update_lines_tasks', e)
    return response


@tasks.route('/lines/<int:task_header_id>/', methods=['GET'])
def get_lines_tasks(task_header_id=None):
    try:
        tasks_obj = Tasks()
        result = tasks_obj.get_lines_tasks(task_header_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        response = CommonUtils.pass_error('tasks', 'get_lines_tasks', e)
    return response


@tasks.route('/lines/<int:task_line_id>/', methods=['DELETE'])
def delete_lines_tasks(task_line_id=None):
    try:
        tasks_obj = Tasks()
        result = tasks_obj.delete_lines_tasks(task_line_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        response = CommonUtils.pass_error('tasks', 'delete_lines_tasks', e)
    return response


@tasks.before_request
@auth.login_required
def before_request():
    pass

