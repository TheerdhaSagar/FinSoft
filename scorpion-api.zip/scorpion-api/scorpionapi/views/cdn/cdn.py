import ujson

from flask import request, Blueprint, Response
from scorpionapi.utils.logdata import logger
from flask import send_file
import os
import base64

cdn = Blueprint('cdn', __name__, url_prefix='/cdn')


@cdn.route('/', methods=['GET'])
def send_files():
    logger.addinfo('@ [GET] - views - cdn - send_file(+)')
    try:
        download_name = request.args.get('download_name')
        mimetype = request.args.get('mimetype')
        data_format = request.args.get('format')
        if not mimetype:
            mimetype = 'application/vnd.ms-excel'
        file_name = request.args.get('file_name')
        file_path = os.path.dirname(os.path.dirname(__file__))
        file_path = os.path.dirname(file_path) + '/static/'
        if os.path.exists(file_path + file_name):
            file_path += file_name
        else:
            file_path = '/tmp/' + file_name
        if data_format and data_format == 'base64':
            with open(file_path, 'r') as tmp_file:
                encoded = base64.b64encode(tmp_file.read())
            data = Response(ujson.dumps({'file_data': encoded}),
                            status=200,
                            mimetype=mimetype)
        else:
            data = send_file(file_path,
                             attachment_filename=download_name,
                             as_attachment=True,
                             mimetype=mimetype)
    except Exception as e:
        logger.dthublog(""" @ 22 EXCEPTION - views - cdn -
                         send_file """ + str(e))
        raise e
    logger.addinfo('@ [GET] - views - cdn -send_file(-)')
    return data


@cdn.route('/download', methods=['GET'])
def download_file():
    logger.addinfo('@ [GET] - views - cdn - download_file(+)')
    try:
        download_name = request.args.get('download_name')
        file_name = request.args.get('file_name')
        file_path = os.path.dirname(os.path.dirname(__file__))
        file_path = os.path.dirname(file_path) + '/static/'
        if os.path.exists(file_path + file_name):
            file_path += file_name
        else:
            file_path = '/tmp/' + file_name
        data = send_file(file_path,
                         attachment_filename=download_name,
                         as_attachment=True,
                         mimetype="text/csv")
    except Exception as e:
        logger.dthublog(""" @ 50 EXCEPTION - views - cdn -
                         download_file """ + str(e))
        raise e
    logger.addinfo('@ [GET] - views - cdn -download_file(-)')
    return data
