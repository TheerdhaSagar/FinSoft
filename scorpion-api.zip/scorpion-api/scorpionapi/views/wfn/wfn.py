from flask import Blueprint, Response, request
from scorpionapi.models.wfn.wfn import Wfn
from scorpionapi.plugins import auth
from scorpionapi.utils.common_utils import CommonUtils
import ujson
from scorpionapi.utils.constants import Status
from scorpionapi.utils.log_util import LogUtil

wfn = Blueprint('wfn', __name__, url_prefix='/wfn')


@wfn.route('/', methods=['POST'])
def read_file():
    jsond = ujson.loads(request.data)
    try:
        wfn_obj = Wfn()
        file_data = wfn_obj.read_file(jsond)
        response = Response(ujson.dumps(file_data), status=200,
                            mimetype="application/json")
    except Exception as e:
        return CommonUtils.pass_error('wfn', 'add_client', e)
    return respons9


@wfn.route('/preview/', methods=['POST'])
def read_preview_file():
    jsond = ujson.loads(request.data)
    try:
        wfn_obj = Wfn()
        file_data = wfn_obj.read_preview_file(jsond)
        response = Response(ujson.dumps(file_data), status=200,
                            mimetype="application/json")
    except Exception as e:
        return CommonUtils.pass_error('wfn', 'add_client', e)
    return response


@wfn.route('/parser/', methods=['POST'])
def parse_error_log():
    jsond = ujson.loads(request.data)
    try:
        wfn_obj = Wfn()
        file_data = wfn_obj.parse_error_log(jsond)
        response = Response(ujson.dumps(file_data), status=200,
                            mimetype="application/json")
    except Exception as e:
        return CommonUtils.pass_error('wfn', 'parse_error_log', e)
    return response


@wfn.route('/validation/', methods=['POST'])
def run_validation_report():
    jsond = ujson.loads(request.data)
    try:
        wfn_obj = Wfn()
        file_data = wfn_obj.run_validation_report(jsond)
        response = Response(ujson.dumps(file_data), status=200,
                            mimetype="application/json")
    except Exception as e:
        return CommonUtils.pass_error('wfn', 'run_validation_report', e)
    return response


@wfn.route('/error/report/download/<string:client_id>/<string:conversion_name>/', methods=['GET'])
def download_error_report(client_id, conversion_name):
    try:
        wfn_obj = Wfn()
        result = wfn_obj.download_error_report(client_id, conversion_name)
    except Exception as e:
        return CommonUtils.pass_error('wfn', 'download_error_report', e)
    response = Response(ujson.dumps(result), status=200,
                        mimetype='application/json')
    return response


@wfn.route('/error/report/download/summary/<string:client_id>/<string:conversion_name>/', methods=['GET'])
def download_summary_error_report(client_id, conversion_name):
    try:
        wfn_obj = Wfn()
        result = wfn_obj.download_summary_error_report(client_id, conversion_name)
    except Exception as e:
        return CommonUtils.pass_error('wfn', 'download_summary_error_report', e)
    response = Response(ujson.dumps(result), status=200,
                        mimetype='application/json')
    return response


@wfn.route('/summary/<int:user_id>/', methods=['GET'])
@wfn.route('/summary/', methods=['GET'])
def get_balances_summary(user_id=None):
    try:
        wfn_obj = Wfn()
        result = wfn_obj.get_preview_summary(user_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('wfn', 'get_balances_summary', e)
    return response


@wfn.route('/setup/summary/<int:user_id>/', methods=['GET'])
def get_setup_summary(user_id=None):
    try:
        balance_obj = Wfn()
        result = balance_obj.get_setup_summary(user_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('wfn', 'get_setup_summary', e)
    return response


@wfn.route('/setup/details/<string:client_id>/', methods=['GET'])
def get_setup_details(client_id=None):
    try:
        balance_obj = Wfn()
        result = balance_obj.get_setup_details(client_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('wfn', 'get_setup_summary', e)
    return response


@wfn.route('/issue/create/', methods=['POST'])
def issue_create():
    jsond = ujson.loads(request.data)
    try:
        wfn_obj = Wfn()
        file_data = wfn_obj.issue_create(jsond)
        response = Response(ujson.dumps(file_data), status=200,
                            mimetype="application/json")
    except Exception as e:
        return CommonUtils.pass_error('wfn', 'issue_create', e)
    return response


@wfn.route('/issue/edit/', methods=['POST'])
def issue_edit():
    jsond = ujson.loads(request.data)
    try:
        wfn_obj = Wfn()
        file_data = wfn_obj.issue_edit(jsond)
        response = Response(ujson.dumps(file_data), status=200,
                            mimetype="application/json")
    except Exception as e:
        return CommonUtils.pass_error('wfn', 'issue_edit', e)
    return response


@wfn.route('/add/client/', methods=['POST'])
def add_client():
    req_data = ujson.loads(request.data)
    try:
        wfn_obj = Wfn()
        result = wfn_obj.add_client(req_data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('wfn', 'add_client', e)
    return response


@wfn.route('/client/update/', methods=['POST'])
def update_client():
    req_data = ujson.loads(request.data)
    try:
        wfn_obj = Wfn()
        result = wfn_obj.update_client(req_data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('wfn', 'update_client', e)
    return response


@wfn.route('/client/<string:client_id>/', methods=['DELETE'])
def delete_client(client_id=None):
    try:
        wfn_obj = Wfn()
        result = wfn_obj.delete_client(client_id)
        if result == 'SUCCESS':
            resp = {
                'msg': 'Client deleted successfully',
                'status': Status.OK.value
            }
        else:
            resp = {
                'msg': result,
                'status': Status.ERROR.value
            }
        response = Response(ujson.dumps(resp), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('wfn', 'delete_client', e)
    return response


@wfn.route('/clients/<int:org_id>/', methods=['GET'])
def get_clients(org_id=None):
    try:
        wfn_obj = Wfn()
        result = wfn_obj.get_clients(org_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('wfn', 'get_clients', e)
    return response


@wfn.route('/issues/', methods=['POST'])
@wfn.route('/issues/<int:org_id>/', methods=['POST'])
def get_issues(org_id=None):
    try:
        req = ujson.loads(request.data)
        issue_arrea = req['issue_task_filter']
        wfn_obj = Wfn()
        issue_id = request.args.get('issue_id')
        result = wfn_obj.get_issues(org_id, issue_id, issue_arrea)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('wfn', 'get_clients', e)
    return response


@wfn.route('/issue/delete/<int:issue_id>/', methods=['DELETE'])
def delete_issue(issue_id=None):
    try:
        wfn_obj = Wfn()
        result = wfn_obj.delete_issue(issue_id)
        if result == 'SUCCESS':
            resp = {
                'msg': 'Client deleted successfully',
                'status': Status.OK.value
            }
        else:
            resp = {
                'msg': result,
                'status': Status.ERROR.value
            }
        response = Response(ujson.dumps(resp), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('wfn', 'delete_issue', e)
    return response


@wfn.before_request
@auth.login_required
@LogUtil.before_request
def before_request():
    pass


@wfn.after_request
@LogUtil.after_request
def after_request(response):
    return response

