from flask import Blueprint, request, Response
from scorpionapi.models.scheduler.scheduler import Scheduler
from scorpionapi.plugins import auth
from scorpionapi.utils.common_utils import CommonUtils
import ujson

scheduler = Blueprint('scheduler', __name__, url_prefix='/scheduler')


@scheduler.route('/add/', methods=['POST'])
def add_team():
    req_data = ujson.loads(request.data)
    try:
        leave_obj = Scheduler()
        result = leave_obj.add_team(req_data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        response = CommonUtils.pass_error('teams', 'add_team', e)
    return response


@scheduler.route('/update/', methods=['POST'])
def update_team():
    req_data = ujson.loads(request.data)
    try:
        leave_obj = Scheduler()
        result = leave_obj.update_team(req_data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        response = CommonUtils.pass_error('teams', 'update_team', e)
    return response


@scheduler.before_request
@auth.login_required
def before_request():
    pass



