from flask import Blueprint, request, Response
from scorpionapi.models.usermngmnt.teams import Teams
from scorpionapi.plugins import auth
from scorpionapi.utils.common_utils import CommonUtils
import ujson


teams = Blueprint('teams', __name__, url_prefix='/teams')


@teams.route('/add/', methods=['POST'])
def add_team():
    req_data = ujson.loads(request.data)
    try:
        leave_obj = Teams()
        result = leave_obj.add_team(req_data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        response = CommonUtils.pass_error('teams', 'add_team', e)
    return response


@teams.route('/update/', methods=['POST'])
def update_team():
    req_data = ujson.loads(request.data)
    try:
        leave_obj = Teams()
        result = leave_obj.update_team(req_data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        response = CommonUtils.pass_error('teams', 'update_team', e)
    return response


@teams.route('/', methods=['GET'])
def get_teams():
    try:
        leave_obj = Teams()
        result = leave_obj.get_teams()
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        response = CommonUtils.pass_error('teams', 'get_teams', e)
    return response


@teams.before_request
@auth.login_required
def before_request():
    pass
