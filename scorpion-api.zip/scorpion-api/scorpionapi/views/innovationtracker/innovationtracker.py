from flask import Blueprint, Response, request
from scorpionapi.models.innovationtracker.innovationtracker import Innovations
from scorpionapi.plugins import auth
from scorpionapi.utils.common_utils import CommonUtils
import ujson
from scorpionapi.utils.log_util import LogUtil
from scorpionapi.utils.constants import Status

innovations = Blueprint('innovations', __name__, url_prefix='/innovations')


@innovations.route('/sync/adpworks/', methods=['GET'])
def sync_innovations_with_adp_works():
    try:
        innovation_tracker_obj = Innovations()
        result = innovation_tracker_obj.sync_adpworks_innovation_tracker()
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('innovations', 'sync_innovations_with_adp_works', e)
    return response
