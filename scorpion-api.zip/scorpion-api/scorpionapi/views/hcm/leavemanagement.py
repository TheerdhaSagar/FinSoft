from flask import Blueprint, Response, request
from scorpionapi.models.hcm.leavemanagement import LeaveManagement
from scorpionapi.plugins import auth
from scorpionapi.utils.common_utils import CommonUtils
import ujson
from scorpionapi.utils.logdata import logger
from scorpionapi.utils.constants import Status

leavemanagement = Blueprint('leavemanagement', __name__, url_prefix='/hcm/leavemanagement')


# This view is to configure Holidays for each org_id, only visible to managers
@leavemanagement.route('/holiday/add/', methods=['POST'])
def holiday_insert():
    logger.addinfo('@ [POST] views - leavemanagement - holiday_insert(+)')
    req_data = ujson.loads(request.data)
    try:
        leave_obj = LeaveManagement()
        result = leave_obj.holiday_insert(req_data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('leavemanagement', 'holiday_insert', e)
    logger.addinfo('@ [POST] views - leavemanagement - holiday_insert(+)')
    return response


# This View is to update Holiday calendar - Visible only for managers
@leavemanagement.route('/holiday/update/', methods=['POST'])
def holiday_update():
    logger.addinfo('@ [POST] views - leavemanagement - holiday_update(+)')
    req_data = ujson.loads(request.data)
    try:
        leave_obj = LeaveManagement()
        result = leave_obj.holiday_update(req_data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('leavemanagement', 'holiday_update', e)
    logger.addinfo('@ [POST] views - leavemanagement - holiday_update(+)')
    return response


# Fetching Holiday calendar based on org_id of the employee

@leavemanagement.route('/holidays/', methods=['POST'])
def get_holidays():
    logger.addinfo('@ [POST] views - leavemanagement - get_holidays(+)')
    jsond = ujson.loads(request.data)
    try:
        # org_id, holiday_id, year
        leave_obj = LeaveManagement()
        result = leave_obj.get_holidays(jsond)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('leavemanagement', 'get_holidays', e)
    logger.addinfo('@ [POST] views - leavemanagement - get_holidays(+)')
    return response


# Deleting existing Holidays w.r.t holiday_id or complete list for an Org - Visible only for managers
@leavemanagement.route('/holidays/<int:org_id>/', methods=['DELETE'])
def delete_holidays(org_id=None):
    logger.addinfo('@ [POST] views - leavemanagement - delete_holidays(+)')
    try:
        leave_obj = LeaveManagement()
        holiday_id = request.args.get('holiday_id')
        result = leave_obj.delete_holidays(org_id, holiday_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('leavemanagement', 'delete_holidays', e)
    logger.addinfo('@ [POST] views - leavemanagement - delete_holidays(+)')
    return response


# Add leave type for each org_id - Visible only for managers
@leavemanagement.route('/leave/type/add/', methods=['POST'])
def leave_type_insert():
    logger.addinfo('@ [POST] views - leavemanagement - leave_type_insert(+)')
    req_data = ujson.loads(request.data)
    try:
        leave_obj = LeaveManagement()
        result = leave_obj.leave_type_insert(req_data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('leavemanagement', 'leave_type_insert', e)
    logger.addinfo('@ [POST] views - leavemanagement - leave_type_insert(+)')
    return response


# Update leave type for each org_id - Visible only for managers
@leavemanagement.route('/leave/type/update/', methods=['POST'])
def leave_type_update():
    logger.addinfo('@ [POST] views - leavemanagement - leave_type_update(+)')
    req_data = ujson.loads(request.data)
    try:
        leave_obj = LeaveManagement()
        result = leave_obj.leave_type_update(req_data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('leavemanagement', 'leave_type_update', e)
    logger.addinfo('@ [POST] views - leavemanagement - leave_type_update(+)')
    return response


# lov for leave type while applying leaves
@leavemanagement.route('/leave/types/', methods=['GET'])
@leavemanagement.route('/leave/types/<int:org_id>/', methods=['GET'])
def get_leave_types(org_id=None):
    logger.addinfo('@ [GET] views - leavemanagement - get_leave_types(+)')
    try:
        leave_obj = LeaveManagement()
        leave_type_id = request.args.get('leave_type_id')
        result = leave_obj.get_leave_types(org_id, leave_type_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('leavemanagement', 'get_leave_types', e)
    logger.addinfo('@ [GET] views - leavemanagement - get_leave_types(+)')
    return response


# Hit this API when employee applies for Leave
@leavemanagement.route('/leave/add/', methods=['POST'])
def leave_insert():
    logger.addinfo('@ [POST] views - leavemanagement - leave_insert(+)')
    req_data = ujson.loads(request.data)
    try:
        leave_obj = LeaveManagement()
        result = leave_obj.leave_insert(req_data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('leavemanagement', 'leave_insert', e)
    logger.addinfo('@ [POST] views - leavemanagement - leave_insert(+)')
    return response


# Hit this API when manager approves, employee makes changes to leave or cancel the leave
@leavemanagement.route('/leave/update/', methods=['POST'])
def leave_update():
    logger.addinfo('@ [POST] views - leavemanagement - leave_update(+)')
    req_data = ujson.loads(request.data)
    try:
        leave_obj = LeaveManagement()
        result = leave_obj.leave_update(req_data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('leavemanagement', 'leave_update', e)
    logger.addinfo('@ [POST] views - leavemanagement - leave_update(+)')
    return response


# To update leave status - Used for approve / reject
@leavemanagement.route('/leave/update/status/', methods=['POST'])
def update_leave_status():
    logger.addinfo('@ [POST] views - leavemanagement - update_leave_status(+)')
    req_data = ujson.loads(request.data)
    try:
        leave_obj = LeaveManagement()
        result = leave_obj.update_leave_status(req_data)
        if result == 'SUCCESS':
            resp = {
                'msg': 'Status updated successfully',
                'status': Status.OK.value
            }
        else:
            resp = {
                'msg': result,
                'status': Status.ERROR.value
            }
        response = Response(ujson.dumps(resp), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('leavemanagement', 'update_leave_status', e)
    logger.addinfo('@ [POST] views - leavemanagement - update_leave_status(+)')
    return response


# Get leave history for an employee
@leavemanagement.route('/leaves/', methods=['POST'])
def get_leaves():
    logger.addinfo('@ [POST] views - leavemanagement - get_leaves(+)')
    jsond = ujson.loads(request.data)
    try:
        leave_obj = LeaveManagement()
        result = leave_obj.get_leaves(jsond)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('leavemanagement', 'get_leave', e)
    logger.addinfo('@ [POST] views - leavemanagement - get_leaves(+)')
    return response


# GET leaves based on Start date, end date and org_id
@leavemanagement.route('/leaves/schedule/', methods=['POST'])
def get_leaves_scheduler():
    logger.addinfo('@ [POST] views - leavemanagement - get_leaves_scheduler(+)')
    jsond = ujson.loads(request.data)
    try:
        leave_obj = LeaveManagement()
        result = leave_obj.get_leaves_scheduler(jsond)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('leavemanagement', 'get_leaves_scheduler', e)
    logger.addinfo('@ [POST] views - leavemanagement - get_leaves_scheduler(+)')
    return response


# Delete leave type
@leavemanagement.route('/leaves/<int:leave_type_id>/', methods=['DELETE'])
def delete_leave_type(leave_type_id=None):
    logger.addinfo('@ [DELETE] views - leavemanagement - delete_leave_type(+)')
    try:
        leave_obj = LeaveManagement()
        result = leave_obj.delete_leave_type(leave_type_id)
        if result == 'SUCCESS':
            resp = {
                'msg': 'Leave type deleted successfully',
                'status': Status.OK.value
            }
        else:
            resp = {
                'msg': result,
                'status': Status.ERROR.value
            }
        response = Response(ujson.dumps(resp), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('leavemanagement', 'delete_leave_type', e)
    logger.addinfo('[DELETE] views - leavemanagement - delete_leave_type(-)')
    return response


# Get all applied leaves
@leavemanagement.route('/leaves/summary/', methods=['POST'])
def get_leaves_summary():
    logger.addinfo('@ [POST] views - leavemanagement - get_leaves_summary(+)')
    jsond = ujson.loads(request.data)
    try:
        leave_obj = LeaveManagement()
        result = leave_obj.get_leaves_summary(jsond)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('leavemanagement', 'get_leaves_summary', e)
    logger.addinfo('[POST] views - leavemanagement - get_leaves_summary(-)')
    return response


# Get Line details for selected leave
@leavemanagement.route('/leaves/details/<int:leave_id>/', methods=['GET'])
def get_leave_details(leave_id=None):
    logger.addinfo('@ [GET] views - leavemanagement - get_leave_details(+)')
    try:
        leave_obj = LeaveManagement()
        result = leave_obj.get_leave_details(leave_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('leavemanagement', 'get_leave_details', e)
    logger.addinfo('[GET] views - leavemanagement - get_leave_details(-)')
    return response


# Get leave types with applied count for each leave
@leavemanagement.route('/leaves/types/count/', methods=['POST'])
def get_leave_type_withcount():
    logger.addinfo('@ [POST] views - leavemanagement - get_leave_type_withcount(+)')
    jsond = ujson.loads(request.data)
    try:
        leave_obj = LeaveManagement()
        result = leave_obj.get_leave_type_withcount(jsond)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('leavemanagement', 'get_leave_type_withcount', e)
    logger.addinfo('[POST] views - leavemanagement - get_leave_type_withcount(-)')
    return response


# Get users having leave management roles
@leavemanagement.route('/managers/<int:org_id>/', methods=['GET'])
def get_role_users(org_id=None):
    logger.addinfo('@ [GET] views - leavemanagement - get_role_users(+)')
    try:
        leave_obj = LeaveManagement()
        result = leave_obj.get_role_users(org_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('leavemanagement', 'get_role_users', e)
    logger.addinfo('[GET] views - leavemanagement - get_role_users(-)')
    return response


@leavemanagement.before_request
@auth.login_required
def before_request():
    pass
