from flask import Blueprint, Response, request
from scorpionapi.models.resumeparser.resumeparser import ResumeParser
from scorpionapi.plugins import auth
from scorpionapi.utils.common_utils import CommonUtils
import ujson
from scorpionapi.utils.constants import Status
from scorpionapi.utils.log_util import LogUtil

resumeparser = Blueprint('resumeparser', __name__, url_prefix='/resumeparser')


@resumeparser.route('/summary/<int:user_id>/', methods=['GET'])
def get_resume_parser_summary(user_id=None):
    try:
        resume_parser_obj = ResumeParser()
        result = resume_parser_obj.get_resume_parser_summary(user_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('resumeparser', 'get_resume_parser_summary', e)
    return response


@resumeparser.route('/', methods=['POST'])
def manage_resumeparser():
    data = ujson.loads(request.data)
    try:
        resume_parser_obj = ResumeParser()
        result = resume_parser_obj.manage_resumeparser(data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('resumeparser', 'manage_resumeparser', e)
    return response


@resumeparser.before_request
@auth.login_required
@LogUtil.before_request
def before_request():
    pass


@resumeparser.after_request
@LogUtil.after_request
def after_request(response):
    return response
