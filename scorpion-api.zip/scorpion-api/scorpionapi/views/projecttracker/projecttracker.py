from flask import Blueprint, Response, request
from scorpionapi.models.projecttracker.projecttracker import ProjectTracker
from scorpionapi.plugins import auth
from scorpionapi.utils.common_utils import CommonUtils
import ujson
from scorpionapi.utils.log_util import LogUtil

projecttracker = Blueprint('projecttracker', __name__, url_prefix='/project/tracker/')


@projecttracker.route('/', methods=['GET'])
def project_summary():
    try:
        projecttracker_obj = ProjectTracker()
        result = projecttracker_obj.get_project_info()
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('project_tracker', 'project_summary', e)
    return response


@projecttracker.route('/dc/summary/', methods=['GET'])
def get_project_summary():
    try:
        projecttracker_obj = ProjectTracker()
        result = projecttracker_obj.get_project_summary()
    except Exception as e:
        return CommonUtils.pass_error('project_tracker', 'get_project_summary', e)
    response = Response(ujson.dumps(result), status=200,
                        mimetype='application/json')
    return response


@projecttracker.route('/dc/manage/project/', methods=['POST'])
def manage_project():
    jsond = ujson.loads(request.data)
    try:
        projecttracker_obj = ProjectTracker()
        result = projecttracker_obj.manage_project(jsond)
    except Exception as e:
        return CommonUtils.pass_error('project_tracker', 'manage_project', e)
    response = Response(ujson.dumps(result), status=200,
                        mimetype='application/json')
    return response


@projecttracker.before_request
@auth.login_required
@LogUtil.before_request
def before_request():
    pass


@projecttracker.after_request
@LogUtil.after_request
def after_request(response):
    return response
