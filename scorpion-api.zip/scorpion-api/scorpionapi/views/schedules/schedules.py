import ujson
from flask import Blueprint, Response, request
from scorpionapi.models.schedules.schedules import Schedules
from scorpionapi.utils.logdata import logger
from scorpionapi.plugins import auth

schedules = Blueprint('schedules', __name__, url_prefix='/schedules')


@schedules.route('/', methods=['POST'])
def post():
    logger.addinfo(" @[POST] views - schedules - post(+)")
    jsonData = ujson.loads(request.data)
    header_id = Schedules.head_id()
    try:
        result = Schedules.insertSchedule(jsonData, header_id)
    except Exception as error:
        logger.dthublog("""@ 19 EXCEPTION - views - schedules -
             post """ + str(error))
        final = dict()
        final['status'] = 1
        final['msg'] = str(error)
        response = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
        return response
    final = dict()
    if result['result'] == "success":
        final['status'] = 0
        final['msg'] = "Schedule created successfully"
        final['header_id'] = result['req_id']
    else:
        final = result
    logger.addinfo("@ [POST] views - schedules - post(-)")
    return ujson.dumps(final)


@schedules.route('/summary/<int:org_id>/', methods=['GET'])
def get_schedules(org_id=None):
    logger.addinfo(" @[GET] views - schedules - get_schedules(+)")
    try:
        result = Schedules.get_schedules(org_id)
    except Exception as error:
        logger.dthublog("""@ 46 EXCEPTION - views - schedules -
             get_schedules """ + str(error))
        final = dict()
        final['status'] = 1
        final['msg'] = str(error)
        response = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
        return response
    logger.addinfo("@ [GET] views - schedules - get_schedules(-)")
    return ujson.dumps(result)


@schedules.route('/<int:schedule_id>/', methods=['DELETE'])
def delete_schedule(schedule_id=None):
    logger.addinfo('@ [DELETE] views - schedules - delete_schedule(+)')
    try:
        result = Schedules.delete_schedule(schedule_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as error:
        logger.dthublog("""@ 67 EXCEPTION - views - schedules -
                         delete_schedule """ + str(error))
        final = dict()
        final['status'] = 1
        final['msg'] = str(error)
        resp = Response(ujson.dumps(final), status=200,
                        mimetype='application/json')
        return resp
    logger.addinfo('@ [DELETE] views - schedules - delete_schedule(-)')
    return response


@schedules.route('/line/<int:line_id>/', methods=['DELETE'])
def delete_line(line_id=None):
    logger.addinfo('@ [DELETE] views - schedules - delete_line(+)')
    try:
        result = Schedules.delete_line(line_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as error:
        logger.dthublog("""@ 88 EXCEPTION - views - schedules -
                         delete_line """ + str(error))
        final = dict()
        final['status'] = 1
        final['msg'] = str(error)
        resp = Response(ujson.dumps(final), status=200,
                        mimetype='application/json')
        return resp
    logger.addinfo('@ [DELETE] views - schedules - delete_line(-)')
    return response


@schedules.route('/<int:schedule_id>/', methods=['GET'])
def get_by_id(schedule_id=None):
    logger.addinfo('@ [GET] views - schedules - get_by_id(+)')
    try:
        result = Schedules.show_header(schedule_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as error:
        logger.dthublog("""@ 109 EXCEPTION - views - schedules -
                         get_by_id """ + str(error))
        final = dict()
        final['status'] = 1
        final['msg'] = str(error)
        resp = Response(ujson.dumps(final), status=200,
                        mimetype='application/json')
        return resp
    logger.addinfo('@ [GET] views - schedules - get_by_id(-)')
    return response


@schedules.route('/header/<int:schedule_id>/', methods=['GET'])
def get_schedule_details(schedule_id=None):
    logger.addinfo('@ [GET] views - schedules - get_by_id(+)')
    try:
        result = Schedules.get_schedule_details(schedule_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as error:
        logger.dthublog("""@ 109 EXCEPTION - views - schedules -
                         get_by_id """ + str(error))
        final = dict()
        final['status'] = 1
        final['msg'] = str(error)
        resp = Response(ujson.dumps(final), status=200,
                        mimetype='application/json')
        return resp
    logger.addinfo('@ [GET] views - schedules - get_by_id(-)')
    return response


@schedules.route('/', methods=['PUT'])
def put():
    logger.addinfo("@ [PUT] views - schedules - put(+)")
    jsond = ujson.loads(request.data)
    header_id = jsond['SCHEDULE_HEADER_ID']
    lines = jsond['lines']
    del jsond['lines']
    try:
        new_lines = []
        update_lines = []
        for i in lines:
            if 'SCHEDULE_LINE_ID' in i:
                update_lines.append(i)
            else:
                new_lines.append(i)
        update_result = Schedules.line_update(update_lines)
        if update_result == 'success':
            result = Schedules.insert_lines(new_lines, header_id, jsond['TASK_ID'])
        if result == 'success':
            final_msg = Schedules.update_schedule(jsond, header_id)
    except Exception as error:
        logger.dthublog("""@ 143 EXCEPTION - views - schedules -
             put """ + str(error))
        final = dict()
        final['status'] = 1
        final['msg'] = str(error)
        response = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
        return response
    final = dict()
    if final_msg == "success":
        final['status'] = 0
        final['msg'] = "Schedule updated successfully"
        final['header_id'] = header_id
    else:
        final['status'] = 1
        final['msg'] = "Schedule updation failed"
    logger.addinfo("@ [POST] views - schedules - put(-)")
    return ujson.dumps(final)


@schedules.route('/lines/', methods=['POST'])
def delete_lines():
    jsond = ujson.loads(request.data)
    logger.addinfo('@ [POST] views - schedules - delete_lines(+)')
    final = dict()
    try:
        results = []
        for i in jsond:
            result = Schedules.delete_line(i)
            if result == 'success':
                results.append(result)
        if len(jsond) == len(results):
            final['status'] = 0
            final['msg'] = 'Lines deleted successfully'
        response = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
    except Exception as error:
        logger.dthublog("""@ 173 EXCEPTION - views - schedules -
                         delete_lines """ + str(error))
        final['status'] = 1
        final['msg'] = str(error)
        resp = Response(ujson.dumps(final), status=200,
                        mimetype='application/json')
        return resp
    logger.addinfo('@ [POST] views - schedules - delete_lines(-)')
    return response


@schedules.before_request
@auth.login_required
def before_request():
    pass
