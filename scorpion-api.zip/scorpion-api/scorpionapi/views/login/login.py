import ujson
import requests
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer

from flask import Blueprint, request, Response
from scorpionapi.models.login.login import Login
from flask import current_app
from scorpionapi.utils import auth_util
from scorpionapi.utils.common_utils import CommonUtils
from scorpionapi.models.preferences.preferences import Preferences
from scorpionapi.utils.constants import Status
from scorpionapi.models.wfn.wfn import Wfn


login = Blueprint('login', __name__, url_prefix='/login')


# check user credentials
@login.route('/', methods=['POST'])
def user_verification():
    req = ujson.loads(request.data)
    """
    Decoding username & password which were received in random attributes
    from the front-end. The correct attribute values start with `--#` and end with `#--`
    """
    if 'user_name1' in req:
        for i in range(3):
            user_name = CommonUtils.decode_credential(req['user_name' + str(i + 1)])
            password = CommonUtils.decode_credential(req['password' + str(i + 1)])
            if user_name[:3].decode() == '--#' and user_name[-3:].decode() == '#--':
                req['user_name'] = user_name[3:-3].decode()
            if password[:3].decode() == '--#' and password[-3:].decode() == '#--':
                req['password'] = password[3:-3].decode()
    user_name = req['user_name']
    password = req['password']
    source = ''
    if 'source' in req:
        source = req['source']
    res = {}
    if user_name and password:
        try:
            s = Serializer(current_app.config['SECRET_KEY'], expires_in=86400)
            user_data = Login.authenticate(user_name, password, source)
            if user_data != 'user_name' and user_data != 'fails':
                url = "http://localhost:8008/request-token"
                token = requests.get(url, auth=(user_name, password))
                res = token.json()
                res['result'] = user_data
                res['refresh_token'] = s.dumps({'username': user_name,
                                                'password': password})
            else:
                res['status'] = 1
                res['msg'] = "Please enter valid credentials"
        except Exception as error:
            CommonUtils.pass_error('login', 'user_verification', error)
            print(str(error))
    else:
        res['status'] = 1
        res['msg'] = "Please enter valid data"
    response = Response(ujson.dumps(res), status=200,
                        mimetype='application/json')
    return response


@login.route('/details/', methods=['POST'])
def get_user_details():
    req = ujson.loads(request.data)
    res = {}
    if 'key_val' in req:
        try:
            result = Preferences.get_userdetails(req['key_val'])
            res['status'] = 0
            res['msg'] = result
        except Exception as error:
            CommonUtils.pass_error('login', 'get_user_details', error)
    else:
        res['status'] = 1
        res['msg'] = "Please enter valid data"
    response = Response(ujson.dumps(res), status=200,
                        mimetype='application/json')
    return response


@login.route('/re-requesttoken/', methods=['POST'])
def generate_new_token():
    res = {}
    try:
        req = ujson.loads(request.data)
        s = Serializer(current_app.config['SECRET_KEY'])
        data = s.loads(req['refresh_token'])
        url = "http://localhost:8008/request-token"
        token = requests.get(url, auth=(data['username'],
                                        data['password']))
        res = token.json()
    except Exception as error:
        CommonUtils.pass_error('login', 'generate_new_token', error)
    return Response(ujson.dumps(res), status=200,
                    mimetype='application/json')


@login.route('/reset/', methods=['POST'])
def reset_pass():
    req = ujson.loads(request.data)
    res = {}
    if 'user_name' in req:
        try:
            result = Preferences.reset_passwd(req['user_name'])
            res['status'] = 1
            if result == 'success':
                res['status'] = 0
                res['msg'] = "Please check your email for further details"
            elif result == 'failed':
                res['msg'] = "Failed to change the password"
            else:
                res['msg'] = "Please enter valid username"
        except Exception as error:
            CommonUtils.pass_error('login', 'reset_pass', error)
    else:
        res['status'] = 1
        res['msg'] = "Please enter valid data"
    response = Response(ujson.dumps(res), status=200,
                        mimetype='application/json')
    return response


@login.route('/passwdchanged/', methods=['POST'])
def password_changed():
    req = ujson.loads(request.data)
    res = {}
    if 'user_name' in req and 'new_password' in req:
        try:
            result = Preferences.reset_message(req['user_name'],
                                               req['new_password'])
            res['status'] = 0
            res['msg'] = result
        except Exception as error:
            CommonUtils.pass_error('login', 'password_changed', error)
    else:
        res['status'] = 1
        res['msg'] = "Please enter valid data"
    response = Response(ujson.dumps(res), status=200,
                        mimetype='application/json')
    return response


# Approve or reject wfn client addition from mail
@login.route('/approveclient/<string:client_id>/', methods=['GET'])
def approve_leave(client_id=None):
    try:
        wfn_obj = Wfn()
        result = wfn_obj.update_client_status(client_id)
        if result == 'SUCCESS':
            resp = {
                'msg': 'Status updated successfully',
                'status': Status.OK.value
            }
        else:
            resp = {
                'msg': result,
                'status': Status.ERROR.value
            }
        response = Response(ujson.dumps(resp), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('login', 'approve_leave', e)
    return response

# generate encrypted password
def hashPassword(password):
    return auth_util.encrypt(password)
