from flask import Blueprint, Response, request
from scorpionapi.models.rpo.rpo import Rpo
from scorpionapi.plugins import auth
from scorpionapi.utils.common_utils import CommonUtils
import ujson
from scorpionapi.utils.constants import Status
from scorpionapi.utils.log_util import LogUtil

rpo = Blueprint('rpo', __name__, url_prefix='/rpo')


@rpo.route('/', methods=['POST'])
def read_file():
    jsond = ujson.loads(request.data)
    try:
        rpo_obj = Rpo()
        file_data = rpo_obj.read_file(jsond)
        response = Response(ujson.dumps(file_data), status=200,
                            mimetype="application/json")
    except Exception as e:
        return CommonUtils.pass_error('wfn', 'add_client', e)
    return response


@rpo.before_request
@auth.login_required
@LogUtil.before_request
def before_request():
    pass


@rpo.after_request
@LogUtil.after_request
def after_request(response):
    return response
