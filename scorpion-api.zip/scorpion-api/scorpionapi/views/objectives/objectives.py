from flask import Blueprint, Response, request
from scorpionapi.models.objectives.objectives import Objectives
import ujson
from scorpionapi.utils.logdata import logger
from scorpionapi.plugins import auth

objectives = Blueprint('objectives', __name__, url_prefix='/objectives')


@objectives.route('/budget/categories/', methods=['GET'])
def get_budget_categories():
    logger.addinfo('@ [GET] views - objectives - get_budget_categories(+)')
    try:
        budget = Objectives.get_budget_categories()
        resp = Response(ujson.dumps(budget), status=200,
                        mimetype='application/json')
    except Exception as error:
        logger.dthublog("""@ 18 EXCEPTION - views - objectives -
             get_budget_categories """ + str(error))
        final_msg = dict()
        final_msg['status'] = 1
        final_msg['msg'] = str(error)
        resp = Response(ujson.dumps(final_msg), status=200,
                        mimetype='application/json')
        return resp
    logger.addinfo('@ [GET] - views - objectives - get_budget_categories(-)')
    return resp


@objectives.route('/budget/description/', methods=['GET'])
def get_budget_description():
    logger.addinfo('@ [GET] views - objectives - get_budget_description(+)')
    try:
        budget = Objectives.get_budget_description()
        resp = Response(ujson.dumps(budget), status=200,
                        mimetype='application/json')
    except Exception as error:
        logger.dthublog("""@ 39 EXCEPTION - views - objectives -
             get_budget_description """ + str(error))
        final_msg = dict()
        final_msg['status'] = 1
        final_msg['msg'] = str(error)
        resp = Response(ujson.dumps(final_msg), status=200,
                        mimetype='application/json')
        return resp
    logger.addinfo('@ [GET] - views - objectives - get_budget_description(-)')
    return resp


@objectives.route('/invoicefrequency/', methods=['GET'])
def get_invoice_frequency():
    logger.addinfo('@ [GET] views - objectives - get_invoice_frequency(+)')
    try:
        invoice_frequency = Objectives.get_invoice_frequency()
        resp = Response(ujson.dumps(invoice_frequency), status=200,
                        mimetype='application/json')
    except Exception as error:
        logger.dthublog("""@ 60 EXCEPTION - views - objectives -
             get_invoice_frequency """ + str(error))
        final_msg = dict()
        final_msg['status'] = 1
        final_msg['msg'] = str(error)
        resp = Response(ujson.dumps(final_msg), status=200,
                        mimetype='application/json')
        return resp
    logger.addinfo('@ [GET] - views - objectives - get_invoice_frequency(-)')
    return resp


@objectives.route('/targets/', methods=['GET'])
def get_targets():
    logger.addinfo('@ [GET] views - objectives - get_targets(+)')
    try:
        targets = Objectives.get_targets()
        resp = Response(ujson.dumps(targets), status=200,
                        mimetype='application/json')
    except Exception as error:
        logger.dthublog("""@ 80 EXCEPTION - views - objectives -
             get_targets """ + str(error))
        final_msg = dict()
        final_msg['status'] = 1
        final_msg['msg'] = str(error)
        resp = Response(ujson.dumps(final_msg), status=200,
                        mimetype='application/json')
        return resp
    logger.addinfo('@ [GET] - views - objectives - get_targets(-)')
    return resp


@objectives.route('/data/', methods=['POST'])
def get_customer_objectives():
    logger.addinfo('@ [POST] views - objectives - get_customer_objectives(+)')
    jsond = ujson.loads(request.data)
    try:
        customer_objectives = Objectives.get_customer_objectives(jsond)
        resp = Response(ujson.dumps(customer_objectives), status=200,
                        mimetype='application/json')
    except Exception as error:
        logger.dthublog("""@ 101 EXCEPTION - views - objectives -
             get_customer_objectives """ + str(error))
        final_msg = dict()
        final_msg['status'] = 1
        final_msg['msg'] = str(error)
        resp = Response(ujson.dumps(final_msg), status=200,
                        mimetype='application/json')
        return resp
    logger.addinfo('@ [POST] - views - objectives - get_customer_objectives(-)')
    return resp


@objectives.route('/<int:cust_objective_id>/', methods=['DELETE'])
def delete_objective(cust_objective_id=None):
    logger.addinfo('@ [DELETE] views - objectives - delete_objective(+)')
    final = {}
    try:
        objective = Objectives.delete_objective(cust_objective_id)
        if objective == 'S':
            final['msg'] = 'Objective with # ' + str(cust_objective_id)
            final['msg'] += ' deleted successfully'
            final['status'] = 0
        resp = Response(ujson.dumps(final), status=200,
                        mimetype='application/json')
    except Exception as error:
        logger.dthublog("""@ 170 EXCEPTION - views - objectives -
             delete_objective """ + str(error))
        final['status'] = 1
        final['msg'] = str(error)
        resp = Response(ujson.dumps(final), status=200,
                        mimetype='application/json')
        return resp
    logger.addinfo('@ [DELETE] - views - objectives - delete_objective(-)')
    return resp


@objectives.route('/', methods=['POST'])
def save_objective():
    logger.addinfo('@ [POST] views - objectives - save_objective(+)')
    jsond = ujson.loads(request.data)
    final = {}
    try:
        objective = Objectives.save_objective(jsond)
        if len(objective) == 1 and objective[0] == 'success':
            final['msg'] = 'Objective created successfully'
            final['status'] = 0
        elif len(objective) == 1 and objective[0] == 'error':
            final['msg'] = 'Failed to create objective'
            final['status'] = 1
        else:
            msg = 'Objective created successfully but failed to insert '
            for b in objective:
                if b == 'customers':
                    msg += 'related customers,'
                if b == 'vendors':
                    msg += ' related vendors,'
                if b == 'lines':
                    msg += ' budget lines'
                if b == 'attachments':
                    msg += ' attachments'
            final['msg'] = msg
            final['status'] = 0
        resp = Response(ujson.dumps(final), status=200,
                        mimetype='application/json')
    except Exception as error:
        logger.dthublog("""@ 166 EXCEPTION - views - objectives -
             save_objective """ + str(error))
        final['status'] = 1
        final['msg'] = str(error)
        resp = Response(ujson.dumps(final), status=200,
                        mimetype='application/json')
        return resp
    logger.addinfo('@ [POST] - views - objectives - save_objective(-)')
    return resp


@objectives.route('/edit/<int:cust_objective_id>/', methods=['GET'])
def get_objective_details(cust_objective_id=None):
    logger.addinfo('@ [GET] views - objectives - get_objective_details(+)')
    final = {}
    try:
        objective = Objectives.get_objective_details(cust_objective_id)
        resp = Response(ujson.dumps(objective), status=200,
                        mimetype='application/json')
    except Exception as error:
        logger.dthublog("""@ 188 EXCEPTION - views - objectives -
             get_objective_details """ + str(error))
        final['status'] = 1
        final['msg'] = str(error)
        resp = Response(ujson.dumps(final), status=200,
                        mimetype='application/json')
        return resp
    logger.addinfo('@ [GET] - views - objectives - get_objective_details(-)')
    return resp


@objectives.route('/', methods=['PUT'])
def update_objective():
    logger.addinfo('@ [PUT] views - objectives - update_objective(+)')
    jsond = ujson.loads(request.data)
    final = dict()
    try:
        objective = Objectives.update_objective(jsond)
        if len(objective) == 1 and objective[0] == 'success':
            final['msg'] = 'Objective updated successfully'
            final['status'] = 0
        elif len(objective) == 1 and objective[0] == 'error':
            final['msg'] = 'Failed to update objective'
            final['status'] = 1
        else:
            msg = 'Objective updated successfully but failed to update '
            for b in objective:
                if b == 'customers':
                    msg += 'related customers,'
                if b == 'vendors':
                    msg += ' related vendors,'
                if b == 'lines':
                    msg += ' budget lines'
                if b == 'attachments':
                    msg += ' attachments'
            final['msg'] = msg
            final['status'] = 0
        resp = Response(ujson.dumps(final), status=200,
                        mimetype='application/json')
    except Exception as error:
        logger.dthublog("""@ 166 EXCEPTION - views - objectives -
             update_objective """ + str(error))
        final['status'] = 1
        final['msg'] = str(error)
        resp = Response(ujson.dumps(final), status=200,
                        mimetype='application/json')
        return resp
    logger.addinfo('@ [POST] - views - objectives - update_objective(-)')
    return resp


@objectives.before_request
@auth.login_required
def before_request():
    pass
