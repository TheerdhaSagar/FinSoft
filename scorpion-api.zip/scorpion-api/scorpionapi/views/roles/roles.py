from flask import Blueprint, request, Response
import ujson
from scorpionapi.utils.logdata import logger
from scorpionapi.plugins import auth
from scorpionapi.models.usermngmnt.roles import Roles

roles = Blueprint('roles', __name__, url_prefix='/roles')


@roles.route('/', methods=['GET'])
@roles.route('/id/<int:role_id>/', methods=['GET'])
def get_roles(role_id=None):
    logger.addinfo("@ [GET] views - roles - get_roles(+)")
    try:
        result = Roles.get_roles(role_id)
        resp = Response(ujson.dumps(result), status=200,
                        mimetype='application/json')
    except Exception as error:
        logger.dthublog("""@ 19 EXCEPTION - models - roles -
             get_roles """ + str(error))
        final = dict
        final['status'] = 1
        final['msg'] = str(error)
        response = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
        return response
    logger.addinfo("@ [GET] views - roles - get_roles(-)")
    return resp


@roles.route('/permissions/<int:role_id>/', methods=['GET'])
def get_roleperms(role_id=None):
    logger.addinfo("@ [GET] views - roles - get_roleperms(+)")
    final = {}
    if role_id:
        try:
            result = Roles.get_role_withperm(role_id)
            resp = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
        except Exception as error:
            logger.dthublog("""@ 42 EXCEPTION - views - roles -
                 get_roleperms """ + str(error))
            final['status'] = 1
            final['msg'] = str(error)
            response = Response(ujson.dumps(final), status=200,
                                mimetype='application/json')
            return response
            raise
    else:
        final['status'] = 1
        final['msg'] = "Please enter valid data"
        resp = Response(ujson.dumps(final), status=200,
                        mimetype='application/json')
    logger.addinfo("@ [GET] views - roles - get_roleperms(-)")
    return resp


@roles.route('/permissions/', methods=['GET'])
def get_roleperm():
    logger.addinfo("@ [GET] views - roles - get_roleperm(+)")
    try:
        result = Roles.get_permlov()
        resp = Response(ujson.dumps(result), status=200,
                        mimetype='application/json')
    except Exception as error:
        logger.dthublog("""@ 67 EXCEPTION - views - roles -
             get_roleperm """ + str(error))
        final = dict()
        final['status'] = 1
        final['msg'] = str(error)
        response = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
        return response
    logger.addinfo("@ [GET] views - roles - get_roleperm(-)")
    return resp


@roles.route('/save/', methods=['POST'])
def role_save():
    logger.addinfo("@ [POST] views - roles - role_save(+)")
    jsond = ujson.loads(request.data)
    final = dict()
    if jsond:
        try:
            seqval = Roles.get_roleseq()
            permissions = jsond['role_permissions']
            del jsond['role_permissions']
            new_role = Roles()
            for key, value in jsond.items():
                setattr(new_role, key, value)
            resultr = Roles.save(new_role, seqval, "role")
            for permission in permissions:
                new_rolep = Roles()
                for key, value in permission.items():
                    setattr(new_rolep, key, value)
                resultr = Roles.save(new_rolep, seqval, "permission")
        except Exception as error:
            logger.dthublog("""@ 100 EXCEPTION - views - roles -
                 role_save """ + str(error))
            final = dict()
            final['status'] = 1
            final['msg'] = error
            resp = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
            return resp
        if resultr == "success":
            final['status'] = 0
            final['msg'] = "Role created successfully"
            resp = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
        else:
            final['status'] = 1
            final['msg'] = "Failed to create role"
            resp = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
    logger.addinfo("@ [POST] views - roles - role_save(-)")
    return resp


@roles.route('/update/', methods=['POST'])
def role_update():
    logger.addinfo("@ [POST] views - roles - role_update(+)")
    jsond = ujson.loads(request.data)
    final = dict()
    if jsond:
        try:
            permissions = jsond['role_permissions']
            role_id = jsond['role_id']
            del jsond['role_permissions']
            del jsond['role_id']
            new_role = Roles()
            for key, value in jsond.items():
                setattr(new_role, key, value)
            resultr = Roles.update(new_role, "role", role_id)
            for permission in permissions:
                new_rolep = Roles()
                perm_id = ""
                for key, value in permission.items():
                    if key == 'permission_id':
                        perm_id = value
                    setattr(new_rolep, key, value)
                result = Roles.get_role_perm_validation(role_id, perm_id)
                if result == "update":
                    resultr = Roles.update(new_rolep, "permission", role_id)
                elif result == "save":
                    resultr = Roles.save(new_rolep, role_id, "permission")
        except Exception as error:
            logger.dthublog("""@ 151 EXCEPTION - views - roles -
                 role_update """ + str(error))
            final = dict()
            final['status'] = 1
            final['msg'] = str(error)
            resp = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
            return resp
        if resultr == "success":
            final['status'] = 0
            final['msg'] = "Role updated successfully"
            resp = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
        else:
            final['status'] = 1
            final['msg'] = "Failed to update role"
            resp = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
    logger.addinfo("@ [POST] views - roles - role_update(-)")
    return resp


@roles.route('/validate/<string:value>/', methods=['GET'])
def role_validation(value=None):
    logger.addinfo("@ [GET] views - roles - role_validation(+)")
    try:
        result = Roles.get_validation(value)
        resp = Response(ujson.dumps(result), status=200,
                        mimetype='application/json')
    except Exception as error:
        logger.dthublog("""@ 182 EXCEPTION - views - roles -
             role_validation """ + str(error))
        final = dict()
        final['status'] = 1
        final['msg'] = str(error)
        resp = Response(ujson.dumps(final),
                        status=200, mimetype='application/json')
        return ujson.dumps(final)
    logger.addinfo("@ [GET] views - roles - role_validation(-)")
    return resp


@roles.before_request
@auth.login_required
def before_request():
    pass
