from flask import Blueprint, Response, request
from scorpionapi.models.balances.balances import Balances
from scorpionapi.plugins import auth
from scorpionapi.utils.common_utils import CommonUtils
import ujson
from scorpionapi.utils.log_util import LogUtil
from scorpionapi.utils.constants import Status

balances = Blueprint('balances', __name__, url_prefix='/balances')


@balances.route('/', methods=['POST'])
def manage_balance():
    data = ujson.loads(request.data)
    try:
        balance_obj = Balances()
        job_status = balance_obj.check_client_is_processing(data)
        if job_status[0]['status'] == 'P':
            result = {
                "status": 1,
                "msg": 'ASP Files are currently processing for Client, ' + data['client_name'] +
                       '. Please retry once current processing has completed.'
            }
        else:
            result = balance_obj.add_balance(data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('balances', 'request_insert', e)
    return response


@balances.route('/audit/upload/', methods=['POST'])
def manage_wage_tax():
    data = ujson.loads(request.data)
    try:
        balance_obj = Balances()
        result = balance_obj.wage_tax_upload(data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('balances', 'manage_wage_tax', e)
    return response


@balances.route('/client/<string:client_id>/', methods=['DELETE'])
def delete_client_details(client_id=None):
    try:
        balance_obj = Balances()
        result = balance_obj.delete_client_details(client_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('balances', 'delete_client_details', e)
    return response


@balances.route('/emp/report/<int:report_id>/', methods=['DELETE'])
def delete_emp_report(report_id=None):
    try:
        balance_obj = Balances()
        result = balance_obj.delete_emp_report(report_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('balances', 'delete_emp_report', e)
    return response


@balances.route('/audit/client/<string:client_id>/<string:audit_type>/', methods=['DELETE'])
def delete_audit_client_details(client_id=None, audit_type=None):
    try:
        balance_obj = Balances()
        result = balance_obj.delete_audit_client_details(client_id, audit_type)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('balances', 'delete_audit_client_details', e)
    return response


@balances.route('/summary/<int:user_id>/<string:status>/', methods=['GET'])
def get_balances_summary(user_id=None, status=None):
    try:
        balance_obj = Balances()
        result = balance_obj.get_balances_summary(user_id, status)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('balances', 'get_balances_summary', e)
    return response


@balances.route('/report/check/<string:report_name>/<int:user_id>/<string:report_type>/', methods=['GET'])
def report_checker(report_name=None, user_id=None, report_type=None):
    try:
        balance_obj = Balances()
        result = balance_obj.report_checker(report_name, user_id, report_type)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('balances', 'report_checker', e)
    return response


@balances.route('/audit/summary/<int:user_id>/<string:status>/', methods=['GET'])
def get_tax_wage_balances_summary(user_id=None, status=None):
    try:
        balance_obj = Balances()
        result = balance_obj.get_tax_wage_balances_summary(user_id, status)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('balances', 'get_balances_summary', e)
    return response


@balances.route('/client/details/', methods=['POST'])
def get_client_details():
    try:
        req = ujson.loads(request.data)
        balance_obj = Balances()
        result = balance_obj.get_client_details(req)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('balances', 'get_client_details', e)
    return response


@balances.route('/report/emp/summary/', methods=['POST'])
def add_emp_report():
    try:
        req = ujson.loads(request.data)
        balance_obj = Balances()
        result_checker = balance_obj.report_checker(req, 'emp-report')
        if result_checker['status'] == 0:
            result = balance_obj.async_generate_emp_report(req)
        else:
            result = result_checker
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('balances', 'add_emp_report', e)
    return response


@balances.route('/dcon/files/<string:client_id>/', methods=['GET'])
def get_dcon_attachment(client_id=None):
    try:
        balance_obj = Balances()
        user = request.args.get('user')
        result = balance_obj.get_dcon_attachment(client_id, user)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('balances', 'get_dcon_attachment', e)
    return response


@balances.route('/emp/audit/report/files/<int:report_id>/', methods=['GET'])
def get_emp_report_attachment(report_id=None):
    try:
        balance_obj = Balances()
        user = request.args.get('user')
        result = balance_obj.get_emp_report_attachment(report_id, user)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('balances', 'get_dcon_attachment', e)
    return response


@balances.route('/reports/codes/<int:user_id>/', methods=['GET'])
def get_audit_client_codes(user_id=None):
    try:
        balance_obj = Balances()
        result = balance_obj.get_audit_client_codes(user_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('balances', 'get_dcon_attachment', e)
    return response


@balances.route('/wage/tax/files/<string:client_id>/', methods=['GET'])
def get_wage_tax_attachment(client_id=None):
    try:
        balance_obj = Balances()
        user = request.args.get('user')
        result = balance_obj.get_wage_tax_attachment(client_id, user)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('balances', 'get_wage_tax_attachment', e)
    return response


@balances.route('/control/files/<string:client_id>/', methods=['GET'])
def get_control_totals_attachment(client_id=None):
    try:
        balance_obj = Balances()
        user = request.args.get('user')
        result = balance_obj.get_control_totals_attachment(client_id, user)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('balances', 'get_control_totals_attachment', e)
    return response


@balances.route('/translation/files/<string:client_id>/', methods=['GET'])
def get_translation_attachment(client_id=None):
    try:
        balance_obj = Balances()
        user = request.args.get('user')
        result = balance_obj.get_translation_attachment(client_id, user)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('balances', 'get_translation_attachment', e)
    return response


@balances.route('/report/emp/download/<int:report_id>/', methods=['GET'])
def get_report_emp_download(report_id=None):
    try:
        balance_obj = Balances()
        result = balance_obj.get_report_emp_download(report_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('balances', 'get_translation_attachment', e)
    return response


@balances.route('/emp/report/summary/<int:user_id>/', methods=['GET'])
def get_report_emp_summary(user_id=None):
    try:
        balance_obj = Balances()
        result = balance_obj.get_report_emp_summary(user_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('balances', 'get_report_emp_summary', e)
    return response


@balances.route('/report/download/', methods=['POST'])
def get_reports_pkg_attachment():
    try:
        req = ujson.loads(request.data)
        balance_obj = Balances()
        result = balance_obj.get_reports_pkg_attachment(req)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('balances', 'get_reports_pkg_attachment', e)
    return response


@balances.before_request
@auth.login_required
@LogUtil.before_request
def before_request():
    pass


@balances.after_request
@LogUtil.after_request
def after_request(response):
    return response
