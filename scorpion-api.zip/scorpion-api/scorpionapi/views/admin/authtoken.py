import base64

from flask import request, Blueprint, jsonify, g
from flask_httpauth import HTTPBasicAuth

from scorpionapi.decorators import json
from scorpionapi.models.admin.user import User
from scorpionapi.sql import sql_util
from scorpionapi.utils import db_util

authtoken = Blueprint('authtoken', __name__)
token_auth = HTTPBasicAuth()
user_name = ""
debug_flag = ""


@token_auth.verify_password
def verify_password(username, password):
    """
    Check whether the username exists and if the given username & password
    matches with the values in database

    :param username: Username
    :param password: Password
    :type username: str
    :type password: str
    :return: True if username & password match else returns False
    :rtype: bool
    """
    api_key = request.headers.get('x-api-key')
    api_secret = request.headers.get('x-api-secret')

    connection = db_util.get_connection()
    cursor = connection.cursor()
    sql_file = sql_util.get_sql('generic')

    user_data = User()

    if not api_key and not api_secret:
        user_query = sql_file['user_auth_query']
        cursor.execute(user_query, p_user_name=username.upper())
        data = cursor.fetchone()
        if data:
            user_data.user_id = data[1]
            user_data.user_name = data[0]
            user_data.debug_flag = data[3]
            user_data.encrypted_password = data[2]
        else:
            user_data.clear()
    else:
        api_query = sql_file['api_validate_query']
        cursor.execute(api_query, p_api_key=api_key,
                       p_api_secret=api_secret)
        data = cursor.fetchone()
        if data and len(data) > 0:
            user_data.user_id = data[2]
            user_data.user_name = data[1]
            user_data.debug_flag = None
            user_data.encrypted_password = None

    g.user = user_data

    cursor.close()
    db_util.release_connection(connection)

    if api_key and api_secret:
        return True
    return g.user.verify_password(password)


def user_details():
    user_data = dict()
    user_data['user_name'] = g.user.user_name
    return user_data


@token_auth.error_handler
def unauthorized_error():
    response = jsonify({'status': 401, 'error': 'Unauthorized',
                        'message': 'Please authenticate to access this API'})
    response.status_code = 401
    return response


@authtoken.route('/request-token', methods=['GET'])
@token_auth.login_required
@json
def request_token():
    """
    Generate token based on the user

    :return: JWT token along with user_id & user_name
    :rtype: object

    :Example:

    .. code-block:: json

        {
            "user_id": 1,
            "user_name": "Username",
            "debug_flag": "N",
            "token": "<jwt_token>"
        }
    """
    api_key = request.headers.get('x-api-key')
    response = {
        'user_id': g.user.user_id,
        'debug_flag': g.user.debug_flag,
        'user_name': g.user.user_name
    }
    if api_key:
        auth_token = g.user.generate_auth_token() + ':' + g.user.user_id
        response['token'] = base64.b64encode(auth_token)
    else:
        response['token'] = g.user.generate_auth_token()
    return response
