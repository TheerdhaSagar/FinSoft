from __future__ import absolute_import

import os.path
import cx_Oracle

from scorpionapi.utils.common_utils import CommonUtils
from scorpionapi.utils.constants import Status
from scorpionapi.sql import sql_util
from scorpionapi.utils import db_util
from scorpionapi.utils.code_util import Code_util
from scorpionapi.utils.logdata import logger
import pandas as pd
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import jinja2
import os
import csv
import random
import zipfile
import io
import re
import base64
import threading
import shutil


class Balances:

    def __init__(self):
        self.strings = db_util.get_strings()
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())
        self.connection = None
        self.cursor = None
        self.is_acquired = False

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()
        self.is_acquired = True

    def release(self):
        if self.cursor:
            self.cursor.close()
            self.is_acquired = False
        db_util.release_connection(self.connection)

    def async_generate_wage_tax_upload(self, data):
        # Check if client id is already in processing
        """
        Generate balance audit asynchronously on a separate thread
        """
        # logger doesn't work when running on thread as it use
        # flask context to get current user details, so when
        # running on thread set logging to False
        thread = threading.Thread(target=self.wage_tax_upload, args=(data,))
        thread.deamon = True
        thread.start()
        return {
            'status': 0,
            'msg': self.sql_file['balances_async_status']
        }

    # inserting a new wage taxes file
    def wage_tax_upload(self, data):
        try:
            result = self.add_wage_tax_log(data)
            if result['status'] == 0:
                if not self.is_acquired:
                    self.acquire()
                status_code = self.cursor.var(cx_Oracle.STRING)
                decoded = base64.b64decode(data['base64'])
                column_list = self.sql_file['wage_tax_column_list']
                if data['audit_type'] == 'wage-tax':
                    comma_matcher = re.compile(r",(?=(?:[^\"']*[\"'][^\"']*[\"'])*[^\"']*$)")
                    with zipfile.ZipFile(io.BytesIO(decoded)) as z:
                        for filename in z.namelist():
                            if not os.path.isdir(filename):
                                # reading file
                                with z.open(filename) as f:
                                    lines = []
                                    for line in f.readlines():
                                        line = line.decode('utf8').strip()
                                        # line = str(line.decode('ISO-8859-1')).replace('Ð', '}')
                                        line = line.strip()
                                        line_list = ['"{}"'.format(x) for x in list(csv.reader([line.replace('\0', '')],
                                                                                               quotechar='"',
                                                                                               delimiter=',',
                                                                                               quoting=csv.QUOTE_ALL,
                                                                                               skipinitialspace=True
                                                                                               ))[0]]
                                        line_list = [i.strip('"') for i in line_list]
                                        extra_length = len(line_list) - 505
                                        del line_list[-extra_length:]
                                        line_list.append(data['client_id'])
                                        lines.append(line_list)
                                        # self.check_header_tax_wages()
                                    self.cursor.executemany(self.sql_file['insert_statement_wage_tax'], lines)
                    self.cursor.execute("""
                                        begin
                                            NAS_BALANCE_AUDIT_PKG.update_balance_audit_log(
                                            :p_client_id,
                                            :p_upload_type,
                                            :x_status_code
                                            );
                                    end; """, p_client_id=data['client_id'],
                                        p_upload_type='wage-tax',
                                        x_status_code=status_code)
                elif data['audit_type'] == 'control-totals':
                    file_name = CommonUtils.generate_random_string(10)
                    # Create file in tmp folder
                    temp_file_name = '/tmp/' + file_name + '.zip'

                    # Open file in write mode and write decoded excel content
                    text_file = open(temp_file_name, 'wb')
                    text_file.write(decoded)
                    text_file.close()
                    with zipfile.ZipFile(temp_file_name, 'r') as zip:
                        zip.extractall('/tmp/' + file_name)
                    files = os.listdir('/tmp/' + file_name)
                    df_all_excel_files = pd.DataFrame()
                    for f in files:
                        info = pd.read_excel('/tmp/' + file_name + '/' + f, dtype=str).fillna(value='')
                        info.replace('nan', '')
                        df_all_excel_files = df_all_excel_files.append(info)
                    lines = []
                    batch_size = 10000
                    for row in df_all_excel_files.iterrows():
                        row_data = row[1]
                        row_data['client_id'] = data['client_id']
                        lines.append(tuple(row_data))
                        if len(lines) % batch_size == 0:
                            self.cursor.executemany(self.sql_file['insert_control_totals'], lines)
                            lines = []
                    self.cursor.executemany(self.sql_file['insert_control_totals'], lines)
                    self.cursor.execute("""
                                        begin
                                            NAS_BALANCE_AUDIT_PKG.update_balance_audit_log(
                                            :p_client_id,
                                            :p_upload_type,
                                            :x_status_code
                                            );
                                    end; """, p_client_id=data['client_id'],
                                        p_upload_type='control-totals',
                                        x_status_code=status_code)
                elif data['audit_type'] == 'translations':
                    sheet_names = ['PAYGROUP_XLAT', 'FILE_NBR_XLAT', 'STATE_XLAT', 'SUI_XLAT', 'LOCAL1_XLAT',
                                   'LOCAL2_XLAT', 'OH_SD_XLAT', 'PA_LST_XLAT']
                    file_name = CommonUtils.generate_random_string(10)
                    # Create file in tmp folder
                    temp_file_name = '/tmp/' + file_name + '.xlsx'

                    # Open file in write mode and write decoded excel content
                    text_file = open(temp_file_name, 'wb')
                    text_file.write(decoded)
                    text_file.close()
                    df_paygroup = pd.read_excel(temp_file_name, dtype=str, sheet_name=sheet_names[0], engine='xlrd')
                    df_paygroup.replace('nan', '')
                    df_file_nbr = pd.read_excel(temp_file_name, dtype=str, sheet_name=sheet_names[1], engine='xlrd')
                    df_file_nbr.replace('nan', '')
                    df_state = pd.read_excel(temp_file_name, dtype=str, sheet_name=sheet_names[2], engine='xlrd')
                    df_state.replace('nan', '')
                    df_sui = pd.read_excel(temp_file_name, dtype=str, sheet_name=sheet_names[3], engine='xlrd')
                    df_sui.replace('nan', '')
                    df_local1 = pd.read_excel(temp_file_name, dtype=str, sheet_name=sheet_names[4], engine='xlrd')
                    df_local1.replace('nan', '')
                    df_local2 = pd.read_excel(temp_file_name, dtype=str, sheet_name=sheet_names[5], engine='xlrd')
                    df_local2.replace('nan', '')
                    df_oh_sd = pd.read_excel(temp_file_name, dtype=str, sheet_name=sheet_names[6], engine='xlrd')
                    df_oh_sd.replace('nan', '')
                    df_pa_lst = pd.read_excel(temp_file_name, dtype=str, sheet_name=sheet_names[7], engine='xlrd')
                    df_pa_lst.replace('nan', '')
                    lines = []
                    batch_size = 10000
                    for row in df_paygroup.iterrows():
                        row_data = row[1]
                        row_data['client_id'] = data['client_id']
                        lines.append(tuple(row_data))
                        if len(lines) % batch_size == 0:
                            self.cursor.executemany(self.sql_file['insert_xlat_paygroup'], lines)
                            lines = []
                    self.cursor.executemany(self.sql_file['insert_xlat_paygroup'], lines)
                    lines = []
                    for row in df_file_nbr.iterrows():
                        row_data = row[1]
                        row_data['client_id'] = data['client_id']
                        lines.append(tuple(row_data))
                        if len(lines) % batch_size == 0:
                            self.cursor.executemany(self.sql_file['insert_xlat_filenbr'], lines)
                            lines = []
                    self.cursor.executemany(self.sql_file['insert_xlat_filenbr'], lines)
                    lines = []
                    for row in df_state.iterrows():
                        row_data = row[1]
                        row_data['client_id'] = data['client_id']
                        lines.append(tuple(row_data))
                        if len(lines) % batch_size == 0:
                            self.cursor.executemany(self.sql_file['insert_xlat_state'], lines)
                            lines = []
                    self.cursor.executemany(self.sql_file['insert_xlat_state'], lines)
                    lines = []
                    for row in df_sui.iterrows():
                        row_data = row[1]
                        row_data['client_id'] = data['client_id']
                        lines.append(tuple(row_data))
                        if len(lines) % batch_size == 0:
                            self.cursor.executemany(self.sql_file['insert_xlat_sui'], lines)
                            lines = []
                    self.cursor.executemany(self.sql_file['insert_xlat_sui'], lines)
                    lines = []
                    for row in df_local1.iterrows():
                        row_data = row[1]
                        row_data['client_id'] = data['client_id']
                        lines.append(tuple(row_data))
                        if len(lines) % batch_size == 0:
                            self.cursor.executemany(self.sql_file['insert_xlat_local1'], lines)
                            lines = []
                    self.cursor.executemany(self.sql_file['insert_xlat_local1'], lines)
                    lines = []
                    for row in df_local2.iterrows():
                        row_data = row[1]
                        row_data['client_id'] = data['client_id']
                        lines.append(tuple(row_data))
                        if len(lines) % batch_size == 0:
                            self.cursor.executemany(self.sql_file['insert_xlat_local2'], lines)
                            lines = []
                    self.cursor.executemany(self.sql_file['insert_xlat_local2'], lines)
                    lines = []
                    for row in df_oh_sd.iterrows():
                        row_data = row[1]
                        row_data['client_id'] = data['client_id']
                        lines.append(tuple(row_data))
                        if len(lines) % batch_size == 0:
                            self.cursor.executemany(self.sql_file['insert_xlat_oh_sd'], lines)
                            lines = []
                    self.cursor.executemany(self.sql_file['insert_xlat_oh_sd'], lines)
                    lines = []
                    for row in df_pa_lst.iterrows():
                        row_data = row[1]
                        row_data['client_id'] = data['client_id']
                        lines.append(tuple(row_data))
                        if len(lines) % batch_size == 0:
                            self.cursor.executemany(self.sql_file['insert_xlat_pa_lst'], lines)
                            lines = []
                    self.cursor.executemany(self.sql_file['insert_xlat_pa_lst'], lines)
                    self.cursor.execute("""
                                        begin
                                            NAS_BALANCE_AUDIT_PKG.update_balance_audit_log(
                                            :p_client_id,
                                            :p_upload_type,
                                            :x_status_code
                                            );
                                    end; """, p_client_id=data['client_id'],
                                        p_upload_type='translations',
                                        x_status_code=status_code)
                if status_code.getvalue() == 'SUCCESS':
                    result['status'] = Status.OK.value
                    if data['audit_type'] == 'wage-tax':
                        result['msg'] = 'Tax & Wage file added successfully'
                    elif data['audit_type'] == 'control-totals':
                        result['msg'] = 'Control Totals file added successfully'
                    result['client_id'] = data['client_id']
                else:
                    result['status'] = Status.ERROR.value
                    if data['audit_type'] == 'wage-tax':
                        result['msg'] = 'Failed to add Tax & Wage files'
                    elif data['audit_type'] == 'control-totals':
                        result['msg'] = 'Failed to add Control Total Files'
                    result['client_id'] = -1
                mail_status = self.send_mail(result, data['user_id'], data['audit_type'])
                if mail_status == 'success':
                    result['mail_status'] = 'email sent successfully'
                else:
                    result['mail_status'] = 'email notification failed'
        except Exception as e:
            result['status'] = 1
            print(str(e))
            mail_status = self.send_mail(result, data['user_id'], data['audit_type'])
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        return result

    def add_wage_tax_log(self, req):
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                                  begin
                                        NAS_BALANCE_AUDIT_PKG.add_balance_audit_log(
                                        :p_client_id,
                                        :p_client_name,
                                        :p_user_id,
                                        :p_audit_type,
                                        :x_status_code
                                        );
                                    end; """, p_client_id=req['client_id'],
                                p_client_name=req['client_name'],
                                p_user_id=req['user_id'],
                                p_audit_type=req['audit_type'],
                                x_status_code=status_code)
            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'Balance log updated'
            else:
                result['status'] = 1
                result['msg'] = 'Failed to log balance audit - ' + str(status)
        except Exception as e:
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        return result

    def async_generate_asp_files(self, data):
        # Check if client id is already in processing
        """
        Generate balance audit asynchronously on a separate thread
        """
        # logger doesn't work when running on thread as it use
        # flask context to get current user details, so when
        # running on thread set logging to False
        thread = threading.Thread(target=self.add_balance, args=(data,))
        thread.deamon = True
        thread.start()
        return {
            'status': 0,
            'msg': self.sql_file['balances_async_status']
        }

    def check_client_is_processing(self, data):
        try:
            if not self.is_acquired:
                self.acquire()
            self.cursor.execute(self.sql_file['check_if_processing'], p_client_id=data['client_id'])
            result = Code_util.iterate_data(self.cursor)
        except Exception as e:
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        return result

    def add_client_log(self, req):
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                                  begin
                                        NAS_BALANCE_AUDIT_PKG.add_balances_log(
                                        :p_client_id,
                                        :p_client_name,
                                        :p_user_id,
                                        :x_status_code
                                        );
                                    end; """, p_client_id=req['client_id'],
                                p_client_name=req['client_name'],
                                p_user_id=req['user_id'],
                                x_status_code=status_code)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'Balance log updated'
            else:
                result['status'] = 1
                result['msg'] = 'Failed to log balance audit - ' + str(status)
        except Exception as e:
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        return result

    def delete_client_details(self, client_id):
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                                  begin
                                        NAS_BALANCE_AUDIT_PKG.update_balance_log(
                                        :p_client_id,
                                        :x_status_code
                                        );
                                    end; """, p_client_id=client_id,
                                x_status_code=status_code)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'Client deleted Successfully'
            else:
                result['status'] = 1
                result['msg'] = 'Failed to log balance audit - ' + str(status)
        except Exception as e:
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        return result

    def delete_audit_client_details(self, client_id, audit_type):
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                                  begin
                                        NAS_BALANCE_AUDIT_PKG.delete_tax_wage_balance_log(
                                        :p_client_id,
                                        :p_audit_type,
                                        :x_status_code
                                        );
                                    end; """, p_client_id=client_id,
                                p_audit_type=audit_type,
                                x_status_code=status_code)
            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'Client deleted Successfully'
            else:
                result['status'] = 1
                result['msg'] = 'Failed to log balance audit - ' + str(status)
        except Exception as e:
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        return result

    def delete_emp_report(self, report_id):
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                                  begin
                                        NAS_BALANCE_AUDIT_PKG.delete_emp_report(
                                        :p_report_id,
                                        :x_status_code
                                        );
                                    end; """, p_report_id=report_id,
                                x_status_code=status_code)
            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'Report deleted Successfully'
            else:
                result['status'] = 1
                result['msg'] = 'Failed to delete report - ' + str(status)
        except Exception as e:
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        return result

    def get_balances_summary(self, user_id, status):
        logger.addinfo('@ models - balances - get_balances_summary(+)')
        result = dict()
        try:
            self.acquire()
            if status == 'ALL':
                self.cursor.execute(self.sql_file['balances_summary_all'], p_user_id=user_id)
            else:
                self.cursor.execute(self.sql_file['balances_summary'], p_user_id=user_id, p_status=status)
            summary = Code_util.iterate_data(self.cursor)
            result['status'] = 0
            result['result'] = summary
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - balances -
                get_balances_summary """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - balances - get_balances_summary(-)')
        return result

    def report_checker(self, req, report_type):
        logger.addinfo('@ models - balances - report_checker(+)')
        result = dict()
        try:
            self.acquire()
            result = {}
            if report_type == 'emp-report':
                self.cursor.execute(self.sql_file['report_user_validate'], p_report_name=req['report_name'],
                                    p_user_id=req['user_id'])
                if self.cursor.fetchone()[0] > 0:
                    result['status'] = 1
                    result['msg'] = 'Report name already exists'
                    return result
                else:
                    result['status'] = 0
                    return result
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - balances -
                report_checker """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - balances - report_checker(-)')
        return result

    def get_report_emp_summary(self, user_id):
        logger.addinfo('@ models - balances - get_report_emp_summary(+)')
        result = dict()
        try:
            self.acquire()
            self.cursor.execute(self.sql_file['report_emp_summary'], p_user_id=user_id)
            report_record_count = Code_util.iterate_data(self.cursor)
            result['status'] = 0
            result['result'] = report_record_count
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - balances -
                get_report_emp_summary """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - balances - get_report_emp_summary(-)')
        return result

    def get_tax_wage_balances_summary(self, user_id, status):
        logger.addinfo('@ models - balances - get_tax_wage_balances_summary(+)')
        result = dict()
        try:
            self.acquire()
            if status == 'ALL':
                self.cursor.execute(self.sql_file['wage_tax_summary_all'], p_user_id=user_id)
            else:
                self.cursor.execute(self.sql_file['wage_taxes_summary'], p_user_id=user_id, p_status=status)
            summary = Code_util.iterate_data(self.cursor)
            result['status'] = 0
            result['result'] = summary
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - balances -
                get_tax_wage_balances_summary """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - balances - get_tax_wage_balances_summary(-)')
        return result

    def get_audit_client_codes(self, user_id):
        logger.addinfo('@ models - balances - get_audit_client_codes(+)')
        result = dict()
        try:
            self.acquire()
            self.cursor.execute(self.sql_file['get_audit_client_codes'], p_user_id=user_id)
            summary = Code_util.iterate_data(self.cursor)
            result['status'] = 0
            result['result'] = summary
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - balances -
                get_audit_client_codes """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - balances - get_audit_client_codes(-)')
        return result

    def get_dcon_attachment(self, client_id, user):
        try:
            result = {}
            if not self.is_acquired:
                self.acquire()
            query = self.sql_file['decon_file_row_count']
            self.cursor.execute(query, p_client_id=client_id)
            if self.cursor.fetchone()[0] < 500000:
                query = self.sql_file['dcon_attachment_data_query']
                df = pd.read_sql(query, self.connection, params={'p_client_id': client_id})
                static_path = '/tmp/'
                file_name = CommonUtils.generate_random_string(10)
                file_path = os.path.join(static_path, file_name)
                df.to_csv(file_path + '.csv', index=False, header=True, encoding='utf-8-sig')
                if os.path.exists(file_path + '.csv'):
                    with zipfile.ZipFile(file_path + '.zip', 'w', zipfile.ZIP_DEFLATED, allowZip64=True) as zf:
                        zf.write(file_path + '.csv', arcname=file_name + '.csv')
                    os.remove(file_path + '.csv')
                    result['file_name'] = file_name + '.zip'
                else:
                    result['status'] = 1
                    result['msg'] = 'Unable to download De-construction file'
            else:
                self.async_generate_decon_files(client_id, user)
                result = {'status': 0, 'msg': self.sql_file['balances_dcon_status'], 'async_flag': 'Y'}
        except Exception as e:
            raise e
        finally:
            if self.is_acquired:
                self.release()
        return result

    def get_emp_report_attachment(self, report_id, user):
        try:
            result = {}
            if not self.is_acquired:
                self.acquire()
            # query = self.sql_file['emp_report_attachment_count']
            # self.cursor.execute(query, p_report_id=report_id)
            # if self.cursor.fetchone()[0] < 500000:
            query = self.sql_file['emp_report_attachment_data_query']
            df = pd.read_sql(query, self.connection, params={'p_report_id': report_id})
            static_path = '/tmp/'
            file_name = CommonUtils.generate_random_string(10)
            file_path = os.path.join(static_path, file_name)
            df.to_csv(file_path + '.csv', index=False, header=True, encoding='utf-8-sig')
            if os.path.exists(file_path + '.csv'):
                with zipfile.ZipFile(file_path + '.zip', 'w', zipfile.ZIP_DEFLATED, allowZip64=True) as zf:
                    zf.write(file_path + '.csv', arcname=file_name + '.csv')
                os.remove(file_path + '.csv')
                result['file_name'] = file_name + '.zip'
            else:
                result['status'] = 1
                result['msg'] = 'Unable to download emp report file'
        except Exception as e:
            raise e
        finally:
            if self.is_acquired:
                self.release()
        return result

    def get_wage_tax_attachment(self, client_id, user):
        try:
            result = {}
            if not self.is_acquired:
                self.acquire()
            query = self.sql_file['wage_tax_file_row_count']
            self.cursor.execute(query, p_client_id=client_id)
            if self.cursor.fetchone()[0] < 500000:
                query = self.sql_file['wage_tax_data_query']
                df = pd.read_sql(query, self.connection, params={'p_client_id': client_id})
                static_path = '/tmp/'
                file_name = CommonUtils.generate_random_string(10)
                file_path = os.path.join(static_path, file_name)
                df.to_csv(file_path + '.csv', index=False, header=True, encoding='utf-8-sig')
                if os.path.exists(file_path + '.csv'):
                    with zipfile.ZipFile(file_path + '.zip', 'w', zipfile.ZIP_DEFLATED, allowZip64=True) as zf:
                        zf.write(file_path + '.csv', arcname=file_name + '.csv')
                    os.remove(file_path + '.csv')
                    result['file_name'] = file_name + '.zip'
                else:
                    result['status'] = 1
                    result['msg'] = 'Unable to download wage & tax file'
            else:
                self.async_generate_wage_tax_files(client_id, user)
                result = {'status': 0, 'msg': self.sql_file['balances_wage_tax_status'], 'async_flag': 'Y'}
        except Exception as e:
            raise e
        finally:
            if self.is_acquired:
                self.release()
        return result

    def get_control_totals_attachment(self, client_id, user):
        try:
            result = {}
            if not self.is_acquired:
                self.acquire()
            query = self.sql_file['control_file_row_count']
            self.cursor.execute(query, p_client_id=client_id)
            if self.cursor.fetchone()[0] < 500000:
                query = self.sql_file['wage_control_totals_query']
                df = pd.read_sql(query, self.connection, params={'p_client_id': client_id})
                static_path = '/tmp/'
                file_name = CommonUtils.generate_random_string(10)
                file_path = os.path.join(static_path, file_name)
                df.to_csv(file_path + '.csv', index=False, header=True, encoding='utf-8-sig')
                if os.path.exists(file_path + '.csv'):
                    with zipfile.ZipFile(file_path + '.zip', 'w', zipfile.ZIP_DEFLATED, allowZip64=True) as zf:
                        zf.write(file_path + '.csv', arcname=file_name + '.csv')
                    os.remove(file_path + '.csv')
                    result['file_name'] = file_name + '.zip'
                else:
                    result['status'] = 1
                    result['msg'] = 'Unable to download wage & tax file'
            else:
                self.async_generate_control_total_files(client_id, user)
                result = {'status': 0, 'msg': self.sql_file['balances_control_totals_status'], 'async_flag': 'Y'}
        except Exception as e:
            raise e
        finally:
            if self.is_acquired:
                self.release()
        return result

    def async_generate_control_total_files(self, client_id, user):
        # Check if client id is already in processing
        """
        Generate balance audit asynchronously on a separate thread
        """
        # logger doesn't work when running on thread as it use
        # flask context to get current user details, so when
        # running on thread set logging to False
        thread = threading.Thread(target=self.download_control_async_file, args=(client_id, user,))
        thread.deamon = True
        thread.start()
        return {
            'status': 0,
            'msg': self.sql_file['balances_wage_tax_status'],
            'async_flag': 'Y'
        }

    def get_translation_attachment(self, client_id, user):
        try:
            result = {}
            if not self.is_acquired:
                self.acquire()
            paygroup_query = self.sql_file['translate_paygroup_query']
            df_translate_paygroup = pd.read_sql(paygroup_query, self.connection, params={'p_client_id': client_id})
            filenbr_query = self.sql_file['translate_filenbr_query']
            df_translate_filenbr = pd.read_sql(filenbr_query, self.connection, params={'p_client_id': client_id})
            state_query = self.sql_file['translate_state_query']
            df_translate_state = pd.read_sql(state_query, self.connection, params={'p_client_id': client_id})
            sui_query = self.sql_file['translate_sui_query']
            df_translate_sui = pd.read_sql(sui_query, self.connection, params={'p_client_id': client_id})
            local1_query = self.sql_file['translate_local1_query']
            df_translate_local1 = pd.read_sql(local1_query, self.connection, params={'p_client_id': client_id})
            local2_query = self.sql_file['translate_local2_query']
            df_translate_local2 = pd.read_sql(local2_query, self.connection, params={'p_client_id': client_id})
            oh_sd_query = self.sql_file['translate_oh_sd_query']
            df_translate_oh_sd = pd.read_sql(oh_sd_query, self.connection, params={'p_client_id': client_id})
            pa_lst_query = self.sql_file['translate_pa_lst_query']
            df_translate_pa_lst = pd.read_sql(pa_lst_query, self.connection, params={'p_client_id': client_id})
            sheet_names = {'PAYGROUP_XLAT': df_translate_paygroup, 'FILE_NBR_XLAT':df_translate_filenbr,
                           'STATE_XLAT': df_translate_state, 'SUI_XLAT': df_translate_sui,
                           'LOCAL1_XLAT': df_translate_local1, 'LOCAL2_XLAT': df_translate_local2,
                           'OH_SD_XLAT': df_translate_oh_sd, 'PA_LST_XLAT': df_translate_pa_lst}
            static_path = '/tmp/'
            file_name = CommonUtils.generate_random_string(10)
            file_path = os.path.join(static_path, file_name)
            writer = pd.ExcelWriter(file_path + '.xlsx', engine='xlsxwriter')
            for sheet_name in sheet_names.keys():
                sheet_names[sheet_name].to_excel(writer, sheet_name=sheet_name, index=False)
            writer.save()
            if os.path.exists(file_path + '.xlsx'):
                with zipfile.ZipFile(file_path + '.zip', 'w', zipfile.ZIP_DEFLATED, allowZip64=True) as zf:
                    zf.write(file_path + '.xlsx', arcname=file_name + '.xlsx')
                os.remove(file_path + '.xlsx')
                result['file_name'] = file_name + '.zip'
            else:
                result['status'] = 1
                result['msg'] = 'Unable to download wage & tax file'
        except Exception as e:
            raise e
        finally:
            if self.is_acquired:
                self.release()
        return result

    def download_control_async_file(self, client_id, user):
        try:
            result = {}
            self.acquire()
            query = self.sql_file['wage_control_totals_query']
            df = pd.read_sql(query, self.connection, params={'p_client_id': client_id})
            static_path = '/tmp/'
            file_name = CommonUtils.generate_random_string(10)
            file_path = os.path.join(static_path, file_name)
            df.to_csv(file_path + '.csv', index=False, header=True, encoding='utf-8-sig')
            if os.path.exists(file_path + '.csv'):
                with zipfile.ZipFile(file_path + '.zip', 'w', zipfile.ZIP_DEFLATED, allowZip64=True) as zf:
                    zf.write(file_path + '.csv', arcname=file_name + '.csv')
                os.remove(file_path + '.csv')
                result['file_name'] = file_name + '.zip'
                result['status'] = 0
                result['msg'] = 'Failed to consolidate control totals'
            else:
                result['status'] = 1
                result['msg'] = 'Unable to download  control total files'
            mail_status = self.send_decon_mail(result, user, 'control-tots')
            if mail_status == 'success':
                result['mail_status'] = 'email sent successfully'
            else:
                result['mail_status'] = 'email notification failed'
        except Exception as e:
            raise e
        finally:
            if self.is_acquired:
                self.release()
        return result

    def async_generate_wage_tax_files(self, client_id, user):
        # Check if client id is already in processing
        """
        Generate balance audit asynchronously on a separate thread
        """
        # logger doesn't work when running on thread as it use
        # flask context to get current user details, so when
        # running on thread set logging to False
        thread = threading.Thread(target=self.download_wage_tax_file, args=(client_id, user,))
        thread.deamon = True
        thread.start()
        return {
            'status': 0,
            'msg': self.sql_file['balances_wage_tax_status'],
            'async_flag': 'Y'
        }

    def download_wage_tax_file(self, client_id, user):
        try:
            result = {}
            self.acquire()
            query = self.sql_file['wage_tax_data_query']
            df = pd.read_sql(query, self.connection, params={'p_client_id': client_id})
            static_path = '/tmp/'
            file_name = CommonUtils.generate_random_string(10)
            file_path = os.path.join(static_path, file_name)
            df.to_csv(file_path + '.csv', index=False, header=True, encoding='utf-8-sig')
            if os.path.exists(file_path + '.csv'):
                with zipfile.ZipFile(file_path + '.zip', 'w', zipfile.ZIP_DEFLATED, allowZip64=True) as zf:
                    zf.write(file_path + '.csv', arcname=file_name + '.csv')
                os.remove(file_path + '.csv')
                result['file_name'] = file_name + '.zip'
                result['status'] = 0
                result['msg'] = 'Failed to consolidate wage & tax files'
            else:
                result['status'] = 1
                result['msg'] = 'Unable to download  wage & tax file'
            mail_status = self.send_decon_mail(result, user, 'wage-tax')
            if mail_status == 'success':
                result['mail_status'] = 'email sent successfully'
            else:
                result['mail_status'] = 'email notification failed'
        except Exception as e:
            raise e
        finally:
            if self.is_acquired:
                self.release()
        return result

    def get_reports_pkg_attachment(self, data):
        try:
            result = self.add_input_codes(data)
            self.async_generate_report_files(data)
            result = {'status': 0, 'msg': self.sql_file['balances_reports_pkg_status'], 'async_flag': 'Y'}
        except Exception as e:
            raise e
        finally:
            if self.is_acquired:
                self.release()
        return result

    def async_generate_report_files(self, data):
        # Check if client id is already in processing
        """
        Generate balance audit asynchronously on a separate thread
        """
        # logger doesn't work when running on thread as it use
        # flask context to get current user details, so when
        # running on thread set logging to False
        thread = threading.Thread(target=self.download_all_reports, args=(data,))
        thread.deamon = True
        thread.start()
        return {
            'status': 0,
            'msg': self.sql_file['balances_reports_pkg_status']
        }

    def download_all_reports(self, data):
        result = {}
        try:
            if not self.is_acquired:
                self.acquire()
            gtt_query = self.sql_file['gtt_insert_statement']
            self.cursor.execute(gtt_query, p_client_id=data['client_id'])
            gtt_record_query = self.sql_file['gtt_record_count']
            self.cursor.execute(gtt_record_query)
            gtt_max_rec_query = self.sql_file['gtt_max_rec_selection']
            self.cursor.execute(gtt_max_rec_query)
            recalc_query = self.sql_file['get_recalc_report']
            df_recalc = pd.read_sql(recalc_query, self.connection, params={'p_client_id': data['client_id'],
                                                                           'p_ss_limit': data['ss_limit']})
            asp_paygroup_tot_query = self.sql_file['get_asp_paygroup_totals']
            df_asp_paygroup_tot = pd.read_sql(asp_paygroup_tot_query, self.connection,
                                              params={'p_client_id': data['client_id']})
            asp_emp_query = self.sql_file['get_asp_employee_totals']
            df_emp_totals = pd.read_sql(asp_emp_query, self.connection)
            jurisdiction_query = self.sql_file['get_asp_jurisdiction_totals']
            df_jurisdiction = pd.read_sql(jurisdiction_query, self.connection)
            pre_audit_query = self.sql_file['ASP_PRE_AUDIT']
            df_pre_audit = pd.read_sql(pre_audit_query, self.connection)
            earn_gross_query = self.sql_file['AUDIT_EARNINGS_MATCH_GROSS']
            df_earn_gross = pd.read_sql(earn_gross_query, self.connection, params={'p_client_id': data['client_id']})
            static_path = '/tmp/'
            file_name = CommonUtils.generate_random_string(10)
            file_path = os.path.join(static_path, file_name)
            os.mkdir(file_path)
            df_recalc.to_csv(file_path + '/recalc.csv', index=False, header=True, encoding='utf-8-sig')
            df_asp_paygroup_tot.to_csv(file_path + '/asp_paygroup_totals.csv', index=False, header=True,
                                       encoding='utf-8-sig')
            df_emp_totals.to_csv(file_path + '/asp_employee_totals.csv', index=False, header=True, encoding='utf-8-sig')
            df_jurisdiction.to_csv(file_path + '/asp_jurisdiction_totals.csv', index=False, header=True,
                                   encoding='utf-8-sig')
            df_pre_audit.to_csv(file_path + '/pre_audit.csv', index=False, header=True, encoding='utf-8-sig')
            df_earn_gross.to_csv(file_path + '/earn_gross.csv', index=False, header=True, encoding='utf-8-sig')
            result['status'] = 0
            if os.path.exists(file_path):
                with zipfile.ZipFile(file_path + '.zip', 'w', zipfile.ZIP_DEFLATED, allowZip64=True) as zf:
                    for dirname, subdirs, files in os.walk(file_path):
                        for filename in files:
                            zf.write(os.path.join(dirname, filename), arcname=filename)
                shutil.rmtree(file_path)
                result['file_name'] = file_name + '.zip'
                result['status'] = 0
                result['msg'] = 'All reports generated successfully'
            else:
                result['status'] = 1
                result['msg'] = 'Unable to download reports pkg'
            mail_status = self.send_decon_mail(result, data['user_id'], 'report_pkg')
            if mail_status == 'success':
                result['mail_status'] = 'email sent successfully'
            else:
                result['mail_status'] = 'email notification failed'
        except Exception as e:
            raise e
        finally:
            if self.is_acquired:
                self.release()
        return result

    def download_decon_file(self, client_id, user):
        try:
            result = {}
            self.acquire()
            query = self.sql_file['dcon_attachment_data_query']
            df = pd.read_sql(query, self.connection, params={'p_client_id': client_id})
            static_path = '/tmp/'
            file_name = CommonUtils.generate_random_string(10)
            file_path = os.path.join(static_path, file_name)
            df.to_csv(file_path + '.csv', index=False, header=True, encoding='utf-8-sig')
            if os.path.exists(file_path + '.csv'):
                with zipfile.ZipFile(file_path + '.zip', 'w', zipfile.ZIP_DEFLATED, allowZip64=True) as zf:
                    zf.write(file_path + '.csv', arcname=file_name + '.csv')
                os.remove(file_path + '.csv')
                result['file_name'] = file_name + '.zip'
                result['status'] = 0
                result['msg'] = 'Failed to add ADJ files'
            else:
                result['status'] = 1
                result['msg'] = 'Unable to download De-construction file'
            mail_status = self.send_decon_mail(result, user, 'decon')
            if mail_status == 'success':
                result['mail_status'] = 'email sent successfully'
            else:
                result['mail_status'] = 'email notification failed'
        except Exception as e:
            raise e
        finally:
            if self.is_acquired:
                self.release()
        return result

    def async_generate_decon_files(self, client_id, user):
        # Check if client id is already in processing
        """
        Generate balance audit asynchronously on a separate thread
        """
        # logger doesn't work when running on thread as it use
        # flask context to get current user details, so when
        # running on thread set logging to False
        thread = threading.Thread(target=self.download_decon_file, args=(client_id, user,))
        thread.deamon = True
        thread.start()
        return {
            'status': 0,
            'msg': self.sql_file['balances_dcon_status'],
            'async_flag': 'Y'
        }

    def add_input_codes(self, data):
        logger.addinfo('@ models - balances - add_input_codes(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            query = self.sql_file['DELETE_EXISTING_INPUT_CODES']
            self.cursor.execute(query, p_client_id=data['client_id'])
            self.connection.commit()
            for input_code in data['input_codes']:
                if input_code['checked']:
                    self.cursor.execute("""
                                          begin
                                                NAS_BALANCE_AUDIT_PKG.add_input_codes(
                                                :p_id,
                                                :p_mod,
                                                :p_client_id,
                                                :x_status_code
                                                );
                                            end; """, p_id=input_code['id'],
                                        p_mod=input_code['mod'],
                                        p_client_id=data['client_id'],
                                        x_status_code=status_code)
            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'input code successfully added'
            else:
                result['status'] = 1
                result['msg'] = 'Failed to Add input Codes'
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - balances -
                add_input_codes """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - balances - get_client_details(-)')
        return result

    def get_client_details(self, data):
        result = {}
        try:
            if data['report_type'] == 'ern-gross':
                result = self.add_input_codes(data)
            if not self.is_acquired:
                self.acquire()
            gtt_query = self.sql_file['gtt_insert_statement']
            self.cursor.execute(gtt_query, p_client_id=data['client_id'])
            if data['report_type'] == 'recalc':
                query = self.sql_file['get_recalc_report']
                self.cursor.execute(query, p_client_id=data['client_id'], p_ss_limit=data['ss_limit'])
                result['recalc_report'] = Code_util.iterate_data(self.cursor)
            elif data['report_type'] == 'asp':
                query = self.sql_file['get_asp_paygroup_totals']
                self.cursor.execute(query, p_client_id=data['client_id'])
                result['asp_report'] = Code_util.iterate_data(self.cursor)
            elif data['report_type'] == 'asp-emp':
                asp_emp_v1_query = self.sql_file['asp_employee_count_v1']
                self.cursor.execute(asp_emp_v1_query, p_client_id=data['client_id'])
                asp_emp_tot = Code_util.iterate_data(self.cursor)
                if asp_emp_tot:
                    asp_emp_count = asp_emp_tot[0]['asp_emp']
                else:
                    asp_emp_query = self.sql_file['asp_employee_count']
                    self.cursor.execute(asp_emp_query)
                    asp_emp_count = self.cursor.fetchone()[0]
                if asp_emp_count < 100000:
                    query = self.sql_file['get_asp_employee_totals']
                    self.cursor.execute(query)
                    result['asp_emp_report'] = Code_util.iterate_data(self.cursor)
                else:
                    self.connection.commit()
                    self.release()
                    self.async_generate_bal_report_files(data['client_id'], 'asp_emp', data['user_id'], )
                    result = {'status': 0, 'msg': self.sql_file['balances_report_status'], 'async_flag': 'Y'}
            elif data['report_type'] == 'asp-jurisdiction':
                asp_emp_jurisdiction_v1 = self.sql_file['asp_jurisdiction_count_v1']
                self.cursor.execute(asp_emp_jurisdiction_v1, p_client_id=data['client_id'])
                asp_jurisdiction_tot = Code_util.iterate_data(self.cursor)
                if asp_jurisdiction_tot:
                    asp_jurisdiction_count = asp_jurisdiction_tot[0]['asp_jurisdiction']
                else:
                    asp_jurisdiction_query = self.sql_file['asp_jurisdiction_count']
                    self.cursor.execute(asp_jurisdiction_query)
                    asp_jurisdiction_count = self.cursor.fetchone()[0]
                if asp_jurisdiction_count < 100000:
                    query = self.sql_file['get_asp_jurisdiction_totals']
                    self.cursor.execute(query)
                    result['asp_jurisdiction_report'] = Code_util.iterate_data(self.cursor)
                else:
                    self.connection.commit()
                    self.release()
                    self.async_generate_bal_report_files(data['client_id'], 'asp_jurisdiction', data['user_id'], )
                    result = {'status': 0, 'msg': self.sql_file['balances_report_status'], 'async_flag': 'Y'}
            elif data['report_type'] == 'pre_audit':
                pre_audit_v1_query = self.sql_file['asp_pre_audit_count_v1']
                self.cursor.execute(pre_audit_v1_query, p_client_id=data['client_id'])
                pre_audit = Code_util.iterate_data(self.cursor)
                if pre_audit:
                    pre_audit_count = pre_audit[0]['pre_audit']
                else:
                    pre_audit_query = self.sql_file['ASP_PRE_AUDIT_COUNT']
                    self.cursor.execute(pre_audit_query)
                    pre_audit_count = self.cursor.fetchone()[0]
                if pre_audit_count < 100000:
                    gtt_record_query = self.sql_file['gtt_record_count']
                    self.cursor.execute(gtt_record_query)
                    gtt_max_rec_query = self.sql_file['gtt_max_rec_selection']
                    self.cursor.execute(gtt_max_rec_query)
                    query = self.sql_file['ASP_PRE_AUDIT']
                    self.cursor.execute(query)
                    result['pre_audit'] = Code_util.iterate_data(self.cursor)
                else:
                    self.connection.commit()
                    self.release()
                    self.async_generate_bal_report_files(data['client_id'], 'PRE_AUDIT', data['user_id'], )
                    result = {'status': 0, 'msg': self.sql_file['balances_report_status'], 'async_flag': 'Y'}
            elif data['report_type'] == 'ern-gross':
                earn_gross_count_v1 = self.sql_file['earn_gross_count_v1']
                self.cursor.execute(earn_gross_count_v1, p_client_id=data['client_id'])
                earn_gross = Code_util.iterate_data(self.cursor)
                if earn_gross:
                    earn_gross_count = earn_gross[0]['earnings_gross']
                else:
                    gross_query = self.sql_file['gtt_gross_insert']
                    self.cursor.execute(gross_query, p_client_id=data['client_id'])
                    earn_query = self.sql_file['gtt_earn_insert']
                    self.cursor.execute(earn_query, p_client_id=data['client_id'])
                    ern_gross_query = self.sql_file['EARNINGS_GROSS_COUNT']
                    self.cursor.execute(ern_gross_query, p_client_id=data['client_id'])
                    earn_gross_count = self.cursor.fetchone()[0]
                if earn_gross_count < 100000:
                    # query = self.sql_file['gtt_gross_insert']
                    # self.cursor.execute(query, p_client_id=data['client_id'])
                    # query = self.sql_file['gtt_earn_insert']
                    # self.cursor.execute(query, p_client_id=data['client_id'])
                    query = self.sql_file['AUDIT_EARNINGS_MATCH_GROSS']
                    self.cursor.execute(query, p_client_id=data['client_id'])
                    result['earning_gross_match'] = Code_util.iterate_data(self.cursor)
                else:
                    self.connection.commit()
                    self.release()
                    self.async_generate_bal_report_files(data['client_id'], 'ERN_GROSS', data['user_id'], )
                    result = {'status': 0, 'msg': self.sql_file['balances_report_status'], 'async_flag': 'Y'}
            result['status'] = 0
        except Exception as e:
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        return result

    def async_generate_emp_report(self, data):
        # Check if client id is already in processing
        """
        Generate balance audit asynchronously on a separate thread
        """
        # logger doesn't work when running on thread as it use
        # flask context to get current user details, so when
        # running on thread set logging to False
        thread = threading.Thread(target=self.add_emp_report, args=(data,))
        thread.deamon = True
        thread.start()
        return {
            'status': 0,
            'msg': self.sql_file['balances_async_emp_report']
        }

    def add_emp_report(self, data):
        result = {}
        try:
            if not self.is_acquired:
                self.acquire()
            # report log creation
            report_creation_log_s = self.sql_file['report_creation_log_s']
            report_sq = self.cursor.execute(report_creation_log_s).fetchone()
            report_creation_log = self.sql_file['report_creation_log']
            self.cursor.execute(report_creation_log, p_report_id=report_sq[0], p_report_name=data['report_name'],
                                p_user_id=data['user_id'], p_status='P', p_tax_wage_client_id=data['tax_client_id'],
                                p_control_tot_client_id=data['control_client_id'],
                                p_translate_client_id=data['translate_client_id'])
            self.connection.commit()
            # Add each module to GTT tables
            gtt_tax_wage_query = self.sql_file['gtt_insert_tax_wages_insert']
            self.cursor.execute(gtt_tax_wage_query, p_client_id=data['tax_client_id'])
            gtt_control_query = self.sql_file['gtt_control_insert']
            self.cursor.execute(gtt_control_query, p_client_id=data['control_client_id'])
            gtt_balance_xlat_paygroup = self.sql_file['gtt_balance_xlat_paygroup_insert']
            self.cursor.execute(gtt_balance_xlat_paygroup, p_client_id=data['translate_client_id'])
            gtt_balance_xlat_filenbr = self.sql_file['gtt_balance_xlat_filenbr_insert']
            self.cursor.execute(gtt_balance_xlat_filenbr, p_client_id=data['translate_client_id'])
            gtt_balance_xlat_state = self.sql_file['gtt_balance_xlat_state_insert']
            self.cursor.execute(gtt_balance_xlat_state, p_client_id=data['translate_client_id'])
            gtt_bal_sq_rept_audit_tax = self.sql_file['gtt_bal_sq_rept_audit_tax_insert']
            self.cursor.execute(gtt_bal_sq_rept_audit_tax)
            gtt_bal_sq_rept_audit_taxable = self.sql_file['gtt_bal_sq_rept_audit_taxable_insert']
            self.cursor.execute(gtt_bal_sq_rept_audit_taxable)
            gtt_bal_sq_rept_audit_wt_final = self.sql_file['gtt_bal_sq_rept_audit_wt_final_insert']
            self.cursor.execute(gtt_bal_sq_rept_audit_wt_final)
            gtt_bal_sq_rpt_adt_emp_n_xlat = self.sql_file['gtt_bal_sq_rpt_adt_emp_n_xlat_insert']
            self.cursor.execute(gtt_bal_sq_rpt_adt_emp_n_xlat)
            # insert into report summary table
            report_creation_query = self.sql_file['insert_emp_report_summary']
            self.cursor.execute(report_creation_query, p_xlat_client_id=data['translate_client_id'],
                                p_report_id=report_sq[0], p_report_name=data['report_name'])
            self.cursor.execute(self.sql_file['update_status_emp_report_log'], p_report_id=report_sq[0])
            self.connection.commit()
            result['status'] = 0
            result['msg'] = 'Report generated successfully'
            result['report_id'] = report_sq
            # sending email to user
            mail_status = self.send_mail(result, data['user_id'], 'emp-report')
        except Exception as e:
            self.cursor.execute(self.sql_file['update_status_emp_report_log_failed'], p_report_id=report_sq[0])
            print(str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        return result

    def async_generate_bal_report_files(self, client_id, report_type, user):
        # Check if client id is already in processing
        """
        Generate balance audit asynchronously on a separate thread
        """
        # logger doesn't work when running on thread as it use
        # flask context to get current user details, so when
        # running on thread set logging to False
        thread = threading.Thread(target=self.download_report_file, args=(client_id, report_type, user,))
        thread.deamon = True
        thread.start()
        return {
            'status': 0,
            'msg': self.sql_file['balances_report_status'],
            'async_flag': 'Y'
        }

    def download_report_file(self, client_id, report_type, user):
        try:
            result = {}
            if not self.is_acquired:
                self.acquire()
            query = self.sql_file['gtt_insert_statement']
            self.cursor.execute(query, p_client_id=client_id)
            gtt_record_query = self.sql_file['gtt_record_count']
            self.cursor.execute(gtt_record_query)
            gtt_max_rec_query = self.sql_file['gtt_max_rec_selection']
            self.cursor.execute(gtt_max_rec_query)
            recalc_query = self.sql_file['get_recalc_report']
            if report_type == 'PRE_AUDIT':
                query = self.sql_file['ASP_PRE_AUDIT']
            elif report_type == 'ERN_GROSS':
                gross_query = self.sql_file['gtt_gross_insert']
                self.cursor.execute(gross_query, p_client_id=client_id)
                earn_query = self.sql_file['gtt_earn_insert']
                self.cursor.execute(earn_query, p_client_id=client_id)
                query = self.sql_file['AUDIT_EARNINGS_MATCH_GROSS']
            elif report_type == 'asp_emp':
                query = self.sql_file['get_asp_employee_totals']
            elif report_type == 'asp_jurisdiction':
                query = self.sql_file['get_asp_jurisdiction_totals']
            df = pd.read_sql(query, self.connection)
            static_path = '/tmp/'
            file_name = CommonUtils.generate_random_string(10)
            file_path = os.path.join(static_path, file_name)
            df.to_csv(file_path + '.csv', index=False, header=True, encoding='utf-8-sig')
            if os.path.exists(file_path + '.csv'):
                with zipfile.ZipFile(file_path + '.zip', 'w', zipfile.ZIP_DEFLATED, allowZip64=True) as zf:
                    zf.write(file_path + '.csv', arcname=file_name + '.csv')
                os.remove(file_path + '.csv')
                result['file_name'] = file_name + '.zip'
                result['status'] = 0
                result['msg'] = 'Failed to add ADJ files'
            else:
                result['status'] = 1
                result['msg'] = 'Unable to download De-construction file'
            mail_status = self.send_report_mail(result, user, report_type)
            if mail_status == 'success':
                result['mail_status'] = 'email sent successfully'
            else:
                result['mail_status'] = 'email notification failed'
        except Exception as e:
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        return result

    def send_report_mail(self, data, user, report_type):
        try:
            req = {}
            self.acquire()
            self.cursor.execute(self.sql_file['get_user_details'], p_user_id=user)
            user_details = Code_util.iterate_data(self.cursor)
            if data['status'] == 0:
                msg = 'Please use the below link to download ' + report_type + ' file, note that this file will be ' \
                                                                              'auto deleted after 7 days.'
                url = data['file_name']
            else:
                msg = 'Unable to download ' + report_type + ' file, please check with Admin'
                url = {}
            path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
            path += '/static/email_templates'
            template = jinja2.Environment(
                loader=jinja2.FileSystemLoader(path)
            ).get_template('balances_reports_download.html').render(
                msg=msg,
                user=user_details[0]['first_name'],
                url=url
            )
            req['email'] = user_details[0]['email_address']
            req['subject'] = 'Balance Audit Tool Notification'
            req['message_template'] = template
            email_status = Balances.send_smtp_mail(req)
        except Exception as error:
            raise error
        finally:
            if self.is_acquired:
                self.release()
        return email_status

    # inserting a new ADJ file
    def add_balance(self, data):
        try:
            result = self.add_client_log(data)
            if result['status'] == 0:
                if not self.is_acquired:
                    self.acquire()
                i_status_code = self.cursor.var(cx_Oracle.STRING)
                row_nbr = 0
                mj_rcd_nbr = 0
                block_nbr = 0
                rcd_nbr = 0
                termination = ''
                status = ''
                decoded = base64.b64decode(data['base64'])
                batch_size = 10000
                with zipfile.ZipFile(io.BytesIO(decoded)) as z:
                    for filename in z.namelist():
                        if not os.path.isdir(filename):
                            # reading file
                            with z.open(filename) as f:
                                lines = []
                                count = 0
                                for line in f.readlines():
                                    line = str(line.decode('ISO-8859-1')).replace('Ð', '}')
                                    row_nbr = row_nbr + 1
                                    if count == 3:
                                        count = 0
                                    if count > 0:
                                        count = count + 1
                                        continue
                                    if str(line[:3]) == 'DP1':
                                        count = count + 1
                                        continue
                                    sub_record = str(line[15:18]).strip()
                                    if termination != 'X' and sub_record == 'B11':
                                        mj_rcd_nbr = str(int(mj_rcd_nbr) + 1)
                                    else:
                                        mj_rcd_nbr = str(mj_rcd_nbr) if int(mj_rcd_nbr) > 0 else 1
                                    if termination == 'X':
                                        block_nbr = str(block_nbr)
                                        rcd_nbr = str(int(rcd_nbr) + 1)
                                    else:
                                        block_nbr = str(int(block_nbr) + 1)
                                        rcd_nbr = str(1)
                                    pay_group = str(line[2:5]).strip()
                                    file_nbr = str(line[6:12]).strip()
                                    id_1 = str(line[31:33]).strip()
                                    mod_1 = str(line[33:36]).strip()
                                    amount_1 = str(line[37:47]).strip()
                                    id_2 = str(line[47:49]).strip()
                                    mod_2 = str(line[49:52]).strip()
                                    amount_2 = str(line[53:63]).strip()
                                    id_3 = str(line[63:65]).strip()
                                    mod_3 = str(line[65:68]).strip()
                                    amount_3 = str(line[69:79]).strip()
                                    termination = str(line[87:88]).strip()
                                    # if (id_1 == '45' and id_2 == '45' and amount_1 in ['1', '2', '3', '4']) and \
                                    #         mod_1 in ['Q', 'D']:
                                    #     print(str(line[46:47]).strip())
                                    #     print(str(line[56:63].strip()))
                                    #     continue
                                    lines.append(tuple([data['client_id'], str(row_nbr),
                                                 str(mj_rcd_nbr), block_nbr, rcd_nbr, pay_group, file_nbr, sub_record,
                                                        id_1, mod_1, amount_1, id_2, mod_2, amount_2, id_3, mod_3,
                                                        amount_3, termination]))
                                    if len(lines) % batch_size == 0:
                                        self.cursor.executemany(self.sql_file['insert_statement_balances'], lines)
                                        lines = []
                                        self.connection.commit()
                                self.cursor.executemany(self.sql_file['insert_statement_balances'], lines)
                                status = 'SUCCESS'
                self.cursor.execute("""
                                    begin
                                        NAS_BALANCE_AUDIT_PKG.add_dcon_table(
                                        :p_client_id,
                                        :x_status_code
                                        );
                                end; """, p_client_id=data['client_id'],
                                    x_status_code=i_status_code)
                self.connection.commit()
                if status == 'SUCCESS':
                    # self.cursor.execute("""
                    #                     begin
                    #                         NAS_BALANCE_AUDIT_PKG.add_dcon_table(
                    #                         :p_client_id,
                    #                         :x_status_code
                    #                         );
                    #                 end; """, p_client_id=data['client_id'],
                    #                     x_status_code=status_code)
                    if i_status_code.getvalue() == 'SUCCESS':
                        result['status'] = Status.OK.value
                        result['msg'] = 'ADJ file added successfully'
                        result['client_id'] = data['client_id']
                    else:
                        self.cursor.execute(self.sql_file['update_status_balances_failed'], p_client_id=data['client_id'])
                        result['status'] = Status.ERROR.value
                        result['msg'] = 'Failed to insert to DCON table'
                        result['client_id'] = -1
                else:
                    self.cursor.execute(self.sql_file['update_status_balances_failed'], p_client_id=data['client_id'])
                    result['status'] = Status.ERROR.value
                    result['msg'] = 'Failed to add ADJ files'
                    result['client_id'] = -1
                mail_status = self.send_mail(result, data['user_id'])
                if mail_status == 'success':
                    result['mail_status'] = 'email sent successfully'
                else:
                    result['mail_status'] = 'email notification failed'
        except Exception as e:
            print(str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        return result

    def send_decon_mail(self, data, user, mail_type):
        try:
            req = {}
            msg = ''
            download_name = ''
            self.acquire()
            self.cursor.execute(self.sql_file['get_user_details'], p_user_id=user)
            user_details = Code_util.iterate_data(self.cursor)
            if data['status'] == 0:
                if mail_type == 'decon':
                    download_name = 'Download Decon File'
                    msg = 'Please use the below link to download deconstruction file, note that this file will be ' \
                          'auto deleted after 7 days.'
                elif mail_type == 'report_pkg':
                    download_name = 'Download reports pkg'
                    msg = 'Please use the below link to download reports pkg zip file, note that this file will ' \
                          'be auto deleted after 7 days.'
                elif mail_type == 'control-tots':
                    download_name = 'Download control total files'
                    msg = 'Please use the below link to download control totals zip file, note that this file will ' \
                          'be auto deleted after 7 days.'
                elif mail_type == 'wage-tax':
                    download_name = 'Download wage tax'
                    msg = 'Please use the below link to download wage tax zip file, note that this file will ' \
                          'be auto deleted after 7 days.'
                url = data['file_name']
            else:
                if mail_type == 'decon':
                    msg = 'Unable to download deconstruction file, please check with Admin'
                elif mail_type == 'report_pkg':
                    msg = 'Error in generating all the reports for this client, please check with Admin'
                url = {}
            path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
            path += '/static/email_templates'
            template = jinja2.Environment(
                loader=jinja2.FileSystemLoader(path)
            ).get_template('balances_decon_download.html').render(
                msg=msg,
                user=user_details[0]['first_name'],
                download_name=download_name,
                url=url
            )
            req['email'] = user_details[0]['email_address']
            req['subject'] = 'Balance Audit Tool Notification'
            req['message_template'] = template
            email_status = Balances.send_smtp_mail(req)
        except Exception as error:
            raise error
        finally:
            if self.is_acquired:
                self.release()
        return email_status

    def send_mail(self, data, user, type=None):
        try:
            req = {}
            self.acquire()
            self.cursor.execute(self.sql_file['get_user_details'], p_user_id=user)
            user_details = Code_util.iterate_data(self.cursor)
            if data['status'] == 0:
                if type == 'wage-tax':
                    msg = 'Processing of the file that you uploaded is Completed, you can review and ' \
                          'download tax & wage consolidated file.'
                elif type == 'control-totals':
                    msg = 'Processing of the file that you uploaded is Completed, you can review and ' \
                          'download control totals consolidated file.'
                elif type == 'emp-report':
                    msg = 'Report generated successfully, you can review and ' \
                          'download.'
                else:
                    msg = 'Processing of the file that you uploaded is Completed, you can review and download Audit ' \
                      'reports.'
            else:
                msg = 'Processing of the file you Uploaded has Failed, please check with Admin'
            path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
            path += '/static/email_templates'
            template = jinja2.Environment(
                loader=jinja2.FileSystemLoader(path)
            ).get_template('notification.html').render(
                msg=msg,
                user=user_details[0]['first_name'],
            )
            req['email'] = user_details[0]['email_address']
            req['subject'] = 'Balance Audit Tool Notification'
            req['message_template'] = template
            email_status = Balances.send_smtp_mail(req)
        except Exception as error:
            raise error
        finally:
            if self.is_acquired:
                self.release()
        return email_status

    @staticmethod
    def send_smtp_mail(req_data):
        try:
            strings = db_util.get_strings()
            # req_data['activation_key'] = self.password
            # req_data['user'] = self.user_value
            """message_template = Registration.read_template('email_template_registration.txt')"""
            msg = MIMEMultipart()       # create a message
            # add in the actual person name to the message template
            server = smtplib.SMTP()
            server.connect(strings['mail_server'], 25)
            # message = message_template.substitute(PERSON_NAME=user_name, MESSAGE_BODY=message_body)
            # Prints out the message body for our sake
            # setup the parameters of the message
            msg['From'] = strings['sender_email']
            msg['To'] = req_data['email']
            msg['Subject'] = req_data['subject']
            # add in the message body
            msg.attach(MIMEText(req_data['message_template'], 'html'))
            # send the message via the server set up earlier.
            server.send_message(msg)
            del msg
            server.quit()
            status = 'success'
        except Exception as e:
            status = 'Failure - Failed to send email'
            raise e
        return status
