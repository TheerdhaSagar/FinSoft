from __future__ import absolute_import

import cx_Oracle
from scorpionapi.utils.code_util import Code_util
from scorpionapi.sql import sql_util
from scorpionapi.utils import db_util
from scorpionapi.utils.logdata import logger
from scorpionapi.utils.constants import Status
import datetime
from scorpionapi.utils.common_utils import CommonUtils
# from scorpionapi.utils.google_utils import GoogleUtils
from scorpionapi.utils.conn_util import OracleConnectionManager


class ActivityPlanner:

    def __init__(self):
        self.strings = db_util.get_strings()
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())
        self.connection = None
        self.cursor = None
        self.is_acquired = False

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()
        self.is_acquired = True

    def release(self):
        if self.cursor:
            self.cursor.close()
            self.is_acquired = False
        db_util.release_connection(self.connection)

    # for inserting a new task details
    def task_add(self, data):
        logger.addinfo('@ models - activityplanner - task_add(-)')
        result = dict()
        try:
            self.acquire()
            task_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                                begin
                                    nas_activity_planner_pkg.insert_task(
                                    :x_task_id,
                                    :p_org_id,
                                    :p_task_description,
                                    :p_task_location,
                                    :p_start_date_time,
                                    :p_end_date_time,
                                    :p_goals,
                                    :p_results,
                                    :p_status,
                                    :p_user_comments,
                                    :p_approver_comments,
                                    :p_approver_id,
                                    :p_created_id,
                                    :p_tags,
                                    :x_status_code
                                    );
                                end; """, x_task_id=task_id,
                                p_org_id=data['org_id'],
                                p_task_description=data['task_description'],
                                p_task_location=data['task_location'],
                                p_start_date_time=data['start_date'],
                                p_end_date_time=data['end_date'],
                                p_goals=data['goals'],
                                p_results=data['results'],
                                p_status=data['status'],
                                p_user_comments=data['user_comments'],
                                p_approver_comments=data['approver_comments'],
                                p_approver_id=data['approver_id'],
                                p_created_id=data['created_id'],
                                p_tags=data.get('tags', ''),
                                x_status_code=status_code)
            status = status_code.getvalue()

            if status == 'SUCCESS':
                status_attachments = {'status': 0}
                map_result = {'status': 0}
                # check for attachment
                if len(data['attachments']) > 0:
                    # call the attachment
                    status_attachments = self.add_attachment({
                            'attachments': data['attachments'],
                            'reference_id': task_id,
                            'reference_type': 'task',
                            'created_id': data['created_id']
                        })
                # linking trip to task
                if data['map_trip']:
                    # call the trip and task mapping/link function
                    data['map_trip']['tasks'] = [int(task_id.getvalue())]
                    map_result = self.trip_task_link(data['map_trip'])

                # checking both attachments and map_trip success or not
                if status_attachments['status'] == 0 and \
                        map_result['status'] == 0:
                    result['status'] = Status.OK.value
                    result['msg'] = 'Task added successfully'
                    result['task_id'] = int(task_id.getvalue())
                else:
                    result['status'] = Status.ERROR.value
                    result['msg'] = 'Failed to add task attachments /'
                    result['msg'] += 'mapping trips'
                    result['failed_attachments'] = status_attachments[
                        'failed_attachments']
                    result['failed_links'] = map_result['failed_links']
                    result['task_id'] = int(task_id.getvalue())
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to add task'
                result['task_id'] = -1
        except Exception as e:
            logger.dthublog("""@ EXCEPTION models - activityplanner -
              task_add """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - activityplanner - task_add(+)')
        return result

    # for inserting a new attachment
    def add_attachment(self, req):
        logger.addinfo('@ models - activityplanner - add_attachment(-)')
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.setinputsizes(p_file_content=cx_Oracle.BLOB)
            file_id = self.cursor.var(cx_Oracle.NUMBER)
            status_codes = []
            result = {}
            attachments = req['attachments']
            for attachment in attachments:
                self.cursor.execute("""
                begin
                    nas_activity_planner_pkg.add_attachment(
                        :x_file_id,
                        :p_reference_id,
                        :p_reference_type,
                        :p_attachment_type,
                        :p_file_name,
                        :p_file_type,
                        :p_file_content,
                        :p_created_id,
                        :x_status_code
                    );
                end; """, x_file_id=file_id,
                                    p_reference_id=req['reference_id'],
                                    p_reference_type=req['reference_type'],
                                    p_attachment_type=attachment['attachment_type'],
                                    p_file_name=attachment['file_name'],
                                    p_file_type=attachment['file_type'],
                                    p_file_content=attachment['file_content'],
                                    p_created_id=req['created_id'],
                                    x_status_code=status_code)
                status = status_code.getvalue()
                if status != 'SUCCESS':
                    status_codes.append({
                        'file_name': attachment['file_name'],
                        'error': status
                    })
            if len(status_codes) > 0:
                result['status'] = Status.ERROR.value
            else:
                result['status'] = Status.OK.value
            result['failed_attachments'] = status_codes

        except Exception as e:
            logger.dthublog("""@ EXCEPTION models - activityplanner -
              add_attachment """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - activityplanner - add_attachment(+)')
        return result

    # for updating task details
    def task_update(self, jsond):
        logger.addinfo('@ models - activityplanner - task_update(-) ')
        try:
            self.acquire()
            task_data = []
            if jsond['status'] == 'D':
                query = self.sql_file['get_task_event_details']
                query = query.format(jsond['task_id'])
                task_data = Code_util.iterate_data(
                    self.cursor.execute(query))
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                                begin
                                    nas_activity_planner_pkg.update_task(
                                    :p_task_id,
                                    :p_org_id,
                                    :p_task_description,
                                    :p_task_location,
                                    :p_start_date_time,
                                    :p_end_date_time,
                                    :p_goals,
                                    :p_results,
                                    :p_status,
                                    :p_user_comments,
                                    :p_approver_comments,
                                    :p_approver_id,
                                    :p_recent_update_id,
                                    :p_tags,
                                    :x_status_code
                                    );
                                end; """, p_task_id=jsond['task_id'],
                                p_org_id=jsond['org_id'],
                                p_task_description=jsond['task_description'],
                                p_task_location=jsond['task_location'],
                                p_start_date_time=jsond['start_date'],
                                p_end_date_time=jsond['end_date'],
                                p_goals=jsond['goals'],
                                p_results=jsond['results'],
                                p_status=jsond['status'],
                                p_user_comments=jsond['user_comments'],
                                p_approver_comments=jsond['approver_comments'],
                                p_approver_id=jsond['approver_id'],
                                p_recent_update_id=jsond['created_id'],
                                p_tags=jsond.get('tags', ''),
                                x_status_code=status_code)
            status = status_code.getvalue()
            result = {}
            if status == 'SUCCESS':
                status_attachments = {'status': 0}
                delete_attach_status = 'SUCCESS'
                if len(jsond['attachments']) > 0:
                    status_attachments = self.add_attachment({
                            'attachments': jsond['attachments'],
                            'reference_id': jsond['task_id'],
                            'reference_type': 'task',
                            'created_id': jsond['created_id']
                        })
                if len(jsond['delete_attachments']) > 0:
                    delete_attach_status = self.delete_attachments(
                        jsond['delete_attachments'])
                google_event_status = {'status': 0}
                if len(task_data) > 0:
                    google_event_status = self.delete_calendar_events(jsond['task_id'], task_data, 'task')
                if status_attachments['status'] == 0 and \
                        delete_attach_status == 'SUCCESS':
                    if google_event_status['status'] == 0:
                        result['status'] = Status.OK.value
                        result['msg'] = 'Task updated successfully'
                        result['task_id'] = jsond['task_id']
                    else:
                        result['status'] = Status.OK.value
                        result['msg'] = 'Task updated successfully, google sync failed'
                        result['task_id'] = jsond['task_id']
                else:
                    result['status'] = Status.ERROR.value
                    result['msg'] = 'Failed to update task attachments/'
                    result['msg'] += 'mapped trips'
                    result['failed_attachments'] = status_attachments[
                        'failed_attachments']
                    result['task_id'] = jsond['task_id']

            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to update task- ' + str(status)
                result['task_id'] = jsond['task_id']

        except Exception as e:
            logger.dthublog("""@ EXCEPTION models - activityplanner - 
              task_update""" + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - activityplanner - task_update(+)')
        return result

    # Deleting existing attachments
    def delete_attachments(self, attachment_ids):
        logger.addinfo('@ models - activityplanner - delete_attachments(-)')
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            for attch_id in attachment_ids:
                self.cursor.execute("""
                                    begin
                                        nas_activity_planner_pkg.delete_attachment(
                                    :p_file_id,
                                    :x_status_code
                                        );
                                    end; """, p_file_id=attch_id,
                                    x_status_code=status_code)
        except Exception as e:
            logger.dthublog("""@ EXCEPTION models - activityplanner - 
              delete_attachments """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - activityplanner - delete_attachments(+)')
        return status_code.getvalue()

    # for mapping trip and task
    def trip_task_link(self, jsond):
        logger.addinfo('@ models - activityplanner - trip_task_link(-)')
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            status_codes = []
            for task in jsond['tasks']:
                self.cursor.execute("""
                                    begin
                                        nas_activity_planner_pkg.link_trip_tasks(
                                            :p_trip_id,
                                            :p_task_id,
                                            :p_created_id,
                                            :x_status_code);
                                    end;""",
                                    p_trip_id=jsond['trip'],
                                    p_task_id=task,
                                    p_created_id=jsond['created_id'],
                                    x_status_code=status_code)
                status = status_code.getvalue()
                if status != 'SUCCESS':
                    status_codes.append(
                        {'task': task, 'trip': jsond['trip'], 'status': status})
            result = {}
            if len(status_codes) > 0:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to link trip and task'
                result['failed_links'] = status_codes
            else:
                result['status'] = Status.OK.value
                result['msg'] = 'Inserted the link successfully'
                result['failed_links'] = status_codes
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION models - activityplanner - 
              trip_task_link""" + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - activityplanner - trip_task_link(+)')
        return result

    # for deleting the link between trip and task
    def trip_task_unlink(self, jsond):
        logger.addinfo('@ models - activityplanner - trip_task_unlink(-)')
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            status_codes = []
            for task in jsond['tasks']:
                self.cursor.execute("""
                                    begin
                                        nas_activity_planner_pkg.unlink_trip_tasks(
                                            :p_trip_id, 
                                            :p_task_id,      
                                            :x_status_code);
                                    end;""",
                                    p_task_id=task,
                                    p_trip_id=jsond['trip'],
                                    x_status_code=status_code)
                status = status_code.getvalue()
                if status != 'SUCCESS':
                    status_codes.append(
                        {'task': task, 'trip': jsond['trip'], 'status': status})
            result = {}
            if len(status_codes) > 0:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to delete link between task and trip'
                result['failed_links'] = status_codes
            else:
                result['status'] = Status.OK.value
                result['msg'] = 'Deleted the link successfully'
                result['failed_links'] = []
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION models - activityplanner - 
              trip_task_unlink""" + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - activityplanner - trip_task_unlink(+)')
        return result

    # for getting a single task details based on id
    def get_task_details(self, task_id):
        logger.addinfo('@ models - activityplanner - trip_task_details(-)')
        result = {}
        try:
            self.acquire()
            # for getting details of a single task
            query = self.sql_file['get_task_id_details']
            self.cursor.execute(query, p_task_id=task_id)
            task_details = Code_util.iterate_data(self.cursor)

            # get mapped trip details
            query_trip = self.sql_file['get_trip_summary']
            query_mapped = self.sql_file['get_mapped_trip_details']
            query = query_trip + query_mapped
            self.cursor.execute(query, p_task_id=task_id)
            linked_trip_details = Code_util.iterate_data(self.cursor)
            result['status'] = Status.OK.value
            result['tasks'] = task_details
            result['mapped_trips'] = linked_trip_details

        except Exception as e:
            logger.dthublog(""" @ EXCEPTION models - activityplanner - 
              trip_task_details""" + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - activityplanner - trip_task_details(+)')
        return result

    # for getting single trip details based on trip id
    def get_trip_details(self, trip_id):
        logger.addinfo('@ models - activityplanner - get_trip_details(-)')
        result = {}
        try:
            self.acquire()
            # for getting details of a single trip
            query = self.sql_file['get_trip_id_details']
            self.cursor.execute(query, p_trip_id=trip_id)
            trip_details = Code_util.iterate_data(self.cursor)

            # get task details that are linked to trip
            query_summary = self.sql_file['get_task_summary']
            query_mapped = self.sql_file['get_mapped_task_details']
            query = query_summary + ' ' + query_mapped
            self.cursor.execute(query, p_trip_id=trip_id)
            linked_task_details = Code_util.iterate_data(self.cursor)
            result['status'] = Status.OK.value
            result['trips'] = trip_details
            result['mapped_tasks'] = linked_task_details
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION models - activityplanner -
              get_trip_details""" + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - activityplanner - get_trip_details(+)')
        return result

    def trip_task_summary(self, jsond):
        """
        get trip and task details based on date range and view multiple users tasks/trips.
        fetch their comments of each task.
        :param jsond:
        :return:
        """
        logger.addinfo('@ models - activityplanner - trip_task_summary(-)')
        result = {}
        try:
            self.acquire()
            user_ids = ','.join(str(jsond['users'][i])
                                for i in range(len(jsond['users'])))
            if jsond['type'] == 'task':
                status = ','.join(str(jsond['status'][i])
                                  for i in range(len(jsond['status'])))
                """ If request json has comments as Y then we're going to fetch only comments with 
                specific date range.
                else - Fetch all tasks with no date range specificity, also get comments for a 
                given specific time period."""
                if jsond['comments'] == 'Y':
                    query = self.sql_file['get_task_comments_and_mapped_trips']
                    self.cursor.execute(query.format(status, user_ids, jsond['start_date'],
                                                     jsond['end_date']))
                    comments = Code_util.iterate_data(self.cursor)
                    result['comments'] = comments
                else:
                    query = self.sql_file['get_task_summary_by_status']
                    self.cursor.execute(query.format(status, user_ids, jsond['start_date'],
                                                     jsond['end_date']))
                    task_details = Code_util.iterate_data(self.cursor)
                    query = self.sql_file['get_task_count_based_on_status']
                    # Fetching completed tasks count as they are not loaded by default in front end
                    completed_task_count = self.cursor.execute(query, p_task_status='C',
                                                               p_user_id=jsond['users'][0]).fetchone()
                    result['completed_task_count'] = completed_task_count[0] \
                        if completed_task_count[0] else 0
                    result['tasks'] = task_details
                if jsond['goals'] == 'Y':
                    # Goals summary for the selected users
                    query = self.sql_file['get_goal_summary']
                    self.cursor.execute(query.format(user_ids))
                    result['goals'] = Code_util.iterate_data(self.cursor)
            elif jsond['type'] == 'trip':
                query_summary = self.sql_file['get_trip_summary']
                query_dates = self.sql_file['get_trips_based_on_dates']
                query = query_summary + query_dates
                query += " AND trip.created_id IN ({0})"
                query = query.format(user_ids)
                self.cursor.execute(query, p_start_date=jsond['start_date'],
                                    p_end_date=jsond['end_date'])
                trip_details = Code_util.iterate_data(self.cursor)
                result['trips'] = trip_details
            result['status'] = Status.OK.value

        except Exception as e:
            logger.dthublog(""" @ EXCEPTION models - activityplanner -
              trip_task_summary""" + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - activityplanner - trip_task_summary(+)')
        return result

    # get trip and task details based on user and status
    def summary_based_on_user_id(self, user_id, status):
        logger.addinfo('@ models - activityplanner - summary_based_on_user_id(-)')
        result = {}
        try:
            self.acquire()
            # for getting task details for summary page for user with status
            query_summary = self.sql_file['get_task_summary']
            query_user_id = self.sql_file['get_tasks_based_on_user_id']
            query = query_summary + query_user_id
            query = query.format(status)
            self.cursor.execute(query, p_user_id=user_id)
            task_details = Code_util.iterate_data(self.cursor)
            result['tasks'] = task_details

            # for getting trip details for summary page for user with status
            query_summary = self.sql_file['get_trip_summary']
            query_user_id = self.sql_file['get_trip_based_on_user_id']
            query = query_summary + query_user_id
            query = query.format(status)
            self.cursor.execute(query, p_user_id=user_id)
            trip_details = Code_util.iterate_data(self.cursor)
            result['trips'] = trip_details
            result['status'] = Status.OK.value

        except Exception as e:
            logger.dthublog(""" @ EXCEPTION models - activityplanner - 
              summary_based_on_user_id""" + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - activityplanner - summary_based_on_user_id(+)')
        return result

    # Inserts new approved trips and tasks, deletes
    def google_sync(self, user_id):
        logger.addinfo('@ models - activityplanner - google_sync(-)')
        result = dict()
        try:
            self.acquire()
            # Get list of tasks and trips
            query = self.sql_file['get_google_sync_insert']
            self.cursor.execute(query, p_user_id=user_id)
            result['managers'] = Code_util.iterate_data(self.cursor)
            query = self.sql_file['manager_employees_list']
            self.cursor.execute(query, p_user_id=user_id)
            result['employees'] = Code_util.iterate_data(self.cursor)
            result['status'] = Status.OK.value
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - activityplanner -
              google_sync """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - activityplanner - google_sync(+)')
        return result

    # get manager and employee details
    def get_managers_lov(self, user_id, permission=None):
        logger.addinfo('@ models - activityplanner - get_managers_lov(-)')
        result = dict()
        try:
            with OracleConnectionManager() as conn:
                ''' To fetch the manager details of the user who are active and have
                    access to Activity Planner '''
                query = self.sql_file['check_reports_to_id'] + self.sql_file['role_based_users']
                query += ' AND u.user_id = qam.manager_id AND employee_id = :p_user_id'
                query += ' AND module_name = \'Activity Planner\''
                conn.execute(query, p_user_id=user_id)
                result['managers'] = conn.get_result()

                # checking if TripAllAccess permission present for a user
                if permission and permission == 'UITripAccessAll':
                    common_util_obj = CommonUtils()
                    employee = common_util_obj.get_users_with_role('UI-TRIP-PLANNER')
                    for emp in employee[:]:
                        if emp['user_id'] == user_id:
                            employee.remove(emp)
                        else:
                            emp['user_description'] = emp['full_name']
                else:
                    ''' To fetch the employee details under the user who are active and have
                        access to Activity Planner '''
                    query = self.sql_file['manager_employees_list'] + self.sql_file['role_based_users']
                    query += ' AND u.user_id = employee_id AND manager_id = :p_user_id'
                    query += ' AND module_name = \'Activity Planner\''
                    conn.execute(query, p_user_id=user_id)
                    employee = conn.get_result()
                result['employees'] = employee
                result['status'] = Status.OK.value

        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - activityplanner -
              get_managers_lov """ + str(e))
            raise e
        logger.addinfo('@ models - activityplanner - get_managers_lov(+)')
        return result

    # get list of leaves for the given users
    def get_user_leaves(self, jsond):
        logger.addinfo('@ models - activityplanner - get_user_leaves(-)')
        result = dict()
        try:
            self.acquire()
            query = self.sql_file['user_leave_dates']
            user_ids = ','.join(str(jsond['users'][i])
                                for i in range(len(jsond['users'])))
            query = query.format(user_ids)
            self.cursor.execute(query, p_start_date=jsond['start_date'],
                                p_end_date=jsond['end_date'])
            leave_details = Code_util.iterate_data(self.cursor)
            leave_records = []
            # getting all leave records of a single user into one json
            for leave in leave_details:
                count = 1
                for d in leave_records:
                    # checking if user details are pr esent in the array
                    if d['applied_by'] == leave['applied_by']:
                        count = 0
                        # appending the leave to the respective user
                        d['leaves'].append(leave)
                # if user not found , add the record to the array
                if count == 1:
                    leave_record = {'applied_by': leave['applied_by'],
                                    'leaves': []}
                    leave_record['leaves'].append(leave)
                    leave_records.append(leave_record)
            result['leaves'] = leave_records
            result['status'] = Status.OK.value
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - activityplanner -
              get_user_leaves """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - activityplanner - get_user_leaves(+)')
        return result

    @staticmethod
    def create_google_json_object(data, description, summary, location):
        return {
            'timezone': 'Europe/Amsterdam',
            'calendar_name': 'ActivityPlanner',
            'event_id': '',
            'account': data['email_address'],
            'start_time': data['start_time'],
            'start_date': data['start_date'],
            'end_time': data['end_time'],
            'end_date': data['end_date'],
            'location': location,
            'description': description,
            'summary': summary
        }

    # get list of leaves for the given users
    def google_sync_add(self, jsond):
        logger.addinfo('@ models - activityplanner - google_sync_add(-)')
        try:
            self.acquire()
            result = {'status': 'OK'}
            final_data = {}
            google_event_details = {}
            location = ''
            status = jsond.get('status', '')
            if jsond['trip'] == 'Y':
                query = self.sql_file['get_trips_by_user_id']
                trip_data = Code_util.iterate_data(self.cursor.execute(query, p_user_id=jsond['user_id'],
                                                                       p_status=status))
                for i in range(len(trip_data)):
                    trip_line_details = trip_data[i]['trip_lines']
                    description = ''
                    for j in range(len(trip_line_details)):
                        description += 'Destination - ' + str(j+1) + '\n' + trip_line_details[j]['trip_info'] + '\n'
                        if j == (len(trip_line_details) - 1):
                            location = trip_line_details[j]['to_location']
                    google_event_details['description'] = description
                    summary = 'Trip - ' + trip_data[i]['trip_description']
                    google_event_details = ActivityPlanner.create_google_json_object(trip_data[i], description, summary,
                                                                                     location)
                    google_utils_obj = GoogleUtils()
                    result = google_utils_obj.change_google_calendar(google_event_details)
                    if result['status'] == 'OK':
                        query = self.sql_file['update_trip_google_event_id']
                        self.cursor.execute(query, p_trip_id=trip_data[i]['trip_id'], p_google_event_id=result[
                            'event_id'].encode('ascii'))
            if jsond['task'] == 'Y':
                query = self.sql_file['get_tasks_by_user_id']
                task_header = self.cursor.execute(query, p_user_id=jsond['user_id'], p_status=status)
                task_data = Code_util.iterate_data(task_header)
                for i in range(len(task_data)):
                    # send default start_time as 9 AM as time is mandatory for google sync
                    task_data[i]['start_time'] = '09:00:00'
                    summary = 'Task - ' + task_data[i]['task_description']
                    description = task_data[i]['goals']
                    location = task_data[i]['task_location']
                    google_event_details = ActivityPlanner.create_google_json_object(task_data[i], description, summary,
                                                                                     location)
                    google_utils_obj = GoogleUtils()
                    result = google_utils_obj.change_google_calendar(google_event_details)
                    if result['status'] == 'OK':
                        query = self.sql_file['update_task_google_event_id']
                        self.cursor.execute(query, p_task_id=task_data[i]['task_id'], p_google_event_id=result[
                            'event_id'].encode('ascii'))
            if result['status'] == 'OK':
                final_data['status'] = 0
                final_data['msg'] = 'All Trips and Tasks synced to Google calendar'
            else:
                final_data['status'] = 1
                final_data['msg'] = result['msg']
        except Exception as e:
            logger.dthublog("""@ EXCEPTION - models - activityplanner - 
               google_sync_add""" + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - activityplanner - google_sync_add(+)')
        return final_data

    @staticmethod
    def delete_google_calendar_object(data):
        return {
            'calendar_name': 'ActivityPlanner',
            'account': data[0]['email_address'],
            'event_id': data[0]['google_event_id']
        }

    # delete all trips and tasks in Google calendar
    def delete_calendar_events(self, id, details, activity_type):
        logger.addinfo('@ models - activityplanner - delete_calendar_events(-)')
        try:
            self.acquire()
            result = {}
            final_data = {}
            google_event_details = ActivityPlanner.delete_google_calendar_object(details)
            google_utils_obj = GoogleUtils()
            result = google_utils_obj.delete_event_google_cal(
                google_event_details)
            if result['status'] == 0:
                if activity_type == 'trip':
                    query = self.sql_file['update_trip_google_event_id']
                    self.cursor.execute(query, p_google_event_id='', p_trip_id=id)
                if activity_type == 'task':
                    query = self.sql_file['update_task_google_event_id']
                    self.cursor.execute(query, p_google_event_id='', p_task_id=id)
            if result['status'] == 0:
                final_data['status'] = 0
                final_data['msg'] = 'Google sync completed'
            else:
                final_data['status'] = 1
                final_data['msg'] = 'Failed to update Google sync'
        except Exception as e:
            logger.dthublog("""@ EXCEPTION - models - activityplanner - 
              delete_calendar_events""" + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - activityplanner - delete_calendar_events(+)')
        return final_data

    # change status like submission, approve or reject for a task or a trip
    def change_status(self, jsond):
        logger.addinfo('@ models - activityplanner - change_status(-)')
        result = {}
        try:
            self.acquire()
            trip_data = []
            if len(jsond['trips']) > 0:
                trip_ids = ','.join(str(jsond['trips'][i])
                                    for i in range(len(jsond['trips'])))
                select_query = self.sql_file['get_trip_event_details']
                select_query = select_query.format(trip_ids)
                trip_data = Code_util.iterate_data(self.cursor.execute(select_query))

                query = self.sql_file['change_trip_status']
                query = query.format(trip_ids)
                self.cursor.execute(query, p_status=jsond['status'],
                                    p_approver_comments=jsond['approver_comments'],
                                    p_updated_by=jsond['updated_by'])

            self.connection.commit()
            activities = trip_data
            if len(activities) > 0:
                for activity in activities:
                    if "trip_id" in activity:
                        self.delete_calendar_events(
                            activity['trip_id'], [activity], 'trip')
                    else:
                        self.delete_calendar_events(
                            activity['task_id'], [activity], 'task')

            if jsond['status'] != 'C':
                result = self.send_email(jsond)
            else:
                result = {'status': Status.OK.value,
                          'msg': 'Request updated successfully'}
        except Exception as e:
            logger.dthublog("""@ EXCEPTION - models - activityplanner - 
              change_status""" + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - activityplanner - change_status(+)')
        return result

    # Send Email when user submits or manager approves or reject
    def send_email(self, jsond):
        logger.addinfo('@ models - activityplanner - send_email(-)')
        try:

            self.acquire()
            # for getting created user details
            query = self.sql_file['get_mail_id']
            self.cursor.execute(query, p_user_id=jsond['user_id'])
            created_user_details = self.cursor.fetchone()
            created_user_email = created_user_details[0]
            created_user_name = created_user_details[1]

            # for getting comments related to an activity
            comments_query = self.sql_file['get_comment_or_reply_data'] \
                + self.sql_file['get_comment_data'] + ' DESC'

            # get trip details
            trip_details = []
            if len(jsond['trips']) > 0:
                trip_ids = ','.join(str(jsond['trips'][i])
                                    for i in range(len(jsond['trips'])))
                query_summary = self.sql_file['get_trip_summary']
                query_mapped = self.sql_file['get_multiple_trips']
                query = query_summary + ' ' + query_mapped
                query = query.format(trip_ids)
                self.cursor.execute(query)
                trip_details = Code_util.iterate_data(self.cursor)
                for trip in trip_details:
                    self.cursor.execute(comments_query, p_activity_id=trip['trip_id'], p_activity_type='trip')
                    trip['comments'] = Code_util.iterate_data(self.cursor)
                    for destination in trip['lines']:
                        if destination['goals']:
                            destination['goals'] = destination['goals'].replace('\n', '<br />')
                        if destination['results']:
                            destination['results'] = destination['results'].replace('\n', '<br />')

            # Unique approver_id list from the selected activities
            approver_ids = list({activity['approver_id'] for activity in trip_details})
            successful_mails = 0
            # Send mails to the respective approvers
            if approver_ids and len(approver_ids) > 0:
                for approver_id in approver_ids:
                    # for getting manager details
                    query = self.sql_file['get_mail_id']
                    self.cursor.execute(query, p_user_id=approver_id)
                    manager_details = self.cursor.fetchone()
                    manager_email = manager_details[0]
                    manager_name = manager_details[1]

                    dates = []
                    show_comments = False
                    # Activities to be sent to the respective manager
                    filtered_activities = [activity for activity in trip_details
                                           if activity['approver_id'] == approver_id]
                    if len(filtered_activities) > 0:
                        for activity in filtered_activities:
                            # calculate the duration
                            activity['duration'] = ActivityPlanner.calculate_duration(
                                datetime.datetime.strptime(activity['start_date_time'],
                                                           '%d-%b-%Y %H:%M:%S'),
                                datetime.datetime.strptime(activity['end_date_time'],
                                                           '%d-%b-%Y %H:%M:%S'))

                            dates.append(
                                datetime.datetime.strptime(activity['start_date_time'],
                                                           '%d-%b-%Y %H:%M:%S'))

                            activity['start_date'] = datetime.datetime.strptime(
                                                        activity['start_date_time'],
                                                        '%d-%b-%Y %H:%M:%S').strftime("%d-%b-%Y")
                            activity['comments_length'] = len(activity['comments'])
                            # if any activity has comments the mail template will show comments column
                            if not show_comments:
                                show_comments = activity['comments_length'] > 0
                            # Storing the index to verify conditions in the template
                            for i in range(activity['comments_length']):
                                activity['comments'][i]['index'] = i
                                activity['comments'][i]['user_details'] = activity['comments'][i]['user_details'][0]

                        # Get min date and max date from the above activities
                        start_date = min(dates).strftime("%d-%b-%Y")
                        end_date = max(dates).strftime("%d-%b-%Y")
                        # sort the data based on dates
                        activities = sorted(filtered_activities, key=lambda x: datetime.datetime.strptime(
                                                            x['start_date_time'],
                                                            '%d-%b-%Y %H:%M:%S'), reverse=False)
                        template_data = {
                            'template_id': 755521,
                            'params': [
                                {
                                    'key': 'activities',
                                    'value': activities
                                },
                                {
                                    'key': 'user_id',
                                    'value': jsond['user_id']
                                },
                                {
                                    'key': 'approver_comments',
                                    'value': jsond['approver_comments']
                                },
                                {
                                    'key': 'show_comments',
                                    'value': show_comments
                                }
                            ]
                        }
                        template_subject = ''
                        subject = ''
                        if jsond['status'] == 'P':
                            if len(activities) > 1:
                                subject = self.sql_file['subject_for_pending_for_multi']
                                subject = subject.format(str(len(activities)),
                                                         str(start_date),
                                                         str(end_date), created_user_name)
                                template_subject = self.sql_file['template_subj_for_pending_all']
                            else:
                                subject = self.sql_file['subject_for_pending_for_single']
                                subject = subject.format(str(len(activities)),
                                                         str(start_date), created_user_name)
                                template_subject = self.sql_file['template_subj_for_pending_one']
                                end_date = ''

                            template_subject = template_subject.format(
                                                                        created_user_name,
                                                                        str(len(activities)),
                                                                        str(start_date),
                                                                        str(end_date))
                            template_data['subject'] = subject

                            template_data['to_email'] = manager_email
                            template_data['to_name'] = manager_name
                            template_data['sender'] = {
                                'email': created_user_email,
                                'name': created_user_name
                            }
                        elif jsond['status'] == 'A':
                            if len(activities) > 1:
                                subject = self.sql_file['subject_for_approve_for_multi']
                                template_subject = self.sql_file['subject_for_approve_for_multi']
                            else:
                                subject = self.sql_file['subject_for_approve_for_single']
                                template_subject = self.sql_file['subject_for_approve_for_single']
                                end_date = ''
                            template_subject = template_subject.format(manager_name,
                                                     '<b>' + str(len(activities)) + '</b>',
                                                     '<b>' + str(start_date) + '</b>',
                                                     '<b>' + str(end_date) + '</b>')

                            template_data['subject'] = subject.format(manager_name,
                                                         'your',
                                                         str(start_date),
                                                         str(end_date))

                            template_data['to_email'] = created_user_email
                            template_data['to_name'] = created_user_name
                            template_data['sender'] = {
                                'email': manager_email,
                                'name': manager_name
                            }
                        elif jsond['status'] == 'R':
                            if len(activities) > 1:
                                subject = self.sql_file['subject_for_reject_for_multi']
                                template_subject = self.sql_file['subject_for_reject_for_multi']

                            else:
                                subject = self.sql_file['subject_for_reject_for_single']

                                template_subject = self.sql_file['subject_for_reject_for_single']
                                end_date = ''
                            template_subject = template_subject.format(manager_name,
                                                                       '<b>' + str(len(
                                                                           activities)) + '</b>',
                                                                       '<b>' + str(
                                                                           start_date) + '</b>',
                                                                       '<b>' + str(
                                                                           end_date) + '</b>')
                            template_data['subject'] = subject.format(manager_name,
                                                         'your',
                                                         str(start_date),
                                                         str(end_date))
                            template_data['to_email'] = created_user_email
                            template_data['to_name'] = created_user_name
                            template_data['sender'] = {
                                'email': manager_email,
                                'name': manager_name
                            }

                        template_data['params'].append({
                            'key': 'template_subject',
                            'value': template_subject

                        })

                        template_data['params'].append({
                            'key': 'subjected_to',
                            'value': (manager_name if jsond['status'] == 'P'
                                      else created_user_name)

                        })
                        mail_status_manager = CommonUtils.send_mail(template_data)
                        if mail_status_manager == 'SUCCESS':
                            successful_mails += 1
                    else:
                        successful_mails += 1

            result = {}
            if successful_mails == len(approver_ids):
                result['status'] = 0
                result['msg'] = 'Request updated Successfully'
            else:
                result['status'] = 1
                result['msg'] = 'Failed to send emails to recipients'

        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - activityplanner - 
              send_email""" + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - activityplanner - send_email(+)')
        return result

    @staticmethod
    def calculate_duration(start_date, end_date):
        logger.addinfo('@ models - activityplanner - calculate_duration(-)')
        try:
            end_date = end_date + datetime.timedelta(days=1)
            sub = end_date - start_date
            final = ''
            if int(sub.days) > 0:
                days = str(sub.days)
                final = days + ' days'
            else:
                hours, rem = divmod(sub.seconds, 3600)
                minutes, seconds = divmod(rem, 60)
                if hours > 0:
                    final += str(hours) + ' hrs '
                if minutes > 0:
                    final += str(minutes) + ' min '
        except Exception as e:
            logger.dthublog("""@ EXCEPTION - models - activityplanner - 
              calculate_duration""" + str(e))
            raise e
        logger.addinfo('@ models - activityplanner - calculate_duration(+)')
        return final

    # Add a new trip
    def trip_add(self, jsond):
        logger.addinfo('@ models - activityplanner - trip_add(-)')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            trip_id = self.cursor.var(cx_Oracle.NUMBER)
            to_location = []
            from_location = []
            start_date_time = []
            end_date_time = []
            goals = []
            results = []
            budget_type = []
            budget_expense = []
            budget_currency = []
            count_budget = []
            budget_values = []
            count = 0
            for line in jsond['lines']:
                to_location.append(line['to_location'])
                from_location.append(line['from_location'])
                start_date_time.append(line['start_date_time'])
                end_date_time.append(line['end_date_time'])
                goals.append(line['goals'])
                results.append(line['results'])
                count = count + len(line['budget_list'])
                count_budget.append(count)
                for budget in line['budget_list']:
                    budget_type.append(budget['budget_type'])
                    budget_expense.append(str(budget['expense_amount']))
                    budget_currency.append(budget['currency_code'])
                    budget_values.append(budget['budget_value'])
            self.cursor.execute("""
                                declare\

                                p_trip_lines
                                    nas_activity_planner_pkg.trip_lines_type_cover;

                                budget_array
                                    nas_activity_planner_pkg.budget_type_cover;
                                
                                new_budget_array
                                    nas_activity_planner_pkg.budget_type_cover;

                                type number_table_t is table of number
                                                        index by binary_integer;

                                type string_table_t is table of nvarchar2(2000)
                                    index by binary_integer;
                                
                                type varchar_table_t is table of varchar2(2000)
                                    index by binary_integer;

                                d_to_location string_table_t := :p_to_location;\
                                d_from_location string_table_t := :p_from_location;\
                                d_start_date_time  string_table_t := :p_start_date_time_arr;\
                                d_end_date_time string_table_t := :p_end_date_time_arr;\
                                d_goals string_table_t := :p_goals;\
                                d_results string_table_t := :p_results;\
                                d_budget_type string_table_t := :p_budget_type;\
                                d_count_budget number_table_t := :p_count;\
                                d_expense_amount varchar_table_t := :p_budget_expense;\
                                d_budget_currency string_table_t := :p_budget_currency;\
                                d_budget_values string_table_t := :p_budget_values;\

                                p_start_range number;\
                                p_end_range number;\

                                begin
                                    FOR i in 1..d_to_location.count
                                    LOOP
                                        budget_array := new_budget_array;
                                        p_trip_lines(i).to_location := d_to_location(i);\
                                        p_trip_lines(i).from_location := d_from_location(i);\
                                        p_trip_lines(i).start_date_time := d_start_date_time(i); \
                                        p_trip_lines(i).end_date_time := d_end_date_time(i);\
                                        p_trip_lines(i).goals := d_goals(i);\
                                        p_trip_lines(i).results := d_results(i);\
                                        p_trip_lines(i).line_id := null;
                                        IF i = 1 THEN
                                          p_start_range := 1;
                                          p_end_range := d_count_budget(i);
                                        ELSE
                                            p_start_range := d_count_budget(i-1) + 1;
                                            p_end_range := d_count_budget(i);
                                        END IF;

                                        FOR j in p_start_range..p_end_range
                                        LOOP
                                            budget_array(j-p_start_range).budget_type := d_budget_type(j);\
                                            budget_array(j-p_start_range).currency_code := d_budget_currency(j);\
                                            budget_array(j-p_start_range).expense_amount := TO_NUMBER(d_expense_amount(j));\
                                            budget_array(j-p_start_range).budget_id := null;\
                                            budget_array(j-p_start_range).budget_value := d_budget_values(j);\
                                        END LOOP;
                                        p_trip_lines(i).budget_list := budget_array;
                                    END LOOP;
                                    nas_activity_planner_pkg.insert_trip_header(
                                    :x_trip_id,
                                    :p_org_id,
                                    :p_trip_description,
                                    :p_status,
                                    :p_approver_id,
                                    :p_user_comments,
                                    :p_approver_comments,
                                    :p_created_id,
                                    :p_start_date_time,
                                    :p_end_date_time,
                                    p_trip_lines,
                                    :x_status_code);
                                end; """, x_trip_id=trip_id,
                                p_org_id=jsond['org_id'],
                                p_trip_description=jsond['trip_description'],
                                p_status=jsond['status'],
                                p_approver_id=jsond['approver_id'],
                                p_user_comments=jsond['user_comments'],
                                p_approver_comments=jsond['approver_comments'],
                                p_created_id=jsond['created_id'],
                                p_start_date_time=jsond['start_date_time'],
                                p_end_date_time=jsond['end_date_time'],
                                p_from_location=from_location,
                                p_to_location=to_location,
                                p_goals=goals,
                                p_start_date_time_arr=start_date_time,
                                p_end_date_time_arr=end_date_time,
                                p_results=results,
                                p_count=count_budget,
                                p_budget_type=budget_type,
                                p_budget_expense=budget_expense,
                                p_budget_currency=budget_currency,
                                p_budget_values=budget_values,
                                x_status_code=status_code)
            result = {}
            status = status_code.getvalue()
            if status == 'SUCCESS':
                status_attachments = {'status': 0}
                map_result = {'status': 0}
                # check for attachment
                if len(jsond['attachments']) > 0:
                    # call the attachment
                    status_attachments = self.add_attachment({
                            'attachments': jsond['attachments'],
                            'reference_id': int(trip_id.getvalue()),
                            'reference_type': 'trip',
                            'created_id': jsond['created_id']
                        })

                # linking trip to task
                if jsond['map_task']:
                    # call the trip and task mapping/link function
                    jsond['map_task']['trip'] = int(trip_id.getvalue())
                    map_result = self.trip_task_link(jsond['map_task'])

                # checking both attachments and map_trip success or not
                if status_attachments['status'] == 0 and \
                        map_result['status'] == 0:
                    result['status'] = Status.OK.value
                    result['msg'] = 'Trip added successfully'
                    result['trip_id'] = int(trip_id.getvalue())
                else:
                    result['status'] = Status.ERROR.value
                    result['msg'] = 'Failed to add trip attachments /'
                    result['msg'] += ' mapping tasks'
                    result['failed_attachments'] = status_attachments[
                        'failed_attachments']
                    result['failed_links'] = map_result['failed_links']
                    result['trip_id'] = int(trip_id.getvalue())
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to Add Trip - ' + str(status)
                result['trip_id'] = -1

        except Exception as e:
            logger.dthublog("""@ EXCEPTION models - activityplanner -
              trip_add """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - activityplanner - trip_add (+)')
        return result

    # Update a existing trip
    def trip_update(self, jsond):
        logger.addinfo('@ models - activityplanner - trip_update(-)')
        try:
            self.acquire()
            trip_data = []
            if jsond['status'] == 'D':
                query = self.sql_file['get_trip_event_details']
                query = query.format(jsond['trip_id'])
                trip_data = Code_util.iterate_data(
                    self.cursor.execute(query))
            status_code = self.cursor.var(cx_Oracle.STRING)
            to_location = []
            from_location = []
            start_date_time = []
            end_date_time = []
            goals = []
            results = []
            budget_type = []
            budget_expense = []
            budget_currency = []
            count_budget = []
            line_ids = []
            budget_ids = []
            budget_values = []
            count = 0
            for line in jsond['lines']:
                to_location.append(line['to_location'])
                from_location.append(line['from_location'])
                start_date_time.append(line['start_date_time'])
                end_date_time.append(line['end_date_time'])
                goals.append(line['goals'])
                results.append(line['results'])
                count = count + len(line['budget_list'])
                count_budget.append(count)
                if line['line_id'] is None:
                    line_ids.append('')
                else:
                    line_ids.append(str(line['line_id']))
                for budget in line['budget_list']:
                    budget_type.append(budget['budget_type'])
                    budget_expense.append(str(budget['expense_amount']))
                    budget_currency.append(budget['currency_code'])
                    budget_values.append(budget['budget_value'])
                    if budget['budget_id'] is None:
                        budget_ids.append('')
                    else:
                        budget_ids.append(str(budget['budget_id']))
            self.cursor.execute("""
                                declare\

                                p_trip_lines
                                    nas_activity_planner_pkg.trip_lines_type_cover;

                                budget_array
                                    nas_activity_planner_pkg.budget_type_cover;
                                
                                new_budget_array
                                    nas_activity_planner_pkg.budget_type_cover;

                                type number_table_t is table of number
                                                        index by binary_integer;

                                type string_table_t is table of nvarchar2(2000)
                                    index by binary_integer;
                                
                                type varchar_table_t is table of varchar2(1000)
                                    index by binary_integer;

                                d_to_location string_table_t := :p_to_location;\
                                d_from_location string_table_t := :p_from_location;\
                                d_start_date_time  string_table_t := :p_start_date_time_arr;\
                                d_end_date_time string_table_t := :p_end_date_time_arr;\
                                d_goals string_table_t := :p_goals;\
                                d_results string_table_t := :p_results;\
                                d_budget_type string_table_t := :p_budget_type;\
                                d_count_budget number_table_t := :p_count;\
                                d_expense_amount varchar_table_t := :p_budget_expense;\
                                d_budget_currency string_table_t := :p_budget_currency;\
                                d_lines_ids varchar_table_t := :p_line_ids;\
                                d_budget_ids varchar_table_t := :p_budget_ids;\
                                d_budget_values string_table_t := :p_budget_values;\

                                p_start_range number;\
                                p_end_range number;\

                                begin
                                    FOR i in 1..d_to_location.count
                                    LOOP
                                        budget_array := new_budget_array;
                                        p_trip_lines(i).to_location := d_to_location(i);\
                                        p_trip_lines(i).from_location := d_from_location(i);\
                                        p_trip_lines(i).start_date_time := d_start_date_time(i); \
                                        p_trip_lines(i).end_date_time := d_end_date_time(i);\
                                        p_trip_lines(i).goals := d_goals(i);\
                                        p_trip_lines(i).results := d_results(i);\
                                        p_trip_lines(i).line_id := TO_NUMBER(d_lines_ids(i));\
                                        IF i = 1 THEN
                                          p_start_range := 1;
                                          p_end_range := d_count_budget(i);
                                        ELSE
                                            p_start_range := d_count_budget(i-1) + 1;
                                            p_end_range := d_count_budget(i);
                                        END IF;

                                        FOR j in p_start_range..p_end_range
                                        LOOP
                                            budget_array(j-p_start_range).budget_type := d_budget_type(j);\
                                            budget_array(j-p_start_range).currency_code := d_budget_currency(j);\
                                            budget_array(j-p_start_range).expense_amount := TO_NUMBER(d_expense_amount(j));\
                                            budget_array(j-p_start_range).budget_id := TO_NUMBER(d_budget_ids(j));\
                                            budget_array(j-p_start_range).budget_value := d_budget_values(j);\
                                        END LOOP;
                                        p_trip_lines(i).budget_list := budget_array;\
                                    END LOOP;
                                    nas_activity_planner_pkg.update_trip_header(
                                    :p_trip_id,
                                    :p_org_id,
                                    :p_trip_description,
                                    :p_status,
                                    :p_approver_id,
                                    :p_user_comments,
                                    :p_approver_comments,
                                    :p_recent_updated_user_id,
                                    :p_start_date_time,
                                    :p_end_date_time,
                                     p_trip_lines,
                                    :x_status_code);
                                end; """, p_trip_id=jsond['trip_id'],
                                p_org_id=jsond['org_id'],
                                p_trip_description=jsond[
                                    'trip_description'],
                                p_status=jsond['status'],
                                p_approver_id=jsond['approver_id'],
                                p_user_comments=jsond['user_comments'],
                                p_approver_comments=jsond[
                                    'approver_comments'],
                                p_recent_updated_user_id=jsond[
                                    'recent_updated_user_id'],
                                p_start_date_time=jsond['start_date_time'],
                                p_end_date_time=jsond['end_date_time'],
                                p_from_location=from_location,
                                p_to_location=to_location,
                                p_goals=goals,
                                p_start_date_time_arr=start_date_time,
                                p_end_date_time_arr=end_date_time,
                                p_results=results,
                                p_count=count_budget,
                                p_budget_type=budget_type,
                                p_budget_expense=budget_expense,
                                p_budget_currency=budget_currency,
                                p_line_ids=line_ids,
                                p_budget_ids=budget_ids,
                                p_budget_values=budget_values,
                                x_status_code=status_code)
            result = {}
            status = status_code.getvalue()
            if status == 'SUCCESS':
                status_attachments = {'status': 0}
                delete_attach_status = 'SUCCESS'
                delete_lines = {'status': 0}
                # check for attachment
                if len(jsond['attachments']) > 0:
                    # call the attachment
                    status_attachments = self.add_attachment({
                            'attachments': jsond['attachments'],
                            'reference_id': jsond['trip_id'],
                            'reference_type': 'trip',
                            'created_id': jsond['created_id']
                        })

                # delete attachments
                if len(jsond['delete_attachments']) > 0:
                    delete_attach_status = self.delete_attachments(
                        jsond['delete_attachments'])
                # delete lines
                if len(jsond['delete_lines']) > 0:
                    delete_lines = self.delete_line_details(
                        jsond['delete_lines'])
                google_event_status = {'status': 0}
                if len(trip_data) > 0:
                    google_event_status = self.delete_calendar_events(jsond['trip_id'], trip_data, 'trip')
                # checking both attachments and map_trip success or not
                if status_attachments['status'] == 0 and \
                        delete_attach_status == 'SUCCESS' and \
                        delete_lines['status'] == 0:
                    if google_event_status['status'] == 0:
                        result['status'] = Status.OK.value
                        result['msg'] = 'Trip updated successfully'
                        result['trip_id'] = jsond['trip_id']
                    else:
                        result['status'] = Status.OK.value
                        result['msg'] = 'Trip updated successfully, google sync failed'
                        result['trip_id'] = jsond['trip_id']
                else:
                    result['status'] = Status.ERROR.value
                    result['msg'] = 'Failed to update trip attachments / '
                    result['msg'] += ' mapping tasks / lines'
                    result['failed_attachments'] = status_attachments[
                        'failed_attachments']
                    result['trip_id'] = jsond['trip_id']
                    result['failed_lines'] = delete_lines['failed_lines']
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to Update Trip - ' + str(status)
                result['trip_id'] = jsond['trip_id']

        except Exception as e:
            logger.dthublog("""@ EXCEPTION models - activityplanner -
              trip_update """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - activityplanner - trip_update (+)')
        return result

    # to get attachment file content based on id
    @staticmethod
    def get_attachment_details(attachment_id):
        logger.addinfo('@ models - activityplanner - get_attachment_details(-)')
        try:
            common_utils_obj = CommonUtils()
            result = common_utils_obj.get_attachment_data('file_content',
                                                          'nas_activity_attachments',
                                                          'file_id',
                                                          attachment_id)
            final = {'file_content': result}
        except Exception as e:
            logger.dthublog("""@ EXCEPTION models - activityplanner -
              get_attachment_details """ + str(e))
            raise e
        logger.addinfo('@ models - activityplanner - get_attachment_details(+)')
        return final

    def delete_line_details(self, lines):
        logger.addinfo('@ models - activityplanner - delete_line_details(-)')
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            budget_status_code = self.cursor.var(cx_Oracle.STRING)
            status_codes = []
            for line_id in lines:
                # delete lines
                self.cursor.execute("""
                                    begin
                                        nas_activity_planner_pkg.delete_trip_lines(
                                    :p_line_id,
                                    :x_status_code
                                        );
                                    end; """,
                                    p_line_id=line_id,
                                    x_status_code=status_code)
                if status_code.getvalue() == 'SUCCESS':
                    # delete budget lines based on line_id
                    self.cursor.execute("""
                                        begin
                                            nas_activity_planner_pkg.delete_activity_budget(
                                        :p_line_id,
                                        :x_status_code
                                            );
                                        end; """,
                                        p_line_id=line_id,
                                        x_status_code=budget_status_code)
                if status_code.getvalue() != 'SUCCESS':
                    status_codes.append({'status': status_code.getvalue(),
                                        'line_id': line_id})
            result = {}
            if len(status_codes) > 0:
                result['msg'] = 'Failed to delete lines'
                result['failed_lines'] = status_codes
                result['status'] = Status.ERROR.value
            else:
                result['msg'] = 'SUCCESS'
                result['failed_lines'] = status_codes
                result['status'] = Status.OK.value
        except Exception as e:
            logger.dthublog("""@ EXCEPTION models - activityplanner -
                      delete_line_details """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - activityplanner - delete_line_details(+)')
        return result

    def add_comments(self, data):
        """ This method is used for inserting comments in tasks or trips """
        logger.addinfo('@ models - activityplanner - add_comments(-)')
        result = {}
        try:
            self.acquire()
            comment_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                                begin
                                    nas_activity_planner_pkg.insert_comment(
                                    :x_comment_id,
                                    :p_comment_type,
                                    :p_comment_data,
                                    :p_parent_id,
                                    :p_activity_id,
                                    :p_activity_type,
                                    :p_created_id,
                                    :p_created_date,
                                    :x_status_code
                                    );
                                end; """, x_comment_id=comment_id,
                                p_comment_type=data['comment_type'],
                                p_comment_data=data['comment_data'],
                                p_parent_id=data['parent_id'],
                                p_activity_id=data['activity_id'],
                                p_activity_type=data['activity_type'],
                                p_created_id=data['created_id'],
                                p_created_date=data['created_date'],
                                x_status_code=status_code)
            status = status_code.getvalue()
            line_type = 'Comment' if data['comment_type'] == 'C' else 'Reply'
            if status == 'SUCCESS':
                result['status'] = Status.OK.value
                result['msg'] = line_type + ' added successfully'
                result['comment_id'] = int(comment_id.getvalue())
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to add ' + line_type
        except Exception as e:
            logger.dthublog("""@ EXCEPTION models - activityplanner -
              add_comments """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - activityplanner - add_comments(+)')
        return result

    def get_comments(self, activity_type, activity_id):
        """ This method is used for fetching the comments
            and their replies based on activity id and type """
        logger.addinfo('@ models - activityplanner - get_comments(-)')
        result = {}
        try:
            self.acquire()
            # get the common fields required for replies/comments
            query_common = self.sql_file['get_comment_or_reply_data']
            # Adding a cursor to fetch all the replies related to a comment
            query_replies = ', CURSOR(' + query_common + self.sql_file['get_reply_data'] + ') replies'
            query = query_common + query_replies + self.sql_file['get_comment_data']
            self.cursor.execute(query, p_activity_id=activity_id, p_activity_type=activity_type)
            comments = Code_util.iterate_data(self.cursor)
            result['status'] = Status.OK.value
            result['comments'] = comments
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION models - activityplanner -
              get_comments""" + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - activityplanner - get_comments(+)')
        return result

    def delete_comment(self, comment_id):
        """ This method is used for deletion of comments or replies in an activity.

            Note: If a comment is deleted, all the replies related to it will be deleted too
        """
        logger.addinfo('@ models - activityplanner - delete_comment(-)')
        result = {}
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                                begin
                                    nas_activity_planner_pkg.delete_comment(
                                :p_comment_id,
                                :x_status_code
                                    );
                                end; """, p_comment_id=comment_id,
                                x_status_code=status_code)
            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = Status.OK.value
                result['msg'] = 'Comment/Reply deleted successfully'
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to delete Comment/Reply'
        except Exception as e:
            logger.dthublog("""@ EXCEPTION models - activityplanner -
              delete_comment """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - activityplanner - delete_comment(+)')
        return result

    def delete_activity(self, activity_type, activity_id):
        """ This method is used for deletion of an activity.

            Note: If an activity is deleted, all the comments, mappings
            and attachments related to it will be deleted too.
        """
        logger.addinfo('@ models - activityplanner - delete_activity(-)')
        result = {}
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            if activity_type == 'trip':
                self.cursor.execute("""
                                    begin
                                        nas_activity_planner_pkg.delete_trip_header(
                                    :p_trip_id,
                                    :x_status_code
                                        );
                                    end; """, p_trip_id=activity_id,
                                    x_status_code=status_code)
            else:
                self.cursor.execute("""
                                    begin
                                        nas_activity_planner_pkg.delete_task(
                                    :p_task_id,
                                    :x_status_code
                                        );
                                    end; """, p_task_id=activity_id,
                                    x_status_code=status_code)
            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = Status.OK.value
                result['msg'] = activity_type.capitalize() + ' deleted successfully'
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to delete ' + activity_type.capitalize()
        except Exception as e:
            logger.dthublog("""@ EXCEPTION models - activityplanner -
              delete_activity """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - activityplanner - delete_activity(+)')
        return result

    def update_task_status(self, req):
        logger.addinfo('@ models - activityplanner - update_task_status(+)')
        result = {}
        try:
            self.acquire()
            status = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute('''
            begin
                nas_activity_planner_pkg.update_task_status(
                    :p_task_id,
                    :p_task_status,
                    :p_user_id,
                    :x_status_code
                );
            end; ''', p_task_id=req['task_id'],
                                p_task_status=req['task_status'],
                                p_user_id=req['user_id'],
                                x_status_code=status)
            if status.getvalue() == 'SUCCESS':
                result = {
                    'status': 0,
                    'msg': 'Task status updated successfully'
                }
            else:
                result = {
                    'status': 1,
                    'msg': 'Failed to update task status - ' + str(status.getvalue())
                }
        except Exception as e:
            logger.dthublog('''@ EXCEPTION models - activityplanner -
                update_task_status ''' + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - activityplanner - update_task_status(-)')
        return result

    def get_task_tags(self):
        logger.addinfo('@ models - activityplanner - get_task_tags(+)')
        try:
            self.acquire()
            query = self.sql_file['task_tags_query']
            self.cursor.execute(query)
            result = Code_util.iterate_data(self.cursor)
        except Exception as e:
            logger.dthublog('''@ EXCEPTION models - activityplanner -
                get_task_tags ''' + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - activityplanner - get_task_tags(-)')
        return result

    def add_sub_task(self, data):
        logger.addinfo('@ models - activityplanner - add_sub_task(-)')
        result = {}
        try:
            self.acquire()
            sub_task_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute('''
                                begin
                                    nas_activity_planner_pkg.insert_sub_task(
                                    :x_sub_task_id,
                                    :p_task_id,
                                    :p_sub_task_title,
                                    :p_assigned_user_id,
                                    :p_sub_task_description,
                                    :p_sub_task_display_order,
                                    :p_sub_task_priority,
                                    :p_due_date,
                                    :p_created_id,
                                    :x_status_code
                                    );
                                end; ''', x_sub_task_id=sub_task_id,
                                p_task_id=data['task_id'],
                                p_sub_task_title=data['sub_task_title'],
                                p_assigned_user_id=data['assigned_user_id'],
                                p_sub_task_description=data['sub_task_description'],
                                p_sub_task_display_order=data['sub_task_display_order'],
                                p_sub_task_priority=data['sub_task_priority'],
                                p_due_date=data['due_date'],
                                p_created_id=data['created_id'],
                                x_status_code=status_code)
            status = status_code.getvalue()

            if status == 'SUCCESS':
                result['status'] = Status.OK.value
                result['msg'] = 'Sub-Task added successfully'
                result['sub_task_id'] = int(sub_task_id.getvalue())
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to add sub task'
        except Exception as e:
            logger.dthublog("""@ EXCEPTION models - activityplanner -
              add_sub_task """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - activityplanner - add_sub_task(+)')
        return result

    def update_sub_task(self, data):
        logger.addinfo('@ models - activityplanner - update_sub_task(-)')
        result = {}
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute('''
                                begin
                                    nas_activity_planner_pkg.update_sub_task(
                                    :p_sub_task_id,
                                    :p_task_id,
                                    :p_sub_task_title,
                                    :p_assigned_user_id,
                                    :p_sub_task_description,
                                    :p_sub_task_display_order,
                                    :p_sub_task_priority,
                                    :p_due_date,
                                    :p_recent_updated_user_id,
                                    :x_status_code
                                    );
                                end; ''', p_sub_task_id=data['sub_task_id'],
                                p_task_id=data['task_id'],
                                p_sub_task_title=data['sub_task_title'],
                                p_assigned_user_id=data['assigned_user_id'],
                                p_sub_task_description=data['sub_task_description'],
                                p_sub_task_display_order=data['sub_task_display_order'],
                                p_sub_task_priority=data['sub_task_priority'],
                                p_due_date=data['due_date'],
                                p_recent_updated_user_id=data['recent_updated_user_id'],
                                x_status_code=status_code)
            status = status_code.getvalue()

            if status == 'SUCCESS':
                result['status'] = Status.OK.value
                result['msg'] = 'Sub-Task updated'
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to update sub task'
        except Exception as e:
            logger.dthublog("""@ EXCEPTION models - activityplanner -
              update_sub_task """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - activityplanner - update_sub_task(+)')
        return result

    def add_or_delete_collaborators(self, data):
        logger.addinfo('@ models - activityplanner - add_or_delete_collaborators(-)')
        result = {}
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            # Sending an array with -1 to the package if empty arrays are passed
            if len(data['add_user_ids']) == 0:
                data['add_user_ids'] = [-1]
            if len(data['delete_user_ids']) == 0:
                data['delete_user_ids'] = [-1]
            self.cursor.execute('''
                                begin
                                    nas_activity_planner_pkg.add_or_delete_collaborator(
                                    :p_add_user_ids,
                                    :p_delete_user_ids,
                                    :p_task_id,
                                    :p_created_id,
                                    :x_status_code
                                    );
                                end; ''', p_add_user_ids=data['add_user_ids'],
                                p_delete_user_ids=data['delete_user_ids'],
                                p_task_id=data['task_id'],
                                p_created_id=data['created_id'],
                                x_status_code=status_code)
            status = status_code.getvalue()

            if status == 'SUCCESS':
                result['status'] = Status.OK.value
                result['msg'] = 'Collaborators updated successfully'
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to update collaborators'
        except Exception as e:
            logger.dthublog("""@ EXCEPTION models - activityplanner -
              add_or_delete_collaborators """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - activityplanner - add_or_delete_collaborators(+)')
        return result

    def delete_sub_task(self, sub_task_id):
        logger.addinfo('@ models - activityplanner - delete_sub_task(-)')
        result = {}
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute('''
                                begin
                                    nas_activity_planner_pkg.delete_sub_task(
                                    :p_sub_task_id,
                                    :x_status_code
                                    );
                                end; ''', p_sub_task_id=sub_task_id,
                                x_status_code=status_code)
            status = status_code.getvalue()

            if status == 'SUCCESS':
                result['status'] = Status.OK.value
                result['msg'] = 'Sub task deleted'
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to delete sub task'
        except Exception as e:
            logger.dthublog("""@ EXCEPTION models - activityplanner -
              delete_sub_task """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - activityplanner - delete_sub_task(+)')
        return result

    def update_sub_task_order(self, data):
        logger.addinfo('@ models - activityplanner - update_sub_task_order(-)')
        result = {}
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            sub_task_id = []
            sub_task_display_order = []
            for sub_task in data['sub_task_order']:
                sub_task_id.append(sub_task['sub_task_id'])
                sub_task_display_order.append(sub_task['sub_task_display_order'])
            self.cursor.execute('''
                                declare\

                                p_sub_task_order
                                    nas_activity_planner_pkg.sub_task_type_cover;

                                type number_table_t is table of number
                                                        index by binary_integer;

                                d_sub_task_id number_table_t := :p_sub_task_id;\
                                d_sub_task_display_order number_table_t := :p_sub_task_display_order;\

                                begin
                                    FOR i in 1..d_sub_task_id.count
                                    LOOP
                                        p_sub_task_order(i).sub_task_id := d_sub_task_id(i);\
                                        p_sub_task_order(i).sub_task_display_order := d_sub_task_display_order(i);\
                                    END LOOP;
                                    nas_activity_planner_pkg.update_sub_task_order(
                                    p_sub_task_order,
                                    :x_status_code
                                    );
                                end; ''', p_sub_task_id=sub_task_id,
                                p_sub_task_display_order=sub_task_display_order,
                                x_status_code=status_code)
            status = status_code.getvalue()

            if status == 'SUCCESS':
                result['status'] = Status.OK.value
                result['msg'] = 'Sub task order updated'
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to update sub task order'
        except Exception as e:
            logger.dthublog("""@ EXCEPTION models - activityplanner -
              update_sub_task_order """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - activityplanner - update_sub_task_order(+)')
        return result

    def add_activity_log(self, data):
        logger.addinfo('@ models - activityplanner - add_activity_log(-)')
        result = {}
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute('''
                                begin
                                    nas_activity_planner_pkg.insert_activity_log(
                                    :p_task_id,
                                    :p_log_message,
                                    :p_created_id,
                                    :p_created_date,
                                    :x_status_code
                                    );
                                end; ''', p_task_id=data['task_id'],
                                p_log_message=data['log_message'],
                                p_created_id=data['created_id'],
                                p_created_date=data['created_date'],
                                x_status_code=status_code)
            status = status_code.getvalue()

            if status == 'SUCCESS':
                result['status'] = Status.OK.value
                result['msg'] = 'Log message added successfully'
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to update activity logs'
        except Exception as e:
            logger.dthublog("""@ EXCEPTION models - activityplanner -
              add_activity_log """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - activityplanner - add_activity_log(+)')
        return result

    def get_activity_logs(self, task_id):
        logger.addinfo('@ models - activityplanner - get_activity_logs(+)')
        try:
            self.acquire()
            query = self.sql_file['activity_logs_query']
            self.cursor.execute(query, p_task_id=task_id)
            result = Code_util.iterate_data(self.cursor)
        except Exception as e:
            logger.dthublog('''@ EXCEPTION models - activityplanner -
                get_activity_logs ''' + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - activityplanner - get_activity_logs(-)')
        return result

    def update_task_order(self, data):
        """
        This method saves the task/project display order for a user in activity planner
        """
        logger.addinfo('@ models - activityplanner - update_task_order(-)')
        result = {}
        try:
            task_id = []
            task_status = []
            display_order = []
            for task in data['task_order']:
                if task['status'] in data['task_status']:
                    task_id.append(task['task_id'])
                    task_status.append(task['status'])
                    display_order.append(task['display_order'])
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute('''
                                declare\

                                p_task_order 
                                        nas_activity_planner_pkg.task_order_type_cover;

                                type number_table_t is table of number
                                                        index by binary_integer;

                                type string_table_t is table of varchar2(50) 
                                                        index by binary_integer;

                                d_task_id number_table_t := :p_task_id;\
                                d_status string_table_t := :p_status;\
                                d_display_order number_table_t := :p_display_order;\

                                begin
                                    FOR i in 1..d_task_id.count
                                    LOOP
                                        p_task_order(i).task_id := d_task_id(i);\
                                        p_task_order(i).status := d_status(i);\
                                        p_task_order(i).display_order := d_display_order(i);\
                                    END LOOP;
                                
                                    nas_activity_planner_pkg.update_task_order(
                                    p_task_order,
                                    :p_task_status,
                                    :p_user_id,
                                    :x_status_code
                                    );
                                end; ''', p_task_id=task_id,
                                p_status=task_status,
                                p_display_order=display_order,
                                p_task_status=data['task_status'],
                                p_user_id=data['user_id'],
                                x_status_code=status_code)
            status = status_code.getvalue()

            if status == 'SUCCESS':
                result['status'] = Status.OK.value
                result['msg'] = 'Task order saved successfully'
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to update task order'
        except Exception as e:
            logger.dthublog("""@ EXCEPTION models - activityplanner -
              update_task_order """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - activityplanner - update_task_order(+)')
        return result

    def add_goal(self, data):
        logger.addinfo('@ models - activityplanner - add_goal(-)')
        result = {}
        try:
            self.acquire()
            goal_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute('''
                                begin
                                    nas_activity_planner_pkg.insert_goal(
                                    :x_goal_id,
                                    :p_goal_name,
                                    :p_goal_description,
                                    :p_created_id,
                                    :x_status_code
                                    );
                                end; ''', x_goal_id=goal_id,
                                p_goal_name=data['name'],
                                p_goal_description=data['description'],
                                p_created_id=data['created_id'],
                                x_status_code=status_code)
            status = status_code.getvalue()

            if status == 'SUCCESS':
                result['status'] = Status.OK.value
                result['msg'] = 'Goal created successfully'
                result['goal_id'] = int(goal_id.getvalue())
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to create the goal'
        except Exception as e:
            logger.dthublog("""@ EXCEPTION models - activityplanner -
              add_goal """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - activityplanner - add_goal(+)')
        return result

    def update_goal(self, data):
        logger.addinfo('@ models - activityplanner - update_goal(-)')
        result = {}
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute('''
                                begin
                                    nas_activity_planner_pkg.update_goal(
                                    :p_goal_id,
                                    :p_goal_name,
                                    :p_goal_description,
                                    :p_recent_updated_user_id,
                                    :x_status_code
                                    );
                                end; ''', p_goal_id=data['id'],
                                p_goal_name=data['name'],
                                p_goal_description=data['description'],
                                p_recent_updated_user_id=data['recent_updated_user_id'],
                                x_status_code=status_code)
            status = status_code.getvalue()

            if status == 'SUCCESS':
                result['status'] = Status.OK.value
                result['msg'] = 'Goal updated'
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to update goal'
        except Exception as e:
            logger.dthublog("""@ EXCEPTION models - activityplanner -
              update_goal """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - activityplanner - update_goal(+)')
        return result

    def get_goal_details(self, goal_id):
        logger.addinfo('@ models - activityplanner - get_goal_details(+)')
        try:
            self.acquire()
            query = self.sql_file['get_goal_details_by_id']
            self.cursor.execute(query, p_goal_id=goal_id)
            result = Code_util.iterate_data(self.cursor)
        except Exception as e:
            logger.dthublog('''@ EXCEPTION models - activityplanner -
                get_goal_details ''' + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - activityplanner - get_goal_details(-)')
        return result

    def delete_goal(self, goal_id):
        logger.addinfo('@ models - activityplanner - delete_goal(+)')
        result = {}
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute('''
                                begin
                                    nas_activity_planner_pkg.delete_goal(
                                    :p_goal_id,
                                    :x_status_code
                                    );
                                end; ''', p_goal_id=goal_id,
                                x_status_code=status_code)
            status = status_code.getvalue()

            if status == 'SUCCESS':
                result['status'] = Status.OK.value
                result['msg'] = 'Goal deleted'
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to delete goal'
        except Exception as e:
            logger.dthublog('''@ EXCEPTION models - activityplanner -
                delete_goal ''' + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - activityplanner - delete_goal(-)')
        return result

    def link_or_unlink_goal(self, data):
        logger.addinfo('@ models - activityplanner - link_or_unlink_goal(-)')
        result = {}
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute('''
                                begin
                                    nas_activity_planner_pkg.link_unlink_goal(
                                    :p_goal_id,
                                    :p_task_ids,
                                    :x_status_code
                                    );
                                end; ''', p_goal_id=data['goal_id'],
                                p_task_ids=data['task_ids'],
                                x_status_code=status_code)
            status = status_code.getvalue()

            if status == 'SUCCESS':
                result['status'] = Status.OK.value
                result['msg'] = 'Goal and tasks link updated'
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to update goal and tasks link'
        except Exception as e:
            logger.dthublog("""@ EXCEPTION models - activityplanner -
              link_or_unlink_goal """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - activityplanner - link_or_unlink_goal(+)')
        return result

    def map_managers_and_employees(self, data):
        logger.addinfo('@ models - activityplanner - map_managers_and_employees(-)')
        result = {}
        try:
            with OracleConnectionManager() as conn:
                status_code = conn.cursor.var(cx_Oracle.STRING)

                # Sending an array with -1 to the package if empty arrays are passed
                if len(data['insert_managers']) == 0:
                    data['insert_managers'] = [-1]
                if len(data['delete_managers']) == 0:
                    data['delete_managers'] = [-1]
                if len(data['insert_employees']) == 0:
                    data['insert_employees'] = [-1]
                if len(data['delete_employees']) == 0:
                    data['delete_employees'] = [-1]

                conn.execute('''
                                    begin
                                        nas_activity_planner_pkg.map_managers_and_employees(
                                        :p_insert_managers,
                                        :p_delete_managers,
                                        :p_insert_employees,
                                        :p_delete_employees,
                                        :p_employee_id,
                                        :p_primary_approver,
                                        :p_created_id,
                                        :x_status_code
                                        );
                                    end; ''', p_insert_managers=data['insert_managers'],
                             p_delete_managers=data['delete_managers'],
                             p_insert_employees=data['insert_employees'],
                             p_delete_employees=data['delete_employees'],
                             p_employee_id=data['employee_id'],
                             p_primary_approver=data['primary_approver'],
                             p_created_id=data['created_id'],
                             x_status_code=status_code)
                status = status_code.getvalue()

                if status == 'SUCCESS':
                    result['status'] = Status.OK.value
                    result['msg'] = 'Employees mapped to manager successfully'
                else:
                    result['status'] = Status.ERROR.value
                    result['msg'] = 'Failed to map employees'
        except Exception as e:
            logger.dthublog("""@ EXCEPTION models - activityplanner -
              map_managers_and_employees """ + str(e))
            raise e
        logger.addinfo('@ models - activityplanner - '
                       'map_managers_and_employees(+)')
        return result

    def get_manager_employee_details(self):
        logger.addinfo('@ models - activityplanner - get_manager_employee_details(-)')
        result = {}
        try:
            common_utils_obj = CommonUtils()
            result['employees'] = common_utils_obj.get_users_with_role('UI-TRIP-PLANNER')
            result['status'] = Status.OK.value
        except Exception as e:
            logger.dthublog("""@ EXCEPTION models - activityplanner -
              get_manager_employee_details """ + str(e))
            raise e
        logger.addinfo('@ models - activityplanner - '
                       'get_manager_employee_details(+)')
        return result
