"""
 models.
"""
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer
from werkzeug.security import generate_password_hash, check_password_hash
from flask import current_app
from scorpionapi.utils.logdata import logger


class User(object):
    id = 1

    @property
    def password(self):
        raise AttributeError('password is not a readable attribute')

    @password.setter
    def password(self, password):
        self.password_hash = generate_password_hash(password)

    def verify_password(self, password):
        return check_password_hash(self.password_hash, password)

    def generate_auth_token(self, expires_in=3600):
        s = Serializer(current_app.config['SECRET_KEY'], expires_in=expires_in)
        return s.dumps({'id': self.id}).decode('utf-8')

    @staticmethod
    def verify_auth_token(token):
        log = logger.getLog()
        s = Serializer(current_app.config['SECRET_KEY'])
        try:
            data = s.loads(token)
            log.info("ID of user: "+data['id'])
        except Exception as e:
            log.info("in exception: "+str(e))
            return None
        return 'admin'
