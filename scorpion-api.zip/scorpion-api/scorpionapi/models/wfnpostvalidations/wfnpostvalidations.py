from __future__ import absolute_import

import base64
import random
import string
import cx_Oracle
import csv
import os
import jinja2
import threading
import xlrd
import zipfile
import pandas as pd
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from scorpionapi.utils.constants import Status

from scorpionapi.utils.code_util import Code_util
from scorpionapi.utils.common_utils import CommonUtils
from scorpionapi.sql import sql_util
from scorpionapi.utils import db_util
from scorpionapi.utils.logdata import logger


class WfnPostValidations:

    def __init__(self):
        self.strings = db_util.get_strings()
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())
        self.connection = None
        self.cursor = None
        self.is_acquired = False

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()
        self.is_acquired = True

    def release(self):
        if self.cursor:
            self.cursor.close()
            self.is_acquired = False
        db_util.release_connection(self.connection)

    def check_client_is_processing(self, data):
        try:
            if not self.is_acquired:
                self.acquire()
            self.cursor.execute(self.sql_file['check_if_processing'], p_client_id=data['client_id'])
            result = Code_util.iterate_data(self.cursor)
        except Exception as e:
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        return result

    def async_generate_asp_files(self, data):
        # Check if client id is already in processing
        """
        Generate balance audit asynchronously on a separate thread
        """
        # logger doesn't work when running on thread as it use
        # flask context to get current user details, so when
        # running on thread set logging to False
        thread = threading.Thread(target=self.insert_adpr_import_files, args=(data,))
        thread.deamon = True
        thread.start()
        return {
            'status': 0,
            'msg': self.sql_file['dm_async_status']
        }

    @staticmethod
    def id_generator():
        size = 9
        chars = string.ascii_uppercase + string.digits
        return ''.join(random.choice(chars) for _ in range(size))

    def insert_adpr_import_files(self, data):
        try:
            result = {}
            self.acquire()
            # report log creation
            user_id = data['user_id']
            report_creation_log_s = self.sql_file['report_creation_log_s']
            report_sq = self.cursor.execute(report_creation_log_s).fetchone()
            report_creation_log = self.sql_file['report_creation_log']
            self.cursor.execute(report_creation_log, p_report_id=report_sq[0], p_report_name=data['report_name'],
                                p_user_id=data['user_id'], p_status='P', p_conversion=data['conversion_name'])
            self.connection.commit()
            # Import file upload
            decoded = base64.b64decode(data['import_base64'])

            temp_file_name = '/tmp/' + self.id_generator() + '.csv'
            text_file = open(temp_file_name, 'wb')
            text_file.write(decoded)
            text_file.close()
            lines = []
            batch_size = 10000
            insert_import_sql = ''
            insert_adpr_sql = ''
            if data['conversion_name'] == 'master-file':
                insert_adpr_sql = self.sql_file['insert_statement_adpr_mf']
                insert_import_sql = self.sql_file['insert_statement_import_mf']
            elif data['conversion_name'] == 'position':
                insert_adpr_sql = self.sql_file['insert_statement_adpr_position']
                insert_import_sql = self.sql_file['insert_statement_import_position']
            elif data['conversion_name'] == 'pay-rate':
                insert_adpr_sql = self.sql_file['insert_statement_adpr_payrate']
                insert_import_sql = self.sql_file['insert_statement_import_payrate']
            with open(temp_file_name, "r") as csv_file:
                csv_reader = csv.reader(csv_file, delimiter=',')
                next(csv_reader)
                for line in csv_reader:
                    line_list = [i.strip('"') for i in line]
                    line_list.append(report_sq[0])
                    lines.append(line_list)
                    if len(lines) % batch_size == 0:
                        self.cursor.executemany(insert_import_sql, lines)
                        lines = []
                self.cursor.executemany(insert_import_sql, lines)
            os.remove(temp_file_name)
            # ADPR file upload
            decoded_adpr = base64.b64decode(data['adpr_base64'])
            # Create file in tmp folder
            temp_file_name_adpr = '/tmp/' + self.id_generator() + '.xls'

            # Open file in write mode and write decoded excel content
            text_file = open(temp_file_name_adpr, 'wb')
            text_file.write(decoded_adpr)
            text_file.close()
            batch_size = 10000
            b = xlrd.open_workbook(temp_file_name_adpr)
            sheet_data = b.sheet_by_index(0)
            column_names = []
            for i in range(sheet_data.ncols):
                column_names.append(sheet_data.cell_value(0, i))
            rows = []
            for i in range(1, sheet_data.nrows):
                rows_data = sheet_data.row_values(i)
                row_data = []
                for j in range(sheet_data.ncols):
                    row_data.append(str(rows_data[j]))
                row_data.append(report_sq[0])
                rows.append(row_data)
                if len(lines) % batch_size == 0:
                    self.cursor.executemany(insert_adpr_sql, rows)
                    rows = []
            self.cursor.executemany(insert_adpr_sql, rows)
            os.remove(temp_file_name_adpr)
            self.connection.commit()
            # generate comparison report between ADPR & Import file
            if data['conversion_name'] == 'master-file':
                insert_report = self.sql_file['create_report']
                self.cursor.execute(insert_report, p_report_id=report_sq[0])
            elif data['conversion_name'] == 'position':
                insert_report_position = self.sql_file['create_report_position']
                self.cursor.execute(insert_report_position, p_report_id=report_sq[0])
            elif data['conversion_name'] == 'pay-rate':
                insert_report_pay_rate = self.sql_file['create_report_payrate']
                self.cursor.execute(insert_report_pay_rate, p_report_id=report_sq[0])
            self.cursor.execute(self.sql_file['update_status_dm_report_log'], p_report_id=report_sq[0])
            self.connection.commit()
            result['status'] = 0
            result['msg'] = 'Report creation is Successful'
            result['report_id'] = report_sq[0]
            # sending email to user
            mail_status = self.send_mail(result, user_id)
        except Exception as error:
            self.cursor.execute(self.sql_file['update_status_dm_report_log_failed'], p_report_id=report_sq[0])
            print(str(error))
            raise error
        finally:
            if self.is_acquired:
                self.release()
        return result

    def report_checker(self, data):
        logger.addinfo('@ models - wfnpostvalidations - report_checker(+)')
        result = dict()
        try:
            self.acquire()
            self.cursor.execute(self.sql_file['report_user_validate'], p_report_name=data['report_name'],
                                p_user_id=data['user_id'])
            if self.cursor.fetchone()[0] > 0:
                result['status'] = 1
                result['msg'] = 'Report name already exists'
                return result
            else:
                result['status'] = 0
                return result
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - wfnpostvalidations -
                report_checker """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()

    def get_report_dm_summary(self, user_id):
        logger.addinfo('@ models - wfnpostvalidations - get_report_dm_summary(+)')
        result = dict()
        try:
            self.acquire()
            self.cursor.execute(self.sql_file['report_dm_summary'], p_user_id=user_id)
            report_record_count = Code_util.iterate_data(self.cursor)
            result['status'] = 0
            result['result'] = report_record_count
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - wfnpostvalidations -
                get_report_dm_summary """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - wfnpostvalidations - get_report_dm_summary(-)')
        return result

    def get_dm_attachment(self, report_id, conversion, user):
        try:
            result = {}
            if not self.is_acquired:
                self.acquire()
            if conversion.lower() == 'master-file':
                query = self.sql_file['get_dm_report_attachment_query']
            elif conversion.lower() == 'position':
                query = self.sql_file['get_dm_report_position_attachment_query']
            elif conversion.lower() == 'pay-rate':
                query = self.sql_file['get_dm_report_payrate_attachment_query']
            upd_df = pd.read_sql(query, self.connection, params={'p_report_id': report_id, 'p_dml_type': 'UPD'})
            insert_df = pd.read_sql(query, self.connection, params={'p_report_id': report_id, 'p_dml_type': 'INS'})
            delete_df = pd.read_sql(query, self.connection, params={'p_report_id': report_id, 'p_dml_type': 'DEL'})
            sheet_names = {'Update Existing': upd_df, 'New Employees': insert_df, 'Extra records in WFN': delete_df}
            static_path = '/tmp/'
            file_name = CommonUtils.generate_random_string(10)
            file_path = os.path.join(static_path, file_name)
            writer = pd.ExcelWriter(file_path + '.xlsx', engine='xlsxwriter')
            for sheet_name in sheet_names.keys():
                sheet_names[sheet_name].to_excel(writer, sheet_name=sheet_name, index=False)
            writer.save()
            if os.path.exists(file_path + '.xlsx'):
                with zipfile.ZipFile(file_path + '.zip', 'w', zipfile.ZIP_DEFLATED, allowZip64=True) as zf:
                    zf.write(file_path + '.xlsx', arcname=file_name + '.xlsx')
                os.remove(file_path + '.xlsx')
                result['file_name'] = file_name + '.zip'
            else:
                result['status'] = 1
                result['msg'] = 'Unable to download Dual maintenance file'
        except Exception as e:
            raise e
        finally:
            if self.is_acquired:
                self.release()
        return result

    def delete_dm_report(self, report_id):
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                                  begin
                                        NAS_WFN_DM_PKG.delete_dm_report(
                                        :p_report_id,                                     
                                        :x_status_code
                                        );
                                    end; """, p_report_id=report_id,
                                x_status_code=status_code)
            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'Report deleted Successfully'
            else:
                result['status'] = 1
                result['msg'] = 'Failed to delete report - ' + str(status)
        except Exception as e:
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        return result

    def send_mail(self, data, user):
        try:
            req = {}
            if not self.is_acquired:
                self.acquire()
            self.cursor.execute(self.sql_file['get_user_details'], p_user_id=user)
            user_details = Code_util.iterate_data(self.cursor)
            if data['status'] == 0:
                 msg = 'Processing of the file that you uploaded is Completed, you can review and download dual ' \
                       'maintenance reports.'
            else:
                msg = 'Processing of the file you Uploaded has Failed, please check with Admin'
            path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
            path += '/static/email_templates'
            template = jinja2.Environment(
                loader=jinja2.FileSystemLoader(path)
            ).get_template('notification_wfn.html').render(
                msg=msg,
                user=user_details[0]['first_name'],
            )
            req['email'] = user_details[0]['email_address']
            req['subject'] = 'Dual Maintenance Tool Notification'
            req['message_template'] = template
            email_status = WfnPostValidations.send_smtp_mail(req)
        except Exception as error:
            raise error
        return email_status

    @staticmethod
    def send_smtp_mail(req_data):
        try:
            strings = db_util.get_strings()
            # req_data['activation_key'] = self.password
            # req_data['user'] = self.user_value
            """message_template = Registration.read_template('email_template_registration.txt')"""
            msg = MIMEMultipart()       # create a message
            # add in the actual person name to the message template
            server = smtplib.SMTP()
            server.connect(strings['mail_server'], 25)
            # message = message_template.substitute(PERSON_NAME=user_name, MESSAGE_BODY=message_body)
            # Prints out the message body for our sake
            # setup the parameters of the message
            msg['From'] = strings['sender_email']
            msg['To'] = req_data['email']
            msg['Subject'] = req_data['subject']
            # add in the message body
            msg.attach(MIMEText(req_data['message_template'], 'html'))
            # send the message via the server set up earlier.
            server.send_message(msg)
            del msg
            server.quit()
            status = 'success'
        except Exception as e:
            status = 'Failure - Failed to send email'
            raise e
        return status
