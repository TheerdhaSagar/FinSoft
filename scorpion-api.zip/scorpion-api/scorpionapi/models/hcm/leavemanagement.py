from __future__ import absolute_import

import cx_Oracle
import os

from scorpionapi.utils.code_util import Code_util
from scorpionapi.sql import sql_util
from scorpionapi.utils import db_util
from scorpionapi.utils.logdata import logger


class LeaveManagement:

    def __init__(self):
        self.strings = db_util.get_strings()
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())
        self.connection = None
        self.cursor = None
        self.is_acquired = False

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()
        self.is_acquired = True

    def release(self):
        if self.cursor:
            self.cursor.close()
            self.is_acquired = False
        db_util.release_connection(self.connection)

    def holiday_insert(self, data):
        logger.addinfo('@ models - leavemanagement - holiday_insert(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            holiday_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            holiday_dates = self.cursor.var(cx_Oracle.STRING)
            holiday_ids = self.cursor.var(cx_Oracle.STRING)
            dates = []
            for i in range(len(data['dates'])):
                dates.append(data['dates'][i])
            self.cursor.execute("""
                declare\
                    l_holiday_dates nas_leavemanagement_pkg.lm_date_record_type_cover;\

                    type t_dates_table is table of varchar2(100)
                          index by binary_integer;\
                    p_dates t_dates_table := :p_holidays_dates;\
                begin\

                    for i in 1..p_dates.count
                    LOOP
                        l_holiday_dates(i).holiday_date := p_dates(i);\
                    END LOOP;\
                    nas_leavemanagement_pkg.insert_holidays(
                        :x_holiday_id,
                        :p_user_id,
                        :p_holiday_name,
                        :p_description,
                        :p_org_id,
                        :p_year,
                        l_holiday_dates,
                        :x_status_code,
                        :x_holiday_dates,
                        :x_holiday_ids
                    );
                end; """, x_holiday_id=holiday_id,
                                p_user_id=data['user_id'],
                                p_holiday_name=data['holiday_name'],
                                p_description=data['description'],
                                p_org_id=data['org_id'],
                                p_year=data['year'],
                                p_holidays_dates=dates,
                                x_status_code=status_code,
                                x_holiday_dates=holiday_dates,
                                x_holiday_ids=holiday_ids)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'Holiday added to the List'
                result['holiday_ids'] = holiday_ids.getvalue()
                result['holiday_dates'] = holiday_dates.getvalue()
            else:
                result['status'] = 1
                result['msg'] = 'Failed to add to holiday list - ' + str(status)
                result['holiday_id'] = -1
                result['holiday_ids'] = ''
                result['holiday_dates'] = ''
        except Exception as e:
            logger.dthublog("""@ 70 EXCEPTION models - leavemanagement -
                holiday_insert """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - leavemanagement - holiday_insert(-)')
        return result

    def holiday_update(self, data):
        logger.addinfo('@ models - leavemanagement - holiday_update(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                nas_leavemanagement_pkg.update_holidays(
                    :p_holiday_id,
                    :p_user_id,
                    :p_holiday_name,
                    :p_description,
                    :p_holiday_date,
                    :p_holiday_to_date,
                    :p_year,
                    :x_status_code
                );
            end; """, p_holiday_id=data['holiday_id'],
                                p_user_id=data['user_id'],
                                p_holiday_name=data['holiday_name'],
                                p_description=data['description'],
                                p_holiday_date=data['holiday_date'],
                                p_holiday_to_date=data['holiday_to_date'],
                                p_year=data['year'],
                                x_status_code=status_code)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'Holiday updated successfully'
                result['holiday_id'] = data['holiday_id']
            else:
                result['status'] = 1
                result['msg'] = 'Failed to update holiday calendar - ' + str(status)
                result['holiday_id'] = -1
        except Exception as e:
            logger.dthublog("""@ 115 EXCEPTION models - leavemanagement -
                holiday_update """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - leavemanagement - holiday_update(-)')
        return result

    def get_holidays(self, jsond):
        logger.addinfo('@ models - leavemanagement - get_holidays(+)')
        result = dict()
        try:
            self.acquire()
            query = self.sql_file['holiday_calender_query']
            self.cursor.execute(query, p_org_id=jsond['org_id'],
                                p_holiday_id=jsond['holiday_id'],
                                p_year=jsond['year'])
            holidays = Code_util.iterate_data(self.cursor)
            result['status'] = 0
            result['result'] = holidays
        except Exception as e:
            logger.dthublog(""" @ 143 EXCEPTION - models - leavemanagement -
                get_holidays """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - leavemanagement - get_holidays(-)')
        return result

    def delete_holidays(self, org_id, holiday_id):
        logger.addinfo('@ models - leavemanagement - delete_holidays(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                nas_leavemanagement_pkg.delete_holidays(
                    :p_holiday_id,
                    :p_org_id,
                    :x_status_code
                );
            end; """, p_holiday_id=holiday_id,
                                p_org_id=org_id,
                                x_status_code=status_code)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'Holiday(s) deleted successfully'
                result['org_id'] = org_id
            else:
                result['status'] = 1
                result['msg'] = 'Failed to delete holiday calendar - ' + str(status)
                result['holiday_id'] = -1
        except Exception as e:
            logger.dthublog("""@ 170 EXCEPTION models - leavemanagement -
                delete_holidays """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - leavemanagement - delete_holidays(-)')
        return result

    def leave_type_insert(self, data):
        logger.addinfo('@ models - leavemanagement - leave_type_insert(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            leave_type_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                nas_leavemanagement_pkg.insert_leave_type(
                    :x_leave_type_id,
                    :p_user_id,
                    :p_leave_type,
                    :p_description,
                    :p_org_id,
                    :p_leave_count,
                    :p_year,
                    :p_allow_hourly,
                    :x_status_code
                );
            end; """, x_leave_type_id=leave_type_id,
                                p_user_id=data['user_id'],
                                p_leave_type=data['leave_type'],
                                p_description=data['description'],
                                p_org_id=data['org_id'],
                                p_leave_count=data['leave_count'],
                                p_year=data['year'],
                                p_allow_hourly=data['allow_hourly'],
                                x_status_code=status_code)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'Leave type added to the List'
                result['leave_type_id'] = leave_type_id.getvalue()
            else:
                result['status'] = 1
                result['msg'] = 'Failed to add to leave type - ' + str(status)
                result['leave_type_id'] = -1
        except Exception as e:
            logger.dthublog("""@ 235 EXCEPTION models - leavemanagement -
                leave_type_insert """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - leavemanagement - leave_type_insert(-)')
        return result

    def leave_type_update(self, data):
        logger.addinfo('@ models - leavemanagement - leave_type_update(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                nas_leavemanagement_pkg.leave_type_update(
                    :p_leave_type_id,
                    :p_user_id,
                    :p_leave_type,
                    :p_description,
                    :p_leave_count,
                    :p_year,
                    :p_allow_hourly,
                    :x_status_code
                );
            end; """, p_leave_type_id=data['leave_type_id'],
                                p_user_id=data['user_id'],
                                p_leave_type=data['leave_type'],
                                p_description=data['description'],
                                p_leave_count=data['leave_count'],
                                p_year=data['year'],
                                p_allow_hourly=data['allow_hourly'],
                                x_status_code=status_code)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'Leave type updated successfully'
                result['leave_type_id'] = data['leave_type_id']
            else:
                result['status'] = 1
                result['msg'] = 'Failed to update Leave type - ' + str(status)
                result['leave_type_id'] = -1
        except Exception as e:
            logger.dthublog("""@ 281 EXCEPTION models - leavemanagement -
                leave_type_update """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - leavemanagement - leave_type_update(-)')
        return result

    def get_leave_types(self, org_id, leave_type_id):
        logger.addinfo('@ models - leavemanagement - get_leave_type(+)')
        result = dict()
        try:
            self.acquire()
            query = self.sql_file['leave_type_query']
            self.cursor.execute(query, p_org_id=org_id,
                                p_leave_type_id=leave_type_id)
            leave_types = Code_util.iterate_data(self.cursor)
            result['status'] = 0
            result['result'] = leave_types
        except Exception as e:
            logger.dthublog(""" @ 307 EXCEPTION - models - leavemanagement -
                get_leave_type """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - leavemanagement - get_leave_type(-)')
        return result

    def leave_insert(self, data):
        logger.addinfo('@ models - leavemanagement - leave_insert(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            dates = data['dates']

            # Get if user already applied leave for selected dates
            query = self.sql_file['get_duplicate_leaves']
            query = query % (',' . join(["'" + dates[i]['leave_date'].upper() + "'"
                            for i in range(len(dates))]))
            self.cursor.execute(query, p_applied_by=data['user_id'],
                                p_org_id=data['org_id'])
            duplicates = Code_util.iterate_data(self.cursor)

            duplicated_dates = []
            for i in range(len(dates)):
                for j in range(len(duplicates)):
                    if dates[i]['leave_date'].upper() == duplicates[j]['leave_date'].upper():
                        duplicated_dates.append({
                            'date': dates[i]['leave_date'],
                            'leave_type': duplicates[j]['leave_type']
                        })

            if len(duplicated_dates) == 0:
                leave_id = self.cursor.var(cx_Oracle.NUMBER)
                status_code = self.cursor.var(cx_Oracle.STRING)
                leave_dates = []
                full_day = []
                leave_from_time = []
                leave_hours = []

                for i in range(len(dates)):
                    hhmm = ''
                    if dates[i]['full_day'] != 'Y':
                        hhmm = str(dates[i]['hours']) + ':' + str(dates[i]['minutes'])
                        hhmm.encode(self.connection.nencoding)
                    leave_dates.append(dates[i]['leave_date'])
                    full_day.append(dates[i]['full_day'])
                    leave_from_time.append(dates[i]['leave_from_time'])
                    leave_hours.append(hhmm)
                self.cursor.execute("""
                    declare\
                        p_leave_details nas_leavemanagement_pkg.details_record_type_cover;

                        type t_dates_table is table of varchar2(100)
                              index by binary_integer;\

                        type t_full_day_table is table of varchar2(100)
                              index by binary_integer;\

                        type t_leave_from_table is table of varchar2(100)
                              index by binary_integer;\

                        type t_leave_hours_table is table of varchar2(100)
                              index by binary_integer;\

                        leave_dates t_dates_table := :p_leave_dates;\
                        full_day t_full_day_table := :p_full_day;\
                        leave_from t_leave_from_table := :p_leave_from;\
                        leave_hours t_leave_hours_table := :p_leave_hours;\
                    begin
                        for i in 1..leave_dates.count
                        LOOP
                            p_leave_details(i).leave_date := leave_dates(i);\
                            p_leave_details(i).full_day := full_day(i);\
                            p_leave_details(i).leave_from_time := leave_from(i);\
                            p_leave_details(i).leave_hours := leave_hours(i);\
                            p_leave_details(i).leave_detail_id := -1;\
                        END LOOP;\

                        nas_leavemanagement_pkg.insert_apply_leave(
                        :x_leave_id,
                        :p_user_id,
                        :p_manager_user_id,
                        :p_leave_type_id,
                        :p_reason,
                        :p_from_date,
                        :p_upto_date,
                        p_leave_details,
                        :p_action,
                        :p_comments,
                        :p_org_id,
                        :x_status_code
                        );
                    end; """, x_leave_id=leave_id,
                                    p_user_id=int(data['user_id']),
                                    p_leave_type_id=data['leave_type_id'],
                                    p_manager_user_id=data['manager_user_id'],
                                    p_reason=data['reason'],
                                    p_from_date=data['from_date'],
                                    p_upto_date=data['upto_date'],
                                    p_leave_dates=leave_dates,
                                    p_full_day=full_day,
                                    p_leave_from=leave_from_time,
                                    p_leave_hours=leave_hours,
                                    p_action=data['action'],
                                    p_comments=data['comments'],
                                    p_org_id=data['org_id'],
                                    x_status_code=status_code)

                status = status_code.getvalue()
                if status == 'SUCCESS':
                    query = self.sql_file['get_mail_id']
                    # Get manager mail_address and name
                    self.cursor.execute(query, p_user_id=data['manager_user_id'])
                    user_data = Code_util.iterate_data(self.cursor)
                    manager_email = user_data[0]['email_address']
                    manager_name = user_data[0]['user_name']

                    # Get user mail_address and name
                    self.cursor.execute(query, p_user_id=data['user_id'])
                    user_data = Code_util.iterate_data(self.cursor)
                    applied_user_email = user_data[0]['email_address']
                    applied_user_name = user_data[0]['user_name']

                    subject = self.strings['leave_request'] + applied_user_name
                    subject += " #" + str(int(leave_id.getvalue()))
                    jsond = {
                        'manager_name': manager_name,
                        'template_id': 579072,
                        'user_name': applied_user_name,
                        'leave_type': data['leave_type'],
                        'no_of_days': data['no_of_days'],
                        'from_date': data['from_date'],
                        'upto_date': data['upto_date'],
                        'total_leaves': data['total_leaves'],
                        'leaves_used': data['leaves_used'],
                        'leaves_remaining': data['leaves_remaining'],
                        'leave_status': '',
                        'deleted_user_name': '',
                        'dates': '',
                        'comments': '',
                        'subject': subject,
                        'created_date': data['created_date'],
                        'reason': data['reason'],
                        'recipients': [manager_email],
                        'recipient_name': ''
                    }
                    # LeaveManagement.send_email(jsond)
                    result['status'] = 0
                    result['msg'] = 'Leave applied Successfully'
                    result['holiday_id'] = leave_id.getvalue()
                else:
                    result['status'] = 1
                    result['msg'] = 'Failed to apply leave - ' + str(status)
                    result['holiday_id'] = -1
            else:
                result = {
                    'status': 1,
                    'duplicated_dates': duplicated_dates
                }
        except Exception as e:
            logger.dthublog("""@ 356 EXCEPTION models - leavemanagement -
                leave_insert """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - leavemanagement - leave_insert(-)')
        return result

    @staticmethod
    def send_email(jsond):
        logger.addinfo('models - leavemanagement - send_email(+)')
        try:
            recipients = []
            for i in range(len(jsond['recipients'])):
                recipients.append({
                    'Email': jsond['recipients'][i]
                })
            strings = db_util.get_strings()
            api_key = os.environ['MJ_APIKEY_PUBLIC']
            api_secret = os.environ['MJ_APIKEY_PRIVATE']
            # mailjet = Client(auth=(api_key, api_secret))
            mail_data = {
                'FromEmail': strings['sender_email'],
                'FromName': strings['sender_name'],
                'Subject': jsond['subject'],
                'MJ-TemplateID': jsond['template_id'],
                'MJ-TemplateLanguage': True,
                'MJ-TemplateErrorReporting': strings['mj_error_report_mail'],
                'Vars': {
                    'manager_name': jsond['manager_name'],
                    'user_name': jsond['user_name'],
                    'leave_type': jsond['leave_type'],
                    'no_of_days': jsond['no_of_days'],
                    'from_date': jsond['from_date'],
                    'to_date': jsond['upto_date'],
                    'total': jsond['total_leaves'],
                    'leaves_used': jsond['leaves_used'],
                    'leaves_available': jsond['leaves_remaining'],
                    'leaves_remaining': jsond['leaves_remaining'],
                    'leave_status': jsond['leave_status'],
                    'deleted_user_name': jsond['deleted_user_name'],
                    'dates': jsond['dates'],
                    'comments': jsond['comments'],
                    'created_date': jsond['created_date'],
                    'reason': jsond['reason'],
                    'recipient_name': jsond['recipient_name']
                },
                'Recipients': recipients
            }

            #mailjet.send.create(data=mail_data)
        except Exception as e:
            raise

    def leave_update(self, data):
        logger.addinfo('@ models - leavemanagement - leave_update(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()

            dates = data['dates']
            # Get if user already applied leave for selected dates
            query = self.sql_file['get_duplicate_leaves']
            query = query % (',' . join(["'" + dates[i]['leave_date'].upper() + "'"
                            for i in range(len(dates))]))
            self.cursor.execute(query, p_applied_by=data['applied_by'],
                                p_org_id=data['org_id'])
            duplicates = Code_util.iterate_data(self.cursor)

            duplicated_dates = []
            for i in range(len(dates)):
                for j in range(len(duplicates)):
                    if (dates[i]['leave_date'].upper() == duplicates[j]['leave_date'].upper()
                        ) and (data['leave_id'] != duplicates[j]['leave_id']):
                        duplicated_dates.append({
                            'date': dates[i]['leave_date'],
                            'leave_type': duplicates[j]['leave_type']
                        })

            if len(duplicated_dates) == 0:
                status_code = self.cursor.var(cx_Oracle.STRING)
                leave_dates = []
                full_day = []
                leave_from_time = []
                leave_hours = []
                leave_detail_ids = []

                delete_ids = []
                deleted_dates = []

                if len(data['deleteIds']) == 0:
                    delete_ids = [-1]

                for i in range(len(data['deleteIds'])):
                    delete_ids.append(data['deleteIds'][i]['leave_detail_id'])
                    deleted_dates.append(data['deleteIds'][i]['leave_date'])
                for i in range(len(dates)):
                    hhmm = ''
                    if dates[i]['full_day'] != 'Y':
                        hhmm = str(dates[i]['hours']) + ':' + str(dates[i]['minutes'])
                        hhmm.encode(self.connection.nencoding)
                        leave_from_time.append(dates[i]['leave_from_time'].encode(self.connection.nencoding))
                        leave_hours.append(hhmm)
                    else:
                        leave_from_time.append('')
                        leave_hours.append('')
                    leave_dates.append(dates[i]['leave_date'].encode(self.connection.nencoding))
                    full_day.append(dates[i]['full_day'].encode(self.connection.nencoding))
                    leave_detail_ids.append(dates[i]['leave_detail_id'])
                self.cursor.execute("""
                    declare\
                        p_leave_details nas_leavemanagement_pkg.details_record_type_cover;
                        p_delete_ids nas_leavemanagement_pkg.delete_leave_detail_type_cover;


                        type t_dates_table is table of varchar2(100)
                              index by binary_integer;\

                        type t_full_day_table is table of varchar2(100)
                              index by binary_integer;\

                        type t_leave_from_table is table of varchar2(100)
                              index by binary_integer;\

                        type t_leave_hours_table is table of varchar2(100)
                              index by binary_integer;\

                        type t_leave_detail_ids_table is table of NUMBER
                            index by binary_integer;\

                        leave_dates t_dates_table := :p_leave_dates;\
                        full_day t_full_day_table := :p_full_day;\
                        leave_from t_leave_from_table := :p_leave_from;\
                        leave_hours t_leave_hours_table := :p_leave_hours;\
                        leave_detail_ids t_leave_detail_ids_table := :p_leave_deails_ids;\
                        delete_leave_ids t_leave_detail_ids_table := :p_delete_leave_ids;\
                        l_leave_id number := :p_leave_id;\
                    begin
                        for i in 1..leave_dates.count
                        LOOP
                            p_leave_details(i).leave_date := leave_dates(i);\
                            p_leave_details(i).full_day := full_day(i);\
                            p_leave_details(i).leave_from_time := leave_from(i);\
                            p_leave_details(i).leave_hours := leave_hours(i);\
                            p_leave_details(i).leave_detail_id := leave_detail_ids(i);\
                        END LOOP;\

                        for i in 1..delete_leave_ids.count
                        LOOP
                            p_delete_ids(i).leave_detail_id := delete_leave_ids(i);\
                            p_delete_ids(i).leave_id := l_leave_id;\
                        END LOOP;

                        nas_leavemanagement_pkg.leave_update(
                        :p_leave_id,
                        :p_user_id,
                        :p_manager_user_id,
                        :p_leave_type_id,
                        :p_reason,
                        :p_from_date,
                        :p_upto_date,
                        :p_status,
                        p_leave_details,
                        p_delete_ids,
                        :p_action,
                        :p_comments,
                        :x_status_code
                        );
                    end; """, p_leave_id=int(data['leave_id']),
                                    p_user_id=int(data['user_id']),
                                    p_leave_type_id=data['leave_type_id'],
                                    p_manager_user_id=data['manager_user_id'],
                                    p_reason=data['reason'],
                                    p_from_date=data['from_date'],
                                    p_upto_date=data['upto_date'],
                                    p_status=data['status'],
                                    p_leave_dates=leave_dates,
                                    p_full_day=full_day,
                                    p_leave_from=leave_from_time,
                                    p_leave_hours=leave_hours,
                                    p_leave_deails_ids=leave_detail_ids,
                                    p_delete_leave_ids=delete_ids,
                                    p_action=data['action'],
                                    p_comments=data['comments'],
                                    x_status_code=status_code)

                status = status_code.getvalue()
                if status == 'SUCCESS':
                    # Send email to user and manager if dates are deleted after approval
                    if data['send_email']:
                        query = self.sql_file['get_mail_id']
                        # Get deleted user name
                        self.cursor.execute(query, p_user_id=data['user_id'])
                        user_data = Code_util.iterate_data(self.cursor)
                        deleted_user_email = user_data[0]['email_address']
                        deleted_user_name = user_data[0]['user_name']

                        # Get manager mail id
                        self.cursor.execute(query, p_user_id=data['manager_user_id'])
                        user_data = Code_util.iterate_data(self.cursor)
                        manager_email = user_data[0]['email_address']
                        manager_name = user_data[0]['user_name']

                        # Get user mail id
                        self.cursor.execute(query, p_user_id=data['applied_by'])
                        user_data = Code_util.iterate_data(self.cursor)
                        applied_user_email = user_data[0]['email_address']
                        applied_user_name = user_data[0]['user_name']

                        # Send email to user
                        subject = 'Leave #' + str(data['leave_id'])
                        subject += ' modified'
                        jsond = {
                            'manager_name': manager_name,
                            'template_id': 579089,
                            'user_name': 'your',
                            'leave_type': data['leave_type'],
                            'no_of_days': data['no_of_days'],
                            'from_date': data['from_date'],
                            'upto_date': data['upto_date'],
                            'total_leaves': data['total_leaves'],
                            'leaves_used': data['leaves_used'],
                            'leaves_remaining': data['leaves_remaining'],
                            'leave_status': 'approved' if data['status'] == 'A' else 'rejected',
                            'deleted_user_name': deleted_user_name,
                            'dates': ',' . join([deleted_dates[i] for i in range(len(deleted_dates))]),
                            'comments': '',
                            'subject': subject,
                            'recipients': [applied_user_email],
                            'created_date': data['created_date'],
                            'reason': data['reason'],
                            'recipient_name': applied_user_name
                        }
                        LeaveManagement.send_email(jsond)

                        # Send email to manager
                        jsond = {
                            'manager_name': manager_name,
                            'template_id': 579089,
                            'user_name': applied_user_name,
                            'leave_type': data['leave_type'],
                            'no_of_days': data['no_of_days'],
                            'from_date': data['from_date'],
                            'upto_date': data['upto_date'],
                            'total_leaves': data['total_leaves'],
                            'leaves_used': data['leaves_used'],
                            'leaves_remaining': data['leaves_remaining'],
                            'leave_status': 'approved' if data['status'] == 'A' else 'rejected',
                            'deleted_user_name': deleted_user_name,
                            'dates': ',' . join([deleted_dates[i] for i in range(len(deleted_dates))]),
                            'comments': '',
                            'subject': subject,
                            'recipients': [manager_email],
                            'created_date': data['created_date'],
                            'reason': data['reason'],
                            'recipient_name': manager_name
                        }
                    #    LeaveManagement.send_email(jsond)
                    result['status'] = 0
                    result['msg'] = 'Leave updated successfully'
                    result['leave_id'] = data['leave_id']
                else:
                    result['status'] = 1
                    result['msg'] = 'Failed to update Leave - ' + str(status)
                    result['leave_id'] = -1
            else:
                result = {
                    'status': 1,
                    'duplicated_dates': duplicated_dates
                }
        except Exception as e:
            logger.dthublog("""@ 400 EXCEPTION models - leavemanagement -
                leave_update """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - leavemanagement - leave_update(-)')
        return result

    def get_leaves(self, jsond):
        logger.addinfo('@ models - leavemanagement - get_leaves(+)')
        result = dict()
        try:
            self.acquire()
            query = self.sql_file['leaves_detail_overview_query']
            self.cursor.execute(query, p_user_id=jsond['user_id'],
                                p_status=jsond['status'],
                                p_manager_user_id=jsond['manager_user_id'],
                                p_leave_type_id=jsond['leave_type_id'],
                                p_org_id=jsond['org_id'])
            leaves = Code_util.iterate_data(self.cursor)
            result['status'] = 0
            result['result'] = leaves
        except Exception as e:
            logger.dthublog(""" @ 430 EXCEPTION - models - leavemanagement -
                get_leaves """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - leavemanagement - get_leaves(-)')
        return result

    def get_leaves_scheduler(self, jsond):
        logger.addinfo('@ models - leavemanagement - get_leaves_scheduler(+)')
        result = dict()
        try:
            self.acquire()
            query = self.sql_file['leave_details_schedule']
            self.cursor.execute(query, p_start_date=jsond['start_date'],
                                p_end_date=jsond['end_date'],
                                p_org_id=jsond['org_id'])
            leaves = Code_util.iterate_data(self.cursor)
            result['status'] = 0
            result['result'] = leaves
        except Exception as e:
            logger.dthublog(""" @ 430 EXCEPTION - models - leavemanagement -
                get_leaves_scheduler """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - leavemanagement - get_leaves(-)')
        return result

    def delete_leave_type(self, leave_type_id):
        logger.addinfo('@ models - leavemanagement - delete_leave_type(+)')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                nas_leavemanagement_pkg.delete_leave_type(:p_leave_type_id,
                :x_status_code
                );
            end; """, p_leave_type_id=leave_type_id,
                                x_status_code=status_code)
        except Exception as e:
            logger.dthublog(""" @ 441 EXCEPTION - models - leavemanagement -
                             delete_leave_type """ + str(e))
            raise e
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('models - leavemanagement - delete_leave_type(-)')
        return status_code.getvalue()

    def get_leaves_summary(self, jsond):
        logger.addinfo('models - leavemanagement - get_leaves_summary(+)')
        try:
            self.acquire()
            query = self.sql_file['leaves_summary_query']
            self.cursor.execute(query, p_user_id=jsond['user_id'],
                                p_manager_user_id=jsond['manager_user_id'],
                                p_status=jsond['status'],
                                p_from_date=jsond['from_date'],
                                p_to_date=jsond['to_date'],
                                p_org_id=jsond['org_id'])
            result = Code_util.iterate_data(self.cursor)
        except Exception as e:
            logger.dthublog(""" @ 521 EXCEPTION - models - leavemanagement -
                             get_leaves_summary """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('models - leavemanagement - get_leaves_summary(-)')
        return result

    def get_leave_details(self, leave_id):
        logger.addinfo('models - leavemanagement - get_leave_details(+)')
        try:
            self.acquire()
            query = self.sql_file['leave_detail_query']
            self.cursor.execute(query, p_leave_id=leave_id)
            result = Code_util.iterate_data(self.cursor)
            history = self.get_leaves_history(leave_id)
            data = {
                'result': result,
                'history': history
            }
        except Exception as e:
            logger.dthublog(""" @ 537 EXCEPTION - models - leavemanagement -
                             get_leave_details """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('models - leavemanagement - get_leave_details(-)')
        return data

    def update_leave_status(self, jsond):
        logger.addinfo('models - leavemanagement - update_leave_status(+)')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                begin
                    nas_leavemanagement_pkg.update_leave_status(
                        :p_leave_id,
                        :p_status,
                        :p_user_id,
                        :p_action,
                        :p_comments,
                        :x_status_code
                    );
                end;""", p_leave_id=jsond['leave_id'],
                                p_status=jsond['status'],
                                p_user_id=jsond['user_id'],
                                p_action=jsond['action'],
                                p_comments=jsond['comments'],
                                x_status_code=status_code)
            if status_code.getvalue() == 'SUCCESS':
                if jsond['send_email']:

                    # Send email to users having role recieve notifications
                    query = self.sql_file['get_role_users']
                    self.cursor.execute(query,
                                        p_role_name='UI-LEAVEMANAGEMENT-RECIEVE-NOTIFICATIONS')
                    users = Code_util.iterate_data(self.cursor)
                    recipients = []
                    for i in range(len(users)):
                        recipients.append(users[i]['email_address'])
                    subject = 'Leave #'
                    subject += str(jsond['leave_id']) + ' '
                    subject +=  'approved' if jsond['status'] == 'A' else 'rejected'
                    subject += " by " + jsond['manager_name']
                    data = {
                        'manager_name': jsond['manager_name'],
                        'user_name': jsond['user_name'],
                        'no_of_days': jsond['no_of_days'],
                        'from_date': jsond['from_date'],
                        'upto_date': jsond['upto_date'],
                        'leave_status': 'approved' if jsond['status'] == 'A' else 'rejected',
                        'comments': jsond['comments'],
                        'leaves_used': jsond['leaves_used'],
                        'leaves_remaining': jsond['leaves_remaining'],
                        'total_leaves': jsond['total_leaves'],
                        'reason': '',
                        'template_id': 579097,
                        'subject': subject,
                        'dates': '',
                        'leave_type': jsond['leave_type'],
                        'created_date': jsond['created_date'],
                        'deleted_user_name': '',
                        'recipients': recipients,
                        'recipient_name': ''
                    }
                   # LeaveManagement.send_email(data)

                    # Get leave applied_by user get_mail_id
                    query = self.sql_file['get_mail_id']
                    self.cursor.execute(query, p_user_id=jsond['applied_by'])
                    email = Code_util.iterate_data(self.cursor)[0]['email_address']
                    # Send email to leave applied_by user to notify status
                    data = {
                        'manager_name': jsond['manager_name'],
                        'user_name': jsond['user_name'],
                        'no_of_days': jsond['no_of_days'],
                        'from_date': jsond['from_date'],
                        'upto_date': jsond['upto_date'],
                        'leave_status': 'approved' if jsond['status'] == 'A' else 'rejected',
                        'comments': jsond['comments'],
                        'leaves_used': jsond['leaves_used'],
                        'leaves_remaining': jsond['leaves_remaining'],
                        'total_leaves': jsond['total_leaves'],
                        'reason': '',
                        'template_id': 579096,
                        'subject': subject,
                        'dates': '',
                        'leave_type': jsond['leave_type'],
                        'created_date': jsond['created_date'],
                        'deleted_user_name': '',
                        'recipients': [email],
                        'recipient_name': ''
                    }
                 #   LeaveManagement.send_email(data)

        except Exception as e:
            logger.dthublog(""" @ 562 EXCEPTION - models - leavemanagement -
                            update_leave_status """ + str(e))
            raise e
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('models - leavemanagement - update_leave_status(-)')
        return status_code.getvalue()

    def get_leaves_history(self, leave_id):
        logger.addinfo('@ models - leavemanagement - get_leaves_history(+)')
        try:
            query = self.sql_file['leaves_history']
            self.cursor.execute(query, p_leave_id=leave_id)
            result = Code_util.iterate_data(self.cursor)
        except Exception as e:
            logger.dthublog(""" @ 684 EXCEPTION - models - leavemanagement -
                             get_leaves_history """ + str(e))
            raise e
        logger.addinfo('models - leavemanagement - get_leaves_history(-)')
        return result

    def get_leave_type_withcount(self, jsond):
        logger.addinfo('models - leavemanagement - get_leave_type_withcount(+)')
        try:
            self.acquire()
            query = self.sql_file['get_leave_type_withcount']
            self.cursor.execute(query, p_user_id=jsond['user_id'],
                                p_org_id=jsond['org_id'])
            result = Code_util.iterate_data(self.cursor)
        except Exception as e:
            logger.dthublog(""" @ 691 EXCEPTION - models - leavemanagement -
                            get_leave_type_withcount """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - leavemanagement - get_leave_type_withcount(-)')
        return result

    def get_role_users(self, org_id):
        logger.addinfo('@ models - leavemanagement - get_role_users(+)')
        try:
            self.acquire()
            role_name = 'UI-LEAVE-APPROVER-' + str(org_id)
            query = self.sql_file['get_role_users']
            self.cursor.execute(query, p_role_name=role_name)
            users = Code_util.iterate_data(self.cursor)
        except Exception as e:
            logger.dthublog("""@ 996 EXCEPTION - models - leavemanagement -
                            get_role_users """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - leavemanagement - get_role_users(-)')
        return users
