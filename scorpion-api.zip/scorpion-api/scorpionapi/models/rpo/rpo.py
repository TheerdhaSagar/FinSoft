from __future__ import absolute_import

import base64
import random
import string
import cx_Oracle
import csv
import os
import jinja2
import openpyxl
from openpyxl.styles import Font

from scorpionapi.models.balances.balances import Balances
from scorpionapi.utils.constants import Status
import pandas as pd
import zipfile
from scorpionapi.utils.code_util import Code_util
from scorpionapi.utils.common_utils import CommonUtils
from scorpionapi.sql import sql_util
from scorpionapi.utils import db_util
from scorpionapi.utils.logdata import logger


class Rpo:

    def __init__(self):
        self.strings = db_util.get_strings()
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())
        self.connection = None
        self.cursor = None
        self.is_acquired = False

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()
        self.is_acquired = True

    def release(self):
        if self.cursor:
            self.cursor.close()
            self.is_acquired = False
        db_util.release_connection(self.connection)