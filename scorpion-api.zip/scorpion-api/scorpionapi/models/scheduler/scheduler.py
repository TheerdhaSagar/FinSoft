from __future__ import absolute_import

import os
import random
import string
import urllib
import ujson
from datetime import datetime
import jinja2
from scorpionapi.utils import db_util
from scorpionapi.utils import auth_util
from scorpionapi.sql import sql_util
from scorpionapi.utils.logdata import logger


class Scheduler:

    def __init__(self):
        self.strings = db_util.get_strings()
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())
        self.connection = None
        self.cursor = None
        self.is_acquired = False
        self.sender_email = self.strings['sender_email']
        self.sender_name = self.strings['sender_name']

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()
        self.is_acquired = True

    def release(self):
        if self.cursor:
            self.cursor.close()
            self.is_acquired = False
        db_util.release_connection(self.connection)

    def login(self, jsond):
        logger.addinfo('@ models - donation - login(+)')
        response = {'status': '', 'result': ''}
        try:
            self.acquire()
            missing_keys = ''
            attribute_names = ['user_name', 'password']
            for i in range(len(attribute_names)):
                if attribute_names[i] not in jsond:
                    missing_keys += attribute_names[i] + ','

            if missing_keys:
                missing_keys = missing_keys[:-1]
                response = dict()
                response['status'] = 'ERROR'
                response['msg'] = 'Missing ' + missing_keys
                response['msg'] += ' parameter(s)'
            else:
                query = self.sql_file['login']
                user_name = jsond['user_name'].lower().strip()
                password = auth_util.encrypt(jsond['password'])
                self.cursor.execute(query, p_user_name=user_name,
                                    p_password=password)
                result = Code_util.iterate_data(self.cursor)
                if len(result) == 0:
                    response['status'] = 'Invalid login credentials'
                else:
                    response['status'] = 'OK'
                    response['result'] = result
        except Exception as e:
            logger.dthublog(""" @ 244 EXCEPTION - models - donation -
                             login """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo('@ models - donation - login(-)')
        return response
