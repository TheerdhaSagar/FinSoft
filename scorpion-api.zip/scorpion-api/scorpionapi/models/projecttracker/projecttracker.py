from __future__ import absolute_import

import os.path
import cx_Oracle

from scorpionapi.utils.common_utils import CommonUtils
from scorpionapi.utils.constants import Status
from scorpionapi.sql import sql_util
from scorpionapi.utils import db_util
from scorpionapi.utils.code_util import Code_util
from scorpionapi.utils.logdata import logger
import pandas as pd
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import jinja2
import os
import csv
import random
import zipfile
import io
import re
import base64
import threading
import shutil


class ProjectTracker:

    def __init__(self):
        self.strings = db_util.get_strings()
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())
        self.connection = None
        self.cursor = None
        self.is_acquired = False

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()
        self.is_acquired = True

    def release(self):
        if self.cursor:
            self.cursor.close()
            self.is_acquired = False
        db_util.release_connection(self.connection)

    def get_project_summary(self):
        logger.addinfo('@ models - ProjectTracker - get_project_summary(+)')
        result = dict()
        try:
            self.acquire()
            self.cursor.execute(self.sql_file['get_project_tracker_summary'])
            summary = Code_util.iterate_data(self.cursor)
            result['status'] = 0
            result['result'] = summary
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - ProjectTracker -
                get_project_summary """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - ProjectTracker - get_project_summary(-)')
        return result