from __future__ import absolute_import

import base64
import random
import string
import cx_Oracle
import csv
import os
import jinja2
import threading
import xlrd
import zipfile
import pandas as pd
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from scorpionapi.utils.constants import Status

from scorpionapi.utils.code_util import Code_util
from scorpionapi.utils.common_utils import CommonUtils
from scorpionapi.sql import sql_util
from scorpionapi.utils import db_util
from scorpionapi.utils.logdata import logger


class ResumeParser:

    def __init__(self):
        self.strings = db_util.get_strings()
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())
        self.connection = None
        self.cursor = None
        self.is_acquired = False

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()
        self.is_acquired = True

    def release(self):
        if self.cursor:
            self.cursor.close()
            self.is_acquired = False
        db_util.release_connection(self.connection)

    def async_generate_asp_files(self, data):
        # Check if client id is already in processing
        """
        Generate balance audit asynchronously on a separate thread
        """
        # logger doesn't work when running on thread as it use
        # flask context to get current user details, so when
        # running on thread set logging to False
        thread = threading.Thread(target=self.manage_resumeparser, args=(data,))
        thread.deamon = True
        thread.start()
        return {
            'status': 0,
            'msg': self.sql_file['dm_async_status']
        }

    @staticmethod
    def id_generator():
        size = 9
        chars = string.ascii_uppercase + string.digits
        return ''.join(random.choice(chars) for _ in range(size))

    def manage_resumeparser(self, data):
        try:
            result = {}
            self.acquire()
            # report log creation
            user_id = data['user_id']
            report_creation_log_s = self.sql_file['candidate_creation_log_s']
            report_sq = self.cursor.execute(report_creation_log_s).fetchone()
            resume_summary_creation_log = self.sql_file['resume_summary_creation_log']
            self.cursor.execute(resume_summary_creation_log, p_resume_parser_id=report_sq[0],
                                p_client_identifier=data['client_identifier'], p_user_id=data['user_id'],
                                p_status='P', p_candidate_status=data['candidate_status'],
                                p_import_source=data['import_source'], p_req_number=data['req_number'])
            self.connection.commit()
            # Import file upload
            decoded = base64.b64decode(data['import_base64'])

            temp_file_name = '/tmp/' + self.id_generator() + '.csv'
            text_file = open(temp_file_name, 'wb')
            text_file.write(decoded)
            text_file.close()
            lines = []
            batch_size = 10000
            with open(temp_file_name, "r") as csv_file:
                csv_reader = csv.reader(csv_file, delimiter=',')
                next(csv_reader)
                for line in csv_reader:
                    line_list = [i.strip('"') for i in line]
                    line_list.append(report_sq[0])
                    lines.append(line_list)
                    if len(lines) % batch_size == 0:
                        self.cursor.executemany(self.sql_file['insert_statement_import_mf'], lines)
                        lines = []
                self.cursor.executemany(self.sql_file['insert_statement_import_mf'], lines)
            os.remove(temp_file_name)
            # ADPR file upload
            decoded_adpr = base64.b64decode(data['adpr_base64'])
            # Create file in tmp folder
            temp_file_name_adpr = '/tmp/' + self.id_generator() + '.xls'

            # Open file in write mode and write decoded excel content
            text_file = open(temp_file_name_adpr, 'wb')
            text_file.write(decoded_adpr)
            text_file.close()
            batch_size = 10000
            b = xlrd.open_workbook(temp_file_name_adpr)
            data = b.sheet_by_index(0)
            column_names = []
            for i in range(data.ncols):
                column_names.append(data.cell_value(0, i))
            rows = []
            for i in range(1, data.nrows):
                rows_data = data.row_values(i)
                row_data = []
                for j in range(data.ncols):
                    row_data.append(str(rows_data[j]))
                row_data.append(report_sq[0])
                rows.append(row_data)
                if len(lines) % batch_size == 0:
                    self.cursor.executemany(self.sql_file['insert_statement_adpr_mf'], rows)
                    rows = []
            self.cursor.executemany(self.sql_file['insert_statement_adpr_mf'], rows)
            os.remove(temp_file_name_adpr)
            self.connection.commit()
            # generate comparison report between ADPR & Import file
            insert_report = self.sql_file['create_report']
            self.cursor.execute(insert_report, p_report_id=report_sq[0])
            self.cursor.execute(self.sql_file['update_status_dm_report_log'], p_report_id=report_sq[0])
            self.connection.commit()
            result['status'] = 0
            result['msg'] = 'Report creation is Successful'
            result['report_id'] = report_sq[0]
            # sending email to user
            mail_status = self.send_mail(result, user_id)
        except Exception as error:
            # self.cursor.execute(self.sql_file['update_status_dm_report_log_failed'], p_report_id=report_sq[0])
            raise error
        finally:
            if self.is_acquired:
                self.release()
        return result

    def get_resume_parser_summary(self, user_id):
        logger.addinfo('@ models - resumeparser - get_resume_parser_summary(+)')
        result = dict()
        try:
            self.acquire()
            self.cursor.execute(self.sql_file['resume_parser_summary'], p_user_id=user_id)
            resume_parser_summary = Code_util.iterate_data(self.cursor)
            result['status'] = 0
            result['result'] = resume_parser_summary
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - resumeparser -
                get_resume_parser_summary """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - resumeparser - get_resume_parser_summary(-)')
        return result

