from __future__ import absolute_import

import os.path
import cx_Oracle

from oauthlib.oauth2 import BackendApplicationClient
from requests_oauthlib import OAuth2Session
from requests.auth import HTTPBasicAuth
from oauthlib.oauth2 import LegacyApplicationClient
from scorpionapi.utils.common_utils import CommonUtils
from scorpionapi.utils.constants import Status
from scorpionapi.sql import sql_util
from scorpionapi.utils import db_util
from scorpionapi.utils.code_util import Code_util
from scorpionapi.utils.logdata import logger
import requests
import json
import pandas as pd
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import jinja2
import os
import csv
import random
import zipfile
import io
import re
import base64
import threading
import shutil


class Innovations:

    def __init__(self):
        self.strings = db_util.get_strings()
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())
        self.connection = None
        self.cursor = None
        self.is_acquired = False

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()
        self.is_acquired = True

    def release(self):
        if self.cursor:
            self.cursor.close()
            self.is_acquired = False
        db_util.release_connection(self.connection)

    def sync_adpworks_innovation_tracker(self):
        logger.addinfo('@ models - balances - get_balances_summary(+)')
        result = dict()
        try:
            token_url = 'https://adp-api-stg.unily.com/connect/token'
            adpworks_api_url = 'https://adp-api-stg.unily.com/api/v2/workfront/site-ideas?siteId=' \
                               '438571&pageSize=10&page=1'
            # client (application) credentials on ADP works
            client_id = '8e78545b-c356-46b4-b66c-ef209bab2013'
            client_secret = 'OzU2yddsyYUvoMQOUltdYw'
            headers = {
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36'}
            proxies = {
                'https': self.sql_file['proxy1_settings']
            }
            # auth = HTTPBasicAuth(client_id, client_secret)
            # client = BackendApplicationClient(client_id=client_id)
            # oauth = OAuth2Session(client=client, scope=['gateway.contentmanagement.read', 'gateway.graphql'])
            # print(oauth)
            # tokens = oauth.fetch_token(token_url=token_url, verify=False, auth=auth)
            data = {'grant_type': 'client_credentials'}
            access_token_response = requests.post(url=token_url, data=data, verify=False, proxies=proxies,
                                                  auth=(client_id, client_secret))
            print(access_token_response)
            tokens = json.loads(access_token_response.text)
            print(tokens)
            api_call_headers = {'Authorization': 'Bearer ' + tokens['access_token']}
            api_call_response = requests.get(adpworks_api_url, headers=api_call_headers, verify=False, proxies=proxies)
            print(api_call_response.text)
            result['status'] = 0
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - balances -
                get_balances_summary """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - balances - get_balances_summary(-)')
        return result
