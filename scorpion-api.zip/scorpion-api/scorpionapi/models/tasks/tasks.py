from __future__ import absolute_import

import cx_Oracle

from scorpionapi.sql import sql_util
from scorpionapi.utils import db_util
from scorpionapi.utils.logdata import logger
from scorpionapi.utils.code_util import Code_util


class Tasks:

    def __init__(self):
        self.strings = db_util.get_strings()
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())
        self.connection = None
        self.cursor = None
        self.is_acquired = False

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()
        self.is_acquired = True

    def release(self):
        if self.cursor:
            self.cursor.close()
            self.is_acquired = False
        db_util.release_connection(self.connection)

    def add_header_tasks(self, data):
        logger.addinfo('@ models - tasks - add_header_tasks(+)')
        result = dict()
        task_lines = data['budget']
        local_acquire = False
        try:
            if not self.is_acquired:
                self.acquire()
                local_acquire = True
            task_header_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                BENEFITS_ALLOCATIONS_PKG.add_task_header(
                    :p_task_header_id,   
                    :p_task_header_name, 
                    :p_task_description,                
                    :p_team_id,              
                    :p_user_id,
                    :p_tot_time,          
                    :p_status_code
                );
            end; """, p_task_header_id=task_header_id,
                                p_task_header_name=data['task_header'],
                                p_task_description=data['header_description'],
                                p_team_id=data['team_id'],
                                p_user_id=data['user_id'],
                                p_tot_time=data['total_time'],
                                p_status_code=status_code)

            status = status_code.getvalue()
            attachment_status = 'success'
            if status == 'SUCCESS' and len(data['attachments']) > 0:
                attachment_status = Tasks.save_attachments(data['attachments'], task_header_id)
            status_code_lines = ''
            if attachment_status == 'success':
                for task in task_lines:
                    task_line_id = self.cursor.var(cx_Oracle.NUMBER)
                    status_code_lines = self.cursor.var(cx_Oracle.STRING)
                    self.cursor.execute("""
                                begin
                                    BENEFITS_ALLOCATIONS_PKG.add_lines_tasks(
                                        :p_task_line_id,      
                                        :p_task_header_id,     
                                        :p_task_name,    
                                        :p_task_description,   
                                        :p_task_weight,        
                                        :p_task_hours,
                                        :p_task_minutes,                                               
                                        :p_status_code 
                                    );
                                end; """, p_task_line_id=task_line_id,
                                        p_task_header_id=task_header_id,
                                        p_task_name=task['subtask'],
                                        p_task_description=task['description'],
                                        p_task_weight=task['task_weight'],
                                        p_task_hours=task['task_hours'],
                                        p_task_minutes=task['task_minutes'],
                                        p_status_code=status_code_lines)
                    status_code_lines = status_code.getvalue()
                if status_code_lines == 'SUCCESS':
                    result['status'] = 0
                    result['msg'] = 'Task added successfully'
                    result['task_header_id'] = task_header_id.getvalue()
                else:
                    result['status'] = 'ERROR'
                    result['msg'] = 'Failed to add Task - ' + str(status_code_lines)
                    result['task_header_id'] = -1
            else:
                result['status'] = 1
                result['msg'] = 'Failed to add Task - ' + str(status)
                result['task_header_id'] = -1
        except Exception as e:
            logger.dthublog("""@ 252 EXCEPTION models - tasks -
                add_header_tasks """ + str(e))
            raise e
        finally:
            if self.is_acquired and local_acquire:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - tasks - add_header_tasks(-)')
        return result

    def update_header_tasks(self, data):
        logger.addinfo('@ models - tasks - update_header_tasks(+)')
        result = dict()
        local_acquire = False
        try:
            if not self.is_acquired:
                self.acquire()
                local_acquire = True
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                BENEFITS_ALLOCATIONS_PKG.update_task_header(
                    :p_task_header_id,   
                    :p_task_header_name, 
                    :p_task_description,                  
                    :p_team_id,          
                    :p_user_id,       
                    :p_tot_time,          
                    :p_status_code
                );
            end; """, p_task_header_id=data['task_header_id'],
                                p_task_header_name=data['task_header'],
                                p_task_description=data['header_description'],
                                p_team_id=data['team_id'],
                                p_user_id=data['user_id'],
                                p_tot_time=data['total_time'],
                                p_status_code=status_code)
            status = status_code.getvalue()
            if status == 'SUCCESS':
                # Add attachments
                if len(data['attachments']) > 0:
                    Tasks.save_attachments(data['attachments'],
                                           data['task_header_id'])

                # To delete attachments
                if len(data['deleted_attachments']) > 0:
                    Tasks.delete_attachment(data['deleted_attachments'])
                if len(data['deleted_lines']) > 0:
                    for line in data['deleted_lines']:
                        self.delete_lines_tasks(line['line_id'])
                if len(data['budget']) > 0:
                    for line in data['budget']:
                        if hasattr(line, 'line_id'):
                            self.update_lines_tasks(line)
                        else:
                            self.add_lines_tasks(line, data['task_header_id'])
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'your task(s) updated successfully'
                result['task_header_id'] = data['task_header_id']
            else:
                result['status'] = 1
                result['msg'] = 'Failed to update task(s) - ' + str(status)
                result['task_header_id'] = -1
        except Exception as e:
            logger.dthublog("""@ 252 EXCEPTION models - tasks -
                update_header_tasks """ + str(e))
            raise e
        finally:
            if self.is_acquired and local_acquire:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - tasks - update_header_tasks(-)')
        return result

    def get_header_tasks(self, team_id):
        logger.addinfo('@ models - tasks - get_header_tasks(+)')
        result = dict()
        try:
            self.acquire()
            query = self.sql_file['tasks_header_query']
            self.cursor.execute(query, p_team_id=team_id)
            tasks_header = Code_util.iterate_data(self.cursor)
            result['status'] = 0
            result['result'] = tasks_header
        except Exception as e:
            logger.dthublog(""" @ 398 EXCEPTION - models - tasks -
                get_header_tasks """ + str(e))
            raise e
        logger.addinfo('@ models - tasks - get_header_tasks(-)')
        return result

    def delete_header_tasks(self, task_header_id):
        logger.addinfo('@ models - tasks - delete_header_tasks(+)')
        result = dict()
        local_acquire = False
        try:
            if not self.is_acquired:
                self.acquire()
                local_acquire = True
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                BENEFITS_ALLOCATIONS_PKG.delete_header_tasks(
                    :p_task_header_id,
                    :p_status_code
                );
            end; """, p_task_header_id=task_header_id,
                                p_status_code=status_code)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'task deleted successfully'
                result['task_header_id'] = task_header_id
            else:
                result['status'] = 1
                result['msg'] = 'Failed to delete task - ' + str(status)
                result['task_header_id'] = -1
        except Exception as e:
            logger.dthublog("""@ 252 EXCEPTION models - tasks -
                delete_header_tasks """ + str(e))
            raise e
        finally:
            if self.is_acquired and local_acquire:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - tasks - delete_header_tasks(-)')
        return result

    def add_lines_tasks(self, data, task_header_id):
        logger.addinfo('@ models - tasks - add_lines_tasks(+)')
        result = dict()
        local_acquire = False
        try:
            if not self.is_acquired:
                self.acquire()
                local_acquire = True
            task_line_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                        begin
                            BENEFITS_ALLOCATIONS_PKG.add_lines_tasks(
                                :p_task_line_id,      
                                :p_task_header_id,     
                                :p_task_name,    
                                :p_task_description,   
                                :p_task_weight,        
                                :p_task_hours,
                                :p_task_minutes,                                               
                                :p_status_code 
                            );
                        end; """, p_task_line_id=task_line_id,
                                p_task_header_id=task_header_id,
                                p_task_name=data['subtask'],
                                p_task_description=data['description'],
                                p_task_weight=data['task_weight'],
                                p_task_hours=data['task_hours'],
                                p_task_minutes=data['task_minutes'],
                                p_status_code=status_code)
            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'task lines added successfully'
                result['task_line_id'] = task_line_id.getvalue()
            else:
                result['status'] = 1
                result['msg'] = 'Failed to add task lines - ' + str(status)
                result['task_line_id'] = -1
        except Exception as e:
            logger.dthublog("""@ 252 EXCEPTION models - tasks -
                add_lines_tasks """ + str(e))
            raise e
        finally:
            if self.is_acquired and local_acquire:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - tasks - add_lines_tasks(-)')
        return result
    
    def attachment_data(self, attachment_id):
        logger.addinfo("@ models - tasks - attachment_data(+)")
        try:
            self.acquire()
            query = self.sql_file['task_attachment_data_query']
            self.cursor.execute(query,
                                p_attachment_id=attachment_id)
            field_data = []
            field_names = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                data = {}
                for index, field in enumerate(field_names):
                    if field == 'file_content':
                        encoded_string = ''
                        if row[index]:
                            encoded_string = row[index].read()
                        data[field] = encoded_string
                    else:
                        data[field] = row[index]
                field_data.append(data)
        except Exception as e:
            logger.dthublog("""@ EXCEPTION - models -
            tasks - attachment_data""" + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo("@ models - tasks - attachment_data(-)")
        return field_data

    def update_lines_tasks(self, data):
        logger.addinfo('@ models - tasks - update_lines_tasks(+)')
        result = dict()
        local_acquire = False
        try:
            if not self.is_acquired:
                self.acquire()
                local_acquire = True
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                BENEFITS_ALLOCATIONS_PKG.update_lines_tasks(
                    :p_task_line_id,                          
                    :p_task_name,    
                    :p_task_description,   
                    :p_task_weight,        
                    :p_task_hours,       
                    :p_task_minutes,
                    :p_status_code 
                );
            end; """, p_task_line_id=data['line_id'],
                                p_task_name=data['subtask'],
                                p_task_description=data['description'],
                                p_task_weight=data['task_weight'],
                                p_task_hours=data['task_hours'],
                                p_task_minutes=data['task_minutes'],
                                p_status_code=status_code)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'tasks lines updated successfully'
                result['task_line_id'] = data['task_line_id']
            else:
                result['status'] = 1
                result['msg'] = 'Failed to update tasks lines - ' + str(status)
                result['task_header_id'] = -1
        except Exception as e:
            logger.dthublog("""@ 252 EXCEPTION models - tasks -
                update_lines_tasks """ + str(e))
            raise e
        finally:
            if self.is_acquired and local_acquire:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - tasks - update_lines_tasks(-)')
        return result

    def get_lines_tasks(self, task_header_id):
        logger.addinfo('@ models - tasks - get_lines_tasks(+)')
        result = dict()
        try:
            self.acquire()
            query = self.sql_file['tasks_lines_query']
            self.cursor.execute(query, p_task_header_id=task_header_id)
            tasks_lines = Code_util.iterate_data(self.cursor)
            result['status'] = 0
            result['result'] = tasks_lines
        except Exception as e:
            logger.dthublog(""" @ 398 EXCEPTION - models - tasks -
                get_lines_tasks """ + str(e))
            raise e
        logger.addinfo('@ models - tasks - get_lines_tasks(-)')
        return result

    def delete_lines_tasks(self, task_line_id):
        logger.addinfo('@ models - tasks - delete_lines_tasks(+)')
        result = dict()
        local_acquire = False
        try:
            if not self.is_acquired:
                self.acquire()
                local_acquire = True
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                BENEFITS_ALLOCATIONS_PKG.delete_lines_tasks(
                    :p_task_line_id,
                    :p_status_code
                );
            end; """, p_task_line_id=task_line_id,
                                p_status_code=status_code)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'task line deleted successfully'
                result['task_line_id'] = task_line_id
            else:
                result['status'] = 1
                result['msg'] = 'Failed to delete tasks lines - ' + str(status)
                result['task_line_id'] = -1
        except Exception as e:
            logger.dthublog("""@ 252 EXCEPTION models - tasks -
                delete_lines_tasks """ + str(e))
            raise e
        finally:
            if self.is_acquired and local_acquire:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - tasks - delete_lines_tasks(-)')
        return result

    @staticmethod
    def save_attachments(attachments, task_header_id):
        logger.addinfo('@ models - tasks - save_attachments(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            attachment_status = 'success'
            cur.setinputsizes(p_blob=cx_Oracle.BLOB)
            status_code = cur.var(cx_Oracle.STRING)
            for a in attachments:
                cur.execute(""" declare
                 begin
                 :retval := nas_attachments.add_attachment(
                 :pref,
                 :ptitle,
                 :pfilename,
                 :pdesc,
                 :p_blob,
                 :pcontent_type,
                 :pentity,
                 :pcategory);
                 end;""", pref=task_header_id,
                            ptitle=a['title'],
                            pfilename=a['file_name'],
                            pdesc=a['description'],
                            p_blob=a['file_blob'],
                            pcontent_type=a['content_type'],
                            pentity=a['entity_name'],
                            pcategory=a['category_name'],
                            retval=status_code)
                if status_code.getvalue() != 'S':
                    attachment_status = 'error'
        except Exception as error:
            logger.dthublog("""@ 297 EXCEPTION - models - tasks -
                  save_attachments """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - tasks - save_attachments(-)')
        return attachment_status

    @staticmethod
    def get_attachments(task_header_id):
        logger.addinfo('@ models - tasks - get_attachments(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['get_objective_attachments']
            cur.execute(query, p_attachseq=task_header_id)
            attachments = []
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                attachment = Tasks()
                for index, field in enumerate(field_names):
                    if field == 'file_data':
                        setattr(attachment, field, row[index].read())
                    else:
                        setattr(attachment, field, row[index])
                attachments.append(attachment)
        except Exception as error:
            logger.dthublog("""@ 297 EXCEPTION - models - tasks -
                  get_attachments """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - tasks - get_attachments(-)')
        return attachments

    @staticmethod
    def delete_attachment(attachments):
        logger.addinfo('@ models - tasks - delete_attachment(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            attachment_status = 'success'
            status_code = cur.var(cx_Oracle.STRING)
            for a in attachments:
                cur.execute(""" declare
                     begin
                         :retval := nas_attachments.delete_attachment(
                         :p_file_id);
                         end;""", p_file_id=a['file_id'],
                            retval=status_code)
                if status_code.getvalue() != 'S':
                    attachment_status = 'error'
        except Exception as error:
            logger.dthublog("""@ 297 EXCEPTION - models - tasks -
                  delete_attachment """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - tasks - delete_attachment(-)')
        return attachment_status
