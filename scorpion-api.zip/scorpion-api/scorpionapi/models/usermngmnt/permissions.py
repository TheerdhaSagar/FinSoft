from __future__ import absolute_import
from scorpionapi.utils import db_util
from scorpionapi.utils.logdata import logger
from scorpionapi.models.usermngmnt.method_util import Methodutil


class Permissions:

    def __init__(self, **kwargs):
        for name, value in kwargs.items():
            setattr(self, name, value)

    @staticmethod
    def get_permissions(p_permid):
        logger.addinfo('@ models - permissions - get_permissions(+)')
        permission_data = []
        try:
            sql_file = db_util.getusermngSql()
            qry = sql_file['permission_get']
            if p_permid:
                qry = sql_file['permissionby_id'
                               ] + ' where permission_id = ' + str(p_permid)
            permission_data = Methodutil.get_qry(qry)
        except Exception as error:
            logger.dthublog("""@ 25 EXCEPTION - models - permissions -
                 get_permissions """ + str(error))
            raise error
        logger.addinfo('@ models - permissions - get_permissions(-)')
        return permission_data

    @staticmethod
    def get_validation(p_val):
        logger.addinfo('@ models - permissions - get_validation(+)')
        permission_data = dict()
        try:
            sql_file = db_util.getusermngSql()
            qry = sql_file['perm_validation']
            permission_data = Methodutil.get_validation(qry, p_val)
        except Exception as error:
            logger.dthublog("""@ 85 EXCEPTION - models - permissions -
                 get_validation """ + str(error))
            raise error
        logger.addinfo('@ models - permissions - get_validation(-)')
        return permission_data

    @staticmethod
    def get_permissiontypes():
        logger.addinfo('@ models - permissions - get_permissiontypes(+)')
        permission_data = []
        try:
            sql_file = db_util.getusermngSql()
            qry = sql_file['permission_type']
            permission_data = Methodutil.get_qry(qry)
        except Exception as error:
            logger.findaylog("""@ 40 EXCEPTION - models - permissions -
                 get_permissiontypes """ + str(error))
            raise error
        logger.addinfo('@ models - permissions - get_permissiontypes(-)')
        return permission_data

    @staticmethod
    def save(perm_list):
        logger.addinfo('@ models - permissions - save(+)')
        con = None
        cur = None
        returnmsg = ""
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getusermngSql()
            query = sql_file['permission_seq']
            data = cur.execute(query).fetchone()
            returnmsg = Methodutil.save(perm_list, "PERMISSIONS",
                                        "PERMISSION_ID", str(data[0]))
        except Exception as error:
            logger.dthublog("""@ 106 EXCEPTION - models - permissions -
                 save """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - permissions - save(-)')
        return returnmsg

    @staticmethod
    def update(permission_json, perm_id):
        logger.addinfo('@ models - permissions - update(+)')
        returnmsg = ""
        try:
            condition = " where PERMISSION_ID="+str(perm_id)
            returnmsg = Methodutil.update("PERMISSIONS",
                                          permission_json, condition)
        except Exception as error:
            logger.dthublog("""@ 124 EXCEPTION - models - permissions -
                 update """ + str(error))
            raise error
        logger.addinfo('@ models - permissions - update(-)')
        return returnmsg
