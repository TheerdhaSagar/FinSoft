from __future__ import absolute_import

import cx_Oracle

from scorpionapi.sql import sql_util
from scorpionapi.utils import db_util
from scorpionapi.utils.logdata import logger
from scorpionapi.utils.code_util import Code_util


class Teams:

    def __init__(self):
        self.strings = db_util.get_strings()
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())
        self.connection = None
        self.cursor = None
        self.is_acquired = False

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()
        self.is_acquired = True

    def release(self):
        if self.cursor:
            self.cursor.close()
            self.is_acquired = False
        db_util.release_connection(self.connection)

    def add_team(self, data):
        logger.addinfo('@ models - teams - add_team(+)')
        result = dict()
        local_acquire = False
        try:
            if not self.is_acquired:
                self.acquire()
                local_acquire = True
            team_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                BENEFITS_ALLOCATIONS_PKG.add_team(
                    :p_team_id,
                    :p_team_name,
                    :p_reporting_manager,
                    :p_emailer_list,        
                    :p_user_id,
                    :p_status_code
                );
            end; """, p_team_id=team_id,
                                p_team_name=data['team_name'],
                                p_reporting_manager=data['reporting_manager'],
                                p_emailer_list=data['emailer_list'],
                                p_user_id=data['user_id'],
                                p_status_code=status_code)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 'OK'
                result['msg'] = 'team added successfully'
                result['team_id'] = team_id.getvalue()
            else:
                result['status'] = 'ERROR'
                result['msg'] = 'Failed to add team - ' + str(status)
                result['team_id'] = -1
        except Exception as e:
            logger.dthublog("""@ 252 EXCEPTION models - teams -
                add_team """ + str(e))
            raise e
        finally:
            if self.is_acquired and local_acquire:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - teams - add_team(-)')
        return result

    def update_team(self, data):
        logger.addinfo('@ models - teams - update_team(+)')
        result = dict()
        local_acquire = False
        try:
            if not self.is_acquired:
                self.acquire()
                local_acquire = True
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                BENEFITS_ALLOCATIONS_PKG.update_team(
                    :p_team_id,
                    :p_team_name,
                    :p_reporting_manager,
                    :p_emailer_list,      
                    :p_user_id,
                    :p_status_code
                );
            end; """, p_team_id=data['team_id'],
                                p_team_name=data['team_name'],
                                p_reporting_manager=data['reporting_manager'],
                                p_emailer_list=data['emailer_list'],
                                p_user_id=data['user_id'],
                                p_status_code=status_code)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 'OK'
                result['msg'] = 'team updated successfully'
                result['team_id'] = data['team_id']
            else:
                result['status'] = 'ERROR'
                result['msg'] = 'Failed to update team - ' + str(status)
                result['team_id'] = -1
        except Exception as e:
            logger.dthublog("""@ 252 EXCEPTION models - teams -
                update_team """ + str(e))
            raise e
        finally:
            if self.is_acquired and local_acquire:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - teams - update_team(-)')
        return result

    def get_teams(self):
        logger.addinfo('@ models - teams - get_holidays(+)')
        result = dict()
        try:
            self.acquire()
            query = self.sql_file['teams_query']
            self.cursor.execute(query)
            teams = Code_util.iterate_data(self.cursor)
            result['status'] = 'OK'
            result['result'] = teams
        except Exception as e:
            logger.dthublog(""" @ 398 EXCEPTION - models - teams -
                get_holidays """ + str(e))
            raise e
        logger.addinfo('@ models - teams - get_holidays(-)')
        return result
