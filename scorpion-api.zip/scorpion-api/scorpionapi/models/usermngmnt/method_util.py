from __future__ import absolute_import
from scorpionapi.utils import db_util
from scorpionapi.utils.logdata import logger


class Methodutil:

    def __init__(self, **kwargs):
        for name, value in kwargs.items():
            setattr(self, name, value)

    @staticmethod
    def get_qry(qry):
        logger.addinfo('@ models - methodutil - get_qry(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            cur.execute(qry)
        except Exception as error:
            logger.dthublog("""@ 23 EXCEPTION - models - methodutil -
                 get_qry """ + str(error))
            raise error
        else:
            field_names = [a[0].lower() for a in cur.description]
            result = []
            for row in cur:
                method_util = Methodutil()
                for index, fn in enumerate(field_names):
                    setattr(method_util, fn, row[index])
                result.append(method_util)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - methodutil - get_qry(-)')
        return result

    @staticmethod
    def get_validation(qry, value):
        logger.addinfo('@ models - methodutil - get_validation(+)')
        con = None
        cur = None
        mydata = []
        result = {}
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            cur.execute(qry, p_parm=value)
            mydata = cur.fetchall()
        except Exception as error:
            logger.dthublog("""@ 54 EXCEPTION - models - methodutil -
                 get_validation """ + str(error))
            raise error
        else:
            if mydata:
                result['msg'] = "already exsists !!"
                result['status'] = 1
            else:
                result['msg'] = "Success !!"
                result['status'] = 0
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - methodutil - get_validation(-)')
        return result

    @staticmethod
    def save(values, table_name, seq_field, seq_val):
        logger.addinfo('@ models - methodutil - save(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            row_data = []
            sql_data = 'insert into ' + str(table_name) + """
             (""" + str(seq_field) + ","
            my_data = []
            for key, value in values.__dict__.items():
                my_data.append(value)
                my_new_tuple = tuple(my_data)
            row_data.append(my_new_tuple)
            for key, value in values.__dict__.items():
                sql_data += str(key)
                sql_data += ','
            sql_data = sql_data[:-1]
            sql_data += ") VALUES ( " + str(seq_val) + ","
            sql_args = ""
            for idx, key in enumerate(values.__dict__.items()):
                sql_args += ":"+str(idx) + ","
            sql_args = sql_args[:-1]
            sql_data += sql_args + ")"
            cur.executemany(sql_data, row_data)
        except Exception as error:
            logger.dthublog("""@ 98 EXCEPTION - models - methodutil -
                 save """ + str(error))
            raise error
        finally:
            con.commit()
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - methodutil - save(-)')
        return "success"

    @staticmethod
    def update(table_name, val_list, condition):
        logger.addinfo('@ models - methodutil - update(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_data = 'update '+str(table_name)+' set '
            for key, value in val_list.__dict__.items():
                sql_data += str(key)+'='+"'"
                if value is not None:
                    sql_data += str(value)
                sql_data += "'"+','
            sql_data = sql_data[:-1]
            sql_data += condition
            cur.execute(sql_data)
        except Exception as error:
            logger.dthublog("""@ 126 EXCEPTION - models - methodutil -
                 update """ + str(error))
            raise error
        finally:
            con.commit()
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - methodutil - update(-)')
        return "success"

    @staticmethod
    def get_data_by_param(qry, value):
        logger.addinfo('@ models - methodutil - get_data_by_param(+)')
        con = None
        cur = None
        result = {}
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            cur.execute("ALTER SESSION SET NLS_LANGUAGE=American")
            cur.execute(qry, p_parm=value)
        except Exception as error:
            logger.dthublog("""@ 148 EXCEPTION - models - methodutil -
                 get_data_by_param """ + str(error))
            raise error
        else:
            data = []
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                item = Methodutil()
                for index, fn in enumerate(field_names):
                    setattr(item, fn, row[index])
                data.append(item)
            result = data
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - methodutil - get_data_by_param(-)')
        return result
