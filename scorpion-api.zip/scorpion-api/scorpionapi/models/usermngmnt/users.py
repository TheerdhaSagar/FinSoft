from __future__ import absolute_import
from scorpionapi.utils import db_util
from scorpionapi.utils import auth_util
import cx_Oracle
import jinja2
import ujson
from flask import Response
from scorpionapi.utils.logdata import logger
from scorpionapi.sql import sql_util
from scorpionapi.utils.code_util import Code_util
import random
import os
import string
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import smtplib
from scorpionapi.models.usermngmnt.method_util import Methodutil


class Users:

    def __init__(self, **kwargs):
        for name, value in kwargs.items():
            setattr(self, name, value)

    @staticmethod
    def get_users():
        logger.addinfo('@ models - users - get_users(+)')
        return_data = []
        try:
            file_data = db_util.getusermngSql()
            query = file_data['users_query']
            return_data = Methodutil.get_qry(query)
        except Exception as error:
            logger.dthublog("""@ 29 EXCEPTION - models - users -
                 get_users """ + str(error))
            raise error
        logger.addinfo('@ models - users - get_users(-)')
        return return_data

    @staticmethod
    def get_team_users(team_id):
        logger.addinfo('@ models - users - get_team_users(+)')
        result = dict()
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            file_data = db_util.getusermngSql()
            query = file_data['team_users_query']
            cursor.execute(query, p_org_id=team_id)
            users = Code_util.iterate_data(cursor)
            result['status'] = 0
            result['result'] = users
        except Exception as e:
            logger.dthublog(""" @ 143 EXCEPTION - models - users -
                get_team_users """ + str(e))
            raise e
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - users - get_team_users(-)')
        return result

    @staticmethod
    def user_id():
        logger.addinfo("@ models - users - user_id")
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            sql_file = db_util.getusermngSql()
            query = sql_file['user_id_sequence']
            cursor = connection.cursor()
            data = cursor.execute(query).fetchone()
            user_id = str(data[0])
        except Exception as error:
            logger.dthublog("""@ 48 EXCEPTION - models - users -
                 user_id """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo("@ models - users - user_id(-)")
        return user_id

    # insert roles of user
    @staticmethod
    def save_roles(p_roles_list, user_id):
        logger.addinfo('@ models - users - save_roles(+)')
        connection = None
        cursor = None
        fieldname_strng = ""
        paramater_strng = ""
        returnval = dict()
        row_list = []
        for role in p_roles_list:
            role['USER_ID'] = user_id
            values = ""
            values = tuple(str(val) for key, val in role.items())
            row_list.append(values)
        if p_roles_list:
            dict_val = p_roles_list[0]
            fieldname_strng += "("
            indx_value = 1
            paramater_strng += "("
            for key, value in dict_val.items():
                fieldname_strng += str(key)+','
                paramater_strng += ":"+str(indx_value)+','
                indx_value = indx_value+1
            fieldname_strng = fieldname_strng[:-1]
            paramater_strng = paramater_strng[:-1]
            fieldname_strng += ")"
            paramater_strng += ")"
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            cursor.prepare("""insert into
            USER_ROLES """ + fieldname_strng+"""
            values""" + paramater_strng)
            cursor.executemany(None, row_list)
        except Exception as error:
            logger.dthublog("""@ 94 EXCEPTION - models - users -
                 save_roles """ + str(error))
            returnval['msg'] = "Fails"
            returnval['user_id'] = ""
            return returnval
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - users - save_roles(-)')

    @staticmethod
    def get_user_data(user_id):
        logger.addinfo('@ models - users - get_user_data(+)')
        final = dict()
        user_data = {}
        try:
            sql_file = db_util.getusermngSql()
            user_details_qry = sql_file['user_details_query']
            user_data = Methodutil.get_data_by_param(user_details_qry, user_id)
        except Exception as error:
            logger.dthublog("""@ 197 EXCEPTION - models - users -
                 get_user_data """ + str(error))
            raise error
        user_roles_data = dict()
        try:
            sql_file = db_util.getusermngSql()
            user_roles_qry = sql_file['user_roles_query']
            user_roles_data = Methodutil.get_data_by_param(user_roles_qry,
                                                           user_id)
        except Exception as error:
            logger.dthublog("""@ 207 EXCEPTION - models - users -
                 get_user_data """ + str(error))
            raise error
        logger.addinfo('@ models - users - get_user_data(-)')
        final['user_details'] = user_data
        final['roles'] = user_roles_data
        return final

    @staticmethod
    def get_user_details(user_id):
        logger.addinfo('@ models - users - get_user_details(+)')
        user_data = dict()
        user_roles_data = {}
        try:
            sql_file = db_util.getusermngSql()
            user_roles_qry = sql_file['user_roles_query']
            user_roles_data = Methodutil.get_data_by_param(user_roles_qry,
                                                           user_id)
        except Exception as error:
            logger.dthublog("""@ 226 EXCEPTION - models - users -
                 get_user_details """ + str(error))
            raise error
        user_data['roles'] = user_roles_data
        logger.addinfo('@ models - users - get_user_details(-)')
        return user_data

    # insert roles of user
    @staticmethod
    def update_roles(p_roles_list, user_id):
        logger.addinfo('@ models - users - update_roles(+)')
        final_data = Users.new_roles(p_roles_list, user_id)
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            row_list = []
            role_ids = []
            my_ids = []
            returnval = dict()
            update_strng = "SET "
            for roleval in final_data:
                for key, value in roleval.items():
                    if key == 'role_id':
                        role_ids.append(value)
                    update_strng += str(key)
                    update_strng += '='
                    if isinstance(value, int):
                        update_strng += str(value)
                    else:
                        update_strng += "'" + value + "'"
                    update_strng += ','
                row_list.append(update_strng[:-1])
                update_strng = "SET "
            length = len(role_ids)
            sql_file = db_util.getusermngSql()
            qry = sql_file['user_roles_exist_query']
            for i in range(0, length):
                cursor.execute(qry, p_role_id=role_ids[i], p_user_id=user_id)
                data = cursor.fetchall()
                if len(data) == 0:
                    my_ids.append(i)
            for i in range(0, length):
                cursor.execute("""update
                USER_ROLES """ + str(row_list[i]) + """
                where role_id = """ + str(role_ids[i]) + """
                and user_id = """ + str(user_id))
        except Exception as error:
            logger.dthublog("""@ 286 EXCEPTION - models - users -
                 update_roles """ + str(error))
            returnval['msg'] = "Fails"
            returnval['user_id'] = ""
            return returnval
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - users - update_roles(-)')
        return "success"

    # insert roles of user
    @staticmethod
    def new_roles(p_roles_list, user_id):
        logger.addinfo('@ models - users - new_roles(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            role_ids = []
            my_ids = []
            new_roles_list = []
            for roleval in p_roles_list:
                for key, value in roleval.items():
                    if key == 'role_id':
                        role_ids.append(value)
            length = len(role_ids)
            for i in range(0, length):
                sql_file = db_util.getusermngSql()
                qry = sql_file['user_roles_exist_query']
                cursor.execute(qry, p_role_id=role_ids[i], p_user_id=user_id)
                data = cursor.fetchall()
                if len(data) == 0:
                    my_ids.append(i)
            exist_list = []
            for i in range(0, len(my_ids)):
                new_roles_list.append(p_roles_list[my_ids[i]])
            for i in range(0, length):
                if i not in my_ids:
                    exist_list.append(p_roles_list[i])
            Users.save_roles(new_roles_list, user_id)
        except Exception as error:
            logger.dthublog("""@ 331 EXCEPTION - models - users -
                 new_roles """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - users - new_roles(-)')
        return exist_list

    # insert roles of user
    @staticmethod
    def update_users(p_users, user_id):
        logger.addinfo('@ models - users - update_users(+)')
        connection = None
        cursor = None
        update_strng = "SET "
        returnval = dict()
        for key, value in p_users.items():
            if key == 'encrypted_password':
                value = auth_util.encrypt(value)
            update_strng += str(key)
            update_strng += '='
            if isinstance(value, int):
                update_strng += str(value)
            else:
                update_strng += "'" + value + "'"
            update_strng += ','
        final = update_strng[:-1]
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            cursor.execute("""update
                nas_users """ + str(final) + """
                where user_id = """ + str(user_id))
        except Exception as error:
            logger.dthublog("""@ 367 EXCEPTION - models - users -
                 update_users """ + str(error))
            returnval['msg'] = "Fails"
            returnval['user_id'] = ""
            return returnval
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - users - update_users(-)')
        return "success"

    @staticmethod
    def validation(p_val):
        logger.addinfo('@ models - users - validation(+)')
        data = dict()
        try:
            sql_file = db_util.getusermngSql()
            qry = sql_file['user_validation']
            data = Methodutil.get_validation(qry, p_val)
        except Exception as error:
            logger.dthublog("""@ 389 EXCEPTION - models - users -
                 validation """ + str(error))
            raise error
        logger.addinfo('@ models - users - validation(-)')
        return data

    @staticmethod
    def get_notifications(user_id, status):
        logger.addinfo('@ models - users - get_notifications(+)')
        connection = None
        cursor = None
        data = []
        try:
            file_data = db_util.getusermngSql()
            connection = db_util.get_connection()
            cursor = connection.cursor()
            query = file_data['user_notifications']
            cursor.execute(query, P_USER_ID=user_id, P_STATUS=status)
        except Exception as error:
            logger.dthublog("""@ 503 EXCEPTION - models - users -
                 get_notifications """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                result = Users()
                for index, fn in enumerate(fieldnames):
                    setattr(result, fn, row[index])
                data.append(result)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - users - get_notifications(-)')
        return data

    @staticmethod
    def get_notification_count(user_id):
        logger.addinfo('@ models - users - get_notification_count(+)')
        connection = None
        cursor = None
        data = []
        try:
            file_data = db_util.getusermngSql()
            connection = db_util.get_connection()
            cursor = connection.cursor()
            query = file_data['user_notifications_count']
            cursor.execute(query, P_USER_ID=user_id)
        except Exception as error:
            logger.dthublog("""@ 503 EXCEPTION - models - users -
                 get_notification_count """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                result = Users()
                for index, fn in enumerate(fieldnames):
                    setattr(result, fn, row[index])
                data.append(result)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - users - get_notification_count(-)')
        return data

    @staticmethod
    def get_usersmail():
        logger.addinfo('@ models - users - get_usersmail(+)')
        return_data = []
        try:
            file_data = db_util.getusermngSql()
            query = file_data['user_emails_query']
            return_data = Methodutil.get_qry(query)
        except Exception as error:
            logger.dthublog("""@ 592 EXCEPTION - models - users -
                 get_usersmail """ + str(error))
            raise error
        logger.addinfo('@ models - users - get_usersmail(-)')
        return return_data

    @staticmethod
    def get_wp_users():
        logger.addinfo('@ models - users - get_wp_users(+)')
        connection = None
        cursor = None
        result = []
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['wordpress_users_query']
            cursor.execute(query)
        except Exception as error:
            logger.dthublog("""@ 147 EXCEPTION - models - users -
                get_wp_users """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                obj = {}
                for index, fn in enumerate(fieldnames):
                    obj[fn] = row[index]
                result.append(obj)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - users - get_wp_users(-)')
        return result

    @staticmethod
    def workflow_action(data):
        logger.dthublog('@models - supplier - workflow_action(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            status_code = cursor.var(cx_Oracle.STRING)
            result ={}
            cursor.execute("alter session set nls_language=American")
            cursor.execute("""
                begin
                    benefits_allocations_pkg.update_notifications(
                        :p_item_key,
                        :p_result,
                        :p_type,
                        :p_comment,
                        :p_login_user_name,
                        :x_status_code
                    );
                end; """, p_item_key=data['item_key'],
                           p_result=data['result'],
                           p_type=data['type'],
                           p_comment=data['comment'],
                           p_login_user_name=data['login_user_name'],
                           x_status_code=status_code)
            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'Task status updated successfully'
            else:
                result['status'] = 1
                result['msg'] = 'Task status failed to update - ' + str(status)
        except Exception as error:
            logger.dthublog("""@ 542 EXCEPTION - models - supplier -
                    workflow_action """ + str(error))
            raise error
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        logger.dthublog('@models - supplier - workflow_action(-)')
        return result

    @staticmethod
    def change_user_status(jsond):
        logger.addinfo('@ models - users - change_user_status(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['update_wp_user_status']
            cursor.execute(query, p_status=jsond['status'],
                           p_email=jsond['email'])
        except Exception as error:
            logger.dthublog("""@ 645 EXCEPTION - models - users -
                change_user_status """ + str(error))
            return "error"
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - users - change_user_status(-)')
        return "success"

        # insert user
    @staticmethod
    def insert_header(p_users, user_id, send_email, jsond):
        logger.addinfo('@ models - users - insert_header(+)')
        connection = None
        cursor = None
        row_data = []
        hashval = ''
        user_dict = {}
        user_name = ''
        sql_data = '''insert into NAS_USERS ('''
        for user in p_users:
            my_data = []
            for key, value in user.__dict__.items():
                user_dict = user.__dict__
                if key == 'user_name':
                    user_name = value
                if key == 'encrypted_password':
                    if not value:
                        hashval = ''.join(random.choice
                                            (string.ascii_uppercase +
                                            string.ascii_lowercase +
                                            string.digits) for i in range(10))
                        value = hashPassword(hashval)
                    else:
                        hashval = value
                        value = hashPassword(value)
                my_data.append(value)
                my_new_tuple = tuple(my_data)
            row_data.append(my_new_tuple)
        for key, value in user.__dict__.items():
            sql_data += str(key)
            sql_data += ','
        if hashval:
            sql_data += "ADDITIONAL_INFO2,"
        sql_data += " USER_ID)\
                VALUES ( "
        sql_args = ""
        for idx, key in enumerate(user.__dict__.items()):
            sql_data += ":" + str(idx) + ","
        if hashval:
            sql_args += "'" + hashval + "'" + ","
        sql_data += sql_args + user_id + ")"
        returnval = {}
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            cursor.executemany(sql_data, row_data)
            if send_email == 'Y':
                if hashval:
                    req_data = dict()
                    req_data['email'] = user_dict['email_address']
                    req_data['subject'] = 'Sign up - Scorpion (NAS Innovations)'
                    req_data['activation_key'] = hashval
                    req_data['user_name'] = jsond['first_name']
                    req_data['user'] = jsond['user_name']
                    req_data['type'] = 'new_user'
                    Users.send_mail(req_data)
                # rvalue = cursor.var(cx_Oracle.STRING)
                # cursor.execute("""
                # begin
                # :retval := qpex_quotes_pub_pkg.send_activation_email
                # (:p_user_name);
                # end;""", p_user_name=user_name, retval=rvalue)
                # if rvalue.getvalue() == 'S':
                connection.commit()
                returnval['msg'] = "User created successfully"
                returnval['status'] = 0
                # else:
                # returnval['msg'] = "Fails"
                # returnval['status'] = 1
            else:
                returnval['msg'] = "User created successfully"
                returnval['status'] = 0
        except Exception as error:
            logger.dthublog("""@ 177 EXCEPTION - models - users -
                    insert_header """ + str(error))
            returnval['msg'] = str(error)
            returnval['status'] = 1
            return returnval
        finally:
            connection.commit()
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - users - insert_header(-)')
        return returnval

    # insert last_logon_date of user to sysdate
    @staticmethod
    def update_last_logon(user_id):
        logger.addinfo('@ models - users - update_last_logon(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getusermngSql()
            query = sql_file['update_last_logon']
            cursor.execute(query, p_user_id=user_id)
            connection.commit()
        except Exception as error:
            logger.dthublog("""@ 94 EXCEPTION - models - users -
                 update_last_logon """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - users - update_last_logon(-)')
        return 'success'

    @staticmethod
    def get_persons(id):
        logger.addinfo('@ models - users - get_persons(+)')
        return_data = []
        query = ''
        try:
            file_data = db_util.getusermngSql()
            if id:
                query = file_data['persons_query']
            else:
                query = file_data['employees_query']
            return_data = Methodutil.get_qry(query)
        except Exception as error:
            logger.dthublog("""@ 451 EXCEPTION - models - users -
                 get_persons """ + str(error))
            raise error
        logger.addinfo('@ models - users - get_persons(-)')
        return return_data

    @staticmethod
    def get_application_template(data):
        logger.addinfo('@ models - Benefits Allocation - get_application_template(+)')
        try:
            path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
            path += '/static/email_templates'
            if data['type'] == "new_user":
                template = jinja2.Environment(
                    loader=jinja2.FileSystemLoader(path)
                ).get_template('welcome.html').render(
                    user_name=data['user_name'],
                    activation_key=data['activation_key'],
                    user=data['user']
                )
            elif data['type'] == "reset_password":
                template = jinja2.Environment(
                    loader=jinja2.FileSystemLoader(path)
                ).get_template('password_reset.html').render(
                    user_name=data['user_name'],
                    activation_key=data['activation_key']
                )
            elif data['type'] == "password_change":
                template = jinja2.Environment(
                    loader=jinja2.FileSystemLoader(path)
                ).get_template('password_change.html').render(
                    user_name=data['user_name']
                )
        except Exception as error:
            logger.dthublog("""@ 933 EXCEPTION - models - Benefits Allocation -
                get_application_template """ + str(error))
            raise error
        logger.addinfo('@ models - Benefits Allocation - get_application_template(-)')
        return template

    # Send email for user registration def send_mail(self, email, user_name, subject, message_body):
    @staticmethod
    def send_mail(req_data):
        logger.addinfo('@ models - Benefits Allocation - send_email(+)')
        try:
            strings = db_util.get_strings()
            # req_data['activation_key'] = self.password
            # req_data['user'] = self.user_value
            """message_template = Registration.read_template('email_template_registration.txt')"""
            message_template = Users.get_application_template(req_data)
            msg = MIMEMultipart()       # create a message
            # add in the actual person name to the message template
            server = smtplib.SMTP()
            server.connect(strings['mail_server'], 25)
            # message = message_template.substitute(PERSON_NAME=user_name, MESSAGE_BODY=message_body)
            # Prints out the message body for our sake
            # setup the parameters of the message
            msg['From'] = strings['sender_email']
            msg['To'] = req_data['email']
            msg['Subject'] = req_data['subject']
            # add in the message body
            msg.attach(MIMEText(message_template, 'html'))
            # send the message via the server set up earlier.
            server.send_message(msg)
            del msg
            server.quit()
            status = 'success'
        except Exception as e:
            status = 'Failure - Failed to send email'
            logger.dthublog(""" @ EXCEPTION - models - Benefits Allocation -
                             send_email """ + str(e))
            raise e
        logger.addinfo('@ models - Benefits Allocation - send_email(-)')
        return status


# generate encrypted password
def hashPassword(password):
    return auth_util.encrypt(password)
