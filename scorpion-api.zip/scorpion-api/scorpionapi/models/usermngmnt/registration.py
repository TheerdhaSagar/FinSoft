from __future__ import absolute_import

import random
import string
import os
import jinja2
import cx_Oracle

from scorpionapi.utils import db_util
from scorpionapi.utils.logdata import logger
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import smtplib
from string import Template
from scorpionapi.sql import sql_util
from scorpionapi.utils import auth_util


class Registration:

    def __init__(self):
        self.strings = db_util.get_strings()
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())
        self.connection = None
        self.cursor = None
        self.is_acquired = False
        self.api_key = 'thisisapikey'
        self.sender_email = self.strings['sender_email']
        self.password = None
        self.user_value = None

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()
        self.is_acquired = True

    def release(self):
        if self.cursor:
            self.cursor.close()
            self.is_acquired = False
        db_util.release_connection(self.connection)

    def insert_user(self, data):
        logger.addinfo('@ models - Benefits Allocation - insert_user(+)')
        result = dict()
        local_acquire = False
        try:
            if not self.is_acquired:
                self.acquire()
                local_acquire = True
            user_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.password = Registration.get_random_sequence(10).lower()
            self.user_value = data['user_name']
            passwd_hash = auth_util.encrypt(self.password)
            self.cursor.execute("""
            begin
                BENEFITS_ALLOCATIONS_PKG.insert_user(
                    :p_user_id,                    
                    :p_first_name,
                    :p_last_name,
                    :p_user_name,
                    :p_employee_id,
                    :p_es_id,
                    :p_team,
                    :p_reporting_manager,
                    :p_encrypted_passwd,
                    :p_user_email,
                    :p_status_code
                );
            end; """, p_user_id=user_id,
                                p_first_name=data['first_name'],
                                p_last_name=data['last_name'],
                                p_user_name=data['user_name'],
                                p_employee_id=data['employee_id'],
                                p_es_id=data['es_id'],
                                P_team=data['team'],
                                p_reporting_manager=data['reporting_manager'],
                                p_encrypted_passwd=passwd_hash,
                                p_user_email=data['user_email'],
                                p_status_code=status_code)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 'OK'
                result['msg'] = 'User created successfully'
                result['user_id'] = user_id.getvalue()
            else:
                result['status'] = 'ERROR'
                result['msg'] = 'Failed to create user - ' + str(status)
                result['user_id'] = -1
        except Exception as e:
            logger.dthublog("""@ 252 EXCEPTION models - Benefits Allocation -
                insert_user """ + str(e))
            raise e
        finally:
            if self.is_acquired and local_acquire:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - Benefits Allocation - insert_user(-)')
        return result

    @staticmethod
    def get_random_sequence(length):
        chars = string.ascii_uppercase + string.digits
        return ''.join(random.choice(chars) for _ in range(length))

    @staticmethod
    def read_template(filename):
        with open(filename, 'r', encoding='utf-8') as template_file:
            template_file_content = template_file.read()
        return Template(template_file_content)

    @staticmethod
    def get_application_template(data):
        logger.addinfo('@ models - Benefits Allocation - get_application_template(+)')
        try:
            path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
            path += '/static/allocations/email_templates'
            template = jinja2.Environment(
                loader=jinja2.FileSystemLoader(path)
            ).get_template('bs_application_notify.html').render(
                user_name=data['user_name'],
                activation_key=data['activation_key'],
                user=data['user']
            )
        except Exception as error:
            logger.dthublog("""@ 933 EXCEPTION - models - Benefits Allocation -
                get_application_template """ + str(error))
            raise error
        logger.addinfo('@ models - Benefits Allocation - get_application_template(-)')
        return template

    # Send email for user registration def send_mail(self, email, user_name, subject, message_body):
    def send_mail(self, req_data):
        logger.addinfo('@ models - Benefits Allocation - send_email(+)')
        try:
            strings = db_util.get_strings()
            req_data['activation_key'] = self.password
            req_data['user'] = self.user_value
            """message_template = Registration.read_template('email_template_registration.txt')"""
            message_template = Registration.get_application_template(req_data)
            msg = MIMEMultipart()       # create a message
            # add in the actual person name to the message template
            server = smtplib.SMTP()
            server.connect(strings['mail_server'], 25)
            # message = message_template.substitute(PERSON_NAME=user_name, MESSAGE_BODY=message_body)
            # Prints out the message body for our sake

            # setup the parameters of the message
            msg['From'] = strings['sender_email']
            msg['To'] = req_data['email']
            msg['Subject'] = req_data['subject']

            # add in the message body
            msg.attach(MIMEText(message_template, 'html'))
            # send the message via the server set up earlier.
            server.send_message(msg)
            del msg
            server.quit()
            status = 'success'
        except Exception as e:
            status = 'Failure - Failed to send email'
            logger.dthublog(""" @ EXCEPTION - models - Benefits Allocation -
                             send_email """ + str(e))
            raise e
        logger.addinfo('@ models - Benefits Allocation - send_email(-)')
        return status


# generate encrypted password
def hashPassword(password):
    return auth_util.encrypt(password)