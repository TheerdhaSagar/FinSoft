from __future__ import absolute_import
from scorpionapi.utils.logdata import logger
from scorpionapi.utils import db_util
# import ujson
import cx_Oracle


class Objectives:

    def __init__(self, **kwargs):
        for name, value in kwargs.items():
            setattr(self, name, value)

    @staticmethod
    def get_budget_categories():
        logger.addinfo('@ models - objectives - get_budget_categories(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['budget_categories_lov']
            cur.execute(query)
        except Exception as error:
            logger.dthublog("""@ 26 EXCEPTION - models - objectives -
                 get_budget_categories """ + str(error))
            raise error
        else:
            budget_categories = []
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                budget = Objectives()
                for index, field in enumerate(field_names):
                    setattr(budget, field, row[index])
                budget_categories.append(budget)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - get_budget_categories(-)')
        return budget_categories

    @staticmethod
    def get_budget_description():
        logger.addinfo('@ models - objectives - get_budget_description(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['budget_description_lov']
            cur.execute(query)
        except Exception as error:
            logger.dthublog("""@ 55 EXCEPTION - models - objectives -
                 get_budget_description """ + str(error))
            raise error
        else:
            budget_descrption = []
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                budget = Objectives()
                for index, field in enumerate(field_names):
                    setattr(budget, field, row[index])
                budget_descrption.append(budget)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - get_budget_description(-)')
        return budget_descrption

    @staticmethod
    def get_invoice_frequency():
        logger.addinfo('@ models - objectives - get_invoice_frequency(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['invoice_frequency_lov']
            cur.execute(query)
        except Exception as error:
            logger.dthublog("""@ 84 EXCEPTION - models - objectives -
                 get_invoice_frequency """ + str(error))
            raise error
        else:
            invoice_frequency = []
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                frequency = Objectives()
                for index, field in enumerate(field_names):
                    setattr(frequency, field, row[index])
                invoice_frequency.append(frequency)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - get_invoice_frequency(-)')
        return invoice_frequency

    @staticmethod
    def get_targets():
        logger.addinfo('@ models - objectives - get_targets(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['target_base_lov']
            cur.execute(query)
        except Exception as error:
            logger.dthublog("""@ 113 EXCEPTION - models - objectives -
                 get_targets """ + str(error))
            raise error
        else:
            targets = []
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                target = Objectives()
                for index, field in enumerate(field_names):
                    setattr(target, field, row[index])
                targets.append(target)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - get_targets(-)')
        return targets

    @staticmethod
    def get_customer_objectives(jsond):
        logger.addinfo('@ models - objectives - get_customer_objectives(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['customer_objectives']

            # Get data from previous year to sysdate if date filters are not selected
            if not jsond['start_date'] and not jsond['end_date']:
                query += "AND to_date(end_date, 'dd-mm-yyyy') >= to_date(add_months(sysdate, - 12), 'dd-mm-yyyy')"
            cur.execute(query, p_org_id=jsond['org_id'],
                        p_start_date=jsond['start_date'],
                        p_end_date=jsond['end_date'])
        except Exception as error:
            logger.dthublog("""@ 142 EXCEPTION - models - objectives -
                 get_customer_objectives """ + str(error))
            raise error
        else:
            cust_objectives = []
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                objective = Objectives()
                for index, field in enumerate(field_names):
                    setattr(objective, field, row[index])
                cust_objectives.append(objective)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - get_customer_objectives(-)')
        return cust_objectives

    @staticmethod
    def delete_objective(objective_id):
        logger.addinfo('@ models - objectives - delete_objective(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            status_code = cur.var(cx_Oracle.STRING)
            cur.execute("""
            begin
            qpex_cust_objectives_pkg.delete_objective(
            :p_cust_objective_id,
            :x_status_code);
            end;""", p_cust_objective_id=objective_id,
                        x_status_code=status_code)
        except Exception as error:
            logger.dthublog("""@ 142 EXCEPTION - models - objectives -
                 delete_objective """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - delete_objective(-)')
        return status_code.getvalue()

    @staticmethod
    def save_objective(jsond):
        logger.addinfo('@ models - objectives - save_objective(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            cust_objective_id = cur.var(cx_Oracle.NUMBER)
            tmp_budget = jsond['budget']
            customers = jsond['related_customers']
            vendors = jsond['related_vendors']
            attachments = jsond['attachments']
            status_code = cur.var(cx_Oracle.STRING)
            cur.execute("""
            begin
            qpex_cust_objectives_pkg.insert_objective(
             :x_cust_objective_id,
             :p_customer_id,
             :p_customer_reference,
             :p_start_date,
             :p_end_date,
             :p_target_amount,
             :p_target_base_id,
             :p_target_description,
             :p_bonus_percentage,
             :p_calc_bonus_amount,
             :p_final_bonus_amount,
             :p_bonus_return_type,
             :p_created_by,
             :p_creation_date,
             :p_org_id,
             :p_last_updated_by,
             :p_last_update_date,
             :p_customer_name,
             :p_customer_number,
             :p_fixed_bonus,
             :p_target_group,
             :p_status,
             :p_party_type,
             :x_status_code);
             end;""", x_cust_objective_id=cust_objective_id,
                        p_customer_id=jsond['customer_id'],
                        p_customer_reference=jsond['customer_reference'],
                        p_start_date=jsond['start_date'],
                        p_end_date=jsond['end_date'],
                        p_target_amount=None,
                        p_target_base_id=None,
                        p_target_description=None,
                        p_bonus_percentage=None,
                        p_calc_bonus_amount=None,
                        p_final_bonus_amount=None,
                        p_bonus_return_type=None,
                        p_created_by=jsond['created_by'],
                        p_creation_date=jsond['creation_date'],
                        p_org_id=jsond['org_id'],
                        p_last_updated_by=jsond['last_updated_by'],
                        p_last_update_date=jsond['last_updated_date'],
                        p_customer_name=jsond['customer_name'],
                        p_customer_number=jsond['customer_number'],
                        p_fixed_bonus=None,
                        p_target_group=None,
                        p_status=None,
                        p_party_type=jsond['party_type'],
                        x_status_code=status_code)
            customer_sequence = cust_objective_id.getvalue()
            objective_status = []
            if status_code.getvalue() == 'S':
                if len(attachments) > 0:
                    result = Objectives.save_attachments(
                            attachments, customer_sequence)
                    if result != 'success':
                        objective_status.append('attachments')
                result = Objectives.save_objective_lines(
                        tmp_budget, customer_sequence)
                if result != 'success':
                    objective_status.append('lines')
                if len(customers) > 0:
                    result = Objectives.save_related_customer(
                            customers, customer_sequence)
                    if result != 'success':
                        objective_status.append('customers')
                if len(vendors) > 0:
                    result = Objectives.save_related_vendors(
                            vendors, customer_sequence)
                    if result != 'success':
                        objective_status.append('vendors')
                if len(objective_status) == 0:
                    objective_status.append('success')
            else:
                objective_status.append('error')
        except Exception as error:
            logger.dthublog("""@ 297 EXCEPTION - models - objectives -
                 save_objective """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - save_objective(-)')
        return objective_status

    @staticmethod
    def save_objective_lines(budgets, line_id):
        logger.addinfo('@ models - objectives - save_objective_lines(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            lines_status = 'success'
            status_code = cur.var(cx_Oracle.STRING)
            for line in budgets:
                cur.execute("""
                begin
                    qpex_cust_objectives_pkg.insert_objective_line (
                    :p_cust_objective_id,
                    :p_line_number,
                    :p_target_amount,
                    :p_target_base_id,
                    :p_target_description,
                    :p_bonus_percentage,
                    :p_calc_bonus_amount,
                    :p_final_bonus_amount,
                    :p_bonus_return_type,
                    :p_fixed_bonus,
                    :p_creation_date,
                    :p_created_by,
                    :p_last_updated_by,
                    :p_last_update_date,
                    :p_budget_category,
                    :p_budge_name,
                    :p_document_created_flag,
                    :p_start_date,
                    :p_end_date,
                    :p_invoice_frequency,
                    :p_target_group,
                    :x_status_code);
                    end;""", p_cust_objective_id=line_id,
                            p_line_number=line['line_number'],
                            p_target_amount=line['target_amount'],
                            p_target_base_id=line['target_base_id'],
                            p_target_description=line['target_description'],
                            p_bonus_percentage=line['bonus_percentage'],
                            p_calc_bonus_amount=line['calc_bonus_amount'],
                            p_final_bonus_amount=line['final_bonus_amount'],
                            p_bonus_return_type=line['bonus_return_type'],
                            p_fixed_bonus=line['fixed_bonus'],
                            p_creation_date=line['creation_date'],
                            p_created_by=line['created_by'],
                            p_last_updated_by=line['last_updated_by'],
                            p_last_update_date=line['last_updated_date'],
                            p_budget_category=line['budget_category'],
                            p_budge_name=line['budget_name'],
                            p_document_created_flag=line[
                                'document_created_flag'],
                            p_start_date=line['start_date'],
                            p_end_date=line['end_date'],
                            p_invoice_frequency=line['invoice_frequency'],
                            p_target_group=line['target_group'],
                            x_status_code=status_code)
                if status_code.getvalue() != 'S':
                    lines_status = 'error'
        except Exception as error:
            logger.dthublog("""@ 364 EXCEPTION - models - objectives -
                 save_objective_lines """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - save_objective_lines(-)')
        return lines_status

    @staticmethod
    def save_related_customer(customers, line_id):
        logger.addinfo('@ models - objectives - save_related_customer(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            customer_status = 'success'
            customer_seq = cur.var(cx_Oracle.NUMBER)
            status_code = cur.var(cx_Oracle.STRING)
            for line in customers:
                cur.execute("""
                begin
                    qpex_cust_objectives_pkg.insert_related_customer(
                    :p_customer_id,
                    :p_customer_name,
                    :p_customer_number,
                    :p_rel_customer_name,
                    :p_rel_customer_id,
                    :p_rel_cust_number,
                    :p_cust_objective_id,
                    :p_creation_date,
                    :p_created_by,
                    :p_last_update_date,
                    :p_last_updated_by,
                    :x_cust_rel_obj_line_id,
                    :x_status_code
                    );
                    end;""", p_customer_id=line['customer_id'],
                            p_customer_name=line['customer_name'],
                            p_customer_number=line['customer_number'],
                            p_rel_customer_name=line['rel_customer_name'],
                            p_rel_customer_id=line['rel_customer_id'],
                            p_rel_cust_number=line['rel_cust_number'],
                            p_cust_objective_id=line_id,
                            p_creation_date=line['creation_date'],
                            p_created_by=line['created_by'],
                            p_last_update_date=line['last_updated_date'],
                            p_last_updated_by=line['last_updated_by'],
                            x_cust_rel_obj_line_id=customer_seq,
                            x_status_code=status_code)
                if status_code.getvalue() != 'S':
                    customer_status = 'error'
        except Exception as error:
            logger.dthublog("""@ 414 EXCEPTION - models - objectives -
                 save_related_customer """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - save_related_customer(-)')
        return customer_status

    @staticmethod
    def save_related_vendors(vendors, line_id):
        logger.addinfo('@ models - objectives - save_related_vendors(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            vendor_status = 'success'
            vendor_seq = cur.var(cx_Oracle.NUMBER)
            status_code = cur.var(cx_Oracle.STRING)
            for line in vendors:
                cur.execute("""
                begin
                    qpex_cust_objectives_pkg.insert_related_vendor(
                    :p_customer_id,
                    :p_customer_name,
                    :p_customer_number,
                    :p_rel_customer_name,
                    :p_rel_vendor_id,
                    :p_rel_vendor_number,
                    :p_cust_objective_id,
                    :p_creation_date,
                    :p_created_by,
                    :p_last_update_date,
                    :p_last_updated_by,
                    :x_cust_rel_obj_line_id,
                    :x_status_code
                    );
                    end;""", p_customer_id=line['customer_id'],
                            p_customer_name=line['customer_name'],
                            p_customer_number=line['customer_number'],
                            p_rel_customer_name=line['rel_customer_name'],
                            p_rel_vendor_id=line['rel_vendor_id'],
                            p_rel_vendor_number=line['rel_vendor_number'],
                            p_cust_objective_id=line_id,
                            p_creation_date=line['creation_date'],
                            p_created_by=line['created_by'],
                            p_last_update_date=line['last_updated_date'],
                            p_last_updated_by=line['last_updated_by'],
                            x_cust_rel_obj_line_id=vendor_seq,
                            x_status_code=status_code)
                if status_code.getvalue() != 'S':
                    vendor_status = 'error'
        except Exception as error:
            logger.dthublog("""@ 464 EXCEPTION - models - objectives -
                 save_related_vendors """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - save_related_vendors(-)')
        return vendor_status

    @staticmethod
    def get_objective_details(objective_id):
        logger.addinfo('@ models - objectives - get_objective_details(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['get_objective_header']
            cur.execute(query, p_objective_id=objective_id)
            details = []
            field_names = [a[0].lower()for a in cur.description]
            for row in cur:
                detail = Objectives()
                for index, field in enumerate(field_names):
                    setattr(detail, field, row[index])
                details.append(detail)
            lines = Objectives.get_objective_lines(objective_id)
            customers = Objectives.get_related_customers(objective_id)
            vendors = Objectives.get_related_vendors(objective_id)
            attachments = Objectives.get_attachments(objective_id)
            result = dict()
            result['header'] = details
            result['budget_lines'] = lines
            result['related_customers'] = customers
            result['related_vendors'] = vendors
            result['attachments'] = attachments
        except Exception as error:
            logger.dthublog("""@ 142 EXCEPTION - models - objectives -
                 get_objective_details """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - get_objective_details(-)')
        return result

    @staticmethod
    def get_objective_lines(objective_id):
        logger.addinfo('@ models - objectives - get_objective_lines(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['get_objective_lines']
            cur.execute(query, p_objective_id=objective_id)
            lines = []
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                line = Objectives()
                for index, field in enumerate(field_names):
                    setattr(line, field, row[index])
                lines.append(line)
        except Exception as error:
            logger.dthublog("""@ 497 EXCEPTION - models - objectives -
                 get_objective_lines """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - get_objective_details(-)')
        return lines

    @staticmethod
    def get_related_customers(objective_id):
        logger.addinfo('@ models - objectives - get_related_customers(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['get_related_customers']
            cur.execute(query, p_objective_id=objective_id)
            related_customers = []
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                customer = Objectives()
                for index, field in enumerate(field_names):
                    setattr(customer, field, row[index])
                related_customers.append(customer)
        except Exception as error:
            logger.dthublog("""@ 545 EXCEPTION - models - objectives -
                 get_related_customers """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - get_related_customers(-)')
        return related_customers

    @staticmethod
    def get_related_vendors(objective_id):
        logger.addinfo('@ models - objectives - get_related_vendors(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['get_related_vendors']
            cur.execute(query, p_objective_id=objective_id)
            related_vendors = []
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                vendor = Objectives()
                for index, field in enumerate(field_names):
                    setattr(vendor, field, row[index])
                related_vendors.append(vendor)
        except Exception as error:
            logger.dthublog("""@ 497 EXCEPTION - models - objectives -
                 get_related_vendors """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - get_related_vendors(-)')
        return related_vendors

    @staticmethod
    def update_objective(jsond):
        logger.addinfo('@ models - objectives - update_objective(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            objective_id = jsond['cust_objective_id']
            tmp_budget = jsond['budget']
            customers = jsond['related_customers']
            vendors = jsond['related_vendors']
            attachments = jsond['attachments']
            deleted_attachments = jsond['deleted_attachments']
            status_code = cur.var(cx_Oracle.STRING)
            cur.execute("""
            begin
            qpex_cust_objectives_pkg.update_objective(
             :p_cust_objective_id,
             :p_customer_id,
             :p_customer_reference,
             :p_start_date,
             :p_end_date,
             :p_target_amount,
             :p_target_base_id,
             :p_target_description,
             :p_bonus_percentage,
             :p_calc_bonus_amount,
             :p_final_bonus_amount,
             :p_bonus_return_type,
             :p_org_id,
             :p_last_updated_by,
             :p_last_update_date,
             :p_customer_name,
             :p_customer_number,
             :p_fixed_bonus,
             :p_target_group,
             :p_status,
             :p_party_type,
             :x_status_code);
             end;""", p_cust_objective_id=jsond['cust_objective_id'],
                        p_customer_id=jsond['customer_id'],
                        p_customer_reference=jsond['customer_reference'],
                        p_start_date=jsond['start_date'],
                        p_end_date=jsond['end_date'],
                        p_target_amount=None,
                        p_target_base_id=None,
                        p_target_description=None,
                        p_bonus_percentage=None,
                        p_calc_bonus_amount=None,
                        p_final_bonus_amount=None,
                        p_bonus_return_type=None,
                        p_org_id=jsond['org_id'],
                        p_last_updated_by=jsond['last_updated_by'],
                        p_last_update_date=jsond['last_updated_date'],
                        p_customer_name=jsond['customer_name'],
                        p_customer_number=jsond['customer_number'],
                        p_fixed_bonus=None,
                        p_target_group=None,
                        p_status=None,
                        p_party_type=jsond['party_type'],
                        x_status_code=status_code)
            objective_status = []
            if status_code.getvalue() == 'S':
                if len(attachments) > 0:
                    result = Objectives.save_attachments(
                            attachments, objective_id)
                    if result != 'success':
                        objective_status.append('attachments')
                result = Objectives.update_objective_lines(
                        tmp_budget, objective_id)
                if result != 'success':
                    objective_status.append('lines')
                if len(jsond['deleted_lines']) > 0:
                    result = Objectives.delete_objective_lines(
                            jsond['deleted_lines'])
                if result != 'success':
                    objective_status.append('deleted_lines')
                if len(jsond['deleted_customers']) > 0:
                    result = Objectives.delete_related_customer(
                                        jsond['deleted_customers'])
                if result != 'success':
                    objective_status.append('deleted_customers')
                if len(jsond['deleted_vendors']) > 0:
                    result = Objectives.delete_related_vendor(
                                    jsond['deleted_vendors'])
                if result != 'success':
                    objective_status.append('deleted_vendors')
                if len(customers) > 0:
                    result = Objectives.save_related_customer(
                            customers, objective_id)
                    if result != 'success':
                        objective_status.append('customers')
                if len(vendors) > 0:
                    result = Objectives.save_related_vendors(
                            vendors, objective_id)
                    if result != 'success':
                        objective_status.append('vendors')
                if len(objective_status) == 0:
                    objective_status.append('success')
                if len(deleted_attachments) > 0:
                    result = Objectives.delete_attachment(deleted_attachments)
                    if result != 'success':
                        objective_status.append('delete_attachments')
            else:
                objective_status.append('error')
        except Exception as error:
            logger.dthublog("""@ 675 EXCEPTION - models - objectives -
                 update_objective """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - update_objective(-)')
        return objective_status

    @staticmethod
    def update_objective_lines(budgets, objective_id):
        logger.addinfo('@ models - objectives - update_objective_lines(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            status_code = cur.var(cx_Oracle.STRING)
            line_status = 'success'
            for line in budgets:
                if 'cust_objective_id' in line:
                    cur.execute("""
                    begin
                        qpex_cust_objectives_pkg.update_objective_line (
                        :p_cust_objective_id,
                        :p_line_number,
                        :p_target_amount,
                        :p_target_base_id,
                        :p_target_description,
                        :p_bonus_percentage,
                        :p_calc_bonus_amount,
                        :p_final_bonus_amount,
                        :p_bonus_return_type,
                        :p_fixed_bonus,
                        :p_last_updated_by,
                        :p_last_update_date,
                        :p_budget_category,
                        :p_budge_name,
                        :p_document_created_flag,
                        :p_start_date,
                        :p_end_date,
                        :p_invoice_frequency,
                        :p_target_group,
                        :x_status_code);
                        end;""", p_cust_objective_id=line['cust_objective_id'],
                                p_line_number=line['line_number'],
                                p_target_amount=line['target_amount'],
                                p_target_base_id=line['target_base_id'],
                                p_target_description=line[
                                    'target_description'],
                                p_bonus_percentage=line['bonus_percentage'],
                                p_calc_bonus_amount=line['calc_bonus_amount'],
                                p_final_bonus_amount=line[
                                    'final_bonus_amount'],
                                p_bonus_return_type=line['bonus_return_type'],
                                p_fixed_bonus=line['fixed_bonus'],
                                p_last_updated_by=line['last_updated_by'],
                                p_last_update_date=line['last_updated_date'],
                                p_budget_category=line['budget_category'],
                                p_budge_name=line['budget_name'],
                                p_document_created_flag=line[
                                    'document_created_flag'],
                                p_start_date=line['start_date'],
                                p_end_date=line['end_date'],
                                p_invoice_frequency=line['invoice_frequency'],
                                p_target_group=line['target_group'],
                                x_status_code=status_code)
                    if status_code.getvalue() != 'S':
                        line_status = 'error'
                else:
                    new_line = []
                    new_line.append(line)
                    status = Objectives.save_objective_lines(
                                new_line, objective_id)
                    if status != 'success':
                        line_status = 'error'
        except Exception as error:
            logger.dthublog("""@ 297 EXCEPTION - models - objectives -
                 update_objective_lines """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - update_objective_lines(-)')
        return line_status

    @staticmethod
    def delete_objective_lines(deleted_lines):
        logger.addinfo('@ models - objectives - delete_objective_lines(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            delete_line_status = 'success'
            status_code = cur.var(cx_Oracle.STRING)
            for line in deleted_lines:
                cur.execute("""
                begin
                qpex_cust_objectives_pkg.delete_objective_line(
                :p_cust_objective_id,
                :p_line_number,
                :x_status_code);
                end;""", p_cust_objective_id=line['cust_objective_id'],
                            p_line_number=line['line_number'],
                            x_status_code=status_code)
                if status_code.getvalue() != 'S':
                    delete_line_status = 'error'
        except Exception as error:
            logger.dthublog("""@ 297 EXCEPTION - models - objectives -
                 delete_objective_lines """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - delete_objective_lines(-)')
        return delete_line_status

    @staticmethod
    def delete_related_customer(deleted_customers):
        logger.addinfo('@ models - objectives - delete_related_customer(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            delete_customer_status = 'success'
            status_code = cur.var(cx_Oracle.STRING)
            for line in deleted_customers:
                cur.execute("""
                begin
                qpex_cust_objectives_pkg.delete_related_customer(
                :p_cust_objective_id,
                :p_cust_rel_obj_line_id,
                :x_status_code);
                end;""", p_cust_objective_id=line['cust_objective_id'],
                            p_cust_rel_obj_line_id=line[
                                    'cust_rel_obj_line_id'],
                            x_status_code=status_code)
                if status_code.getvalue() != 'S':
                    delete_customer_status = 'error'
        except Exception as error:
            logger.dthublog("""@ 297 EXCEPTION - models - objectives -
                 delete_related_customer """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - delete_related_customer(-)')
        return delete_customer_status

    @staticmethod
    def delete_related_vendor(deleted_vendors):
        logger.addinfo('@ models - objectives - delete_related_vendor(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            delete_vendor_status = 'success'
            status_code = cur.var(cx_Oracle.STRING)
            for line in deleted_vendors:
                cur.execute("""
                begin
                qpex_cust_objectives_pkg.delete_related_vendor(
                :p_cust_objective_id,
                :p_cust_rel_obj_line_id,
                :x_status_code);
                end;""", p_cust_objective_id=line['cust_objective_id'],
                            p_cust_rel_obj_line_id=line[
                                        'cust_rel_obj_line_id'],
                            x_status_code=status_code)
                if status_code.getvalue() != 'S':
                    delete_vendor_status = 'error'
        except Exception as error:
            logger.dthublog("""@ 297 EXCEPTION - models - objectives -
                 delete_related_vendor """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - delete_related_vendor(-)')
        return delete_vendor_status

    @staticmethod
    def save_attachments(attachments, objective_id):
        logger.addinfo('@ models - objectives - delete_related_vendor(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            attachment_status = 'success'
            cur.setinputsizes(p_blob=cx_Oracle.BLOB)
            status_code = cur.var(cx_Oracle.STRING)
            for a in attachments:
                cur.execute(""" declare
                begin
                :retval := nas_attachments.add_attachment(
                :pref,
                :ptitle,
                :pfilename,
                :pdesc,
                :p_blob,
                :pcontent_type,
                :pentity,
                :pcategory);
                end;""", pref=objective_id,
                            ptitle=a['title'],
                            pfilename=a['file_name'],
                            pdesc=a['description'],
                            p_blob=a['file_blob'],
                            pcontent_type=a['content_type'],
                            pentity=a['entity_name'],
                            pcategory=a['category_name'],
                            retval=status_code)
                if status_code.getvalue() != 'S':
                    attachment_status = 'error'
        except Exception as error:
            logger.dthublog("""@ 297 EXCEPTION - models - objectives -
                 delete_related_vendor """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - delete_related_vendor(-)')
        return attachment_status

    @staticmethod
    def get_attachments(objective_id):
        logger.addinfo('@ models - objectives - get_attachments(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['get_objective_attachments']
            cur.execute(query, p_attachseq=objective_id)
            attachments = []
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                attachment = Objectives()
                for index, field in enumerate(field_names):
                    if field == 'file_data':
                        setattr(attachment, field, row[index].read())
                    else:
                        setattr(attachment, field, row[index])
                attachments.append(attachment)
        except Exception as error:
            logger.dthublog("""@ 297 EXCEPTION - models - objectives -
                 get_attachments """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - get_attachments(-)')
        return attachments

    @staticmethod
    def delete_attachment(attachments):
        logger.addinfo('@ models - objectives - delete_attachment(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            attachment_status = 'success'
            status_code = cur.var(cx_Oracle.STRING)
            for a in attachments:
                cur.execute(""" declare
                    begin
                        :retval := nas_attachments.delete_attachment(
                        :p_file_id);
                        end;""", p_file_id=a['file_id'],
                            retval=status_code)
                if status_code.getvalue() != 'S':
                    attachment_status = 'error'
        except Exception as error:
            logger.dthublog("""@ 297 EXCEPTION - models - objectives -
                 delete_attachment """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - objectives - delete_attachment(-)')
        return attachment_status
