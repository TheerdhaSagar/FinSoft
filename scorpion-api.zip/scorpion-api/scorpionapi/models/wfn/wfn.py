from __future__ import absolute_import

import base64
import random
import string
import cx_Oracle
import csv
import os
import jinja2
import openpyxl
from openpyxl.styles import Font

from scorpionapi.models.balances.balances import Balances
from scorpionapi.utils.constants import Status
import pandas as pd
import zipfile
from scorpionapi.utils.code_util import Code_util
from scorpionapi.utils.common_utils import CommonUtils
from scorpionapi.sql import sql_util
from scorpionapi.utils import db_util
from scorpionapi.utils.logdata import logger


class Wfn:

    def __init__(self):
        self.strings = db_util.get_strings()
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())
        self.connection = None
        self.cursor = None
        self.is_acquired = False

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()
        self.is_acquired = True

    def release(self):
        if self.cursor:
            self.cursor.close()
            self.is_acquired = False
        db_util.release_connection(self.connection)

    def get_file_data(self):
        fieldnames = [a[0].lower() for a in self.cursor.description]
        data = []
        for row in self.cursor:
            obj = {}
            for index, fn in enumerate(fieldnames):
                if fn == 'file_data':
                    obj[fn] = row[index].read()
                else:
                    obj[fn] = row[index]
            data.append(obj)
        return data

    def read_file(self, jsond):
        logger.addinfo('@ models - wfn - read_file(+)')
        try:
            id_size = 9
            result = {}
            status = 'SUCCESS'
            setup_type = ''
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            x_setup_id = self.cursor.var(cx_Oracle.NUMBER)

            # delete setup info for the client
            self.cursor.execute("""
                                begin
                                    NAS_WFN_PKG.delete_setup(
                                    :p_client_id,
                                    :x_status_code
                                    );
                                end; """, p_client_id=jsond['client_id'],
                                x_status_code=status_code)
            chars = string.ascii_uppercase + string.digits
            file_name = ''.join(random.choice(chars) for _ in range(id_size))
            decoded = base64.b64decode(jsond['base64'])

            # Create file in tmp folder
            temp_file_name = '/tmp/' + file_name + '.xls'

            # Open file in write mode and write decoded excel content
            text_file = open(temp_file_name, 'wb')
            text_file.write(decoded)
            text_file.close()

            # Open excel and create  data frame
            df_setup = pd.read_excel(temp_file_name, sheet_name='Sheet1').fillna(value='no-val')
            drop_cols = [1, 3, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18]
            df_setup.drop(df_setup.columns[drop_cols], axis=1, inplace=True)
            df_setup.rename(columns={'Validation Tables': 'company_code', 'Unnamed: 2': 'code',
                                     'Unnamed: 4': 'description', 'Unnamed: 19': 'status'}, inplace=True)
            for row in df_setup.iterrows():
                row_data = row[1]
                if row_data['code'] == 'Code' or row_data['company_code'] == 'Code':
                    continue
                else:
                    if row_data['company_code'] == 'Business Unit':
                        setup_type = 'business_unit'
                        continue
                    elif row_data['company_code'] == 'Compensation Change Reason':
                        setup_type = 'compensation_change_reason'
                        continue
                    elif row_data['company_code'] == 'Corporate Group Change Reasons':
                        setup_type = 'corporate_group_change'
                        continue
                    elif row_data['company_code'] == 'Deductions':
                        setup_type = 'deductions'
                        continue
                    elif row_data['company_code'] == 'Department':
                        setup_type = 'department'
                        continue
                    elif row_data['company_code'] == 'Worker Category':
                        setup_type = 'worker_category'
                        continue
                    elif row_data['company_code'] == 'Job Change Reasons':
                        setup_type = 'job_change_reason'
                        continue
                    elif row_data['company_code'] == 'Local Tax Jurisdictions':
                        setup_type = 'local_tax'
                        continue
                    elif row_data['company_code'] == 'Location':
                        setup_type = 'location'
                        continue
                    elif row_data['company_code'] == 'State Tax Jurisdictions':
                        setup_type = 'state_tax'
                        continue
                    elif row_data['company_code'] == 'Status Change Reasons':
                        setup_type = 'status_change_reason'
                        continue
                    elif row_data['company_code'] == 'SUI/SDI Jurisdictions':
                        setup_type = 'sui_sdi'
                        continue
                    elif row_data['company_code'].find('Validation') != -1:
                        continue
                    # if setup_type in ['business_unit', 'compensation_change_reason', 'corporate_group_change',
                    #                   'worker_category', 'job_change_reason', 'Location', 'status_change_reason']:
                    #     code = row_data['company_code']
                    #     company_code = ''
                    # else:
                    #     code = row_data['code']
                    #     company_code = row_data['company_code']
                    if row_data['description'] == 'no-val':
                        description = ''
                    else:
                        description = row_data['description'].replace(u'\xa0', u' ')
                    if row_data['code'] == 'no-val':
                        code = ''
                    else:
                        code = row_data['code']
                    self.cursor.execute("""
                                        begin
                                            NAS_WFN_PKG.insert_setup_info(
                                            :x_setup_id,
                                            :p_client_id,
                                            :p_setup_type,
                                            :p_companycode,
                                            :p_code,
                                            :p_description,
                                            :p_status,
                                            :p_user_id,
                                            :x_status_code
                                            );
                                        end; """, x_setup_id=x_setup_id,
                                        p_client_id=jsond['client_id'],
                                        p_setup_type=setup_type,
                                        p_companycode=row_data['company_code'],
                                        p_code=code,
                                        p_description=description,
                                        p_status=row_data['status'],
                                        p_user_id=jsond['user_id'],
                                        x_status_code=status_code)
                    status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = Status.OK.value
                result['msg'] = 'Set up file added successfully'
                result['client_id'] = jsond['client_id']
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to insert setup information'
                result['client_id'] = -1
            # df_deductions = df_setup.loc
        except Exception as e:
            logger.dthublog(""" @ 89 EXCEPTION - models - wfn -
                             read_file """ + str(e))
            raise e
        logger.addinfo('@ models - wfn - read_file(-)')
        return result

    # def update_add_client_status(self, jsond):
    #     logger.addinfo('models - wfn - update_add_client_status(+)')
    #     try:
    #         self.acquire()
    #         status_code = self.cursor.var(cx_Oracle.STRING)
    #         self.cursor.execute("""
    #             begin
    #                 qpex_leavemanagement_pkg.update_leave_status(
    #                     :p_leave_id,
    #                     :p_status,
    #                     :p_user_id,
    #                     :p_action,
    #                     :p_comments,
    #                     :x_status_code
    #                 );
    #             end;""", p_leave_id=jsond['leave_id'],
    #                             p_status=jsond['status'],
    #                             p_user_id=jsond['user_id'],
    #                             p_action=jsond['action'],
    #                             p_comments=jsond['comments'],
    #                             x_status_code=status_code)
    #         if status_code.getvalue() == 'SUCCESS':
    #             if jsond['send_email']:
    #
    #                 # Send email to users having role recieve notifications
    #                 query = self.sql_file['get_role_users']
    #                 self.cursor.execute(query,
    #                                     p_role_name='UI-LEAVEMANAGEMENT-RECIEVE-NOTIFICATIONS')
    #                 users = Code_util.iterate_data(self.cursor)
    #                 recipients = []
    #                 for i in range(len(users)):
    #                     if users[i]['employee_number'] != jsond['user_id']:
    #                         recipients.append(users[i]['email_address'])
    #                 subject = 'Leave '
    #                 subject +=  'approved' if jsond['status'] == 'A' else 'rejected'
    #                 subject += " by " + jsond['manager_name']
    #                 if jsond['from_date'] != jsond['upto_date']:
    #                     subject += " from " + jsond['from_date']
    #                     subject += " to " + jsond['upto_date']
    #                 else:
    #                     subject += " for " + jsond['from_date']
    #                 data = {
    #                     'manager_name': jsond['manager_name'],
    #                     'user_name': jsond['user_name'],
    #                     'no_of_days': round(jsond['no_of_days'],2),
    #                     'from_date': jsond['from_date'],
    #                     'upto_date': jsond['upto_date'],
    #                     'leave_status': 'approved' if jsond['status'] == 'A' else 'rejected',
    #                     'comments': jsond['comments'] if jsond['comments'] else '-',
    #                     'leaves_used': jsond['leaves_used'],
    #                     'leaves_remaining': jsond['leaves_remaining'],
    #                     'total_leaves': jsond['total_leaves'],
    #                     'reason': jsond['reason'],
    #                     'template_id': 781633,
    #                     'subject': subject,
    #                     'dates': '',
    #                     'leave_type': jsond['leave_type'],
    #                     'created_date': jsond['created_date'],
    #                     'deleted_user_name': '',
    #                     'recipients': recipients,
    #                     'recipient_name': '',
    #                     'leave_id': jsond['leave_id'],
    #                     'org_id': jsond['org_id'],
    #                     'applied_by': jsond['applied_by'],
    #                     'approve_link': '',
    #                     'reject_link': ''
    #                 }
    #                 LeaveManagement.send_email(data)
    #
    #                 # Get leave applied_by user get_mail_id
    #                 query = self.sql_file['get_mail_id']
    #                 self.cursor.execute(query, p_user_id=jsond['applied_by'])
    #                 email = Code_util.iterate_data(self.cursor)[0]['email_address']
    #                 # Send email to leave applied_by user to notify status
    #                 data = {
    #                     'manager_name': jsond['manager_name'],
    #                     'user_name': jsond['user_name'],
    #                     'no_of_days': round(jsond['no_of_days'],2),
    #                     'from_date': jsond['from_date'],
    #                     'upto_date': jsond['upto_date'],
    #                     'leave_status': 'approved' if jsond['status'] == 'A' else 'rejected',
    #                     'comments': jsond['comments'] if jsond['comments'] else '-',
    #                     'leaves_used': jsond['leaves_used'],
    #                     'leaves_remaining': jsond['leaves_remaining'],
    #                     'total_leaves': jsond['total_leaves'],
    #                     'reason': jsond['reason'],
    #                     'template_id': 781638,
    #                     'subject': subject,
    #                     'dates': '',
    #                     'leave_type': jsond['leave_type'],
    #                     'created_date': jsond['created_date'],
    #                     'deleted_user_name': '',
    #                     'recipients': [email],
    #                     'recipient_name': '',
    #                     'leave_id': jsond['leave_id'],
    #                     'org_id': jsond['org_id'],
    #                     'applied_by': jsond['applied_by'],
    #                     'approve_link': '',
    #                     'reject_link': ''
    #                 }
    #                 LeaveManagement.send_email(data)
    #
    #     except Exception as e:
    #         logger.dthublog(""" @ 562 EXCEPTION - models - wfn -
    #                         update_add_client_status """ + str(e))
    #         raise e
    #     finally:
    #         self.connection.commit()
    #         self.release()
    #     logger.addinfo('models - wfn - update_add_client_status(-)')
    #     return status_code.getvalue()

    def get_setup_summary(self, user_id):
        logger.addinfo('@ models - wfn - get_setup_summary(+)')
        result = dict()
        try:
            self.acquire()
            self.cursor.execute(self.sql_file['setup_summary'], p_user_id=user_id)
            summary = Code_util.iterate_data(self.cursor)
            result['status'] = 0
            result['result'] = summary
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - wfn -
                get_setup_summary """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - wfn - get_setup_summary(-)')
        return result

    def get_setup_details(self, client_id):
        logger.addinfo('@ models - wfn - get_setup_details(+)')
        result = dict()
        try:
            self.acquire()
            self.cursor.execute(self.sql_file['setup_details'], p_client_id=client_id)
            summary = Code_util.iterate_data(self.cursor)
            result['status'] = 0
            result['result'] = summary
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - wfn -
                get_setup_details """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - wfn - get_setup_details(-)')
        return result

    def add_client(self, data):
        logger.addinfo('@ models - wfn - add_client(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            project_scope = ''
            for i in range(len(data['project_scope'])):
                project_scope += data['project_scope'][i] + ', '
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                NAS_WFN_PKG.insert_client(
                    :p_client_id,    
                    :p_client_name,      
                    :p_project_manager,        
                    :p_ic,
                    :p_mft_details,  
                    :p_shared_path,      
                    :p_project_start_date,           
                    :p_go_live_date,
                    :p_project_scope,
                    :p_user_id,
                    :p_status,
                    :p_team,          
                    :x_status_code 
                );
            end; """, p_client_id=data['client_id'],
                                p_client_name=data['client_name'],
                                p_project_manager=data['project_manager'],
                                p_ic=data['ic'],
                                p_mft_details=data['mft_details'],
                                p_shared_path=data['shared_path'],
                                p_project_start_date=data['project_start_date'],
                                p_go_live_date=data['go_live_date'],
                                p_project_scope=project_scope,
                                p_user_id=data['user_id'],
                                p_status=data['status'],
                                p_team=data['team'],
                                x_status_code=status_code)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                if data['status'] == 'A':
                    result['msg'] = 'Client added Successfully'
                else:
                    self.send_mail(data, project_scope)
                    result['msg'] = 'Your request submitted successfully'
                result['client_id'] = data['client_id']
            else:
                result['status'] = 1
                result['msg'] = 'Failed to add to Client info - ' + str(status)
                result['client_id'] = data['client_id']
        except Exception as e:
            logger.dthublog("""@ 235 EXCEPTION models - wfn -
                add_client """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - wfn - add_client(-)')
        return result

    def send_mail(self, data, project_scope):
        try:
            req = {}
            self.acquire()
            self.cursor.execute(self.sql_file['get_user_details'], p_user_id=data['user_id'])
            user_details = Code_util.iterate_data(self.cursor)
            path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
            path += '/static/email_templates'
            template = jinja2.Environment(
                loader=jinja2.FileSystemLoader(path)
            ).get_template('wfn_client_add.html').render(
                v_client_name=data['client_name'],
                v_project_manager=data['project_manager'],
                v_start_date=data['project_start_date'],
                v_go_live_date=data['go_live_date'],
                v_scope=project_scope,
                v_user_name=user_details[0]['first_name'],
                action_url='http://11.16.45.94:8008/login/approveclient/' + data['client_id'] + '/'
            )
            query = self.sql_file['get_role_users']
            if data['team'] == 4:
                self.cursor.execute(query, p_role_code='DC-WFN-MANAGER')
            elif data['team'] == 5:
                self.cursor.execute(query, p_role_code='MAS-WFN-MANAGER')
            elif data['team'] == 6:
                self.cursor.execute(query, p_role_code='MAS-CAN-WFN-MANAGER')
            elif data['team'] == 7:
                self.cursor.execute(query, p_role_code='MIGRATIONS-WFN-MANAGER')
            users = Code_util.iterate_data(self.cursor)
            req['email'] = users[0]['email_address']
            req['subject'] = 'WFN Validation - Request Client Addition'
            req['message_template'] = template
            email_status = Balances.send_smtp_mail(req)
        except Exception as error:
            raise error
        finally:
            if self.is_acquired:
                self.release()
        return email_status

    def get_clients(self, org_id):
        logger.addinfo('@ models - wfn - get_clients(+)')
        result = dict()
        try:
            self.acquire()
            self.cursor.execute(self.sql_file['clients_info_query'], p_org_id=org_id)
            client_info = Code_util.iterate_data(self.cursor)
            result['status'] = 0
            result['result'] = client_info
        except Exception as e:
            logger.dthublog(""" @ 307 EXCEPTION - models - wfn -
                   get_clients """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - wfn - get_clients(-)')
        return result

    def update_client(self, data):
        logger.addinfo('@ models - wfn - update_client(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                NAS_WFN_PKG.client_info_update(
                    :p_client_id_seq,    
                    :p_client_name,      
                    :p_client_id,        
                    :p_assigned_employee,
                    :p_project_manager,  
                    :p_shared_path,      
                    :p_org_id,           
                    :x_status_code 
                );
            end; """, p_client_id_seq=data['client_id_sq'],
                                p_client_name=data['client_name'],
                                p_client_id=data['client_id'],
                                p_assigned_employee=data['assign_employee'],
                                p_project_manager=data['project_manager'],
                                p_shared_path=data['shared_path'],
                                p_org_id=data['org_id'],
                                x_status_code=status_code)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'Client updated successfully'
                result['client_id'] = data['client_id']
            else:
                result['status'] = 1
                result['msg'] = 'Failed to update Client - ' + str(status)
                result['client_id'] = -1
        except Exception as e:
            logger.dthublog("""@ 281 EXCEPTION models - wfn -
                update_client """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - wfn - update_client(-)')
        return result

    def update_client_status(self, client_id):
        logger.addinfo('@ models - wfn - update_client_status(+)')
        email_status = ''
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                NAS_WFN_PKG.update_client_status(:p_client_id,
                :x_status_code
                );
            end; """, p_client_id=client_id,
                                x_status_code=status_code)
            status = status_code.getvalue()
            if status == 'SUCCESS':
                req = {}
                self.acquire()
                self.cursor.execute(self.sql_file['get_client_details'], p_client_id=client_id)
                data = Code_util.iterate_data(self.cursor)
                path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
                path += '/static/email_templates'
                template = jinja2.Environment(
                    loader=jinja2.FileSystemLoader(path)
                ).get_template('wfn_client_approve_notification.html').render(
                    client_name=data[0]['client_name'],
                    user_name=data[0]['first_name']
                )
                query = self.sql_file['get_role_users']
                if data[0]['team'] == 4:
                    self.cursor.execute(query, p_role_code='DC-WFN-MANAGER')
                elif data[0]['team'] == 5:
                    self.cursor.execute(query, p_role_code='MAS-WFN-MANAGER')
                elif data[0]['team'] == 6:
                    self.cursor.execute(query, p_role_code='MAS-CAN-WFN-MANAGER')
                elif data[0]['team'] == 7:
                    self.cursor.execute(query, p_role_code='MIGRATIONS-WFN-MANAGER')
                users = Code_util.iterate_data(self.cursor)
                req['email'] = users[0]['email_address'] + ';' + data[0]['email_address']
                req['subject'] = 'WFN Validation - Client Approved'
                req['message_template'] = template
                email_status = Balances.send_smtp_mail(req)
        except Exception as e:
            logger.dthublog(""" @ 441 EXCEPTION - models - wfn -
                             update_client_status """ + str(e))
            raise e
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('models - wfn - delete_client(-)')
        return email_status

    def delete_client(self, client_id):
        logger.addinfo('@ models - wfn - delete_client(+)')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                NAS_WFN_PKG.delete_client(:p_client_id,
                :x_status_code
                );
            end; """, p_client_id=client_id,
                                x_status_code=status_code)
        except Exception as e:
            logger.dthublog(""" @ 441 EXCEPTION - models - wfn -
                             delete_client """ + str(e))
            raise e
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('models - wfn - delete_client(-)')
        return status_code.getvalue()

    def issue_create(self, data):
        logger.addinfo('@ models - wfn - issue_create(+)')
        result = dict()
        local_acquire = False
        try:
            if not self.is_acquired:
                self.acquire()
                local_acquire = True
            issue_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                NAS_ISSUE_TRACKER_PKG.add_issue(
                    :p_issue_id,
                    :p_issue_task,
                    :p_issue_sub_task,
                    :p_error_message,
                    :p_issue_resolution,
                    :p_created_id,
                    :p_org_id,
                    :p_status_code
                );
            end; """, p_issue_id=issue_id,
                                p_issue_task=data['issue_task'],
                                p_issue_sub_task=data['issue_sub_task'],
                                p_error_message=data['error_message'],
                                p_issue_resolution=data['issue_resolution'],
                                p_created_id=data['user_id'],
                                p_org_id=data['org_id'],
                                p_status_code=status_code)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'Issue added successfully'
                result['issue_id'] = issue_id.getvalue()
            else:
                result['status'] = 1
                result['msg'] = 'Failed to add Issue - ' + str(status)
                result['issue_id'] = -1
        except Exception as e:
            logger.dthublog("""@ 252 EXCEPTION models - wfn -
                issue_create """ + str(e))
            raise e
        finally:
            if self.is_acquired and local_acquire:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - wfn - issue_create(-)')
        return result

    def issue_edit(self, data):
        logger.addinfo('@ models - wfn - issue_edit(+)')
        result = dict()
        local_acquire = False
        try:
            if not self.is_acquired:
                self.acquire()
                local_acquire = True
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                NAS_ISSUE_TRACKER_PKG.edit_issue(
                    :p_issue_id,
                    :p_issue_task,
                    :p_issue_sub_task,
                    :p_error_message,
                    :p_issue_resolution,
                    :p_status_code
                );
            end; """, p_issue_id=data['issue_id'],
                                p_issue_task=data['issue_task'],
                                p_issue_sub_task=data['issue_sub_task'],
                                p_error_message=data['error_message'],
                                p_issue_resolution=data['issue_resolution'],
                                p_status_code=status_code)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'Issue updated successfully'
                result['issue_id'] = data['issue_id']
            else:
                result['status'] = 1
                result['msg'] = 'Failed to update Issue - ' + str(status)
                result['issue_id'] = -1
        except Exception as e:
            logger.dthublog("""@ 252 EXCEPTION models - wfn -
                issue_edit """ + str(e))
            raise e
        finally:
            if self.is_acquired and local_acquire:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - wfn - issue_edit(-)')
        return result

    def get_issues(self, org_id, issue_id, issue_arrea):
        logger.addinfo('@ models - wfn - get_issues(+)')
        result = dict()
        try:
            self.acquire()
            query = self.sql_file['get_issue']
            self.cursor.execute(query, p_org_id=org_id,
                                p_issue_id=issue_id, p_issue_task=issue_arrea)
            issues = Code_util.iterate_data(self.cursor)
            result['status'] = 0
            result['result'] = issues
        except Exception as e:
            logger.dthublog(""" @ 307 EXCEPTION - models - wfn -
                   get_issues """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - wfn - get_issues(-)')
        return result

    def delete_issue(self, issue_id):
        logger.addinfo('@ models - wfn - delete_client(+)')
        try:
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                NAS_ISSUE_TRACKER_PKG.delete_issue(:p_issue_id,
                :x_status_code
                );
            end; """, p_issue_id=issue_id,
                                x_status_code=status_code)
        except Exception as e:
            logger.dthublog(""" @ 441 EXCEPTION - models - wfn -
                             delete_client """ + str(e))
            raise e
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('models - wfn - delete_client(-)')
        return status_code.getvalue()

    @staticmethod
    def id_generator():
        size = 9
        chars = string.ascii_uppercase + string.digits
        return ''.join(random.choice(chars) for _ in range(size))

    def load_position_preview(self, jsond, tmp_data):
        logger.addinfo('@ models - wfn - load_position_preview(+)')
        try:
            row_data = []
            result = {}
            log_data = {
                'client_id': jsond['client_id'],
                'conversion_name': jsond['conversion_name'],
                'user_id': jsond['created_id']
            }
            self.add_client_log(log_data)
            query = self.sql_file['wfn_position_sequence']
            self.acquire()
            sql_data = 'insert into dc_wfn_source_position ('
            for t in tmp_data:
                if t != {}:
                    position = {}
                    data = self.cursor.execute(query).fetchone()
                    preview_file_keys = list(map(lambda x: x.upper(), list(t.keys())))
                    t = {k.upper(): v for k, v in t.items()}
                    position['source_id'] = str(data[0])
                    position['client_id'] = jsond['client_id']
                    position['POSITION_ID'] = ''
                    position['CHANGE_EFFECTIVE_ON'] = ''
                    position['BENEFITS_ELIGIBILITY_CLASS'] = ''
                    position['CORP_GROUP_CHANGE_REASON'] = ''
                    position['BUSINESS_UNIT'] = ''
                    position['EEOC_JOB_CODE'] = ''
                    position['EMPLOYEE_TYPE'] = ''
                    position['FLSA_CODE'] = ''
                    position['FTE'] = ''
                    position['HOME_COST_NUMBER'] = ''
                    position['HOME_DEPARTMENT'] = ''
                    position['HOURS_PERIOD'] = ''
                    position['JOB_CHANGE_REASON'] = ''
                    position['JOB_CLASS'] = ''
                    position['JOB_FUNCTION'] = ''
                    position['JOB_TITLE'] = ''
                    position['LOCATION_CODE'] = ''
                    position['EMPLOYEE_IS_SUPERVISOR'] = ''
                    position['NAICS_WORKERS_COMP_CODE'] = ''
                    position['SCHEDULED_HOURS'] = ''
                    position['SHIFT'] = ''
                    position['UNION_CODE'] = ''
                    position['UNION_LOCAL'] = ''
                    position['OFFICER_OWNER_INDICATOR'] = ''
                    position['EEO_ESTABLISHMENT'] = ''
                    position['HIRE_DATE'] = ''
                    position['TERMINATION_DATE'] = ''
                    position['LEAVE_OF_ABSENCE_START_DATE'] = ''
                    position['JOB_START_DATE'] = ''
                    position['STATIC_DATE'] = ''
                    position['CREATED_ID'] = jsond['created_id']
                    if 'POSITION ID' in preview_file_keys:
                        position['POSITION_ID'] = t['POSITION ID']
                    if 'CHANGE EFFECTIVE ON' in preview_file_keys:
                        position['CHANGE_EFFECTIVE_ON'] = t['CHANGE EFFECTIVE ON']
                    if 'BENEFITS ELIGIBILITY CLASS' in preview_file_keys:
                        position['BENEFITS_ELIGIBILITY_CLASS'] = t['BENEFITS ELIGIBILITY CLASS']
                    if 'CORP GROUP CHANGE REASON' in preview_file_keys:
                        position['CORP_GROUP_CHANGE_REASON'] = t['CORP GROUP CHANGE REASON']
                    if 'BUSINESS UNIT' in preview_file_keys:
                        position['BUSINESS_UNIT'] = t['BUSINESS UNIT']
                    if 'EEOC JOB CODE' in preview_file_keys:
                        position['EEOC_JOB_CODE'] = t['EEOC JOB CODE']
                    if 'EMPLOYEE TYPE' in preview_file_keys:
                        position['EMPLOYEE_TYPE'] = t['EMPLOYEE TYPE']
                    if 'FLSA CODE' in preview_file_keys:
                        position['FLSA_CODE'] = t['FLSA CODE']
                    if 'FTE' in preview_file_keys:
                        position['FTE'] = t['FTE']
                    if 'HOME COST NUMBER' in preview_file_keys:
                        position['HOME_COST_NUMBER'] = t['HOME COST NUMBER']
                    if 'HOME DEPARTMENT' in preview_file_keys:
                        position['HOME_DEPARTMENT'] = t['HOME DEPARTMENT']
                    if 'HOURS PERIOD' in preview_file_keys:
                        position['HOURS_PERIOD'] = t['HOURS PERIOD']
                    if 'JOB CHANGE REASON' in preview_file_keys:
                        position['JOB_CHANGE_REASON'] = t['JOB CHANGE REASON']
                    if 'JOB CLASS' in preview_file_keys:
                        position['JOB_CLASS'] = t['JOB CLASS']
                    if 'JOB FUNCTION' in preview_file_keys:
                        position['JOB_FUNCTION'] = t['JOB FUNCTION']
                    if 'JOB TITLE' in preview_file_keys:
                        position['JOB_TITLE'] = t['JOB TITLE']
                    if 'LOCATION CODE' in preview_file_keys:
                        position['LOCATION_CODE'] = t['LOCATION CODE']
                    if 'EMPLOYEE IS SUPERVISOR' in preview_file_keys:
                        position['EMPLOYEE_IS_SUPERVISOR'] = t['EMPLOYEE IS SUPERVISOR']
                    if 'NAICS WORKERS COMP CODE' in preview_file_keys:
                        position['NAICS_WORKERS_COMP_CODE'] = t['NAICS WORKERS COMP CODE']
                    if 'SCHEDULED HOURS' in preview_file_keys:
                        position['SCHEDULED_HOURS'] = t['SCHEDULED HOURS']
                    if 'SHIFT' in preview_file_keys:
                        position['SHIFT'] = t['SHIFT']
                    if 'UNION CODE' in preview_file_keys:
                        position['UNION_CODE'] = t['UNION CODE']
                    if 'UNION LOCAL' in preview_file_keys:
                        position['UNION_LOCAL'] = t['UNION LOCAL']
                    if '!!HIRE DATE' in preview_file_keys:
                        position['HIRE_DATE'] = t['!!HIRE DATE']
                    if '!!TERMINATION DATE' in preview_file_keys:
                        position['TERMINATION_DATE'] = t['!!TERMINATION DATE']
                    if '!!LEAVE OF ABSENCE START DATE' in preview_file_keys:
                        position['LEAVE_OF_ABSENCE_START_DATE'] = t['!!LEAVE OF ABSENCE START DATE']
                    if '!!JOB START DATE' in preview_file_keys:
                        position['JOB_START_DATE'] = t['!!JOB START DATE']
                    if '!!STATIC DATE' in preview_file_keys:
                        position['STATIC_DATE'] = t['!!STATIC DATE']
                    my_data = []
                    for key, value in position.items():
                        my_data.append(value)
                        record = tuple(my_data)
                    row_data.append(record)
            for key, value in position.items():
                sql_data += str(key)
                sql_data += ','
            sql_data = sql_data[:-1]
            sql_data += ")\
                                    VALUES ("
            sql_args = ""
            for idx, key in enumerate(position.items()):
                sql_args += ":" + str(idx) + ","
            sql_args = sql_args[:-1]
            sql_data += sql_args + ")"
            self.cursor.executemany(sql_data, row_data)
            query = self.sql_file['update_status']
            self.cursor.execute(query, p_client_id=jsond['client_id'], p_conversion=jsond['conversion_name'])
            result['status'] = 0
            result['msg'] = 'Position preview file uploaded Successfully'
        except Exception as error:
            logger.dthublog("""@ 216 EXCEPTION - models - efn -
                 load_mf_preview """ + str(error))
            result['status'] = 1
            result['msg'] = 'Position preview file failed to upload'
            raise error
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - wfn - load_position_preview(-)')
        return result

    def load_pay_rate_preview(self, jsond, tmp_data):
        logger.addinfo('@ models - wfn - load_pay_rate_preview(+)')
        try:
            row_data = []
            result = {}
            log_data = {
                'client_id': jsond['client_id'],
                'conversion_name': jsond['conversion_name'],
                'user_id': jsond['created_id']
            }
            self.add_client_log(log_data)
            query = self.sql_file['wfn_payrate_sequence']
            self.acquire()
            sql_data = 'insert into dc_wfn_source_payrate ('
            for t in tmp_data:
                if t != {}:
                    position = {}
                    data = self.cursor.execute(query).fetchone()
                    preview_file_keys = list(map(lambda x: x.upper(), list(t.keys())))
                    t = {k.upper(): v for k, v in t.items()}
                    position['source_id'] = str(data[0])
                    position['client_id'] = jsond['client_id']
                    position['POSITION_ID'] = ''
                    position['CHANGE_EFFECTIVE_ON'] = ''
                    position['PAY_FREQUENCY_CODE'] = ''
                    position['STANDARD_HOURS'] = ''
                    position['PAY_GROUP'] = ''
                    position['RATE_TYPE'] = ''
                    position['RATE_1_AMOUNT'] = ''
                    position['RATE_2_AMOUNT'] = ''
                    position['RATE_3_AMOUNT'] = ''
                    position['RATE_4_AMOUNT'] = ''
                    position['RATE_5_AMOUNT'] = ''
                    position['RATE_6_AMOUNT'] = ''
                    position['RATE_7_AMOUNT'] = ''
                    position['RATE_8_AMOUNT'] = ''
                    position['RATE_9_AMOUNT'] = ''
                    position['ADDITIONAL_EARNINGS_CODE'] = ''
                    position['ADDITIONAL_EARNINGS_AMOUNT'] = ''
                    position['COMPENSATION_CHANGE_REASON'] = ''
                    position['HIRE_DATE'] = ''
                    position['TERMINATION_DATE'] = ''
                    position['LEAVE_OF_ABSENCE_START_DATE'] = ''
                    position['RATE_START_DATE'] = ''
                    position['STATIC_DATE'] = ''
                    position['CREATED_ID'] = jsond['created_id']
                    if 'POSITION ID' in preview_file_keys:
                        position['POSITION_ID'] = t['POSITION ID']
                    if 'CHANGE EFFECTIVE ON' in preview_file_keys:
                        position['CHANGE_EFFECTIVE_ON'] = t['CHANGE EFFECTIVE ON']
                    if 'PAY FREQUENCY CODE' in preview_file_keys:
                        position['PAY_FREQUENCY_CODE'] = t['PAY FREQUENCY CODE']
                    if 'STANDARD HOURS' in preview_file_keys:
                        position['STANDARD_HOURS'] = t['STANDARD HOURS']
                    if 'PAY GROUP' in preview_file_keys:
                        position['PAY_GROUP'] = t['PAY GROUP']
                    if 'RATE TYPE' in preview_file_keys:
                        position['RATE_TYPE'] = t['RATE TYPE']
                    if 'RATE 1 AMOUNT' in preview_file_keys:
                        position['RATE_1_AMOUNT'] = t['RATE 1 AMOUNT']
                    if 'RATE 2 AMOUNT' in preview_file_keys:
                        position['RATE_2_AMOUNT'] = t['RATE 2 AMOUNT']
                    if 'RATE 3 AMOUNT' in preview_file_keys:
                        position['RATE_3_AMOUNT'] = t['RATE 3 AMOUNT']
                    if 'RATE 4 AMOUNT' in preview_file_keys:
                        position['RATE_4_AMOUNT'] = t['RATE 4 AMOUNT']
                    if 'RATE 5 AMOUNT' in preview_file_keys:
                        position['RATE_5_AMOUNT'] = t['RATE 5 AMOUNT']
                    if 'RATE 6 AMOUNT' in preview_file_keys:
                        position['RATE_6_AMOUNT'] = t['RATE 6 AMOUNT']
                    if 'RATE 7 AMOUNT' in preview_file_keys:
                        position['RATE_7_AMOUNT'] = t['RATE 7 AMOUNT']
                    if 'RATE 8 AMOUNT' in preview_file_keys:
                        position['RATE_8_AMOUNT'] = t['RATE 8 AMOUNT']
                    if 'RATE 9 AMOUNT' in preview_file_keys:
                        position['RATE_9_AMOUNT'] = t['RATE 9 AMOUNT']
                    if 'ADDITIONAL EARNINGS CODE' in preview_file_keys:
                        position['ADDITIONAL_EARNINGS_CODE'] = t['ADDITIONAL EARNINGS CODE']
                    if 'ADDITIONAL EARNINGS AMOUNT' in preview_file_keys:
                        position['ADDITIONAL_EARNINGS_AMOUNT'] = t['ADDITIONAL EARNINGS AMOUNT']
                    if 'COMPENSATION CHANGE REASON' in preview_file_keys:
                        position['COMPENSATION_CHANGE_REASON'] = t['COMPENSATION CHANGE REASON']
                    if '!!HIRE DATE' in preview_file_keys:
                        position['HIRE_DATE'] = t['!!HIRE DATE']
                    if '!!TERMINATION DATE' in preview_file_keys:
                        position['TERMINATION_DATE'] = t['!!TERMINATION DATE']
                    if '!!LEAVE OF ABSENCE START DATE' in preview_file_keys:
                        position['LEAVE_OF_ABSENCE_START_DATE'] = t['!!LEAVE OF ABSENCE START DATE']
                    if '!!RATE START DATE' in preview_file_keys:
                        position['RATE_START_DATE'] = t['!!RATE START DATE']
                    if '!!STATIC DATE' in preview_file_keys:
                        position['STATIC_DATE'] = t['!!STATIC DATE']
                    my_data = []
                    for key, value in position.items():
                        my_data.append(value)
                        record = tuple(my_data)
                    row_data.append(record)
            for key, value in position.items():
                sql_data += str(key)
                sql_data += ','
            sql_data = sql_data[:-1]
            sql_data += ")\
                                    VALUES ("
            sql_args = ""
            for idx, key in enumerate(position.items()):
                sql_args += ":" + str(idx) + ","
            sql_args = sql_args[:-1]
            sql_data += sql_args + ")"
            self.cursor.executemany(sql_data, row_data)
            query = self.sql_file['update_status']
            self.cursor.execute(query, p_client_id=jsond['client_id'], p_conversion=jsond['conversion_name'])
            result['status'] = 0
            result['msg'] = 'Pay rate preview file uploaded Successfully'
        except Exception as error:
            logger.dthublog("""@ 216 EXCEPTION - models - efn -
                 load_mf_preview """ + str(error))
            result['status'] = 1
            result['msg'] = 'Pay rate preview file failed to upload'
            raise error
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - wfn - load_pay_rate_preview(-)')
        return result

    def load_direct_deposits_preview(self, jsond, tmp_data):
        logger.addinfo('@ models - wfn - load_direct_deposits_preview(+)')
        try:
            row_data = []
            result = {}
            log_data = {
                'client_id': jsond['client_id'],
                'conversion_name': jsond['conversion_name'],
                'user_id': jsond['created_id']
            }
            self.add_client_log(log_data)
            query = self.sql_file['wfn_direct_deposits_sequence']
            self.acquire()
            sql_data = 'insert into dc_wfn_source_dir_dep ('
            for t in tmp_data:
                if t != {}:
                    position = {}
                    data = self.cursor.execute(query).fetchone()
                    preview_file_keys = list(map(lambda x: x.upper(), list(t.keys())))
                    t = {k.upper(): v for k, v in t.items()}
                    position['source_id'] = str(data[0])
                    position['client_id'] = jsond['client_id']
                    position['POSITION_ID'] = ''
                    position['CHANGE_EFFECTIVE_ON'] = ''
                    position['BANK_DEPOSIT_DEDUCTION_CODE'] = ''
                    position['BANK_DEPOSIT_DEDUCTION_AMT'] = ''
                    position['BANK_DEPOSIT_PERCENT_NET'] = ''
                    position['BANK_DEPOSIT_ACCOUNT_NBR'] = ''
                    position['BANK_DEPOSIT_TRANSIT_ABA'] = ''
                    position['BANK_FULL_DEPOSIT_FLAG'] = ''
                    position['BANK_DEPOSIT_PRENOTE_CODE'] = ''
                    position['BANK_DEPOSIT_PRENOTE_DATE'] = ''
                    position['HIRE_DATE'] = ''
                    position['TERMINATION_DATE'] = ''
                    position['LEAVE_OF_ABSENCE_START_DATE'] = ''
                    position['JOB_START_DATE'] = ''
                    position['STATIC_DATE'] = ''
                    position['CREATED_ID'] = jsond['created_id']
                    if 'POSITION ID' in preview_file_keys:
                        position['POSITION_ID'] = t['POSITION ID']
                    if 'CHANGE EFFECTIVE ON' in preview_file_keys:
                        position['CHANGE_EFFECTIVE_ON'] = t['CHANGE EFFECTIVE ON']
                    if 'BANK DEPOSIT DEDUCTION CODE' in preview_file_keys:
                        position['BANK_DEPOSIT_DEDUCTION_CODE'] = t['BANK DEPOSIT DEDUCTION CODE']
                    if 'BANK DEPOSIT DEDUCTION AMOUNT' in preview_file_keys:
                        position['BANK_DEPOSIT_DEDUCTION_AMT'] = t['BANK DEPOSIT DEDUCTION AMOUNT']
                    if 'BANK DEPOSIT PERCENT NET' in preview_file_keys:
                        position['BANK_DEPOSIT_PERCENT_NET'] = t['BANK DEPOSIT PERCENT NET']
                    if 'BANK DEPOSIT ACCOUNT NUMBER' in preview_file_keys:
                        position['BANK_DEPOSIT_ACCOUNT_NBR'] = t['BANK DEPOSIT ACCOUNT NUMBER']
                    if 'BANK DEPOSIT TRANSIT ABA' in preview_file_keys:
                        position['BANK_DEPOSIT_TRANSIT_ABA'] = t['BANK DEPOSIT TRANSIT ABA']
                    if 'BANK FULL DEPOSIT FLAG' in preview_file_keys:
                        position['BANK_FULL_DEPOSIT_FLAG'] = t['BANK FULL DEPOSIT FLAG']
                    if 'BANK DEPOSIT PRENOTE CODE' in preview_file_keys:
                        position['BANK_DEPOSIT_PRENOTE_CODE'] = t['BANK DEPOSIT PRENOTE CODE']
                    if 'BANK DEPOSIT PRENOTE DATE' in preview_file_keys:
                        position['BANK_DEPOSIT_PRENOTE_DATE'] = t['BANK DEPOSIT PRENOTE DATE']
                    if '!!HIRE DATE' in preview_file_keys:
                        position['HIRE_DATE'] = t['!!HIRE DATE']
                    if '!!TERMINATION DATE' in preview_file_keys:
                        position['TERMINATION_DATE'] = t['!!TERMINATION DATE']
                    if '!!LEAVE OF ABSENCE START DATE' in preview_file_keys:
                        position['LEAVE_OF_ABSENCE_START_DATE'] = t['!!LEAVE OF ABSENCE START DATE']
                    if '!!JOB START DATE' in preview_file_keys:
                        position['JOB_START_DATE'] = t['!!JOB START DATE']
                    if '!!STATIC DATE' in preview_file_keys:
                        position['STATIC_DATE'] = t['!!STATIC DATE']
                    my_data = []
                    for key, value in position.items():
                        my_data.append(value)
                        record = tuple(my_data)
                    row_data.append(record)
            for key, value in position.items():
                sql_data += str(key)
                sql_data += ','
            sql_data = sql_data[:-1]
            sql_data += ")\
                                    VALUES ("
            sql_args = ""
            for idx, key in enumerate(position.items()):
                sql_args += ":" + str(idx) + ","
            sql_args = sql_args[:-1]
            sql_data += sql_args + ")"
            self.cursor.executemany(sql_data, row_data)
            query = self.sql_file['update_status']
            self.cursor.execute(query, p_client_id=jsond['client_id'], p_conversion=jsond['conversion_name'])
            result['status'] = 0
            result['msg'] = 'Direct Deposits preview file uploaded Successfully'
        except Exception as error:
            logger.dthublog("""@ 216 EXCEPTION - models - efn -
                 load_mf_preview """ + str(error))
            result['status'] = 1
            result['msg'] = 'Direct deposits preview file failed to upload'
            raise error
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - wfn - load_direct_deposits_preview(-)')
        return result

    def load_deductions_preview(self, jsond, tmp_data):
        logger.addinfo('@ models - wfn - load_deductions_preview(+)')
        try:
            row_data = []
            result = {}
            log_data = {
                'client_id': jsond['client_id'],
                'conversion_name': jsond['conversion_name'],
                'user_id': jsond['created_id']
            }
            self.add_client_log(log_data)
            query = self.sql_file['wfn_deductions_sequence']
            self.acquire()
            sql_data = 'insert into dc_wfn_source_deductions ('
            for t in tmp_data:
                if t != {}:
                    position = {}
                    data = self.cursor.execute(query).fetchone()
                    preview_file_keys = list(map(lambda x: x.upper(), list(t.keys())))
                    t = {k.upper(): v for k, v in t.items()}
                    position['source_id'] = str(data[0])
                    position['client_id'] = jsond['client_id']
                    position['POSITION_ID'] = ''
                    position['CHANGE_EFFECTIVE_ON'] = ''
                    position['DEDUCTION_CODE'] = ''
                    position['DEDUCTION_AMT'] = ''
                    position['DEDUCTION_FACTOR'] = ''
                    position['GOAL_DEDUCTION_CODE'] = ''
                    position['GOAL_POSITION_NBR'] = ''
                    position['GOAL_LIMIT'] = ''
                    position['GOAL_ACCRUAL_ADJUSTMENT'] = ''
                    position['HIRE_DATE'] = ''
                    position['TERMINATION_DATE'] = ''
                    position['LEAVE_OF_ABSENCE_START_DATE'] = ''
                    position['JOB_START_DATE'] = ''
                    position['STATIC_DATE'] = ''
                    position['CREATED_ID'] = jsond['created_id']
                    if 'POSITION ID' in preview_file_keys:
                        position['POSITION_ID'] = t['POSITION ID']
                    if 'CHANGE EFFECTIVE ON' in preview_file_keys:
                        position['CHANGE_EFFECTIVE_ON'] = t['CHANGE EFFECTIVE ON']
                    if 'DEDUCTION CODE' in preview_file_keys:
                        position['DEDUCTION_CODE'] = t['DEDUCTION CODE']
                    if 'DEDUCTION AMT' in preview_file_keys:
                        position['DEDUCTION_AMT'] = t['DEDUCTION AMT']
                    if 'DEDUCTION FACTOR' in preview_file_keys:
                        position['DEDUCTION_FACTOR'] = t['DEDUCTION FACTOR']
                    if 'GOAL DEDUCTION CODE' in preview_file_keys:
                        position['GOAL_DEDUCTION_CODE'] = t['GOAL DEDUCTION CODE']
                    if 'GOAL POSITION NBR' in preview_file_keys:
                        position['GOAL_POSITION_NBR'] = t['GOAL POSITION NBR']
                    if 'GOAL LIMIT' in preview_file_keys:
                        position['GOAL_LIMIT'] = t['GOAL LIMIT']
                    if 'GOAL ACCRUAL ADJUSTMENT' in preview_file_keys:
                        position['GOAL_ACCRUAL_ADJUSTMENT'] = t['GOAL ACCRUAL ADJUSTMENT']
                    if '!!HIRE DATE' in preview_file_keys:
                        position['HIRE_DATE'] = t['!!HIRE DATE']
                    if '!!TERMINATION DATE' in preview_file_keys:
                        position['TERMINATION_DATE'] = t['!!TERMINATION DATE']
                    if '!!LEAVE OF ABSENCE START DATE' in preview_file_keys:
                        position['LEAVE_OF_ABSENCE_START_DATE'] = t['!!LEAVE OF ABSENCE START DATE']
                    if '!!JOB START DATE' in preview_file_keys:
                        position['JOB_START_DATE'] = t['!!JOB START DATE']
                    if '!!STATIC DATE' in preview_file_keys:
                        position['STATIC_DATE'] = t['!!STATIC DATE']
                    my_data = []
                    for key, value in position.items():
                        my_data.append(value)
                        record = tuple(my_data)
                    row_data.append(record)
            for key, value in position.items():
                sql_data += str(key)
                sql_data += ','
            sql_data = sql_data[:-1]
            sql_data += ")\
                                    VALUES ("
            sql_args = ""
            for idx, key in enumerate(position.items()):
                sql_args += ":" + str(idx) + ","
            sql_args = sql_args[:-1]
            sql_data += sql_args + ")"
            self.cursor.executemany(sql_data, row_data)
            query = self.sql_file['update_status']
            self.cursor.execute(query, p_client_id=jsond['client_id'], p_conversion=jsond['conversion_name'])
            result['status'] = 0
            result['msg'] = 'Deductions preview file uploaded Successfully'
        except Exception as error:
            logger.dthublog("""@ 216 EXCEPTION - models - efn -
                 load_mf_preview """ + str(error))
            result['status'] = 1
            result['msg'] = 'Deductions preview file failed to upload'
            raise error
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - wfn - load_deductions_preview(-)')
        return result

    def load_status_preview(self, jsond, tmp_data):
        logger.addinfo('@ models - wfn - load_status_preview(+)')
        try:
            row_data = []
            result = {}
            log_data = {
                'client_id': jsond['client_id'],
                'conversion_name': jsond['conversion_name'],
                'user_id': jsond['created_id']
            }
            self.add_client_log(log_data)
            query = self.sql_file['wfn_status_sequence']
            self.acquire()
            sql_data = 'insert into dc_wfn_source_status ('
            for t in tmp_data:
                if t != {}:
                    position = {}
                    data = self.cursor.execute(query).fetchone()
                    preview_file_keys = list(map(lambda x: x.upper(), list(t.keys())))
                    t = {k.upper(): v for k, v in t.items()}
                    position['source_id'] = str(data[0])
                    position['client_id'] = jsond['client_id']
                    position['POSITION_ID'] = ''
                    position['CHANGE_EFFECTIVE_ON'] = ''
                    position['EMPLOYEE_STATUS'] = ''
                    position['TERMINATION_DATE'] = ''
                    position['TERMINATION_REASON'] = ''
                    position['TERMINATION_COMMENTS'] = ''
                    position['ELIGIBLE_FOR_REHIRE'] = ''
                    position['LEAVE_OF_ABSENCE_START_DATE'] = ''
                    position['LEAVE_OF_ABSENCE_REASON'] = ''
                    position['LEAVE_OF_ABSENCE_IS_PAID'] = ''
                    position['LEAVE_OF_ABSENCE_EXP_RET_DATE'] = ''
                    position['LEAVE_OF_ABSENCE_RETURN_DATE'] = ''
                    position['LEAVE_OF_ABSENCE_RETURN_REASON'] = ''
                    position['HIRE_DATE'] = ''
                    position['JOB_START_DATE'] = ''
                    position['STATIC_DATE'] = ''
                    position['CREATED_ID'] = jsond['created_id']
                    if 'POSITION ID' in preview_file_keys:
                        position['POSITION_ID'] = t['POSITION ID']
                    if 'CHANGE EFFECTIVE ON' in preview_file_keys:
                        position['CHANGE_EFFECTIVE_ON'] = t['CHANGE EFFECTIVE ON']
                    if 'EMPLOYEE STATUS' in preview_file_keys:
                        position['EMPLOYEE_STATUS'] = t['EMPLOYEE STATUS']
                    if 'TERMINATION DATE' in preview_file_keys:
                        position['TERMINATION_DATE'] = t['TERMINATION DATE']
                    if 'TERMINATION REASON' in preview_file_keys:
                        position['TERMINATION_REASON'] = t['TERMINATION REASON']
                    if 'TERMINATION COMMENTS' in preview_file_keys:
                        position['TERMINATION_COMMENTS'] = t['TERMINATION COMMENTS']
                    if 'ELIGIBLE FOR REHIRE' in preview_file_keys:
                        position['ELIGIBLE_FOR_REHIRE'] = t['ELIGIBLE FOR REHIRE']
                    if 'LEAVE OF ABSENCE START DATE' in preview_file_keys:
                        position['LEAVE_OF_ABSENCE_START_DATE'] = t['LEAVE OF ABSENCE START DATE']
                    if 'LEAVE OF ABSENCE REASON' in preview_file_keys:
                        position['LEAVE_OF_ABSENCE_REASON'] = t['LEAVE OF ABSENCE REASON']
                    if 'LEAVE OF ABSENCE IS PAID' in preview_file_keys:
                        position['LEAVE_OF_ABSENCE_IS_PAID'] = t['LEAVE OF ABSENCE IS PAID']
                    if 'LEAVE OF ABSENCE EXPECTED RETURN DATE' in preview_file_keys:
                        position['LEAVE_OF_ABSENCE_EXP_RET_DATE'] = t['LEAVE OF ABSENCE EXPECTED RETURN DATE']
                    if 'LEAVE OF ABSENCE RETURN DATE' in preview_file_keys:
                        position['LEAVE_OF_ABSENCE_RETURN_DATE'] = t['LEAVE OF ABSENCE RETURN DATE']
                    if 'LEAVE OF ABSENCE RETURN REASON' in preview_file_keys:
                        position['LEAVE_OF_ABSENCE_RETURN_REASON'] = t['LEAVE OF ABSENCE RETURN REASON']
                    if '!!HIRE DATE' in preview_file_keys:
                        position['HIRE_DATE'] = t['!!HIRE DATE']
                    if '!!JOB START DATE' in preview_file_keys:
                        position['JOB_START_DATE'] = t['!!JOB START DATE']
                    if '!!STATIC DATE' in preview_file_keys:
                        position['STATIC_DATE'] = t['!!STATIC DATE']
                    my_data = []
                    for key, value in position.items():
                        my_data.append(value)
                        record = tuple(my_data)
                    row_data.append(record)
            for key, value in position.items():
                sql_data += str(key)
                sql_data += ','
            sql_data = sql_data[:-1]
            sql_data += ")\
                                    VALUES ("
            sql_args = ""
            for idx, key in enumerate(position.items()):
                sql_args += ":" + str(idx) + ","
            sql_args = sql_args[:-1]
            sql_data += sql_args + ")"
            self.cursor.executemany(sql_data, row_data)
            query = self.sql_file['update_status']
            self.cursor.execute(query, p_client_id=jsond['client_id'], p_conversion=jsond['conversion_name'])
            result['status'] = 0
            result['msg'] = 'Status preview file uploaded Successfully'
        except Exception as error:
            logger.dthublog("""@ 216 EXCEPTION - models - efn -
                 load_mf_preview """ + str(error))
            result['status'] = 1
            result['msg'] = 'Status preview file failed to upload'
            raise error
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - wfn - load_status_preview(-)')
        return result

    def load_mf_preview(self, jsond, tmp_data):
        logger.addinfo('@ models - wfn - load_mf_preview(+)')
        try:
            row_data = []
            result = {}
            log_data = {
                'client_id': jsond['client_id'],
                'conversion_name': jsond['conversion_name'],
                'user_id': jsond['created_id']
            }
            self.add_client_log(log_data)
            query = self.sql_file['wfn_mf_sequence']
            self.acquire()
            sql_data = 'insert into dc_wfn_source_mf ('
            for t in tmp_data:
                if t != {}:
                    mf = {}
                    data = self.cursor.execute(query).fetchone()
                    preview_file_keys = list(map(lambda x: x.upper(), list(t.keys())))
                    t = {k.upper(): v for k, v in t.items()}
                    mf['source_id'] = str(data[0])
                    mf['client_id'] = jsond['client_id']
                    mf['associate_id'] = ''
                    mf['position_id'] = ''
                    mf['change_effective_on'] = ''
                    mf['is_paid_by_wfn'] = ''
                    mf['position_uses_time'] = ''
                    mf['is_primary'] = ''
                    mf['first_name'] = ''
                    mf['middle_name'] = ''
                    mf['last_name'] = ''
                    mf['generation_suffix'] = ''
                    mf['preferred_name'] = ''
                    mf['social_security_number'] = ''
                    mf['applied_for_ssn'] = ''
                    mf['address_1_line_1'] = ''
                    mf['address_1_line_2'] = ''
                    mf['address_1_line_3'] = ''
                    mf['address_1_city'] = ''
                    mf['address_1_state_postal_code'] = ''
                    mf['address_1_zip_code'] = ''
                    mf['address_2_line_1'] = ''
                    mf['address_2_line_2'] = ''
                    mf['address_2_line_3'] = ''
                    mf['preferred_name'] = ''
                    mf['address_2_city'] = ''
                    mf['address_2_state_postal_code'] = ''
                    mf['address_2_zip_code'] = ''
                    mf['birth_date'] = ''
                    mf['hire_date'] = ''
                    mf['hire_reason'] = ''
                    mf['employee_status'] = ''
                    mf['pay_frequency_code'] = ''
                    mf['compensation_change_reason'] = ''
                    mf['rate_type'] = ''
                    mf['rate_1_amount'] = ''
                    mf['reports_to_position_id'] = ''
                    mf['actual_marital_status'] = ''
                    mf['eeo_ethnic_code'] = ''
                    mf['home_phone_number'] = ''
                    mf['personal_email_address'] = ''
                    mf['business_email_address'] = ''
                    mf['email_to_use_for_notification'] = ''
                    mf['business_area_code'] = ''
                    mf['business_extension'] = ''
                    mf['personal_cell_number'] = ''
                    mf['business_phone_number'] = ''
                    mf['seniority_date'] = ''
                    mf['clock'] = ''
                    mf['employee_type'] = ''
                    mf['gender'] = ''
                    mf['ncalculate_medicare'] = ''
                    mf['ncalculate_social_security'] = ''
                    mf['federal_marital_status'] = ''
                    mf['federal_exemptions'] = ''
                    mf['ncalculate_federal_tax'] = ''
                    mf['federal_extra_tax_$'] = ''
                    mf['worked_state_tax_code'] = ''
                    mf['w_state_marital_status'] = ''
                    mf['w_state_exemptions'] = ''
                    mf['exemptions_in_dollars'] = ''
                    mf['state_withholding_table'] = ''
                    mf['w_nstate_extra_tax_$'] = ''
                    mf['w_nstate_extra_tax_p'] = ''
                    mf['w_ncalculate_state_tax'] = ''
                    mf['w_ncalc_oregon_transit_tax'] = ''
                    mf['lived_state_tax_code'] = ''
                    mf['family_leave_insurance'] = ''
                    mf['medical_leave_insurance'] = ''
                    mf['suisdi_tax_jurisdiction_code'] = ''
                    mf['maryland_county_tax_percentage'] = ''
                    mf['ohio_local_school_district_tax'] = ''
                    mf['ncalc_school_district_tax'] = ''
                    mf['worked_local_tax_code'] = ''
                    mf['w_local_exemptions'] = ''
                    mf['lived_local_tax_code'] = ''
                    mf['l_local_exemptions'] = ''
                    mf['local_4_tax_code'] = ''
                    mf['local_5_tax_code'] = ''
                    mf['local_extra_tax_$'] = ''
                    mf['local_extra_tax_p'] = ''
                    mf['created_id'] = jsond['created_id']
                    if 'ASSOCIATE ID' in preview_file_keys:
                        mf['associate_id'] = t['ASSOCIATE ID']
                    if 'POSITION ID' in preview_file_keys:
                        mf['position_id'] = t['POSITION ID']
                    if 'CHANGE EFFECTIVE ON' in preview_file_keys:
                        mf['change_effective_on'] = t['CHANGE EFFECTIVE ON']
                    if 'IS PAID BY WFN' in preview_file_keys:
                        mf['is_paid_by_wfn'] = t['IS PAID BY WFN']
                    if 'POSITION USES TIME' in preview_file_keys:
                        mf['position_uses_time'] = t['POSITION USES TIME']
                    if 'IS PRIMARY' in preview_file_keys:
                        mf['is_primary'] = t['IS PRIMARY']
                    if 'FIRST NAME' in preview_file_keys:
                        mf['first_name'] = t['FIRST NAME']
                    if 'MIDDLE NAME' in preview_file_keys:
                        mf['middle_name'] = t['MIDDLE NAME']
                    if 'LAST NAME' in preview_file_keys:
                        mf['last_name'] = t['LAST NAME']
                    if 'GENERATION SUFFIX' in preview_file_keys:
                        mf['generation_suffix'] = t['GENERATION SUFFIX']
                    if 'Preferred Namee' in preview_file_keys:
                        mf['PREFERRED NAME'] = t['PREFERRED NAME']
                    if 'SOCIAL SECURITY NUMBER' in preview_file_keys:
                        mf['social_security_number'] = t['SOCIAL SECURITY NUMBER']
                    if 'APPLIED FOR SSN' in preview_file_keys:
                        mf['applied_for_ssn'] = t['APPLIED FOR SSN']
                    if 'ADDRESS 1 LINE 1' in preview_file_keys:
                        mf['address_1_line_1'] = t['ADDRESS 1 LINE 1']
                    if 'ADDRESS 1 LINE 2' in preview_file_keys:
                        mf['address_1_line_2'] = t['ADDRESS 1 LINE 2']
                    if 'ADDRESS 1 LINE 3' in preview_file_keys:
                        mf['address_1_line_3'] = t['ADDRESS 1 LINE 3']
                    if 'ADDRESS 1 CITY' in preview_file_keys:
                        mf['address_1_city'] = t['ADDRESS 1 CITY']
                    if 'ADDRESS 1 STATE POSTAL CODE' in preview_file_keys:
                        mf['address_1_state_postal_code'] = t['ADDRESS 1 STATE POSTAL CODE']
                    if 'ADDRESS 1 ZIP CODE' in preview_file_keys:
                        mf['address_1_zip_code'] = t['ADDRESS 1 ZIP CODE']
                    if 'ADDRESS 2 LINE 1' in preview_file_keys:
                        mf['address_2_line_1'] = t['ADDRESS 2 LINE 1']
                    if 'ADDRESS 2 LINE 2' in preview_file_keys:
                        mf['address_2_line_2'] = t['ADDRESS 2 LINE 2']
                    if 'ADDRESS 2 LINE 3' in preview_file_keys:
                        mf['address_2_line_3'] = t['ADDRESS 2 LINE 3']
                    if 'ADDRESS 2 CITY' in preview_file_keys:
                        mf['address_2_city'] = t['ADDRESS 2 CITY']
                    if 'ADDRESS 2 STATE POSTAL CODE' in preview_file_keys:
                        mf['address_2_state_postal_code'] = t['ADDRESS 2 STATE POSTAL CODE']
                    if 'ADDRESS 2 ZIP CODE' in preview_file_keys:
                        mf['address_2_zip_code'] = t['ADDRESS 2 ZIP CODE']
                    if 'BIRTH DATE' in preview_file_keys:
                        mf['birth_date'] = t['BIRTH DATE']
                    if 'HIRE DATE' in preview_file_keys:
                        mf['hire_date'] = t['HIRE DATE']
                    if 'HIRE REASON' in preview_file_keys:
                        mf['hire_reason'] = t['HIRE REASON']
                    if 'EMPLOYEE STATUS' in preview_file_keys:
                        mf['employee_status'] = t['EMPLOYEE STATUS']
                    if 'PAY FREQUENCY CODE' in preview_file_keys:
                        mf['pay_frequency_code'] = t['PAY FREQUENCY CODE']
                    if 'COMPENSATION CHANGE REASON' in preview_file_keys:
                        mf['compensation_change_reason'] = t['COMPENSATION CHANGE REASON']
                    if 'RATE TYPE' in preview_file_keys:
                        mf['rate_type'] = t['RATE TYPE']
                    if 'RATE 1 AMOUNT' in preview_file_keys:
                        mf['rate_1_amount'] = t['RATE 1 AMOUNT']
                    if 'REPORTS TO POSITION ID' in preview_file_keys:
                        mf['reports_to_position_id'] = t['REPORTS TO POSITION ID']
                    if 'ACTUAL MARITAL STATUS' in preview_file_keys:
                        mf['actual_marital_status'] = t['ACTUAL MARITAL STATUS']
                    if 'ACTUAL NUMBER OF DEPENDENTS' in preview_file_keys:
                        mf['actual_number_of_dependents'] = t['ACTUAL NUMBER OF DEPENDENTS']
                    if 'EEO ETHNIC CODE' in preview_file_keys:
                        mf['eeo_ethnic_code'] = t['EEO ETHNIC CODE']
                    if 'HOME AREA CODE' in preview_file_keys:
                        mf['home_area_code'] = t['HOME AREA CODE']
                    if 'HOME PHONE NUMBER' in preview_file_keys:
                        mf['home_phone_number'] = t['HOME PHONE NUMBER']
                    if 'PERSONAL E-MAIL ADDRESS' in preview_file_keys:
                        mf['personal_email_address'] = t['PERSONAL E-MAIL ADDRESS']
                    if 'BUSINESS E-MAIL ADDRESS' in preview_file_keys:
                        mf['business_email_address'] = t['BUSINESS E-MAIL ADDRESS']
                    if 'E-MAIL TO USE FOR NOTIFICATION' in preview_file_keys:
                        mf['email_to_use_for_notification'] = t['E-MAIL TO USE FOR NOTIFICATION']
                    if 'BUSINESS AREA CODE OR WORK AREA CODE' in preview_file_keys:
                        mf['business_area_code'] = t['BUSINESS AREA CODE OR WORK AREA CODE']
                    if 'BUSINESS EXTENSION OR WORK EXTENSION' in preview_file_keys:
                        mf['business_extension'] = t['BUSINESS EXTENSION OR WORK EXTENSION']
                    if 'BUSINESS PHONE NUMBER OR WORK PHONE NUMBER' in preview_file_keys:
                        mf['business_phone_number'] = t['BUSINESS PHONE NUMBER OR WORK PHONE NUMBER']
                    if 'PERSONAL CELL NUMBER' in preview_file_keys:
                        mf['personal_cell_number'] = t['PERSONAL CELL NUMBER']
                    if 'MOBILE PHONE NUMBER' in preview_file_keys:
                        mf['personal_cell_number'] = t['MOBILE PHONE NUMBER']
                    if 'SENIORITY DATE' in preview_file_keys:
                        mf['seniority_date'] = t['SENIORITY DATE']
                    date_11 = ''
                    date_12 = ''
                    date_13 = ''
                    date_14 = ''
                    date_15 = ''
                    if 'CLOCK' in preview_file_keys:
                        mf['clock'] = t['CLOCK']
                    if 'EMPLOYEE TYPE' in preview_file_keys:
                        mf['employee_type'] = t['EMPLOYEE TYPE']
                    if 'GENDER' in preview_file_keys:
                        mf['gender'] = t['GENDER']
                    if 'DO NOT CALCULATE MEDICARE' in preview_file_keys:
                        mf['ncalculate_medicare'] = t['DO NOT CALCULATE MEDICARE']
                    if 'Do Not Calculate SOCIAL SECURITY' in preview_file_keys:
                        mf['ncalculate_social_security'] = t['Do Not Calculate SOCIAL SECURITY']
                    if 'FEDERAL MARITAL STATUS' in preview_file_keys:
                        mf['federal_marital_status'] = t['FEDERAL MARITAL STATUS']
                    if 'FEDERAL EXEMPTIONS' in preview_file_keys:
                        mf['federal_exemptions'] = t['FEDERAL EXEMPTIONS']
                    if 'DO NOT CALCULATE FEDERAL TAX' in preview_file_keys:
                        mf['ncalculate_federal_tax'] = t['DO NOT CALCULATE FEDERAL TAX']
                    if 'FEDERAL EXTRA TAX $' in preview_file_keys:
                        mf['federal_extra_tax_$'] = t['FEDERAL EXTRA TAX $']
                    if 'FEDERAL EXTRA TAX %' in preview_file_keys:
                        mf['federal_extra_tax_p'] = t['FEDERAL EXTRA TAX %']
                    if 'WORKED STATE TAX CODE' in preview_file_keys:
                        mf['worked_state_tax_code'] = t['WORKED STATE TAX CODE']
                    if 'STATE MARITAL STATUS' in preview_file_keys:
                        mf['w_state_marital_status'] = t['STATE MARITAL STATUS']
                    if 'STATE EXEMPTIONS' in preview_file_keys:
                        mf['w_state_exemptions'] = t['STATE EXEMPTIONS']
                    if 'EXEMPTIONS IN DOLLARS' in preview_file_keys:
                        mf['exemptions_in_dollars'] = t['EXEMPTIONS IN DOLLARS']
                    if 'STATE WITHHOLDING TABLE' in preview_file_keys:
                        mf['state_withholding_table'] = t['STATE WITHHOLDING TABLE']
                    if 'STATE EXTRA TAX $' in preview_file_keys:
                        mf['w_nstate_extra_tax_$'] = t['STATE EXTRA TAX $']
                    if 'STATE EXTRA TAX %' in preview_file_keys:
                        mf['w_nstate_extra_tax_p'] = t['STATE EXTRA TAX %']
                    if 'DO NOT CALCULATE STATE TAX' in preview_file_keys:
                        mf['w_ncalculate_state_tax'] = t['DO NOT CALCULATE STATE TAX']
                    if 'DO NOT CALC OREGON TRANSIT TAX' in preview_file_keys:
                        mf['w_ncalc_oregon_transit_tax'] = t['DO NOT CALC OREGON TRANSIT TAX']
                    if 'LIVED STATE TAX CODE' in preview_file_keys:
                        mf['lived_state_tax_code'] = t['LIVED STATE TAX CODE']
                    # l_state_marital_status = t['State Marital Status']
                    # l_state_exemptions = t['State Exemptions']
                    # l_state_extra_tax_ = t['']
                    # l_state_extra_tax_p = t['']
                    # l_ncalculate_state_tax = t['']
                    # l_ncalc_oregon_transit_tax = t['']
                    if 'FAMILY LEAVE INSURANCE' in preview_file_keys:
                        mf['family_leave_insurance'] = t['FAMILY LEAVE INSURANCE']
                    if 'MEDICAL LEAVE INSURANCE' in preview_file_keys:
                        mf['medical_leave_insurance'] = t['MEDICAL LEAVE INSURANCE']
                    if 'SUI/SDI TAX JURISDICTION CODE' in preview_file_keys:
                        mf['suisdi_tax_jurisdiction_code'] = t['SUI/SDI TAX JURISDICTION CODE']
                    if 'MARYLAND COUNTY TAX PERCENTAGE' in preview_file_keys:
                        mf['maryland_county_tax_percentage'] = t['MARYLAND COUNTY TAX PERCENTAGE']
                    if 'OHIO LOCAL SCHOOL DISTRICT TAX CODE' in preview_file_keys:
                        mf['ohio_local_school_district_tax'] = t['OHIO LOCAL SCHOOL DISTRICT TAX CODE']
                    if 'DO NOT CALC SCHOOL DISTRICT TAX' in preview_file_keys:
                        mf['ncalc_school_district_tax'] = t['DO NOT CALC SCHOOL DISTRICT TAX']
                    if 'WORKED LOCAL TAX CODE' in preview_file_keys:
                        mf['worked_local_tax_code'] = t['WORKED LOCAL TAX CODE']
                    if 'LOCAL EXEMPTIONS' in preview_file_keys:
                        mf['w_local_exemptions'] = t['LOCAL EXEMPTIONS']
                    if 'LIVED LOCAL TAX CODE' in preview_file_keys:
                        mf['lived_local_tax_code'] = t['LIVED LOCAL TAX CODE']
                    if 'LOCAL EXEMPTIONS' in preview_file_keys:
                        mf['l_local_exemptions'] = t['LOCAL EXEMPTIONS']
                    if 'LOCAL 4 TAX CODE' in preview_file_keys:
                        mf['local_4_tax_code'] = t['LOCAL 4 TAX CODE']
                    if 'LOCAL 5 TAX CODE' in preview_file_keys:
                        mf['local_5_tax_code'] = t['LOCAL 5 TAX CODE']
                    if 'LOCAL EXTRA TAX $' in preview_file_keys:
                        mf['local_extra_tax_$'] = t['LOCAL EXTRA TAX $']
                    if 'LOCAL EXTRA TAX %' in preview_file_keys:
                        mf['local_extra_tax_p'] = t['LOCAL EXTRA TAX %']
                    my_data = []
                    for key, value in mf.items():
                        my_data.append(value)
                        record = tuple(my_data)
                    row_data.append(record)
            for key, value in mf.items():
                sql_data += str(key)
                sql_data += ','
            sql_data = sql_data[:-1]
            sql_data += ")\
                                    VALUES ("
            sql_args = ""
            for idx, key in enumerate(mf.items()):
                sql_args += ":" + str(idx) + ","
            sql_args = sql_args[:-1]
            sql_data += sql_args + ")"
            self.cursor.executemany(sql_data, row_data)
            query = self.sql_file['update_status']
            self.cursor.execute(query, p_client_id=jsond['client_id'], p_conversion=jsond['conversion_name'])
            result['status'] = 0
            result['msg'] = 'MF preview file uploaded Successfully'
        except Exception as error:
            logger.dthublog("""@ 216 EXCEPTION - models - efn -
                 load_mf_preview """ + str(error))
            result['status'] = 1
            result['msg'] = 'MF preview file failed to upload'
            raise error
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - wfn - load_mf_preview(-)')
        return result

    def read_preview_file(self, jsond):
        logger.addinfo('@ models - wfn - read_preview_file(+)')
        try:
            result = {}
            self.acquire()
            load_details = {
                'client_id': jsond['client_id'],
                'created_id': jsond['user_id'],
                'conversion_name': jsond['conversion_name']
            }
            decoded = base64.b64decode(jsond['base64'])
            file_name = self.id_generator() + '.csv'
            text_file = open(file_name, 'wb')
            text_file.write(decoded)
            text_file.close()
            tmp_data = self.csv_reading(file_name)
            if tmp_data == 'error':
                logger.addinfo("@ models - contacts - read_preview_file(-)")
                return 'error'
            if jsond['conversion_name'] == 'master-file':
                result = self.load_mf_preview(load_details, tmp_data)
            elif jsond['conversion_name'] == 'position':
                result = self.load_position_preview(load_details, tmp_data)
            elif jsond['conversion_name'] == 'pay-rate':
                result = self.load_pay_rate_preview(load_details, tmp_data)
            elif jsond['conversion_name'] == 'direct-deposits':
                result = self.load_direct_deposits_preview(load_details, tmp_data)
            elif jsond['conversion_name'] == 'deductions':
                result = self.load_deductions_preview(load_details, tmp_data)
            elif jsond['conversion_name'] == 'status':
                result = self.load_status_preview(load_details, tmp_data)
        except Exception as error:
            logger.dthublog("""@ 216 EXCEPTION - models - contacts -
                 read_preview_file """ + str(error))
            raise error
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - wfn - read_preview_file(-)')
        return result

    @staticmethod
    def preview_parser(file_name, random_string):
        logger.addinfo('@ models - wfn - parse_preview(+)')
        result = {}
        try:
            f = open(file_name)
            lines = f.readlines()
            if not (lines[0][:4]).strip() == 'Step':
                return {
                    'status': 1,
                    'msg': 'Uploaded preview error file is not in proper format'
                }
            line_list = []
            doc_list = []
            column_list = []
            for line in lines:
                if '-----' in line:
                    doc_list.append(line_list)
                    line_list = []
                    continue
                elif 'Step:' in line:
                    continue
                elif 'Message Type:' in line:
                    continue
                elif 'Error Sub Index:' in line:
                    continue
                elif 'TXID:' in line:
                    continue
                elif 'Original Source Record:' in line:
                    continue
                else:
                    line_list.append(line)
            workbook = openpyxl.Workbook()
            sheet = workbook.active
            column_flag = 'N'
            # adding column names
            column_list.append('Error Msg')
            for line in doc_list[0]:
                list = line.strip().split(':')
                if 'Source Object:' in line:
                    column_flag = 'Y'
                    continue
                if column_flag == 'Y':
                    if len(list) > 1:
                        column_list.append(list[0])
            column = 0
            for value in column_list:
                column += 1
                sheet.cell(row=1, column=column, value=value)
            # adding values to the excel file
            row = 1
            for i in range(len(doc_list)):
                row += 1
                value_flag = 'N'
                error_msg = ''
                sub_index = 0
                for line in doc_list[i]:
                    value = ''
                    list = line.strip().split(':')
                    if value_flag == 'N':
                        if 'Message:' in line:
                            if len(list) > 3:
                                error_msg += list[1] + ' - ' + list[2] + '-' + list[3] + '-'
                            elif len(list) > 2:
                                error_msg += list[1] + ' - ' + list[2] + '-'
                            else:
                                error_msg += list[1] + ' - '
                        error_msg += list[0]
                    if 'Source Object:' in line:
                        value_flag = 'Y'
                        sheet.cell(row=row, column=1, value=error_msg)
                        continue
                    if value_flag == 'Y':
                        sheet.cell(row=row, column=1, value=error_msg)
                    if list[0] in column_list:
                        column = column_list.index(list[0])
                        if 'H/E/D/T' in column_list:
                            hedt_index = column_list.index('H/E/D/T')
                        if 'H/E/D/T' in line:
                            sub_index += 1
                        if 'H/E/D/T' in line and sub_index > 1:
                            for k in range(hedt_index + 1):
                                sheet.cell(row=row+1, column=k+2, value=sheet.cell(row=row, column=k+2).value)
                            row += 1
                        if len(list) > 1:
                            value = list[1]
                        sheet.cell(row=row, column=column + 1, value=value)
            bold_font = Font(color='FF000000', bold=True, size=12)
            for cell in sheet["1:1"]:
                cell.font = bold_font
            workbook.save(filename='/tmp/' + random_string + '.xlsx')
            f.close()
            result['file_data'] = base64.b64encode(open('/tmp/' + random_string + '.xlsx', 'rb').read())
            os.remove('/tmp/' + random_string + '.xlsx')
            os.remove(file_name)
        except Exception as error:
            logger.dthublog("""@ 216 EXCEPTION - models - contacts -
                     parse_preview """ + str(error))
            raise error
        logger.addinfo('@ models - wfn - parse_preview(-)')
        return result

    @staticmethod
    def parse_preview(file_name, random_string):
        logger.addinfo('@ models - wfn - parse_preview(+)')
        try:
            result = {}
            f = open(file_name)
            lines = f.readlines()
            row = 2
            column = 1
            if not (lines[0][:4]).strip() == 'Step':
                return {
                    'status': 1,
                    'msg': 'Uploaded preview error file is not in proper format'
                }
            workbook = openpyxl.Workbook()
            sheet = workbook.active
            error_msg = ''
            txn_flag = 'N'
            error = ''
            error_flag = 'N'
            multi_line_flag = 'N'
            column_list = []
            source_obj_flag = 'N'
            for line in lines:
                list = line.strip().split(':')
                if '-----' in list[0]:
                    row += 1
                    column = 1
                    error_msg = ''
                    txn_flag = 'N'
                    error = ''
                    error_flag = 'N'
                    multi_line_flag = 'N'
                    source_obj_flag = 'N'
                    column_list = []
                if list[0] == 'Message':
                    error = line.split('Message:')[1]
                    error_flag = 'Y'
                if 'Unable to load record because parent record' in list[0]:
                    error = list[0]
                    continue
                if list[0] == 'TXID':
                    txn_flag = 'Y'
                    continue
                if list[0] == 'Source Object':
                    source_obj_flag = 'Y'
                    error_flag = 'N'
                    continue
                if source_obj_flag == 'Y' and len(list) > 1:
                    column_list.append(list[1])
                if list[0] == 'H/E/D/T' and multi_line_flag == 'Y':
                    row += 1
                    column = 1
                    if len(error_msg) > 0:
                        sheet.cell(row=row, column=column, value=error_msg)
                    else:
                        sheet.cell(row=row, column=column, value=error)
                    for column_value in column_list:
                        column += 1
                        sheet.cell(row=row, column=column, value=column_value)
                if list[0] == 'H/E/D/T':
                    multi_line_flag = 'Y'
                    source_obj_flag = 'N'
                    continue
                if txn_flag == 'Y':
                    error_msg += line
                if list[0] == 'Error Sub Index':
                    list[0] = 'Error Message'
                    txn_flag = 'N'
                if txn_flag == 'Y' and len(list) > 1:
                    continue
                if error_flag == 'Y' and len(list) > 1:
                    if 'ORA-00001' in list[1]:
                        continue
                    elif 'exceeds the maximum length' in list[1]:
                        continue
                if list[0] not in ['Step', 'Message Type', 'Original Source Record', 'Source Object',
                                   'The fields causing the error are', 'Message', '\n'] and len(list) > 1:
                    if row == 2:
                        sheet.cell(row=1, column=column, value=list[0])
                    if list[0] == 'Error Message':
                        if len(error_msg) > 0:
                            sheet.cell(row=row, column=column, value=error_msg)
                        else:
                            sheet.cell(row=row, column=column, value=error)
                    else:
                        sheet.cell(row=row, column=column, value=list[1])
                    column += 1
            bold_font = Font(color='FF000000', bold=True, size=12)
            for cell in sheet["1:1"]:
                cell.font = bold_font
            workbook.save(filename='/tmp/' + random_string + '.xlsx')
            f.close()
            result['file_data'] = base64.b64encode(open('/tmp/' + random_string + '.xlsx', 'rb').read())
            os.remove('/tmp/' + random_string + '.xlsx')
            os.remove(file_name)
        except Exception as error:
            logger.dthublog("""@ 216 EXCEPTION - models - contacts -
                     parse_preview """ + str(error))
            raise error
        logger.addinfo('@ models - wfn - parse_preview(-)')
        return result

    @staticmethod
    def parse_insert(file_name, random_string):
        logger.addinfo('@ models - wfn - parse_insert(+)')
        try:
            result = {}
            f = open(file_name)
            lines = f.readlines()
            row = 2
            column = 1
            if not (lines[0][:8]).strip() == 'POSITION':
                return {
                    'status': 1,
                    'msg': 'Uploaded insert error file is not in proper format'
                }
            workbook = openpyxl.Workbook()
            sheet = workbook.active
            for line in lines:
                list = line.split(':', 1)
                if '-----' in list[0]:
                    row += 1
                    column = 1
                if list[0] not in ['Message Type', '\n'] and len(list) > 1:
                    if row == 2:
                        sheet.cell(row=1, column=column, value=list[0])
                    sheet.cell(row=row, column=column, value=list[1])
                    column += 1
            bold_font = Font(color='FF000000', bold=True, size=12)
            for cell in sheet["1:1"]:
                cell.font = bold_font
            workbook.save(filename='/tmp/' + random_string + '.xlsx')
            f.close()
            result['file_data'] = base64.b64encode(open('/tmp/' + random_string + '.xlsx', 'rb').read())
            os.remove('/tmp/' + random_string + '.xlsx')
            os.remove(file_name)
        except Exception as error:
            logger.dthublog("""@ 216 EXCEPTION - models - contacts -
                     parse_insert """ + str(error))
            raise error
        logger.addinfo('@ models - wfn - parse_insert(-)')
        return result

    @staticmethod
    def parse_preval(old_file_name, random_string):
        logger.addinfo('@ models - wfn - parse_preval(+)')
        try:
            result = {}
            file_name = '/tmp/' + random_string + '.csv'
            os.rename(old_file_name, file_name)
            f = open(file_name)
            lines = f.readlines()
            if not lines[0][:4] == 'Row,':
                return {
                    'status': 1,
                    'msg': 'Uploaded pre-val/CMD error file is not in proper format'
                }
            f.close()
            read_file = pd.read_csv(file_name)
            read_file.to_excel('/tmp/' + random_string + '.xlsx', index=None, header=True)
            result['file_data'] = base64.b64encode(open('/tmp/' + random_string + '.xlsx', 'rb').read())
            os.remove('/tmp/' + random_string + '.xlsx')
            os.remove(file_name)
        except Exception as error:
            logger.dthublog("""@ 216 EXCEPTION - models - contacts -
                     parse_preval """ + str(error))
            raise error
        logger.addinfo('@ models - wfn - parse_preval(-)')
        return result

    def parse_error_log(self, jsond):
        logger.addinfo('@ models - wfn - parse_error_log(+)')
        try:
            result = {}
            decoded = base64.b64decode(jsond['base64'])
            if jsond['file_extension'] == 'ZIP':
                random_string = CommonUtils.generate_random_string(10)
                # Create file in tmp folder
                temp_file_name = '/tmp/' + random_string + '.zip'

                # Open file in write mode and write decoded excel content
                text_file = open(temp_file_name, 'wb')
                text_file.write(decoded)
                text_file.close()
                with zipfile.ZipFile(temp_file_name, 'r') as zip:
                    zip.extractall('/tmp/' + random_string)
                files = os.listdir('/tmp/' + random_string)
                for f in files:
                    file_name = '/tmp/' + random_string + '/' + f
            else:
                random_string = self.id_generator()
                file_name = '/tmp/' + random_string + '.txt'
                text_file = open(file_name, 'w')
                text_file.write(decoded.decode("utf-8", 'ignore'))
                text_file.close()
            if jsond['run_type'] == 'preview':
                result = self.preview_parser(file_name, random_string)
            elif jsond['run_type'] == 'preval':
                result = self.parse_preval(file_name, random_string)
            elif jsond['run_type'] == 'insert':
                result = self.parse_insert(file_name, random_string)
        except Exception as error:
            logger.dthublog("""@ 216 EXCEPTION - models - contacts -
                 parse_error_log """ + str(error))
            raise error
        logger.addinfo('@ models - wfn - parse_error_log(-)')
        return result

    def run_validation_report(self, data):
        logger.addinfo('@ models - wfn - run_validation_report(+)')
        try:
            result = {}
            self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            if data['conversion_name'] == 'master-file':
                self.cursor.execute("""
                begin
                    NAS_WFN_PKG_VALIDATION.validate_mf(:p_client_id,
                    :x_status_code);
                end; """, p_client_id=data['client_id'],
                                    x_status_code=status_code)
            elif data['conversion_name'] == 'position':
                self.cursor.execute("""
                begin
                    NAS_WFN_PKG_VALIDATION.validate_position(:p_client_id,
                    :x_status_code);
                end; """, p_client_id=data['client_id'],
                                    x_status_code=status_code)
            elif data['conversion_name'] == 'pay-rate':
                self.cursor.execute("""
                begin
                    NAS_WFN_PKG_VALIDATION.validate_rates(:p_client_id,
                    :x_status_code);
                end; """, p_client_id=data['client_id'],
                                    x_status_code=status_code)
            elif data['conversion_name'] == 'direct-deposits':
                self.cursor.execute("""
                begin
                    NAS_WFN_PKG_VALIDATION.validate_dirdep(:p_client_id,
                    :x_status_code);
                end; """, p_client_id=data['client_id'],
                                    x_status_code=status_code)
            elif data['conversion_name'] == 'deductions':
                self.cursor.execute("""
                begin
                    NAS_WFN_PKG_VALIDATION.validate_deductions(:p_client_id,
                    :x_status_code);
                end; """, p_client_id=data['client_id'],
                                    x_status_code=status_code)
            elif data['conversion_name'] == 'status':
                self.cursor.execute("""
                begin
                    NAS_WFN_PKG_VALIDATION.validate_status(:p_client_id,
                    :x_status_code);
                end; """, p_client_id=data['client_id'],
                                    x_status_code=status_code)
            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'Report Generated successfully'
            else:
                result['status'] = 1
                result['msg'] = 'Failed to generate Validation Report ' + str(status)
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - wfn -
                             run_validation_report """ + str(e))
            raise e
        finally:
            self.connection.commit()
            self.release()
        logger.addinfo('models - wfn - delete_client(-)')
        return result

    def get_preview_summary(self, user_id):
        logger.addinfo('@ models - wfn - get_balances_summary(+)')
        result = dict()
        try:
            self.acquire()
            self.cursor.execute(self.sql_file['preview_summary'], p_user_id=user_id)
            summary = Code_util.iterate_data(self.cursor)
            result['status'] = 0
            result['result'] = summary
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - wfn -
                get_balances_summary """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - wfn - get_balances_summary(-)')
        return result

    def download_error_report(self, client_id, conversion_name):
        logger.addinfo('@ models - wfn - download_error_report(+)')
        try:
            result = {}
            self.acquire()
            query = self.sql_file['get_mf_errors']
            self.cursor.execute(query, p_client_id=client_id,
                                p_conversion_name=conversion_name)
            error_log = Code_util.iterate_data(self.cursor)
            if len(error_log) > 0:
                result['file_data'] = CommonUtils.dict_to_excel(error_log)
            else:
                result['msg'] = 'Your file is Error free'
            result['status'] = 0
        except Exception as e:
            logger.dthublog("""@ EXCEPTION - models - wfn -
                download_error_report """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - wfn - download_error_report(-)')
        return result

    def download_summary_error_report(self, client_id, conversion_name):
        logger.addinfo('@ models - wfn - download_summary_error_report(+)')
        try:
            result = {}
            self.acquire()
            query = self.sql_file['get_mf_summary_errors']
            self.cursor.execute(query, p_client_id=client_id,
                                p_conversion_name=conversion_name)
            error_log = Code_util.iterate_data(self.cursor)
            if len(error_log) > 0:
                result['file_data'] = CommonUtils.dict_to_excel(error_log)
            else:
                result['msg'] = 'Your file is Error free'
            result['status'] = 0
        except Exception as e:
            logger.dthublog("""@ EXCEPTION - models - wfn -
                download_summary_error_report """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - wfn - download_summary_error_report(-)')
        return result

    def add_client_log(self, req):
        result = dict()
        logger.addinfo('@ models - wfn - add_client_log(+)')
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                                  begin
                                        NAS_WFN_VALIDATION_PKG.add_wfn_log(
                                        :p_client_id,
                                        :p_conversion_name,
                                        :p_user_id,                                            
                                        :x_status_code
                                        );
                                    end; """, p_client_id=req['client_id'],
                                p_conversion_name=req['conversion_name'],
                                p_user_id=req['user_id'],
                                x_status_code=status_code)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'WFN log updated'
            else:
                result['status'] = 1
                result['msg'] = 'Failed to update WFN log- ' + str(status)
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - wfn -
                            add_client_log """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - wfn - add_client_log(-)')
        return result

    @staticmethod
    def csv_reading(file_name):
        logger.addinfo('@ models - wfn - csv_reading(+)')
        array = []
        try:
            with open(file_name, 'r', encoding='utf-8', errors='ignore') as csvFile:
                file_data = csv.reader(csvFile)
                for row in file_data:
                    array.append(row)
                tmp_array = []
                for j in range(1, len(array)):
                    tmp = [0] * len(array[j])
                    for i in range(len(array[j])):
                        tmp[i] = array[j][i].strip('"')
                    tmp_array.append(tmp)
                header_array = [0] * len(array[0])
                for i in range(len(array[0])):
                    header_array[i] = array[0][i].strip('"')
            final_data = []
            for i in range(len(tmp_array)):
                combo = zip(header_array, tmp_array[i])
                who = dict(combo)
                final_data.append(who)
            os.remove(file_name)
        except Exception as error:
            logger.dthublog("""@ 246 EXCEPTION - models - wfn -
                 csv_reading """ + str(error))
            raise error
        logger.addinfo('@ models - wfn - csv_reading(-)')
        return final_data
