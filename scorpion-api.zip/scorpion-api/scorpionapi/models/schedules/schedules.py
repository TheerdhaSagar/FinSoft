from __future__ import absolute_import

import cx_Oracle

from scorpionapi.utils import db_util
from scorpionapi.utils.logdata import logger

from scorpionapi.utils.code_util import Code_util


class Schedules:

    def __init__(self, **kwargs):
        for name, value in kwargs.items():
            setattr(self, name, value)

    @staticmethod
    def head_id():
        logger.addinfo('@models - schedules - head_id(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['schedule_header_sequence']
            data = cursor.execute(query).fetchone()
            header_id = str(data[0])
        except Exception as error:
            logger.dthublog("""@ 25 EXCEPTION - models - schedules -
                 header_id """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo("@ models - schedules - header_id(-)")
        return header_id

    @staticmethod
    def validate_leaves(lines):
        con = db_util.get_connection()
        sql_file = db_util.getSqlData()
        cur = con.cursor()
        for line in lines:
            query = sql_file['chk_leave_details']
            cur.execute(query, p_run_date=line['RUN_DATE'],
                        p_org_id=3,
                        p_user_id=line['USER_ID'])
            count = Code_util.iterate_data(cur)
            if count[0]['count'] > 0:
                return False
        return True

    @staticmethod
    def insertSchedule(jsonData, header_id):
        logger.addinfo('@models - schedules - insertSchedule(+)')
        lines = jsonData['lines']
        del jsonData['lines']
        con = None
        cur = None
        chk_leaves = Schedules.validate_leaves(lines)
        if chk_leaves:
            con = db_util.get_connection()
            sql_file = db_util.getSqlData()
            cur = con.cursor()
            result = Schedules.insert_lines(lines, header_id, jsonData['TASK_ID'])
            if result == "success":
                try:
                    return_data = {}
                    row_data = []
                    query = sql_file['schedule_insert_query1']
                    my_data = []
                    for key, value in jsonData.items():
                        my_data.append(value)
                        my_new_tuple = tuple(my_data)
                    row_data.append(my_new_tuple)
                    for key, value in jsonData.items():
                        query += str(key)
                        query += ','
                    query = query[:-1] + sql_file["schedule_insert_query2"]
                    query += str(header_id) + ","
                    sql_args = ""
                    for idx, key in enumerate(jsonData.items()):
                        sql_args += ":" + str(idx) + ","
                    query = query + sql_args[:-1] + ")"
                    cur.executemany(query, row_data)
                    con.commit()
                    return_data['req_id'] = header_id
                    return_data['status'] = 0
                    return_data['result'] = "success"
                    return_data['msg'] = "Schedule created successfully"
                except Exception as error:
                    logger.dthublog("""@ 124 EXCEPTION - models - schedules -
                            insertSchedule """ + str(error))
                    raise error
                finally:
                    cur.close()
                    db_util.release_connection(con)
                logger.addinfo('@ models - schedules - insertSchedule(-)')
                return return_data
            else:
                return_data = {}
                return_data['result'] = "fails"
                return_data['status'] = 1
                return_data['msg'] = "Error in creating schedule lines"
                return return_data
        else:
            return_data = {}
            return_data['result'] = "fails"
            return_data['status'] = 1
            return_data['msg'] = "Schedule for an employee is allotted on his/her leave date"
            return return_data


    @staticmethod
    def insert_lines(list, header_id, task_id):
        logger.addinfo('@ models - schedules - insert_lines(+)')
        sql_file = db_util.getSqlData()
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            fieldname_strng = ""
            paramater_strng = ""
            row_list = []
            query = sql_file['get_task_name']
            cursor.execute(query, p_task_id=task_id)
            schedule_task = Code_util.iterate_data(cursor)
            for cn_line in list:
                if 'schedule_line_id' not in cn_line:
                    query = sql_file['schedule_line_sequence']
                    cur = connection.cursor()
                    data = cur.execute(query).fetchone()
                    x_notification_id = cur.var(cx_Oracle.NUMBER)
                    status_code = cur.var(cx_Oracle.STRING)
                    time_zone = cur.execute(sql_file['get_time_zone'], p_user_id=cn_line['CREATED_BY']).fetchone()
                    time = cn_line['TIME_SLOT'].split('.')
                    if time_zone[0] == 'PST':
                        time_hours = int(time[0]) - 3
                        time_slot = str(time_hours) + ':' + time[1]
                    elif time_zone[0] == 'CST':
                        time_hours = int(time[0]) - 1
                        time_slot = str(time_hours) + ':' + time[1]
                    else:
                        time_hours = int(time[0])
                        time_slot = str(time_hours) + ':' + time[1]
                    cur.execute("""
                                begin
                                    BENEFITS_ALLOCATIONS_PKG.add_wf_notifications(
                                        :x_notification_id,
                                        :p_message_type,
                                        :p_message_name,
                                        :p_recipient_role,
                                        :p_status,
                                        :p_mail_status,
                                        :p_priority,
                                        :p_begin_date,
                                        :p_end_date,
                                        :p_due_date,
                                        :p_responder,
                                        :p_from_user,
                                        :p_to_user,
                                        :p_subject,
                                        :p_item_key,
                                        :p_user_comment,        
                                        :p_status_code
                                    );
                                end; """, x_notification_id=x_notification_id,
                                p_message_type='SCHEDULER',
                                p_message_name='SCHEDULER_MSG',
                                p_recipient_role='BENEFITS-ORG-UI',
                                p_status='OPEN',
                                p_mail_status='',
                                p_priority='',
                                p_begin_date=cn_line['RUN_DATE'],
                                p_end_date=cn_line['GL_DATE'],
                                p_due_date=cn_line['GL_DATE'],
                                p_responder=cn_line['USER_ID'],
                                p_from_user=cn_line['CREATED_BY'],
                                p_to_user=cn_line['USER_ID'],
                                p_subject=schedule_task[0]['task_header_name'] + ' - task has been assigned to you. Zone - ' + cn_line['ZONE']
                                          + ' , Slot  - ' + time_slot + '(' + time_zone[0] + ')' + '. Request id # ' +
                                          str(data[0]),
                                p_item_key=str(data[0]),
                                p_user_comment='',
                                p_status_code=status_code)
                    status = status_code.getvalue()
                    cur.close()
                    cn_line['schedule_line_id'] = data[0]
                cn_line['schedule_header_id'] = header_id
                values = ""
                values = tuple(str(val) for key, val in cn_line.items())
                row_list.append(values)
            if list:
                dict_val = list[0]
                fieldname_strng += "("
                indx_value = 1
                paramater_strng += "("
                for key, value in dict_val.items():
                    fieldname_strng += str(key)+','
                    paramater_strng += ":"+str(indx_value)+','
                    indx_value = indx_value+1
                fieldname_strng = fieldname_strng[:-1]
                paramater_strng = paramater_strng[:-1]
                fieldname_strng += ")"
                paramater_strng += ")"
            cursor.prepare("""insert into
            SCHEDULE_LINES """ + fieldname_strng+"""
            values""" + paramater_strng)
            cursor.executemany(None, row_list)
            connection.commit()
        except Exception as error:
            logger.dthublog("""@ 323 EXCEPTION - models - schedules -
                 insert_lines """ + str(error))
            raise error
        finally:
            if cursor is not None:
                cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - schedules - insert_lines(-)')
        return "success"

    @staticmethod
    def get_schedules(org_id):
        logger.addinfo('@models - schedules - get_schedules(+)')
        connection = None
        cur = None
        try:
            connection = db_util.get_connection()
            cur = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['schedules_query']
            cur.execute(query, p_org_id=org_id)
        except Exception as error:
            logger.dthublog("""@ 154 EXCEPTION - models - schedules -
                 get_schedules """ + str(error))
            raise error
        else:
            schedule_list = []
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                result = {}
                for index, field in enumerate(field_names):
                    result[field] = row[index]
                schedule_list.append(result)
        finally:
            cur.close()
            db_util.release_connection(connection)
        logger.addinfo("@ models - schedules - get_schedules(-)")
        return schedule_list

    @staticmethod
    def delete_schedule(schedule_id):
        logger.addinfo("@ models - schedules - delete_schedule(+)")
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['schedule_delete_query1']
            cursor.execute(query, p_schedule_id=schedule_id)
            query2 = sql_file['schedule_delete_query3']
            cursor.execute(query2, p_schedule_id=schedule_id)
            query1 = sql_file['schedule_delete_query2']
            cursor.execute(query1, p_schedule_id=schedule_id)
        except Exception as error:
            logger.dthublog("""@ 185 EXCEPTION - models - schedules -
                 delete_schedule """ + str(error))
            raise error
        finally:
            cursor.close()
            connection.commit()
            db_util.release_connection(connection)
        logger.addinfo("@ models - schedules - delete_schedule(-)")
        final = dict()
        final['status'] = 0
        msg = 'Schedule # ' + str(schedule_id) + ' deleted successfully'
        final['msg'] = msg
        return final

    @staticmethod
    def delete_line(line_id):
        logger.addinfo("@ models - schedules - delete_line(+)")
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['schedule_line_delete_query']
            cursor.execute(query, p_line_id=line_id)
        except Exception as error:
            logger.dthublog("""@ 209 EXCEPTION - models - schedules -
                 delete_line """ + str(error))
            raise error
        finally:
            cursor.close()
            connection.commit()
            db_util.release_connection(connection)
        logger.addinfo("@ models - schedules - delete_line(-)")
        return 'success'

    @staticmethod
    def show_header(schedule_id):
        logger.addinfo('@ models - schedules - show_header(+)')
        connection = None
        cursor = None
        sql_file = db_util.getSqlData()
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            query = sql_file['schedule_header_query']
            cursor.execute(query, p_header_id=schedule_id)
            line_details = Schedules.show_lines(schedule_id)
        except Exception as error:
            logger.dthublog("""@ 235 EXCEPTION - models - schedules -
                 show_header """ + str(error))
            raise error
        else:
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                header = Schedules()
                for index, fn in enumerate(fieldnames):
                    setattr(header, fn, row[index])
                setattr(header, "lines", line_details)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - schedules - show_header(-)')
        return header

    @staticmethod
    def get_schedule_details(schedule_id):
        logger.addinfo('@ models - schedules - show_header(+)')
        connection = None
        cursor = None
        sql_file = db_util.getSqlData()
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            query = sql_file['schedule_detail_header_query']
            cursor.execute(query, p_line_id=schedule_id)
            result = Code_util.iterate_data(cursor)
        except Exception as error:
            logger.dthublog("""@ 235 EXCEPTION - models - schedules -
                     show_header """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - schedules - show_header(-)')
        return result

    @staticmethod
    def show_lines(schedule_id):
        logger.addinfo('@models - schedules - show_lines(+)')
        connection = None
        cur = None
        try:
            connection = db_util.get_connection()
            cur = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['schedule_lines_query']
            cur.execute(query, p_header_id=schedule_id)
        except Exception as error:
            logger.dthublog("""@ 263 EXCEPTION - models - schedules -
                 show_lines """ + str(error))
            raise error
        else:
            lines_list = []
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                result = {}
                for index, field in enumerate(field_names):
                    result[field] = row[index]
                lines_list.append(result)
        finally:
            cur.close()
            db_util.release_connection(connection)
        logger.addinfo("@ models - schedules - show_lines(-)")
        return lines_list

    @staticmethod
    def line_update(val_list):
        logger.addinfo('@ models - schedules - line_update(+)')
        con = None
        cur = None
        line_id = ''
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            for line in val_list:
                sql_data = 'update SCHEDULE_LINES set '
                for key, value in line.items():
                    if key == 'SCHEDULE_LINE_ID':
                        line_id = str(value)
                    sql_data += str(key)+'='
                    if isinstance(value, str):
                        sql_data += "'"
                    if value is not None:
                        sql_data += str(value)
                    if isinstance(value, str):
                        sql_data += "'"
                    sql_data += ','
                sql_data = sql_data[:-1]
                sql_data += " where SCHEDULE_LINE_ID =" + line_id
                cur.execute(sql_data)
                sql_data = ''
        except Exception as error:
            logger.dthublog("""@ 422 EXCEPTION - models - schedules -
                 line_update """ + str(error))
            raise error
        finally:
            con.commit()
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - schedules - line_update(-)')
        return 'success'

    @staticmethod
    def update_schedule(final_dict, survey_id):
        logger.addinfo('@ models - schedules - update_schedule(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_data = 'update SCHEDULE_HEADERS set '
            for key, value in final_dict.items():
                sql_data += str(key)+'='
                if isinstance(value, str):
                    sql_data += "'"
                if value is not None:
                    sql_data += str(value)
                if isinstance(value, str):
                    sql_data += "'"
                sql_data += ','
            sql_data = sql_data[:-1]
            sql_data += " where SCHEDULE_HEADER_ID =" + str(survey_id)
            cur.execute(sql_data)
        except Exception as error:
            logger.dthublog("""@ 421 EXCEPTION - models - schedules -
                 update_schedule """ + str(error))
            raise error
        finally:
            con.commit()
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - schedules - update_schedule(-)')
        return 'success'
