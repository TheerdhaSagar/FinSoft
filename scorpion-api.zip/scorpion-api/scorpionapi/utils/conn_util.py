from scorpionapi.utils import db_util
from scorpionapi.utils.code_util import Code_util


class OracleConnectionManager:
    def __init__(self):
        self.connection = None
        self.cursor = None
        self.is_acquired = False

    def __enter__(self):
        """
        sql connection resources are assigned & managed
        :return:
        """
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()
        self.is_acquired = True
        return self

    def __exit__(self, exc_type, exc_value, exc_traceback):
        """
        after completion of query execution, the connections to be released
        """
        if self.is_acquired:
            self.connection.commit()
            self.release()

    def release(self):
        if self.cursor:
            self.cursor.close()
            self.is_acquired = False
        db_util.release_connection(self.connection)

    def execute(self, query, **kwargs):
        """
        To execute the query with params or without params
        :param query:
        :param kwargs:
        """
        try:
            if kwargs:
                params = {key: value for key, value in kwargs.items()}
                self.cursor.execute(query, params)
            else:
                self.cursor.execute(query)
        except Exception as e:
            raise e

    def get_result(self):
        """
        To get the details from the oracle cursor
        :return:
        """
        return Code_util.iterate_data(self.cursor)

