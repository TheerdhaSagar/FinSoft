import logging
import os
import os.path
from flask import g
basedir = os.path.join(os.path.abspath(os.path.dirname(__file__)),'..')


class logger:

    @staticmethod
    # user based log method
    def getLog():
        loglevel = logging.INFO
        l = ""
        tmp_debugflg = ""
        if 'debug' in g:
            tmp_debugflg = g.debug
        if tmp_debugflg == 'Y':
            l = logging.getLogger(g.username)
            file_name = g.username+'.log'
            if not l.handlers:
                l.setLevel(logging.INFO)
                h = logging.FileHandler(os.path.join("/tmp", file_name), "a",
                                        encoding=None, delay="true")
                # h = logging.FileHandler(file_name)
                f = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
                h.setFormatter(f)
                l.addHandler(h)
                l.setLevel(loglevel)
        return l

    @staticmethod
    # verify's each time and add id exsists
    def addinfo(logmsg):
        log = logger.getLog()
        if log:
            log.info(logmsg)

    @staticmethod
    # Validation log
    def dthublog(logmsg):
        lg = logging.getLogger('dthub')
        if not lg.handlers:
            lg.setLevel(logging.INFO)
            file_name = 'naslogger.log'
            log_file_path = basedir + "/tmp"
            h = logging.FileHandler(os.path.join(log_file_path, file_name), "a",
                                    encoding=None, delay="true")
            f = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
            h.setFormatter(f)
            lg.addHandler(h)
            lg.setLevel(logging.INFO)
        lg.info(logmsg)
