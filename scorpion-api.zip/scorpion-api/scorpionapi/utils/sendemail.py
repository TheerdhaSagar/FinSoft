from __future__ import absolute_import

import smtplib
from string import Template
import os

from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from scorpionapi.utils import db_util
from scorpionapi.utils.logdata import logger


class SendEmail:

    """def connect_mailserver():
        server = smtplib.SMTP()
        server.connect ('DC2mailrelay.sd.adp.com', 25)"""

    @staticmethod
    def get_contacts(filename):
        """
        Return two lists names, emails containing names and email addresses
        read from a file specified by filename.
        """
        names = []
        emails = []
        basedir = os.path.abspath(os.path.dirname(__file__))
        os.chdir(basedir)
        with open(filename, mode='r', encoding='utf-8') as contacts_file:
            for a_contact in contacts_file:
                names.append(a_contact.split()[0])
                emails.append(a_contact.split()[1])
        return names, emails

    @staticmethod
    def read_template(filename):
        """
        Returns a Template object comprising the contents of the
        file specified by filename.
        """

        with open(filename, 'r', encoding='utf-8') as template_file:
            template_file_content = template_file.read()
        return Template(template_file_content)

    @staticmethod
    def send_mail(req_data):
        logger.addinfo('@ models - Benefits Allocation - send_email(+)')
        try:
            strings = db_util.get_strings()
            # req_data['activation_key'] = self.password
            # req_data['user'] = self.user_value
            """message_template = Registration.read_template('email_template_registration.txt')"""
            msg = MIMEMultipart()       # create a message
            # add in the actual person name to the message template
            server = smtplib.SMTP()
            server.connect(strings['mail_server'], 25)
            # message = message_template.substitute(PERSON_NAME=user_name, MESSAGE_BODY=message_body)
            # Prints out the message body for our sake
            # setup the parameters of the message
            msg['From'] = strings['sender_email']
            msg['To'] = req_data['email']
            msg['Subject'] = req_data['subject']
            # add in the message body
            msg.attach(MIMEText(req_data['message_template'], 'html'))
            # send the message via the server set up earlier.
            server.send_message(msg)
            del msg
            server.quit()
            status = 'success'
        except Exception as e:
            status = 'Failure - Failed to send email'
            logger.dthublog(""" @ EXCEPTION - models - Benefits Allocation -
                             send_email """ + str(e))
            raise e
        logger.addinfo('@ models - Benefits Allocation - send_email(-)')
        return status
