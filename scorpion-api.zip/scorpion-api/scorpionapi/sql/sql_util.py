import os
import yaml


def get_sql(filename):
    sql_file = None
    path = os.path.dirname(__file__) + '/queries/'
    fn = os.path.join(path, filename + '.yaml')
    with open(fn, 'r') as ymlfile:
        sql_file = yaml.safe_load(ymlfile)
    return sql_file
