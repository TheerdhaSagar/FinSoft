from flask import Flask, abort
from .utils import db_util
from .views.activityplanner.activityplanner import activityplanner
from .views.scheduler.scheduler import scheduler
from .views.admin.authtoken import authtoken
from .views.login.login import login
from .views.cdn.cdn import cdn
from .views.roles.roles import roles
from .views.users.users import users
from .views.permissions.permissions import permissions
from .views.registration.registration import registration
from .views.teams.teams import teams
from .views.tasks.tasks import tasks
from .views.preferences.preferences import preference
from .views.calendar.calendar import calendar
from .views.balances.balances import balances
from .views.wfn.wfn import wfn
from .views.wfnpostvalidations.wfnpostvalidations import wfnpostvalidations
from .views.schedules.schedules import schedules
from .views.projecttracker.projecttracker import projecttracker
from .views.hcm.leavemanagement import leavemanagement
from .views.objectives.objectives import objectives
from .views.resumeparser.resumeparser import resumeparser

DEFAULT_BLUEPRINTS = [activityplanner, scheduler, authtoken, balances, login, wfnpostvalidations,
                      registration, roles, permissions, cdn,
                      users, teams, tasks, calendar, schedules, projecttracker,
                      preference, leavemanagement, objectives, wfn, resumeparser]


def create_app():
    blueprints = DEFAULT_BLUEPRINTS
    app = Flask(__name__)
    configure_app(app)
    configure_app_handlers(app)
    configure_blueprints(app, blueprints)
    configure_error_handlers(app)
    configure_after_request(app)
    return app


def configure_after_request(app):
    @app.after_request
    def after_request(response):
        response.headers.add('Access-Control-Allow-Origin', 'http://localhost:4200')
        response.headers.add('Access-Control-Allow-Credentials', 'true')
        response.headers.add('Access-Control-Allow-Headers',
                             'Content-Type, Authorization, withCredentials')
        response.headers.add('Access-Control-Allow-Headers',
                             'x-api-key, x-api-secret')
        response.headers.add('Access-Control-Allow-Methods',
                             'GET, PUT, POST, DELETE')
        return response


def configure_app(app):
    db_util.db_pool = db_util.init_pool()
    app.config['SECRET_KEY'] = 'trytochangeme'
    app.config['USE_TOKEN_AUTH'] = True


def configure_blueprints(app, blueprints):
    for blueprint in blueprints:
        app.register_blueprint(blueprint)


def configure_app_handlers(app):
        @app.route('/')
        def get():
            abort(404)


def configure_error_handlers(app):
    @app.errorhandler(400)
    @app.errorhandler(401)
    @app.errorhandler(403)
    @app.errorhandler(404)
    @app.errorhandler(405)
    @app.errorhandler(500)
    @app.errorhandler(502)
    def request_error(error):
        return error
