export const environment = {
  image_url: "http://11.16.45.94/cdn/scorpion",
  production: false,
  // url: "http://11.17.4.235:8001",
  url: "http://11.16.45.94:8008",
};
