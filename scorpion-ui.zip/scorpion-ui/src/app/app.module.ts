import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { providers } from './app.provider';
import { AppComponent } from './app.component';
import { FilterPipe } from './globals/filter.pipe';
import { LoginComponent } from './login/login.component';
import { HttpClientModule } from '@angular/common/http';
import { DashboardComponent } from './dashboard/dashboard.component';
import { TemplateComponent } from './template/template.component';
import { SpinnerComponent } from './globals/spinner/spinner.component';
import { BalanceauditComponent } from './balanceaudit/balanceaudit.component';
import { WfnprevalidationComponent } from './wfnprevalidation/wfnprevalidation.component';
import { OrderByPipe } from "./globals/order-by.pipe";
import { UpdateModelDirective } from './globals/update-model.directive';
import { FileUploadDirective } from "./globals/fileupload.directive";
import { SummaryComponent } from './balanceaudit/summary/summary.component';
import {AutocompleteComponent} from "./globals/autocomplete/autocomplete.component";
import {LoadingComponent} from "./globals/loading/loading.component";
import { PreviewSummaryComponent } from './wfnprevalidation/preview-summary/preview-summary.component';
import { PreviewUploadComponent } from './wfnprevalidation/preview-upload/preview-upload.component';
import { SetupSummaryComponent } from './wfnprevalidation/setup-summary/setup-summary.component';
import { AddClientComponent } from './wfnprevalidation/add-client/add-client.component';
import { ClientSummaryComponent } from './wfnprevalidation/client-summary/client-summary.component';
import { InfiniteScrollModule } from "ngx-infinite-scroll";
import { ReportsComponent } from './wfnprevalidation/reports/reports.component';
import { WfnpostvalidationComponent } from './wfnpostvalidation/wfnpostvalidation.component';
import { WfnparserComponent } from './wfnparser/wfnparser.component';
import { VantageparserComponent } from './vantageparser/vantageparser.component';
import { BalanceUploadComponent } from './balanceaudit/balance-upload/balance-upload.component';
import { BalanceAuditSummaryComponent } from './balanceaudit/balance-audit-summary/balance-audit-summary.component';
import { WfndualmaintenanceComponent } from './wfndualmaintenance/wfndualmaintenance.component';
import { ReportSummaryComponent } from './balanceaudit/report-summary/report-summary.component';
import { EmployeeReportSummaryComponent } from './balanceaudit/employee-report-summary/employee-report-summary.component';
import { EmpDeltaReportSummaryComponent } from './balanceaudit/emp-delta-report-summary/emp-delta-report-summary.component';


@NgModule({
  declarations: [
    AutocompleteComponent,
    AppComponent,
    LoginComponent,
    LoadingComponent,
    DashboardComponent,
    TemplateComponent,
    SpinnerComponent,
    OrderByPipe,
    FilterPipe,
    FileUploadDirective,
    BalanceauditComponent,
    WfnprevalidationComponent,
    SummaryComponent,
    UpdateModelDirective,
    PreviewSummaryComponent,
    PreviewUploadComponent,
    SetupSummaryComponent,
    AddClientComponent,
    ClientSummaryComponent,
    ReportsComponent,
    WfnpostvalidationComponent,
    WfnparserComponent,
    VantageparserComponent,
    BalanceUploadComponent,
    BalanceAuditSummaryComponent,
    WfndualmaintenanceComponent,
    ReportSummaryComponent,
    EmployeeReportSummaryComponent,
    EmpDeltaReportSummaryComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    InfiniteScrollModule
  ],
  providers,
  bootstrap: [AppComponent]
})
export class AppModule { }
