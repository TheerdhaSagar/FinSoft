import { Component, OnInit } from '@angular/core';
import { AppService } from '../globals/app.service';
import { CacheService } from '../globals/cache.service';
import { DataService } from '../globals/data.service';
import { HttpService } from '../globals/http.service';
import { Location } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  private _appService: AppService;
  private _cacheService: CacheService;
  private _httpService: HttpService;
  private _location: Location;
  private _router: Router;
  private _window: any;

  roles: any;
  user: any;
  windowWidth: any;
  notificationCount: any;

  constructor(appService: AppService, cacheService: CacheService, dataService: DataService,
              httpService: HttpService, location: Location, router: Router) {
    this._appService = appService;
    this._cacheService = cacheService;
    this._httpService = httpService;
    this._location = location;
    this._router = router;
    this._window = window;

    this.roles = dataService.roles;
    this.user = null;
    this.notificationCount = null;
    this.windowWidth = dataService.windowWidth;
  }

  ngOnInit() {
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }

        this.user = data;

        // this.loadNotificationCount();
      }
    });
  }

  goToState(state) {
    if (state) {
      this._router.navigate([state]);
    } else {
      this._window.open('https://www.10.6.4.17/');
    }
  }

  loadNotificationCount() {
    let endPoint = '/users/notifications/count/' + this.user.user_id + '/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({status: 1, msg: 'Server Error: loadNotificationCount()'});
      } else {
        if (data && data.length > 0) {
          this.notificationCount = data[0].open_count;
        }
      }
    });
  }

}
