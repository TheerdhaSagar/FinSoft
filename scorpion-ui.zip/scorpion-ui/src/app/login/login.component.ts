import { Component, OnInit } from '@angular/core';
import { AppService } from '../globals/app.service';
import { CacheService } from '../globals/cache.service';
import { DataService } from '../globals/data.service';
import { HttpService } from '../globals/http.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';
import jQuery from '../../../node_modules/jquery';
import { CommonService } from '../globals/common.service';
import { FormatService } from '../globals/format.service';
import { PasswordService } from '../globals/password.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  private _appService: AppService;
  private _cacheService: CacheService;
  private _commonService: CommonService;
  private _dataService: DataService;
  private _formatService: FormatService;
  private _httpService: HttpService;
  private _location: Location;
  private _passwordService: PasswordService;
  private _router: Router;
  private _routeParams: ActivatedRoute;
  private _window: any;

  clientId: number;
  conditions: any;
  conditionsMet: boolean;
  conditionMsg: string;
  errorMsg: string;
  focusPassword: boolean;
  isChrome: boolean;
  loginContainer: boolean;
  msg: string;
  password: any;
  passwordMismatch: boolean;
  queryParams: any;
  rePassMsg: string;
  rePassword: any;
  resetContainer: boolean;
  showPassword: boolean;
  showSpinner: boolean;
  status: any;
  token: any;
  user: any;
  username: any;

  constructor(appService: AppService, cacheService: CacheService, commonService: CommonService, dataService: DataService,
              formatService: FormatService, httpService: HttpService, location: Location, passwordService: PasswordService, router: Router,
              routeParams: ActivatedRoute) {

    this._appService = appService;
    this._cacheService = cacheService;
    this._commonService = commonService;
    this._dataService = dataService;
    this._formatService = formatService;
    this._httpService = httpService;
    this._location = location;
    this._passwordService = passwordService;
    this._router = router;
    this._routeParams = routeParams;
    this._window = window;

    this.conditions = {};
    this.conditionsMet = true;
    this.focusPassword = false;
    this.isChrome = false;
    this.loginContainer = true;
    this.msg = '';
    this.password = '';
    this.passwordMismatch = false;
    this.rePassMsg = '';
    this.rePassword = '';
    this.resetContainer = false;
    this.showPassword = false;
    this.showSpinner = false;
    this.status = '';
    this.token = null;
    this.user = null;
    this.username = '';

    routeParams.queryParams.subscribe(params => {
      this.queryParams = params;
    });

  }

  ngOnInit() {

    this.isChrome = this._appService.isChrome();
    // Token will be passed as parameter for reset password state
    this.token = this._routeParams.snapshot.params.token;
    // If there is token in request then get the user details based on token
    if (this.token) {
      if (this.token === 'reset') {
        this.loginContainer = false;
      } else {
        this.loginContainer = false;
        this.resetContainer = true;
        this._httpService.postRequest('/login/details/', { key_val: this.token }, (data) => {
          if (data && data.status === 0) {
            this.user = data;
          }
        });
      }
    }
    // Password policy conditions to be met
    this.conditions = this._passwordService.conditions;
    // When user press enter with cursor in password field then
    // login will be called. Code 13 is for 'Enter'
    jQuery('#password').on('keyup', (event) => {
      if (event.which === 13) {
        this.login();
      }
    });

  }


  changePassword() {
    let password = this.password;
    let rePassword = this.rePassword;
    if (password) {
      this.focusPassword = false;
      if (password !== rePassword) {
        this.passwordMismatch = true;
        this.errorMsg = 'Passwords do not match';
      } else {
        if (this.conditionsMet) {
            let req = {
              user_name: this.username,
              new_password: password
            };
            this.showSpinner = true;
            this._httpService.postRequest('/login/passwdchanged/', req, (data) => {
              try {
                this.showSpinner = false;
                if (data === null || data === undefined) {
                  this._appService.notify({status: 1, msg: 'Server Error'});
                } else {
                  jQuery('#changePassword').html('CHANGE PASSWORD');
                  this.status = data.status;
                  this.msg = this.status === 0 ? 'Password changed' : data.msg;
                  this.resetContainer = false;
                  this.loginContainer = true;
                  this.clear();
                }
              } catch (e) {
                // TODO error
                // console.log(e);
              }
            });

        }
      }
    } else {
      this.conditionsMet = false;
      this.conditionMsg = 'Password field is empty';
    }
  }

  // clears the scope values
  clear() {
    this._dataService.logout = false;
    this.username = null;
    this.password = null;
    jQuery('#login').html('LOGIN <i class="icon-arrow-right icon"></i>');
  }

  login() {
    this.msg = '';
    if (this.username && this.password) {
      let endPoint = '/login/', randomAttr, randomStr, credentials;

      credentials = {
        source: 'C'
      };

      // this._passwordService.passwordOnLogin = this.password;

      credentials['user_name'] = this.username;
      credentials['password'] = this.password;

      // adds a loading indicator to login button
      this.showSpinner = true;

      this._httpService.postRequest(endPoint, credentials, (data) => {
        try {
          this.showSpinner = false;
          if (data === null || data === undefined) {
            // appService.notify({status: 1, msg: 'Server Error'});
          } else {
            if (data.hasOwnProperty('status')) {
              this.status = data.status;
              if (data.hasOwnProperty('accesses_left')) {
                this.msg = 'Login failed. Attempts remaining ' + data.accesses_left;
              } else if (data.msg === 'TOO_MANY_ATTEMPTS') {
                this.msg = 'Too many login attempts. You account is temporarily disabled. Please reset your password or contact IT Support';
              } else {
                this.msg = data.msg;
              }
              return;
            }
            // Store user related data in localStorage
            this._cacheService.setUser(data.result);
            // Store the Auth token and refresh token
            // in cookies
            this._cacheService.setToken(data.token);
            this._cacheService.setRefreshToken(data.refresh_token);

            // Store user organizations
            this._cacheService.setOrgList(data.result.organizations);
            this._cacheService.setGroupList(data.result.groups);
            if (data.result.organizations && data.result.organizations.length > 0) {
              let defaultOrg = data.result.default_org_id;
              if (defaultOrg === null) {
                this._cacheService.setOrgId(data.result.organizations[0].organization_id);
              } else {
                this._cacheService.setOrgId(data.result.default_org_id);
              }
              this._cacheService.setOldOrgId(this._cacheService.getOrgId());
            }
            if (data.result.password_change_on_login === 'Y') {
              this.loginContainer = false;
              this.resetContainer = true;
              this.password = null;
              return;
            }
            this.clear();
            let index = -1, redirectUri;
            if (index === -1) {
              this._router.navigate(['dashboard']);
            }
          }
        } catch (e) {
          // console.log('EndPoint - ' + endPoint + '\n' + JSON.stringify(data) + '\n' + e);
        }
      });
    }
  }

  reset() {
    this.showSpinner = true;
    this._commonService.resetPassword(this.username, (data) => {
      this.showSpinner = false;
      this.status = data.status;
      this.msg = data.msg;
      this.loginContainer = true;
      this.clear();
    });
  }

  // This method is called to toggle the password visibility
  togglePassword() {
    let ids = ['new-password', 're-password'];
    this.showPassword = this._passwordService.togglePassword(ids);
  }

  // This method is called to verify whether all the password policies are met
  validateNewPassword() {
    this.focusPassword = this.password.length !== 0 ? true : false;
    this.conditionsMet = this._passwordService.validateNewPassword(this.password, this.conditions);
    if (!this.conditionsMet) {
      this.conditionMsg = 'Password does not meet the specified policy';
    }
  }

  // This method is called to verify individual password policy
  validatePasswordConditions() {
    this.focusPassword = this.password.length !== 0 ? true : false;
    this.conditionsMet = true;
    this.passwordMismatch = false;
    this.conditions = this._passwordService.validatePasswordConditions(this.password, this.conditions);
  }


}
