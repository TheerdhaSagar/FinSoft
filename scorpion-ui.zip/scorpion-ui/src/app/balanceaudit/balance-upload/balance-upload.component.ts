import { Component, OnInit } from '@angular/core';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { DataService } from '../../globals/data.service';
import { FormatService } from '../../globals/format.service';
import { HttpService } from '../../globals/http.service';
import { Router } from '@angular/router';
import { Location } from '@angular/common';

@Component({
  selector: 'app-balance-upload',
  templateUrl: './balance-upload.component.html',
  styleUrls: ['./balance-upload.component.scss']
})
export class BalanceUploadComponent implements OnInit {

  private _appService: AppService;
  private _cacheService: CacheService;
  private _formatService: FormatService;
  private _httpService: HttpService;
  private _location: Location;
  private _router: Router;
  private _window: any;

  attachments: any;
  clientId: number;
  clientName: string;
  conversionName: string;
  focusUpload: boolean;
  focusClient: boolean;
  focusClientName: boolean;
  showSpinner: boolean;
  uploadDialog: boolean;
  uploadedFile: any;
  user: any;

  constructor(appService: AppService, cacheService: CacheService, dataService: DataService,
              formatService: FormatService, httpService: HttpService, location: Location, router: Router) {

    this._appService = appService;
    this._cacheService = cacheService;
    this._httpService = httpService;
    this._location = location;
    this._router = router;
    this._window = window;

    this.attachments = null;
    this.conversionName = '';
    this.clientId = null;
    this.clientName = '';
    this.focusClient = false;
    this.focusClientName = false;
    this.focusUpload = false;
    this.showSpinner = false;
    this.uploadDialog = false;
    this.uploadedFile = '';
    this.user = '';
  }


  ngOnInit() {

    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this.user = data;
      }
    });
  }


  upload() {
    if (!this.uploadedFile || !this.uploadedFile.base64) {
      this.focusUpload = true;
      return;
    }
    if(!this.clientId || !this.clientName) {
      if(!this.clientId){
        this.focusClient = true;
      }
      if(!this.clientName){
        this.focusClientName = false;
      }
      return
    }
    this.showSpinner = true;
    let dict: any = {}, endPoint = '/balances/audit/upload/';
    dict.base64 = this.uploadedFile.base64;
    dict.user_id = this.user.user_id;
    dict.client_id = this.clientId;
    dict.client_name = this.clientName;
    dict.audit_type = this.conversionName;
    this._httpService.httpRequest('POST', endPoint, dict, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - upload()' });
      } else {
        if (data.status === 1) {
          this._appService.notify({ msg: data.msg, status: data.status });
        } else {
          this._appService.notify({ msg: data.msg, status: data.status });
          setTimeout(() => {
            this._router.navigate(['balance/audit/summary']);
          }, 2000);
        }
      }
      this.showSpinner = false;
    });
  }

  // to validate the uploaded ADJ file sheet
  validateFile() {
    let fileExtension, nameLength, fileName;
    fileName = this.uploadedFile.filename.split('.');
    nameLength = fileName.length - 1;
    fileExtension = fileName[nameLength];
    this.focusUpload = false;
    if (fileExtension.toUpperCase() === 'ZIP' || fileExtension.toUpperCase() === 'XLSX') {
      return;
    } else {
        this.uploadedFile.filename = '';
        this.uploadedFile.base64 = '';
        this.uploadedFile = '';
        (document.getElementsByClassName('file-upload-btn')[0] as HTMLFormElement).value = '';
        this.focusUpload = true;
      }
  }

}
