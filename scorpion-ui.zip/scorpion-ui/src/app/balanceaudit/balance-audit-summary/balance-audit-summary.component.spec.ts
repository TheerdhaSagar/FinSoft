import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BalanceAuditSummaryComponent } from './balance-audit-summary.component';

describe('BalanceAuditSummaryComponent', () => {
  let component: BalanceAuditSummaryComponent;
  let fixture: ComponentFixture<BalanceAuditSummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BalanceAuditSummaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BalanceAuditSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
