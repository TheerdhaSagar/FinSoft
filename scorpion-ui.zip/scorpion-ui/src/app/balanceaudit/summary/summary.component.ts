import { Component, OnDestroy, OnInit } from "@angular/core";
import { AppService } from "../../globals/app.service";
import { CacheService } from "../../globals/cache.service";
import { DataService } from "../../globals/data.service";
import { ExcelService } from "../../globals/excel.service";
import { FormatService } from "../../globals/format.service";
import { HttpService } from "../../globals/http.service";
import { Router } from "@angular/router";
import { Location } from "@angular/common";
import { environment } from "../../../environments/environment";
import jQuery from "../../../../node_modules/jquery";

@Component({
  selector: "app-summary",
  templateUrl: "./summary.component.html",
  styleUrls: ["./summary.component.scss"],
})
export class SummaryComponent implements OnInit {
  private _appService: AppService;
  private _cacheService: CacheService;
  private _dataService: DataService;
  private _excelService: ExcelService;
  private _formatService: FormatService;
  private _httpService: HttpService;
  private _location: Location;
  private _router: Router;
  private _window: any;

  allclientPreAudit: any;
  allUsers: any;
  clientDeconstruction: any;
  clientDialogue: boolean;
  clientEarningGross: any;
  clientPreAudit: any;
  clientAsp: any;
  clientAspEmp: any;
  clientAspJurisdiction: any;
  clientRecalc: any;
  clientsSummary: any;
  clientId: any;
  currentPage: any;
  deleteClientId: any;
  deleteDialogue: boolean;
  detailsAspSave: boolean;
  detailsAspEmpSave: boolean;
  detailsAspJurisdictionSave: boolean;
  detailsEarnGross: boolean;
  detailsEarnGrossSave: boolean;
  detailsPreAudit: boolean;
  detailsPreAuditSave: boolean;
  detailsRecalcSave: boolean;
  detailsAspEmpReport: boolean;
  detailsAspReport: boolean;
  detailsAspJurisdictionReport: boolean;
  detailsRecalc: boolean;
  desc: boolean;
  downloadURL: string;
  dropdownClientId: any;
  existing_input_codes: any;
  fileData: any;
  fileName: any;
  input_ded_codes: any;
  input_ern_codes: any;
  input_gtl_codes: any;
  inputDialog: boolean;
  pageSize: number;
  reportType: string;
  selectedInputCodes: any;
  selectedInputDed: any;
  selectedInputErn: any;
  selectedInputGtl: any;
  selectedStatus: string;
  selectedUser: any;
  showSpinner: boolean;
  ssLimit: any;
  summaryDialogue: boolean;
  predicate: any;
  toggleFilter: (e?) => void;
  user: any;

  constructor(
    appService: AppService,
    cacheService: CacheService,
    dataService: DataService,
    excelService: ExcelService,
    formatService: FormatService,
    httpService: HttpService,
    location: Location,
    router: Router
  ) {
    this._appService = appService;
    this._cacheService = cacheService;
    this._excelService = excelService;
    this._httpService = httpService;
    this._location = location;
    this._router = router;
    this._window = window;

    this.allclientPreAudit = null;
    this.allUsers = [];
    this.clientDeconstruction = null;
    this.clientDialogue = false;
    this.clientEarningGross = null;
    this.clientId = null;
    this.clientPreAudit = null;
    this.clientAsp = null;
    this.clientAspEmp = null;
    this.clientAspJurisdiction = null;
    this.clientRecalc = null;
    this.clientsSummary = null;
    this.currentPage = null;
    this.deleteClientId = null;
    this.deleteDialogue = false;
    this.detailsAspSave = false;
    this.detailsAspEmpSave = false;
    this.detailsAspJurisdictionSave = false;
    this.detailsEarnGross = false;
    this.detailsEarnGrossSave = false;
    this.detailsPreAudit = false;
    this.detailsPreAuditSave = false;
    this.detailsRecalcSave = false;
    this.detailsAspReport = false;
    this.detailsAspEmpReport = false;
    this.detailsAspJurisdictionReport = false;
    this.detailsRecalc = false;
    this.desc = false;
    this.downloadURL = environment.url;
    this.dropdownClientId = null;
    this.existing_input_codes = "";
    this.fileData = null;
    this.fileName = null;
    this.input_ded_codes = null;
    this.input_ern_codes = null;
    this.input_gtl_codes = null;
    this.inputDialog = false;
    this.pageSize = this._appService.pageSize;
    this.reportType = "";
    this.selectedStatus = "ALL";
    this.selectedUser = -1;
    this.selectedInputCodes = "";
    this.selectedInputDed = "";
    this.selectedInputErn = "";
    this.selectedInputGtl = "";
    this.showSpinner = false;
    this.ssLimit = 147000;
    this.summaryDialogue = false;
    this.predicate = null;
    this.user = null;
  }

  ngOnInit() {
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(["login"]);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this.user = data;
      }
      this.selectedUser = this.user.user_id;
      this.loadUsers();
      this.loadClients(this.selectedUser);
      this.setUpDOMHandlers();
      this.toggleFilter = this._appService.toggleFilter();
    });
  }

  applyFilter() {
    this.toggleFilter();
    this.showSpinner = true;
    this.loadClients(this.selectedUser);
  }

  changeView(type) {
    this.showSpinner = true;
    this.detailsEarnGrossSave = false;
    this.detailsPreAuditSave = false;
    this.detailsRecalcSave = false;
    this.detailsAspSave = false;
    this.detailsAspEmpReport = false;
    this.detailsAspJurisdictionReport = false;
    if (type === "ern-gross") {
      this.detailsEarnGross = true;
      this.detailsPreAudit = false;
      this.detailsAspReport = false;
      this.detailsRecalc = false;
      this.detailsAspEmpReport = false;
      this.detailsAspJurisdictionReport = false;

      this.showSpinner = false;
    } else if (type === "pre-audit") {
      this.allclientPreAudit = "";
      let endPoint = "/balances/client/details/",
        dict: any = {};
      dict.client_id = this.clientId;
      dict.report_type = "pre_audit";
      dict.user_id = this.user.user_id;
      this._httpService.httpRequest("POST", endPoint, dict, (data) => {
        try {
          this.showSpinner = false;
          if (data === null || data === undefined) {
            this._appService.notify({
              status: 1,
              msg: "Server Error: getClientDetails()",
            });
          } else {
            if (data.hasOwnProperty("async_flag") && data.status === 0) {
              this._appService.notify({ status: 0, msg: data.msg });
            } else if (data.hasOwnProperty("status") && data.status === 0) {
              this.currentPage = 1;
              this.allclientPreAudit = data.pre_audit;
              this.clientPreAudit = this.allclientPreAudit.slice(
                this.currentPage - 1,
                this.pageSize
              );
            }
          }
        } catch (e) {
          this._appService.notify({
            status: 1,
            msg: e.message,
            details: "<pre>" + e.stack + "</pre>",
          });
        }
      });
      this.detailsEarnGross = false;
      this.detailsPreAudit = true;
      this.detailsAspReport = false;
      this.detailsRecalc = false;
      this.detailsAspEmpReport = false;
      this.detailsAspJurisdictionReport = false;
    } else if (type === "asp") {
      this.clientAsp = "";
      let endPoint = "/balances/client/details/",
        dict: any = {};
      dict.client_id = this.clientId;
      dict.report_type = "asp";
      dict.user_id = this.user.user_id;
      this._httpService.httpRequest("POST", endPoint, dict, (data) => {
        try {
          this.showSpinner = false;
          if (data === null || data === undefined) {
            this._appService.notify({
              status: 1,
              msg: "Server Error: getClientDetails()",
            });
          } else {
            if (data.hasOwnProperty("status") && data.status === 0) {
              this.clientAsp = data.asp_report;
            }
          }
        } catch (e) {
          this._appService.notify({
            status: 1,
            msg: e.message,
            details: "<pre>" + e.stack + "</pre>",
          });
        }
      });

      this.detailsEarnGross = false;
      this.detailsPreAudit = false;
      this.detailsAspReport = true;
      this.detailsRecalc = false;
      this.detailsAspEmpReport = false;
      this.detailsAspJurisdictionReport = false;
    } else if (type === "asp-emp") {
      this.clientAspEmp = "";
      let endPoint = "/balances/client/details/",
        dict: any = {};
      dict.client_id = this.clientId;
      dict.report_type = "asp-emp";
      dict.user_id = this.user.user_id;
      this._httpService.httpRequest("POST", endPoint, dict, (data) => {
        try {
          this.showSpinner = false;
          if (data === null || data === undefined) {
            this._appService.notify({
              status: 1,
              msg: "Server Error: getClientDetails()",
            });
          } else {
            if (data.hasOwnProperty("status") && data.status === 0) {
              this.clientAspEmp = data.asp_emp_report;
            }
          }
        } catch (e) {
          this._appService.notify({
            status: 1,
            msg: e.message,
            details: "<pre>" + e.stack + "</pre>",
          });
        }
      });
      this.detailsEarnGross = false;
      this.detailsPreAudit = false;
      this.detailsAspReport = false;
      this.detailsRecalc = false;
      this.detailsAspEmpReport = true;
      this.detailsAspJurisdictionReport = false;
    } else if (type === "asp-jurisdiction") {
      this.clientAspJurisdiction = "";
      let endPoint = "/balances/client/details/",
        dict: any = {};
      dict.client_id = this.clientId;
      dict.report_type = "asp-jurisdiction";
      dict.user_id = this.user.user_id;
      this._httpService.httpRequest("POST", endPoint, dict, (data) => {
        try {
          this.showSpinner = false;
          if (data === null || data === undefined) {
            this._appService.notify({
              status: 1,
              msg: "Server Error: getClientDetails()",
            });
          } else {
            if (data.hasOwnProperty("status") && data.status === 0) {
              this.clientAspJurisdiction = data.asp_jurisdiction_report;
            }
          }
        } catch (e) {
          this._appService.notify({
            status: 1,
            msg: e.message,
            details: "<pre>" + e.stack + "</pre>",
          });
        }
      });

      this.detailsEarnGross = false;
      this.detailsPreAudit = false;
      this.detailsAspReport = false;
      this.detailsRecalc = false;
      this.detailsAspEmpReport = false;
      this.detailsAspJurisdictionReport = true;
    } else if (type === "recalc") {
      this.clientRecalc = "";
      let endPoint = "/balances/client/details/",
        dict: any = {};
      dict.client_id = this.clientId;
      dict.report_type = "recalc";
      dict.ss_limit = parseInt(this.ssLimit);
      dict.user_id = this.user.user_id;
      this._httpService.httpRequest("POST", endPoint, dict, (data) => {
        try {
          this.showSpinner = false;
          if (data === null || data === undefined) {
            this._appService.notify({
              status: 1,
              msg: "Server Error: getClientDetails()",
            });
          } else {
            if (data.hasOwnProperty("status") && data.status === 0) {
              this.clientRecalc = data.recalc_report;
            }
          }
        } catch (e) {
          this._appService.notify({
            status: 1,
            msg: e.message,
            details: "<pre>" + e.stack + "</pre>",
          });
        }
      });

      this.detailsEarnGross = false;
      this.detailsPreAudit = false;
      this.detailsAspReport = false;
      this.detailsRecalc = true;
      this.detailsAspEmpReport = false;
      this.detailsAspJurisdictionReport = false;
    }
  }

  closeInputDialog() {
    this.inputDialog = false;
  }

  downloadReportsPkg() {
    this.showSpinner = true;
    let endPoint = "/balances/report/download/",
      dict: any = {};
    dict.client_id = this.clientId;
    dict.report_type = "ern-gross";
    dict.user_id = this.user.user_id;
    dict.ss_limit = this.ssLimit;
    this.selectedInputCodes = [
      ...this.selectedInputDed,
      ...this.selectedInputErn,
      ...this.selectedInputGtl,
    ];
    dict.input_codes = this.selectedInputCodes;
    this.inputDialog = false;
    this._httpService.httpRequest("POST", endPoint, dict, (data) => {
      try {
        this.showSpinner = false;
        if (data === null || data === undefined) {
          this._appService.notify({
            status: 1,
            msg: "Server Error: getClientDetails()",
          });
        } else {
          if (data.hasOwnProperty("status") && data.status === 0) {
            this._appService.notify({ status: 0, msg: data.msg });
          }
        }
      } catch (e) {
        this._appService.notify({
          status: 1,
          msg: e.message,
          details: "<pre>" + e.stack + "</pre>",
        });
      }
    });
  }

  downloadAttachment(attachment) {
    jQuery("#" + attachment).removeClass("expanded");
    if (attachment.file_data) {
      this.downloadFile(attachment);
    } else {
      let endPoint =
        "/balances/dcon/files/" + attachment + "/?user=" + this.user.user_id;
      this.showSpinner = true;
      this._httpService.httpRequest("GET", endPoint, null, (data) => {
        this.showSpinner = false;
        if (data === null || data === undefined) {
          this._appService.notify({
            status: 1,
            msg: "Server Error: downloadAttachment()",
          });
        } else {
          if (data.hasOwnProperty("status") && data.status === 1) {
            this._appService.notify({ status: 1, msg: data.msg });
          } else {
            if (data.hasOwnProperty("async_flag") && data.status === 0) {
              this._appService.notify({ status: 0, msg: data.msg });
            }
            if (data !== "") {
              this.fileName = data.file_name;
              this.downloadSingleFile();
            } else {
              this._appService.notify({ status: 1, msg: "File is not found" });
            }
          }
        }
      });
    }
  }

  downloadSingleFile() {
    let link = document.getElementById("dcon-download") as HTMLAnchorElement;
    if (this.fileName) {
      link.href =
        this.downloadURL +
        "/cdn/?file_name=" +
        this.fileName +
        "&?download_name=" +
        this.fileName;
      link.click();
    }
  }

  dropdown(row) {
    for (let i = 0; i < this.clientsSummary.length; i++) {
      jQuery("#" + this.clientsSummary[i].client_id).removeClass("expanded");
    }
    this.dropdownClientId = row.client_id;
    if (jQuery("#" + row.client_id).hasClass("expanded")) {
      jQuery("#" + row.client_id).removeClass("expanded");
    } else {
      jQuery("#" + row.client_id).addClass("expanded");
    }
  }

  deletePopUp(client_id) {
    this.deleteDialogue = true;
    this.deleteClientId = client_id;
  }

  toggleDeleteDialogue() {
    this.deleteClientId = "";
    this.deleteDialogue = false;
  }

  deleteClient(client_id) {
    this.deleteDialogue = false;
    if (client_id) {
      this.showSpinner = true;
      let endPoint = "/balances/client/" + client_id + "/";
      this._httpService.httpRequest("DELETE", endPoint, null, (data) => {
        if (!data) {
          data = {
            msg: "Server Error - deleteLine()",
            status: 1,
          };
        }
        if (data.status === 0) {
          this.pageRelod();
        }
        this._appService.notify({ msg: data.msg, status: data.status });
        this.showSpinner = false;
      });
    }
  }

  downloadFile(attachment) {
    let csvContent = atob(attachment),
      builder,
      blob,
      url,
      a,
      blobFile;
    blobFile = new Blob([csvContent], {
      type: "data:application/octet-stream;base64",
    });
    if (this._appService.isIE()) {
      builder = new MSBlobBuilder();
      builder.append(blobFile);

      blob = builder.getBlob(".csv");
      window.navigator.msSaveBlob(blob, "Deconstruction.csv");
    } else {
      url = this._window.URL.createObjectURL(blobFile);
      a = document.createElement("a");
      document.body.appendChild(a);
      a.style.display = "none";
      a.href = url;
      a.download = "Deconstruction.csv";
      a.click();
    }
  }

  // Export balance audit data
  exportData(type, audit_report) {
    this.showSpinner = false;
    let data,
      i,
      tableData: any = {},
      tmpData = [],
      tmpObj;
    if (audit_report === "ern-gross") {
      if (type === "excel") {
        this._excelService.exportAsExcelFile(
          this.clientEarningGross,
          "Balance Audit Report"
        );
      } else {
        data = this.clientEarningGross;
        for (i = 0; i < data.length; i++) {
          tmpObj = {};
          tmpObj["PAYGROUP"] = {
            data: data[i].paygroup,
          };
          tmpObj["FILE NBR"] = {
            data: data[i].file_nbr,
          };
          tmpObj["QUARTER"] = {
            data: data[i].quarter,
          };
          tmpObj["CHECK DT"] = {
            data: data[i].check_dt,
          };
          tmpObj["WORK STATE"] = {
            data: data[i].work_state,
          };
          tmpObj["LIVED STATE"] = {
            data: data[i].lived_st,
          };
          tmpObj["SUI"] = {
            data: data[i].sui,
          };
          tmpObj["LOCAL 1"] = {
            data: data[i].local1,
          };
          tmpObj["LOCAL 2"] = {
            data: data[i].local2,
          };
          tmpObj["OH SDIT"] = {
            data: data[i].oh_sdit,
          };
          tmpObj["LOCAL 4"] = {
            data: data[i].local4,
          };
          tmpObj["LOCAL 5"] = {
            data: data[i].local5,
          };
          tmpObj["EARNINGS"] = {
            data: data[i].earnings,
          };
          tmpObj["GROSS"] = {
            data: data[i].gross,
          };
          tmpObj["DELTA"] = {
            data: data[i].delta,
          };
          tmpObj["CLIENT ID"] = {
            data: data[i].client_id,
          };
          tmpData.push(tmpObj);
        }
      }
    } else if (audit_report === "pre-audit") {
      if (type === "excel") {
        this._excelService.exportAsExcelFile(
          this.allclientPreAudit,
          "Balance Audit Report"
        );
      } else {
        data = this.allclientPreAudit;
        for (i = 0; i < data.length; i++) {
          tmpObj = {};
          tmpObj["ISSUE"] = {
            data: data[i].issue,
          };
          tmpObj["MJ RCD NBR"] = {
            data: data[i].mj_rcd_nbr,
          };
          tmpObj["BLOCK NBR"] = {
            data: data[i].block_nbr,
          };
          tmpObj["RCD NBR"] = {
            data: data[i].rcd_nbr,
          };
          tmpObj["PAYGROUP"] = {
            data: data[i].paygroup,
          };
          tmpObj["FILE NBR"] = {
            data: data[i].file_nbr,
          };
          tmpObj["QUARTER"] = {
            data: data[i].quarter,
          };
          tmpObj["CHECK DT"] = {
            data: data[i].check_dt,
          };
          tmpObj["WORK STATE"] = {
            data: data[i].work_state,
          };
          tmpObj["LIVED STATE"] = {
            data: data[i].lived_st,
          };
          tmpObj["SUI"] = {
            data: data[i].sui,
          };
          tmpObj["LOCAL 1"] = {
            data: data[i].local1,
          };
          tmpObj["LOCAL 2"] = {
            data: data[i].local2,
          };
          tmpObj["OH SDIT"] = {
            data: data[i].oh_sdit,
          };
          tmpObj["LOCAL 4"] = {
            data: data[i].local4,
          };
          tmpObj["LOCAL 5"] = {
            data: data[i].local5,
          };
          tmpObj["ID"] = {
            data: data[i].id,
          };
          tmpObj["MOD"] = {
            data: data[i].mod,
          };
          tmpObj["AMOUNT"] = {
            data: data[i].amount,
          };
          tmpObj["CLIENT ID"] = {
            data: data[i].client_id,
          };
          tmpData.push(tmpObj);
        }
      }
    } else if (audit_report === "recalc") {
      if (type === "excel") {
        this._excelService.exportAsExcelFile(
          this.clientRecalc,
          "Balance Audit Report"
        );
      } else {
        data = this.clientRecalc;
        for (i = 0; i < data.length; i++) {
          tmpObj = {};
          tmpObj["PAYGROUP"] = {
            data: data[i].paygroup,
          };
          tmpObj["FILE NBR"] = {
            data: data[i].file_nbr,
          };
          tmpObj["GROSS"] = {
            data: data[i].gross,
          };
          tmpObj["PRE TAX DEDS"] = {
            data: data[i].pre_tax_deds,
          };
          tmpObj["NON TAXABLE EARNS"] = {
            data: data[i].non_taxable_earns,
          };
          tmpObj["GTL"] = {
            data: data[i].gtl,
          };
          tmpObj["ADJUSTED GROSS"] = {
            data: data[i].adjusted_gross,
          };
          tmpObj["ACTUAL SOSEC"] = {
            data: data[i].actual_sosec,
          };
          tmpObj["ACTUAL MCARE"] = {
            data: data[i].actual_mcare,
          };
          tmpObj["CALC SOSEC"] = {
            data: data[i].calc_sosec,
          };
          tmpObj["CALC SOSEC RECALC AMT"] = {
            data: data[i].calc_sosec_recalc_amt,
          };
          tmpObj["CALC SOSEC RECALC TAXABLE"] = {
            data: data[i].calc_sosec_recalc_taxable,
          };
          tmpObj["CALC MCARE"] = {
            data: data[i].calc_mcare,
          };
          tmpObj["CALC MCARE RECALC AMT"] = {
            data: data[i].calc_mcare_recalc_amt,
          };
          tmpObj["CALC MCARE RECALC TAXABLE"] = {
            data: data[i].calc_mcare_recalc_taxable,
          };
          tmpObj["CLIENT ID"] = {
            data: data[i].client_id,
          };
          tmpData.push(tmpObj);
        }
      }
    } else if (audit_report === "asp-paygroup") {
      if (type === "excel") {
        this._excelService.exportAsExcelFile(
          this.clientAsp,
          "Balance Audit Report"
        );
      } else {
        data = this.clientAsp;
        for (i = 0; i < data.length; i++) {
          tmpObj = {};
          tmpObj["PAYGROUP"] = {
            data: data[i].paygroup,
          };
          tmpObj["ID"] = {
            data: data[i].id,
          };
          tmpObj["MOD"] = {
            data: data[i].mod,
          };
          tmpObj["amount"] = {
            data: data[i].amount,
          };
          tmpObj["CLIENT ID"] = {
            data: data[i].client_id,
          };
          tmpData.push(tmpObj);
        }
      }
    } else if (audit_report === "asp-emp") {
      if (type === "excel") {
        this._excelService.exportAsExcelFile(
          this.clientAspEmp,
          "Balance Audit Report"
        );
      } else {
        data = this.clientAspEmp;
        for (i = 0; i < data.length; i++) {
          tmpObj = {};
          tmpObj["PAYGROUP"] = {
            data: data[i].paygroup,
          };
          tmpObj["FILE_NBR"] = {
            data: data[i].file_nbr,
          };
          tmpObj["ID"] = {
            data: data[i].id,
          };
          tmpObj["MOD"] = {
            data: data[i].mod,
          };
          tmpObj["amount"] = {
            data: data[i].amount,
          };
          tmpObj["CLIENT ID"] = {
            data: data[i].client_id,
          };
          tmpData.push(tmpObj);
        }
      }
    } else if (audit_report === "asp-jurisdiction") {
      if (type === "excel") {
        this._excelService.exportAsExcelFile(
          this.clientAspJurisdiction,
          "Balance Audit Report"
        );
      } else {
        data = this.clientAspJurisdiction;
        for (i = 0; i < data.length; i++) {
          tmpObj = {};
          tmpObj["SEQUENCE"] = {
            data: data[i].sequence,
          };
          tmpObj["PAYGROUP"] = {
            data: data[i].paygroup,
          };
          tmpObj["TAX_TYPE"] = {
            data: data[i].tax_type,
          };
          tmpObj["JURISDICTION"] = {
            data: data[i].jurisdiction,
          };
          tmpObj["amount"] = {
            data: data[i].amount,
          };
          tmpObj["CLIENT ID"] = {
            data: data[i].client_id,
          };
          tmpData.push(tmpObj);
        }
      }
    }
    if (type === "csv") {
      tableData.data = tmpData;
      this._appService.exportToCSV("Balance Audit Report", tableData, "");
    }
  }

  generateAuditReport() {
    this.showSpinner = true;
    let endPoint = "/balances/client/details/",
      dict: any = {};
    dict.client_id = this.clientId;
    dict.report_type = "ern-gross";
    dict.user_id = this.user.user_id;
    this.selectedInputCodes = [
      ...this.selectedInputDed,
      ...this.selectedInputErn,
      ...this.selectedInputGtl,
    ];
    dict.input_codes = this.selectedInputCodes;
    this._httpService.httpRequest("POST", endPoint, dict, (data) => {
      try {
        this.showSpinner = false;
        if (data === null || data === undefined) {
          this._appService.notify({
            status: 1,
            msg: "Server Error: getClientDetails()",
          });
        } else {
          if (data.hasOwnProperty("status") && data.status === 0) {
            this.detailsEarnGross = true;
            this.detailsPreAudit = false;
            this.detailsAspReport = false;
            this.detailsRecalc = false;
            this.detailsAspEmpReport = false;
            this.detailsAspJurisdictionReport = false;

            this.clientDialogue = true;
            this.summaryDialogue = false;
            this.inputDialog = false;
            this.clientEarningGross = data.earning_gross_match;
          }
        }
      } catch (e) {
        this._appService.notify({
          status: 1,
          msg: e.message,
          details: "<pre>" + e.stack + "</pre>",
        });
      }
    });
  }

  getClientDetails(clientId, reportType) {
    this.reportType = reportType;
    if (this.reportType === "download") {
      jQuery("#" + clientId).removeClass("expanded");
    }
    this.showSpinner = true;
    this.input_ded_codes = "";
    this.input_ern_codes = "";
    this.input_gtl_codes = "";
    this.clientId = "";
    this.selectedInputDed = [];
    this.selectedInputGtl = [];
    this.selectedInputErn = [];
    for (let i = 0; i < this.clientsSummary.length; i++) {
      if (this.clientsSummary[i]["client_id"] === clientId) {
        this.input_ded_codes = this.clientsSummary[i]["input_ded_codes"];
        this.input_ern_codes = this.clientsSummary[i]["input_ern_codes"];
        this.input_gtl_codes = this.clientsSummary[i]["input_gtl_codes"];
        this.existing_input_codes =
          this.clientsSummary[i]["existing_input_codes"];
        this.clientId = clientId;
      }
    }

    for (let i = 0; i < this.existing_input_codes.length; i++) {
      let index, ded, gtl, ern;
      if (this.existing_input_codes[i].id === "S") {
        ded = {
          id: "S",
          mod: this.existing_input_codes[i].mod,
          checked: true,
        };
        index = this.input_ded_codes
          .map((x) => x.mod + x.id)
          .indexOf(ded.mod + ded.id);
        if (index !== -1) {
          this.selectedInputDed.push(ded);
          this.input_ded_codes[index].checked = true;
        }
      } else if (this.existing_input_codes[i].id === "19") {
        gtl = {
          id: "19",
          mod: this.existing_input_codes[i].mod,
          checked: true,
        };
        index = this.input_gtl_codes
          .map((x) => x.mod + x.id)
          .indexOf(gtl.mod + gtl.id);
        if (index !== -1) {
          this.selectedInputGtl.push(gtl);
          this.input_gtl_codes[index].checked = true;
        }
      } else {
        ern = {
          id: this.existing_input_codes[i].id,
          mod: this.existing_input_codes[i].mod,
          checked: true,
        };
        index = this.input_ern_codes
          .map((x) => x.mod + x.id)
          .indexOf(ern.mod + ern.id);
        if (index !== -1) {
          this.selectedInputErn.push(ern);
          this.input_ern_codes[index].checked = true;
        }
      }
    }
    this.inputDialog = true;
    this.showSpinner = false;
  }

  goToState(state) {
    if (state) {
      this._router.navigate([state]);
    }
  }

  loadClients(user_id) {
    let endPoint =
      "/balances/summary/" + user_id + "/" + this.selectedStatus + "/";
    console.log(endPoint);
    this.showSpinner = true;
    this.detailsEarnGross = false;
    this.detailsPreAudit = false;
    this.detailsAspReport = false;
    this.detailsRecalc = false;
    this._httpService.httpRequest("GET", endPoint, null, (data) => {
      try {
        this.showSpinner = false;
        this.clientDialogue = false;
        if (data === null || data === undefined) {
          this._appService.notify({
            status: 1,
            msg: "Server Error: loadClients()",
          });
        } else {
          this.summaryDialogue = true;
          if (data.hasOwnProperty("status") && data.status === 0) {
            let result = data.result;
            this.predicate = "client_id";
            this.desc = true;
            this.clientsSummary = result;
          }
        }
      } catch (e) {
        this._appService.notify({
          status: 1,
          msg: e.message,
          details: "<pre>" + e.stack + "</pre>",
        });
      }
    });
  }

  loadUsers() {
    this.showSpinner = true;
    let endPoint;
    endPoint = "/users/" + this.user.default_org_id + "/";
    this._httpService.httpRequest("GET", endPoint, null, (data) => {
      try {
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: "Server Error" });
        } else {
          this.allUsers = data.result;
        }
      } catch (e) {
        this._appService.notify({
          status: 1,
          msg: e.message,
          details: "<pre>" + e.stack + "</pre>",
        });
      }
    });
  }

  // Load more records on scroll
  loadMore() {
    try {
      let page = this.currentPage + 1,
        tempData,
        i,
        startIndex = (page - 1) * this.pageSize,
        endIndex = page * this.pageSize;
      this.currentPage = page;
      if (this.allclientPreAudit) {
        tempData = this.allclientPreAudit.slice(startIndex, endIndex);
        for (i = 0; i < tempData.length; i++) {
          this.clientPreAudit.push(tempData[i]);
        }
      }
    } catch (e) {
      this._appService.notify({
        status: 1,
        msg: e.message,
        details: "<pre>" + e.stack + "</pre>",
      });
    }
  }

  onInputDedClick(ded) {
    jQuery("#modal-wrapper").scrollTop(0);
    let index = this.input_ded_codes.indexOf(ded);
    if (index !== -1) {
      if (!this.selectedInputDed) {
        this.selectedInputDed = [];
      }
      index = this.selectedInputDed
        .map((x) => x.mod + x.id)
        .indexOf(ded.mod + ded.id);

      if (index === -1) {
        this.selectedInputDed.push(ded);
      } else {
        this.selectedInputDed.splice(index, 1);
      }
    }
  }

  onInputErnClick(ern) {
    jQuery("#modal-wrapper").scrollTop(0);
    let index = this.input_ern_codes.indexOf(ern);
    if (index !== -1) {
      if (!this.selectedInputErn) {
        this.selectedInputErn = [];
      }
      index = this.selectedInputErn
        .map((x) => x.mod + x.id)
        .indexOf(ern.mod + ern.id);

      if (index === -1) {
        this.selectedInputErn.push(ern);
      } else {
        this.selectedInputErn.splice(index, 1);
      }
    }
  }

  onInputGtlClick(gtl) {
    jQuery("#modal-wrapper").scrollTop(0);
    let index = this.input_gtl_codes.indexOf(gtl);
    if (index !== -1) {
      if (!this.selectedInputGtl) {
        this.selectedInputGtl = [];
      }
      index = this.selectedInputGtl
        .map((x) => x.mod + x.id)
        .indexOf(gtl.mod + gtl.id);

      if (index === -1) {
        this.selectedInputGtl.push(gtl);
      } else {
        this.selectedInputGtl.splice(index, 1);
      }
    }
  }

  pageRelod() {
    this._window.location.reload();
  }

  saveButton() {
    this.detailsEarnGrossSave = !this.detailsEarnGrossSave;
    this.detailsPreAuditSave = !this.detailsPreAuditSave;
    this.detailsRecalcSave = !this.detailsRecalcSave;
    this.detailsAspSave = !this.detailsAspSave;
    this.detailsAspEmpSave = !this.detailsAspEmpSave;
    this.detailsAspJurisdictionSave = !this.detailsAspJurisdictionSave;
  }

  setUpDOMHandlers() {
    jQuery(document).mouseup((e) => {
      e.stopPropagation();
      if (!jQuery(e.target).closest(".dropdown").length) {
        jQuery("#" + this.dropdownClientId).removeClass("expanded");
      }
    });
  }

  sort(key) {
    if (this.predicate === key) {
      this.desc = !this.desc;
    } else {
      this.predicate = key;
      this.desc = false;
    }
  }

  summaryButton() {
    this.clientDialogue = false;
    this.summaryDialogue = true;
  }
}
