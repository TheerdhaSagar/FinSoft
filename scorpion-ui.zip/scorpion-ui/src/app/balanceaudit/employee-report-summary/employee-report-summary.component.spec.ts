import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeReportSummaryComponent } from './employee-report-summary.component';

describe('EmployeeReportSummaryComponent', () => {
  let component: EmployeeReportSummaryComponent;
  let fixture: ComponentFixture<EmployeeReportSummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeReportSummaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeReportSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
