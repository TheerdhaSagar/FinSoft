import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BalanceauditComponent } from './balanceaudit.component';

describe('BalanceauditComponent', () => {
  let component: BalanceauditComponent;
  let fixture: ComponentFixture<BalanceauditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BalanceauditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BalanceauditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
