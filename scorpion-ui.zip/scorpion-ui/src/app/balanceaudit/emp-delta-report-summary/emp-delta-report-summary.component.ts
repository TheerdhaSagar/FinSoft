import { Component, OnDestroy, OnInit } from '@angular/core';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { DataService } from '../../globals/data.service';
import { ExcelService } from "../../globals/excel.service";
import { FormatService } from '../../globals/format.service';
import { HttpService } from '../../globals/http.service';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { environment } from '../../../environments/environment';
import jQuery from '../../../../node_modules/jquery';

@Component({
  selector: 'app-emp-delta-report-summary',
  templateUrl: './emp-delta-report-summary.component.html',
  styleUrls: ['./emp-delta-report-summary.component.scss']
})
export class EmpDeltaReportSummaryComponent implements OnInit {

  private _appService: AppService;
  private _cacheService: CacheService;
  private _dataService: DataService;
  private _excelService: ExcelService;
  private _formatService: FormatService;
  private _httpService: HttpService;
  private _location: Location;
  private _router: Router;
  private _window: any;


  allclientPreAudit: any;
  allUsers: any;
  auditType: any;
  clientDeconstruction: any;
  clientDialogue: boolean;
  clientEarningGross: any;
  clientPreAudit: any;
  clientAsp: any;
  clientAspEmp: any;
  clientAspJurisdiction: any;
  clientRecalc: any;
  clientsSummary: any;
  clientId: any;
  currentPage: any;
  deleteClientId: any;
  deleteDialogue: boolean;
  detailsAspSave: boolean;
  detailsAspEmpSave: boolean;
  detailsAspJurisdictionSave: boolean;
  detailsEarnGross: boolean;
  detailsEarnGrossSave: boolean;
  detailsPreAudit: boolean;
  detailsPreAuditSave: boolean;
  detailsRecalcSave: boolean;
  detailsAspEmpReport: boolean;
  detailsAspReport: boolean;
  detailsAspJurisdictionReport: boolean;
  detailsRecalc: boolean;
  desc: boolean;
  downloadURL: string;
  dropdownClientId: any;
  existing_input_codes: any;
  fileData: any;
  fileName: any;
  input_ded_codes: any;
  input_ern_codes: any;
  input_gtl_codes: any;
  inputDialog: boolean;
  pageSize: number;
  reportType: string;
  selectedInputCodes: any;
  selectedInputDed: any;
  selectedInputErn: any;
  selectedInputGtl: any;
  selectedStatus: string;
  selectedUser: any;
  showSpinner: boolean;
  ssLimit: any;
  summaryDialogue: boolean;
  predicate: any;
  toggleFilter: (e?) => void;
  user:any;


  constructor(appService: AppService, cacheService: CacheService, dataService: DataService, excelService: ExcelService, formatService: FormatService,
              httpService: HttpService, location: Location, router: Router) {

    this._appService = appService;
    this._cacheService = cacheService;
    this._excelService = excelService;
    this._httpService = httpService;
    this._location = location;
    this._router = router;
    this._window = window;

    this.allclientPreAudit = null;
    this.allUsers = [];
    this.auditType = null;
    this.clientDeconstruction = null;
    this.clientDialogue = false;
    this.clientEarningGross= null;
    this.clientId = null;
    this.clientPreAudit = null;
    this.clientAsp = null;
    this.clientAspEmp = null;
    this.clientAspJurisdiction = null;
    this.clientRecalc = null;
    this.clientsSummary = null;
    this.currentPage = null;
    this.deleteClientId = null;
    this.deleteDialogue = false;
    this.detailsAspSave = false;
    this.detailsAspEmpSave = false;
    this.detailsAspJurisdictionSave = false;
    this.detailsEarnGross = false;
    this.detailsEarnGrossSave = false;
    this.detailsPreAudit= false;
    this.detailsPreAuditSave = false;
    this.detailsRecalcSave = false;
    this.detailsAspReport = false;
    this.detailsAspEmpReport = false;
    this.detailsAspJurisdictionReport = false;
    this.detailsRecalc = false;
    this.desc = false;
    this.downloadURL = environment.url;
    this.dropdownClientId = null;
    this.existing_input_codes = '';
    this.fileData = null;
    this.fileName = null;
    this.input_ded_codes = null;
    this.input_ern_codes = null;
    this.input_gtl_codes = null;
    this.inputDialog = false;
    this.pageSize = this._appService.pageSize;
    this.reportType = '';
    this.selectedStatus = 'ALL';
    this.selectedUser = -1;
    this.selectedInputCodes = '';
    this.selectedInputDed = '';
    this.selectedInputErn = '';
    this.selectedInputGtl = '';
    this.showSpinner = false;
    this.ssLimit = 137700;
    this.summaryDialogue = false;
    this.predicate = null;
    this.user = null;
  }

  ngOnInit() {
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this.user = data;
      }
      this.selectedUser = this.user.user_id;
      this.loadUsers();
      this.loadClients(this.selectedUser);
      this.setUpDOMHandlers();
      this.toggleFilter = this._appService.toggleFilter();
    });
  }

  applyFilter() {
    this.toggleFilter();
    this.showSpinner = true;
    this.loadClients(this.selectedUser);
  }

  downloadAttachment(attachment, audit_type) {
    jQuery('#' + attachment).removeClass('expanded');
    if (attachment.file_data) {
      this.downloadFile(attachment);
    } else {
      let endPoint;
      if (audit_type === 'wage-tax'){
        endPoint = '/balances/wage/tax/files/' + attachment + '/?user=' + this.user.user_id;
      } else if (audit_type === 'control-totals') {
        endPoint = '/balances/control/files/' + attachment + '/?user=' + this.user.user_id;
      } else if (audit_type === 'translations') {
        endPoint = '/balances/translation/files/' + attachment + '/?user=' + this.user.user_id;
      }
      this.showSpinner = true;
      this._httpService.httpRequest('GET', endPoint, null, (data) => {
        this.showSpinner = false;
        if (data === null || data === undefined) {
          this._appService.notify({status: 1, msg: 'Server Error: downloadAttachment()'});
        } else {
          if (data.hasOwnProperty('status') && data.status === 1) {
            this._appService.notify({status: 1, msg: data.msg});
          } else {
            if (data.hasOwnProperty('async_flag') && data.status === 0) {
              this._appService.notify({status: 0, msg: data.msg});
            }
            if (data !== '') {
              this.fileName = data.file_name;
              this.downloadSingleFile();
            } else {
              this._appService.notify({status: 1, msg: 'File is not found'});
            }
          }
        }
      });
    }
  }

  downloadFile(attachment) {
    let csvContent = atob(attachment),
      builder, blob, url, a, blobFile;
    blobFile = new Blob([csvContent], {type: "data:application/octet-stream;base64"});
    if (this._appService.isIE()) {
      builder = new MSBlobBuilder();
      builder.append(blobFile);

      blob = builder.getBlob('.csv');
      window.navigator.msSaveBlob(blob, 'Deconstruction.csv');
    } else {
      url = this._window.URL.createObjectURL(blobFile);
      a = document.createElement('a');
      document.body.appendChild(a);
      a.style.display = 'none';
      a.href = url;
      a.download = 'wage_tax.csv';
      a.click();
    }
  }

  deletePopUp(client_id, audit_type) {
    this.deleteDialogue = true;
    this.deleteClientId = client_id;
    this.auditType = audit_type;
  }

  toggleDeleteDialogue() {
    this.deleteClientId = '';
    this.auditType = '';
    this.deleteDialogue = false;
  }

  deleteClient(client_id, audit_type){
    this.deleteDialogue = false;
    if(client_id){
      this.showSpinner = true;
      let endPoint = '/balances/audit/client/' + client_id + '/' + audit_type + '/';
      this._httpService.httpRequest('DELETE', endPoint, null, (data) => {
        if (!data) {
          data = {
            msg: 'Server Error - deleteClientAudit()',
            status: 1
          };
        }
        if (data.status === 0) {
          this.pageRelod();
        }
        this._appService.notify({ msg: data.msg, status: data.status });
        this.showSpinner = false;
      });
    }
  }

  downloadSingleFile() {
    let link = document.getElementById('dcon-download') as HTMLAnchorElement;
    if (this.fileName) {
      link.href = this.downloadURL + '/cdn/?file_name=' + this.fileName + '&?download_name=' + this.fileName;
      link.click();
    }
  }

  dropdown(row) {
    for(let i=0; i < this.clientsSummary.length; i++) {
      jQuery('#' + this.clientsSummary[i].client_id).removeClass('expanded');
    }
    this.dropdownClientId = row.client_id;
    if (jQuery('#' + row.client_id).hasClass('expanded')) {
      jQuery('#' + row.client_id).removeClass('expanded');
    } else {
      jQuery('#' + row.client_id).addClass('expanded');
    }
  }

  goToState(state) {
    if (state) {
      this._router.navigate([state]);
    }
  }

  loadClients(user_id) {
    let endPoint = '/balances/audit/summary/' + user_id + '/' + this.selectedStatus + '/';
    this.showSpinner = true;
    this.detailsEarnGross= false;
    this.detailsPreAudit= false;
    this.detailsAspReport= false;
    this.detailsRecalc= false;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        this.showSpinner = false;
        this.clientDialogue = false;
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error: loadClients()' });
        } else {
          this.summaryDialogue = true;
          if (data.hasOwnProperty('status') && data.status === 0) {
            let result = data.result;
            this.predicate = 'client_id';
            this.desc = true;
            this.clientsSummary = result;
          }
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  loadUsers() {
    this.showSpinner = true;
    let endPoint;
    endPoint = '/users/' + this.user.default_org_id + '/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error' });
        } else {
          this.allUsers = data.result;
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  pageRelod(){
    this._window.location.reload();
  }

  setUpDOMHandlers() {
    jQuery(document).mouseup((e) => {
      e.stopPropagation();
      if (!jQuery(e.target).closest('.dropdown').length) {
        jQuery('#' + this.dropdownClientId).removeClass('expanded');
      }
    });

  }

  sort(key) {
    if (this.predicate === key) {
      this.desc = !this.desc;
    } else {
      this.predicate = key;
      this.desc = false;
    }
  }
}
