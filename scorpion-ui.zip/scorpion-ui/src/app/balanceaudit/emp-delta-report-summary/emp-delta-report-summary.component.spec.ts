import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmpDeltaReportSummaryComponent } from './emp-delta-report-summary.component';

describe('EmpDeltaReportSummaryComponent', () => {
  let component: EmpDeltaReportSummaryComponent;
  let fixture: ComponentFixture<EmpDeltaReportSummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmpDeltaReportSummaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmpDeltaReportSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
