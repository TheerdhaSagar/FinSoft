import { Component, OnInit } from '@angular/core';
import {AppService} from "../../globals/app.service";
import {CacheService} from "../../globals/cache.service";
import { DataService } from '../../globals/data.service';
import {FormatService} from "../../globals/format.service";
import {HttpService} from "../../globals/http.service";
import {Location} from "@angular/common";
import {Router} from "@angular/router";

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.scss']
})
export class ReportsComponent implements OnInit {

  private _appService: AppService;
  private _cacheService: CacheService;
  private _dataService: DataService;
  private _formatService: FormatService;
  private _httpService: HttpService;
  private _location: Location;
  private _router: Router;
  private _window: any;

  clientsSummary: any;
  fileData: any;
  showSpinner: boolean;
  user: any;

  constructor(appService: AppService, cacheService: CacheService, dataService: DataService, formatService: FormatService,
              httpService: HttpService, location: Location, router: Router) {

    this._appService = appService;
    this._cacheService = cacheService;
    this._dataService = dataService;
    this._httpService = httpService;
    this._location = location;
    this._router = router;
    this._formatService = formatService;
    this._window = window;

    this.clientsSummary = '';
    this.fileData = '';
    this.showSpinner = false;
    this.user = '';

  }

  ngOnInit() {
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this.user = data;
        this.loadClients();
      }
    });
  }

  downloadAttachment(client_id, conversion_name, type) {
    let endPoint, attachment = {
      file_data: '',
      file_name: '',
      file_type: ''
    };
    if (type === 'EE') {
      endPoint = '/wfn/error/report/download/' + client_id + '/' + conversion_name + '/';
    } else if (type == 'summary') {
      endPoint = '/wfn/error/report/download/summary/' + client_id + '/' + conversion_name + '/'
    }
    this.showSpinner = true;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      this.showSpinner = false;
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error: downloadAttachment()' });
      } else {
        if (data.status === 0) {
          attachment.file_data = data.file_data;
          if (conversion_name == 'master-file'){
            if (type == 'EE') {
              attachment.file_name = 'Mf_Error_Report.xlsx'
            }
            else {
              attachment.file_name = 'Mf_Summary_Report.xlsx'
            }
          }
          attachment.file_type = 'application/vnd.ms-excel';
          this.downloadFile(attachment);
        } else {
          this._appService.notify({ status: 1, msg: data.msg });
        }
      }
    });
  }

  downloadFile(attachment) {
    this.fileData = attachment.file_data;
    // Convert blob to base64 formatHelper
    let blobFile = this._formatService.base64ToBlob(this.fileData, attachment.file_type);
    if (this._appService.isIE()) {
      let builder = new MSBlobBuilder();
      builder.append(blobFile);

      let blob = builder.getBlob(attachment.file_type);
      window.navigator.msSaveBlob(blob, attachment.file_name);
    } else {
      let url = this._window.URL.createObjectURL(blobFile);
      let a = document.createElement('a');
      document.body.appendChild(a);
      a.style.display = 'none';
      a.href = url;
      a.download = attachment.file_name;
      a.click();
    }
  }

  goToState(state) {
    if (state) {
      this._router.navigate([state]);
    }
  }



  loadClients() {
    let endPoint = '/wfn/summary/';
    this.showSpinner = true;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        this.showSpinner = false;
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error: loadClients()' });
        } else {
          if (data.hasOwnProperty('status') && data.status === 0) {
            let result = data.result;
            this.clientsSummary = result;
          }
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

}
