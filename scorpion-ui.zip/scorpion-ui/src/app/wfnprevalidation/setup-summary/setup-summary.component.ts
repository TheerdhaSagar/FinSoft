import { Component, OnDestroy, OnInit } from '@angular/core';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { DataService } from '../../globals/data.service';
import { FormatService } from '../../globals/format.service';
import { HttpService } from '../../globals/http.service';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import jQuery from '../../../../node_modules/jquery';
import {OrderByPipe} from "../../globals/order-by.pipe";
@Component({
  selector: 'app-setup-summary',
  templateUrl: './setup-summary.component.html',
  styleUrls: ['./setup-summary.component.scss']
})
export class SetupSummaryComponent implements OnInit {
  private _appService: AppService;
  private _cacheService: CacheService;
  private _dataService: DataService;
  private _formatService: FormatService;
  private _httpService: HttpService;
  private _location: Location;
  private _router: Router;
  private _window: any;

  desc: boolean;
  detailsDialogue: boolean;
  predicate: any;
  setupDetails: any;
  setupSummary: any;
  showSpinner: boolean;
  summaryDialogue: boolean;
  user:any;

  constructor(appService: AppService, cacheService: CacheService, dataService: DataService, formatService: FormatService,
              httpService: HttpService, location: Location, router: Router) {

    this._appService = appService;
    this._cacheService = cacheService;
    this._httpService = httpService;
    this._location = location;
    this._router = router;
    this._window = window;

    this.desc = false;
    this.detailsDialogue = false;
    this.predicate = null;
    this.setupDetails = null;
    this.setupSummary = null;
    this.showSpinner = false;
    this.summaryDialogue = true;
    this.user = null;

  }

  ngOnInit() {
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this.user = data;
        this.getSetupSummary();
      }
    });

  }

  getSetupDetails(clientId){
    this.showSpinner = true;
    let endPoint = '/wfn/setup/details/'+ clientId + '/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        this.showSpinner = false;
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error: getSetupDetails()' });
        } else {
          if (data.hasOwnProperty('status') && data.status === 0) {
            this.summaryDialogue = false;
            this.detailsDialogue = true;
            this.setupDetails = data.result;
          }
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  getSetupSummary(){
    this.showSpinner = true;
    let endPoint = '/wfn/setup/summary/'+ this.user.user_id + '/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        this.showSpinner = false;
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error: getSetupSummary()' });
        } else {
          if (data.hasOwnProperty('status') && data.status === 0) {
            this.setupSummary = data.result;
          }
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  goToSummary(){
    this.detailsDialogue = false;
    this.summaryDialogue = true;
  }

  goToState(state) {
    if (state) {
      this._router.navigate([state]);
    }
  }

  sort(key) {
    if (this.predicate === key) {
      this.desc = !this.desc;
    } else {
      this.predicate = key;
      this.desc = false;
    }
  }

}
