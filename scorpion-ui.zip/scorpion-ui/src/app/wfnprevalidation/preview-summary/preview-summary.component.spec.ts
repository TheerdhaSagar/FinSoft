import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PreviewSummaryComponent } from './preview-summary.component';

describe('PreviewSummaryComponent', () => {
  let component: PreviewSummaryComponent;
  let fixture: ComponentFixture<PreviewSummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PreviewSummaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PreviewSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
