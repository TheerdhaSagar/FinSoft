import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WfnprevalidationComponent } from './wfnprevalidation.component';

describe('WfnprevalidationComponent', () => {
  let component: WfnprevalidationComponent;
  let fixture: ComponentFixture<WfnprevalidationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WfnprevalidationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WfnprevalidationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
