import { Component, OnInit } from '@angular/core';
import { AppService } from '../../globals/app.service';
import { CacheService } from '../../globals/cache.service';
import { DataService } from '../../globals/data.service';
import { FormatService } from '../../globals/format.service';
import { OrderByPipe } from '../../globals/order-by.pipe';
import { HttpService } from '../../globals/http.service';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import jQuery from '../../../../node_modules/jquery';

declare var FooPicker: any;

@Component({
  selector: 'app-add-client',
  templateUrl: './add-client.component.html',
  styleUrls: ['./add-client.component.scss'],
  providers: [OrderByPipe]
})
export class AddClientComponent implements OnInit {

  private _appService: AppService;
  private _cacheService: CacheService;
  private _dataService: DataService;
  private _formatService: FormatService;
  private _orderBy: OrderByPipe;
  private _httpService: HttpService;
  private _location: Location;
  private _router: Router;
  private _window: any;

  addClientDialogue: boolean;
  clientId: any;
  clientName: any;
  clientsSummary: any;
  focusClientId: boolean;
  focusClientName: boolean;
  goLiveDate: any;
  ic: any;
  mftDetails: any;
  projectDate: any;
  projectManager: any;
  projectScope: any;
  projectScopes: any;
  selectedScopes: any;
  sharedPath: any;
  showSpinner: boolean;
  user: any;

  constructor(appService: AppService, cacheService: CacheService, dataService: DataService, formatService: FormatService, orderBy: OrderByPipe,
              httpService: HttpService, location: Location, router: Router) {

    this._appService = appService;
    this._cacheService = cacheService;
    this._dataService = dataService;
    this._orderBy = orderBy;
    this._httpService = httpService;
    this._location = location;
    this._router = router;
    this._window = window;

    this.addClientDialogue = false;
    this.clientId = '';
    this.clientName = '';
    this.clientsSummary = '';
    this.focusClientId = false;
    this.focusClientName = false;
    this.goLiveDate = '';
    this.ic = '';
    this.mftDetails = '';
    this.projectDate = '';
    this.projectManager = '';
    this.projectScope = '';
    this.projectScopes = ['Launch_Pad', 'New_Logo', 'Balances', 'Monarch'];
    this.selectedScopes = '';
    this.sharedPath = '';
    this.showSpinner = false;
    this.user = '';
  }

  ngOnInit() {
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this.user = data;
        setTimeout(() => {
          new FooPicker({
            id: 'project-cal',
            dateFormat: 'DD-MON-YYYY'
          });

          new FooPicker({
            id: 'golive-date',
            dateFormat: 'DD-MON-YYYY'
          });
        });

      }
    });
  }

  goToState(state) {
    if (state) {
      this._router.navigate([state]);
    }
  }


  onProjectScope(projectScope) {
    let index = this.projectScopes.indexOf(projectScope);
    if (index !== -1) {
      if (!this.selectedScopes) {
        this.selectedScopes = [];
      }
      index = this.selectedScopes.map(x => x).indexOf(projectScope);

      if (index === -1) {
        this.selectedScopes.push(projectScope);
      } else {
        this.selectedScopes.splice(index, 1);
      }
    }
  }

  upload() {
    let dict: any = {}, endPoint = '/wfn/add/client/';
    if (!this.clientId || !this.clientName){
      this._appService.notify({ msg: 'Client_id and Client Name are Mandatory Fields', status: 1 });
      this.addClientDialogue = false;
      return;
    }
    this.showSpinner = true;
    dict.client_id = this.clientId;
    dict.user_id = this.user.user_id;
    dict.client_name = this.clientName;
    dict.project_manager = this.projectManager;
    dict.ic = this.ic;
    dict.mft_details = this.mftDetails;
    dict.shared_path = this.sharedPath;
    dict.project_start_date = this.projectDate;
    dict.go_live_date = this.goLiveDate;
    dict.project_scope = this.selectedScopes;
    dict.status = 'A';
    dict.team = this._dataService.orgId;
    this._httpService.httpRequest('POST', endPoint, dict, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - upload()' });
      } else {
        if (data.status === 1) {
          this._appService.notify({ msg: data.msg, status: data.status });
        } else {
          this._appService.notify({ msg: data.msg, status: data.status });
          this._router.navigate(['/wfn/client/summary']);
        }
      }
      this.showSpinner = false;
    });
  }

}
