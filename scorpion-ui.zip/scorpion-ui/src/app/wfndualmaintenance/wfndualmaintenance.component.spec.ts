import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WfndualmaintenanceComponent } from './wfndualmaintenance.component';

describe('WfndualmaintenanceComponent', () => {
  let component: WfndualmaintenanceComponent;
  let fixture: ComponentFixture<WfndualmaintenanceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WfndualmaintenanceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WfndualmaintenanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
