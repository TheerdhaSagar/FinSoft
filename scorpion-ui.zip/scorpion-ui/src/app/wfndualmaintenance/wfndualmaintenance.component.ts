import { Component, OnDestroy, OnInit } from '@angular/core';
import { AppService } from '../globals/app.service';
import { CacheService } from '../globals/cache.service';
import { DataService } from '../globals/data.service';
import { FormatService } from '../globals/format.service';
import { HttpService } from '../globals/http.service';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import jQuery from '../../../node_modules/jquery';

declare var FooPicker: any;
@Component({
  selector: 'app-wfndualmaintenance',
  templateUrl: './wfndualmaintenance.component.html',
  styleUrls: ['./wfndualmaintenance.component.scss']
})
export class WfndualmaintenanceComponent implements OnInit {
  private _appService: AppService;
  private _cacheService: CacheService;
  private _dataService: DataService;
  private _formatService: FormatService;
  private _httpService: HttpService;
  private _location: Location;
  private _router: Router;
  private _window: any;

  attachments: any;
  Clients: any;
  clientId: any;
  clientIdNew: any;
  clientName: any;
  clientNameNew: any;
  clientDropdown: boolean;
  conversionName: any;
  focusClientId: boolean;
  focusClientName: boolean;
  focusClient: boolean;
  focusConversion: boolean;
  focusUpload: boolean;
  focusImportUpload: boolean;
  goLiveDate: any;
  ic: any;
  inputDialog: boolean;
  mftDetails: any;
  projectManager: any;
  projectScopes: any;
  projectDate: any;
  selectedScopes: any;
  sharedPath: any;
  showSpinner: boolean;
  uploadDialog: boolean;
  uploadedFile: any;
  uploadImportFile: any;
  user: any;


  constructor(appService: AppService, cacheService: CacheService, dataService: DataService, formatService: FormatService,
              httpService: HttpService, location: Location, router: Router) {

    this._appService = appService;
    this._cacheService = cacheService;
    this._dataService = dataService;
    this._httpService = httpService;
    this._location = location;
    this._router = router;
    this._window = window;

    this.attachments = null;
    this.Clients = '';
    this.clientId = 'select client';
    this.clientIdNew = '';
    this.clientName = '';
    this.clientDropdown = false;
    this.conversionName = '';
    this.clientNameNew = '';
    this.focusClient = false;
    this.focusClientId = false;
    this.focusClientName = false;
    this.focusConversion = false;
    this.focusUpload = false;
    this.focusImportUpload = false;
    this.goLiveDate = '';
    this.ic = '';
    this.inputDialog = false;
    this.mftDetails = '';
    this.projectManager = '';
    this.projectScopes = ['Launch_Pad', 'New_Logo', 'Balances', 'Monarch'];
    this.projectDate = '';
    this.selectedScopes = '';
    this.sharedPath = '';
    this.showSpinner = false;
    this.uploadDialog = false;
    this.uploadedFile = '';
    this.uploadImportFile= '';
    this.user = '';

  }

  ngOnInit() {
    setTimeout(() => {
      new FooPicker({
        id: 'project-cal',
        dateFormat: 'DD-MON-YYYY'
      });

      new FooPicker({
        id: 'golive-date',
        dateFormat: 'DD-MON-YYYY'
      });
    });
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this.user = data;
      }
      this.loadClients();
      this.setUpDOMHandlers();
    });
  }

  addClient() {
    let dict: any = {}, endPoint = '/wfn/add/client/';
    if (!this.clientIdNew || !this.clientNameNew) {
      this._appService.notify({msg: 'Client_id and Client Name are Mandatory Fields', status: 1});
      this.inputDialog = false;
      return;
    }
    this.showSpinner = true;
    dict.client_id = this.clientIdNew;
    dict.user_id = this.user.user_id;
    dict.client_name = this.clientNameNew;
    dict.project_manager = this.projectManager;
    dict.ic = this.ic;
    dict.mft_details = this.mftDetails;
    dict.shared_path = this.sharedPath;
    dict.project_start_date = this.projectDate;
    dict.go_live_date = this.goLiveDate;
    dict.project_scope = this.selectedScopes;
    dict.status = 'P';
    dict.team = this._dataService.orgId;
    this._httpService.httpRequest('POST', endPoint, dict, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({status: 1, msg: 'Server Error - upload()'});
      } else {
        if (data.status === 1) {
          this._appService.notify({msg: data.msg, status: data.status});
        } else {
          this._appService.notify({msg: data.msg, status: data.status});
          this._router.navigate(['/wfn/preview/summary']);
        }
      }
      this.showSpinner = false;
    });
  }

  addClientDialog() {
    this.inputDialog = true;
    setTimeout(() => {
      new FooPicker({
        id: 'project-cal',
        dateFormat: 'DD-MON-YYYY'
      });

      new FooPicker({
        id: 'golive-date',
        dateFormat: 'DD-MON-YYYY'
      });
    });
  }

  getClients() {
    this.clientDropdown = !this.clientDropdown;
  }

  goToState(state) {
    if (state) {
      this._router.navigate([state]);
    }
  }

  loadClients() {
    let endPoint = '/wfn/clients/' + this._dataService.orgId + '/';
    this.showSpinner = true;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        this.showSpinner = false;
        if (data === null || data === undefined) {
          this._appService.notify({status: 1, msg: 'Server Error: loadClients()'});
        } else {
          if (data.hasOwnProperty('status') && data.status === 0) {
            let result = data.result;
            this.Clients = result;
          }
        }
      } catch (e) {
        this._appService.notify({status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>'});
      }
    });
  }

  onProjectScope(projectScope) {
    let index = this.projectScopes.indexOf(projectScope);
    if (index !== -1) {
      if (!this.selectedScopes) {
        this.selectedScopes = [];
      }
      index = this.selectedScopes.map(x => x).indexOf(projectScope);

      if (index === -1) {
        this.selectedScopes.push(projectScope);
      } else {
        this.selectedScopes.splice(index, 1);
      }
    }
  }

  onClientSelect(client_id, client_name) {
    this.clientId = client_id;
    this.clientName = client_name;
  }

  upload() {
    if (this.clientId === 'Add Client' || !this.conversionName) {
      this._appService.notify({msg: 'Client & Conversion are mandatory field', status: 1});
      return;
    }
    if (!this.uploadedFile || !this.uploadedFile.base64) {
      this.focusUpload = true;
      return;
    }
    this.showSpinner = true;
    let dict: any = {}, endPoint = '/wfn/preview/';
    dict.base64 = this.uploadedFile.base64;
    dict.user_id = this.user.user_id;
    dict.client_id = this.clientId;
    dict.conversion_name = this.conversionName;
    this._httpService.httpRequest('POST', endPoint, dict, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({status: 1, msg: 'Server Error - upload()'});
      } else {
        if (data.status === 1) {
          this._appService.notify({msg: data.msg, status: data.status});
        } else {
          this._appService.notify({msg: data.msg, status: data.status});
          this._router.navigate(['/wfn/preview/summary']);
        }
      }
      this.showSpinner = false;
    });
  }

  setUpDOMHandlers() {
    jQuery(document).on('click', function (e) {
      if (e.target.className.indexOf('vdl-dropdown-list') != -1) {
        jQuery(".vdl-popup").show();
      }
      else {
        jQuery(".vdl-popup").hide();
      }
    });
  }


  // to validate the uploaded file is csv
  validateFile() {
    let fileExtension, nameLength, fileName;
    fileName = this.uploadedFile.filename.split('.');
    nameLength = fileName.length - 1;
    fileExtension = fileName[nameLength];
    this.focusUpload = false;
    if (fileExtension.toUpperCase() !== 'CSV') {
      this.uploadedFile.filename = '';
      this.uploadedFile.base64 = '';
      this.uploadedFile = '';
      (document.getElementsByClassName('file-upload-btn')[0] as HTMLFormElement).value = '';
      this.focusUpload = true;
    }
  }

}
