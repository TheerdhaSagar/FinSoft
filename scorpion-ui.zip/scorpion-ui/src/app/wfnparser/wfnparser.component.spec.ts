import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WfnparserComponent } from './wfnparser.component';

describe('WfnparserComponent', () => {
  let component: WfnparserComponent;
  let fixture: ComponentFixture<WfnparserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WfnparserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WfnparserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
