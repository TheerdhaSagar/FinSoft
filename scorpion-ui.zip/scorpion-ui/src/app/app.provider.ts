import { AppService } from './globals/app.service';
import { DataService } from './globals/data.service';
import { HttpService } from './globals/http.service';
import { CacheService } from './globals/cache.service';
import { FormatService } from './globals/format.service';
import { ExcelService } from "./globals/excel.service";

export const providers = [
  AppService,
  CacheService,
  DataService,
  ExcelService,
  FormatService,
  HttpService,
];
