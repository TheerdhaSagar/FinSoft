import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { AppService } from '../globals/app.service';
import { CacheService } from '../globals/cache.service';
import { DataService } from '../globals/data.service';
import { FormatService } from '../globals/format.service';
import { ActivatedRoute, NavigationEnd, NavigationStart, Router } from '@angular/router';
import jQuery from '../../../node_modules/jquery';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-template',
  templateUrl: './template.component.html',
  styleUrls: ['./template.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class TemplateComponent implements OnInit {
  private _appService: AppService;
  private _cacheService: CacheService;
  private _dataService: DataService;
  private _formatService: FormatService;
  private _router: Router;
  private _routeParams: ActivatedRoute;

  appStates: any[];
  balanceDrop: boolean;
  debugOn: boolean;
  genericDrop: boolean;
  initials: string;
  minimize: boolean;
  notifications: any[];
  organizations: null;
  orgId: null;
  roles: any;
  searchState: string;
  selectedMenu: string;
  selectedMenuItem: string;
  subNavChange: Subscription;
  subNotifications: Subscription;
  user: any;
  userName: null;
  vantageDrop: boolean;
  wfnDrop: boolean;
  windowWidth: any;
  wfnManager: any;

  constructor(appService: AppService, cacheService: CacheService, dataService: DataService, formatService: FormatService,
              router: Router, routeParams: ActivatedRoute) {
    this._appService = appService;
    this._cacheService = cacheService;
    this._dataService = dataService;
    this._formatService = formatService;
    this._router = router;
    this._routeParams = routeParams;

    this.appStates = [];
    this.balanceDrop = false;
    this.debugOn = false;
    this.genericDrop = false;
    this.initials = '';
    this.minimize = true;
    this.notifications = [];
    this.organizations = null;
    this.orgId = null;
    this.searchState = null;
    this.subNotifications = null;
    this.subNavChange = null;
    this.user = null;
    this.userName = null;
    this.vantageDrop = false;
    this.wfnDrop = false;
    this.wfnManager = false;

  }

  ngOnInit() {
    this._cacheService.getUser((data) => {
      if (data) {
        this.user = data;
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }

        // If user has debug on then display message below username
        if (this.user.debug_flag === 'Y') {
          this.debugOn = true;
        }

        // This holds the username displayed in the application
        this._dataService.userName = this.user.user_description;

        this._routeParams.data.subscribe(routeData => {
          this._dataService.currentState = routeData.state;
        });

        this.userName = this._dataService.userName;
        let wordArray, userName;
        userName = this._dataService.userName;
        wordArray = userName.split(" ");
        for (let i=0; i < wordArray.length; i++){
          this.initials += wordArray[i].substring(0,1).toUpperCase();
        }
        this.windowWidth = jQuery(window).width();
        this._dataService.windowWidth = this.windowWidth;

        let userOrgs = this.user.organizations;
        for (let i = 0; i < userOrgs.length; i++) {
          if (userOrgs[i].organization_id === parseInt(this._cacheService.getOrgId())) {
            this._dataService.orgId = userOrgs[i].organization_id;
            this._dataService.orgName = userOrgs[i].name;

            this.orgId = this._dataService.orgId;
            break;
          }
        }

        this.organizations = userOrgs;  // Display user organizations list

        /* subscribing to global notifications which is fired on call to appService.notify */
        this.subNotifications = this._appService.subscribeNotifications((subData) => {
          let count = this.notifications.length;
          this.notifications.push(subData);
          this.notifications[count].timestamp = this._formatService.getTimeStamp();
          this.notifications[count].notification_time = new Date().getTime();
          this.minimize = false;

          setTimeout(() => {
            this.minimize = true;
          }, 5000);
        });

        /* subscribing to state change event which on fired on entering a new state */
        this.subNavChange = this._router.events.subscribe(e => {
          if (e instanceof NavigationStart) {
            this._dataService.fromState = this._router.url;
          }
          if (e instanceof NavigationEnd) {
            this._dataService.toState = this._router.url;
            this.setUpMenu(this._router.url);
            this._appService.onStateChange({
              fromState: this._dataService.fromState,
              toState: this._dataService.toState
            });
          }
        });

        this.setUpRoles();
        this.setUpAppStates();
        this.setUpDOMHandlers();
        // this._router.navigate(['dashboard']);
      } else {
        this._router.navigate(['login']);
      }
    });
  }


  clearAllNotifications() {
    this.notifications = [];
  }

  clearNotification(n) {
    if (n) {
      let index = this.notifications.indexOf(n);
      if (index !== -1) {
        this.notifications.splice(index, 1);
      }
    }
  }


  setUpRoles() {
    let permissions = this.user.permissions;

    // Identify the user type based on the permissions
    if (permissions) {
      this._dataService.roles.isAdmin = permissions.indexOf('ADMIN') !== -1;
      this._dataService.roles.isDcOrgUI = permissions.indexOf('DC-ORG-UI') !== -1;
      this._dataService.roles.isLifionOrgUI = permissions.indexOf('LIFION-ORG-UI') !== -1;
      this._dataService.roles.isMasOrgUI = permissions.indexOf('MAS-ORG-UI') !== -1;
      this._dataService.roles.isMasCanOrgUI = permissions.indexOf('MAS-CAN-ORG-UI') !== -1;
      this._dataService.roles.isWfnManager = permissions.indexOf('WFN-MANAGER') !== -1;
      this._dataService.roles.isBalanceUI = permissions.indexOf('BALANCE-UI') !== -1;
      this._dataService.roles.isBalanceAuditUI = permissions.indexOf('BALANCE-AUDIT-UI') !== -1;
      this._dataService.roles.isWfnUI = permissions.indexOf('WFN-UI') !== -1;
      this._dataService.roles.isVantageParserUI = permissions.indexOf('VANTAGE-PARSER-UI') !== -1;
      if((permissions.indexOf('WFN-MANAGER') !== -1)|| permissions.indexOf('ADMIN') !== -1 ){
        this.wfnManager=true;
      }
    }
    this._dataService.isIE = this._appService.isIE();
    this._dataService.isSafari = this._appService.isSafari();

    this.roles = this._dataService.roles;
  }


  setUpMenu(url) {
    switch (url) {
      case '/balance/audit':
      case '/balance/summary':
        this.selectedMenu = 'Balances';
        break;
      case '/usermanagement/users':
      case '/usermanagement/users/manage':
        this.selectedMenuItem = 'users';
        this.selectedMenu = 'usermanagement';
        break;
      case '/usermanagement/groups':
      case '/usermanagement/groups/manage':
        this.selectedMenuItem = 'groups';
        this.selectedMenu = 'usermanagement';
        break;
      case '/usermanagement/roles':
      case '/usermanagement/roles/manage':
        this.selectedMenuItem = 'roles';
        this.selectedMenu = 'usermanagement';
        break;
      case '/usermanagement/permissions':
      case '/usermanagement/permissions/create':
      case '/usermanagement/permissions/edit':
        this.selectedMenuItem = 'permissions';
        this.selectedMenu = 'usermanagement';
        break;
      default:
        this.selectedMenu = 'home';
        break;
    }
  }


  setUpAppStates() {
    this.appStates = [
      {name: 'Home', state: 'dashboard'},
      {name: 'Profile', state: 'profile'}
    ];

    if ((this.roles.isAdmin) || this.roles.UIUserManagement) {
      this.appStates.push({name: 'Users', state: 'usermanagement/users'});
      this.appStates.push({name: 'Create User', state: 'usermanagement/users/manage'});
      this.appStates.push({name: 'Groups', state: 'usermanagement/groups'});
      this.appStates.push({name: 'Create Group', state: 'usermanagement/groups/manage'});
      this.appStates.push({name: 'Roles', state: 'usermanagement/roles'});
      this.appStates.push({name: 'Create Role', state: 'usermanagement/roles/manage'});
      this.appStates.push({name: 'Permissions', state: 'usermanagement/permissions'});
      this.appStates.push({name: 'Create Permission', state: 'usermanagement/permissions/create'});
    }

    if ((this.roles.isAdmin) || this.roles.hasNotifications) {
      this.appStates.push({name: 'Notifications', state: 'notifications'});
    }

  }

  vantageDropdown() {
    this.vantageDrop = true;
  }

  genericDropdown() {
    this.genericDrop = true;
  }

  wfnDropdown() {
    this.wfnDrop = true;
  }

  balanceDropdown() {
    this.balanceDrop = true;
  }

  goToState(state) {
    if (state) {
      this._router.navigate([state]);
    }
  }

  // This method is called when user clicked on logout
  logout() {
    this._dataService.logout = true;
    this._cacheService.clear(); // Clear all cached data before logging out
    this._router.navigate(['login']);
  }

  setUpDOMHandlers() {
    jQuery(document).on('click', function (e) {
      e.stopPropagation();
      if(e.target.className.indexOf('dropdown-generic-parent') != -1){
        jQuery(".dropdown-generic").show();
        jQuery(".dropdown-vantage").hide();
        jQuery(".dropdown-wfn").hide();
      }
      else if(e.target.className.indexOf('dropdown-vantage-parent') != -1){
        jQuery(".dropdown-vantage").show();
        jQuery(".dropdown-generic").hide();
        jQuery(".dropdown-wfn").hide();
      }
      else if(e.target.className.indexOf('dropdown-wfn-parent') != -1){
        jQuery(".dropdown-wfn").show();
        jQuery(".dropdown-generic").hide();
        jQuery(".dropdown-vantage").hide();
      }
      else{
        jQuery(".dropdown-wfn").hide();
        jQuery(".dropdown-generic").hide();
        jQuery(".dropdown-vantage").hide();
      }
    });
  }

}
