import { Injectable } from '@angular/core';
import { AppService } from './app.service';
import { CacheService } from './cache.service';
import { HttpService } from './http.service';

@Injectable({
  providedIn: 'root'
})
export class CommonService {
  private _appService: AppService;
  private _cacheService: CacheService;
  private _httpService: HttpService;

  customers: any;
  dateFormats: any;
  languages: any[];
  numberFormats: any[];
  orgs: any;
  pageDim: boolean;

  constructor(appService: AppService, cacheService: CacheService, httpService: HttpService) {
    this._appService = appService;
    this._cacheService = cacheService;
    this._httpService = httpService;

    this.customers = null;
    this.dateFormats = null;
    this.numberFormats = [{ format: '999.999,99' }, { format: '999,999.99' }];
    this.orgs = null;
  }

  checkCCOrBCCDetails(str) {
    if (str) {
      let tmp_bcc = str.split(","), i;
      for (i = 0; i < tmp_bcc.length; i++) {
        if (!this.checkEmail(tmp_bcc[i])) {
          return false;
        }
      }
    }
    return true;
  }

  checkEmail(email) {
    let filter = /^([a-zA-Z0-9_.\-])+@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    return filter.test(email);
  }

  // Check if the username already exists or not
  checkUser(userName, callback) {
    if (userName && userName.indexOf(' ') === -1) {
      let endPoint = '/users/validate/' + userName + '/';
      this._httpService.httpRequest('GET', endPoint, null, (data) => {
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error' });
        } else {
          callback(data.status);
        }
      });
    }
  }

  // load the available date formats
  loadDateFormats(callback) {
    if (!this.dateFormats) {
      let endPoint = '/preferences/dateformat/';
      this._httpService.httpRequest('GET', endPoint, null, (data) => {
        try {
          if (data === null || data === undefined) {
            this._appService.notify({ status: 1, msg: 'Server Error' });
          } else {
            this.dateFormats = data;
            callback(this.dateFormats);
          }
        } catch (e) {
          this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
        }
      });
    }
  }

  loadOrgs(callback) {
    let endPoint = '/operatingunits/all/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this.pageDim = false;
        this._appService.notify({ status: 1, msg: 'Server Error' });
      } else {
        this.orgs = data;
        callback(data);
      }
    });
  }


  loadUserDetails(id, callback) {
    let endPoint = '/users/id/' + id + '/';
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error' });
      } else {
        callback(data);
      }
    });
  }

  phoneValid(phoneNo) {
    let regX = /^[0-9]*$/gm;
    if (!phoneNo || (phoneNo && !phoneNo.match(regX))) {
      return false;
    }
    return true;
  }

  resetPassword(userName, callback) {
    if (userName) {
      let req = { user_name: userName };
      this._httpService.postRequest('/login/reset/', req, (data) => {
        try {
          if (data === null || data === undefined) {
            this._appService.notify({ status: 1, msg: 'Server Error' });
          } else {
            callback(data);
          }
        } catch (e) {
          this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
        }
      });
    }
  }

  secureFileName(fileName) {
    let replacedFileName = this._appService.replaceAll(fileName, ' ', '_');
    replacedFileName = this._appService.replaceAll(replacedFileName, '-', '_');
    replacedFileName = this._appService.replaceAll(replacedFileName, '\'', '_');
    replacedFileName = this._appService.replaceAll(replacedFileName, '"', '_');
    replacedFileName = this._appService.replaceAll(replacedFileName, '\\', '_');
    replacedFileName = this._appService.replaceAll(replacedFileName, '+', '_');
    replacedFileName = this._appService.replaceAll(replacedFileName, '&', '_');
    return replacedFileName;
  }
}
