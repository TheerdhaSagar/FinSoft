import { Injectable } from '@angular/core';
import jQuery from '../../../node_modules/jquery';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  public action: any;
  public currentState: any;
  public fromState: string;
  public isIE: boolean;
  public isSafari: boolean;
  public logout: boolean;
  public orgId: null;
  public orgName: null;
  public previousState: any;
  reportName: any;
  public roles: any;
  public toState: string;
  public userName: null;
  public windowWidth: any;

  constructor() {
    this.currentState = null;
    this.fromState = null;
    this.logout = null;
    this.orgId = null;
    this.orgName = null;
    // contains all UI permissions
    this.roles = {
      isAdmin: false,
      isManager: false,
      UIforHCM: false,
      UIforLeavesApproval: false,
      UILeaveManagement: false,
      UILeaveManagementConfigure: false,
      UILeaveManagementDelete: false,
      UIReports: false,
      UISchedules: false,
      UITripPlanner: false,
      UIUserManagement: false,
    };
    this.userName = null;
    this.windowWidth = jQuery(window).width();
  }
}
