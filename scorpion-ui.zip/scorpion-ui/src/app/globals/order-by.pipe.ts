import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'orderBy'
})
export class OrderByPipe implements PipeTransform {

  transform(data: any[], key?: string, desc?: boolean): any {
    if (data) {
      data.sort((a, b) => {
        if (desc) {
          if (b[key] > a[key]) {
            return 1;
          } else if (b[key] < a[key]) {
            return -1;
          }
          return 0;
        } else {
          if (a[key] > b[key]) {
            return 1;
          } else if (a[key] < b[key]) {
            return -1;
          }
          return 0;
        }
      });
    }

    return data;
  }

}
