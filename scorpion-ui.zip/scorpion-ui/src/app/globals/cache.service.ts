import { Injectable } from '@angular/core';
import { AppService } from './app.service';
import { DataService } from './data.service';
import { HttpService } from './http.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class CacheService {
  private _appService: AppService;
  private _dataService: DataService;
  private _httpService: HttpService;

  private _router: Router;
  public categories: null;
  public columnNames: null;
  public events: null;
  public fields_data = null;
  public formatsData = null;
  public groupList = null;
  public orgId = null;
  public orgList = null;
  public oldOrgId = null;
  public periods = null;
  public roles = null;
  public selectedGroup = null;
  public selectedYear = null;
  public status = null;
  public token = null;
  transaction_data: any;
  public transactionRegister = null;
  public user = null;

  constructor(appService: AppService, dataService: DataService, httpService: HttpService, router: Router) {
    this._appService = appService;
    this._dataService = dataService;
    this._httpService = httpService;
    this._router = router;
  }

  // Clears all data from CacheService and removes
  // USER_ID and AUTH_TOKEN cookies
  clear() {
    this._appService.eraseCookie('USER_ID');
    this._appService.eraseCookie('AUTH_TOKEN');
    this._appService.eraseCookie('REFRESH_TOKEN');
    this._appService.clear();

    this.user = null;
    this.orgList = null;
    this.groupList = null;
    this.orgId = null;
    this.oldOrgId = null;
    this.status = null;
    this.roles = null;

    this.selectedYear = null;
    this.selectedGroup = null;

  }



  getCategories() {
    return this.categories;
  }

  getColumnNames() {
    return this.columnNames;
  }


  getEventData() {
    return this.events;
  }

  getFieldsData() {
    return this.fields_data;
  }

  getGroupList() {
    return this.groupList;
  }

  getOldOrgId() {
    return this.oldOrgId;
  }

  getOrgId() {
    return this.orgId;
  }

  getOrgList() {
    return this.orgList;
  }


  getRolesData() {
    return this.roles;
  }

  getStatus() {
    return this.status;
  }


  getToken() {
    return this.token;
  }

  getTransactionColumnNames() {
    return this.columnNames;
  }

  getTransactionRegisterData() {
    return this.transactionRegister;
  }

  getUser(callback) {
    // If user is null then call the web service and load user details
    // only if there is a valid USER_ID in cookie else redirect to login page
    if (this.user === null || this.user === undefined) {
      let USER_ID = this._appService.readCookie('USER_ID');
      if (USER_ID) {
        let endPoint = '/preferences/details/' + USER_ID + '/';
        this._httpService.httpRequest('GET', endPoint, null, (data) => {
          callback(data);
        });
      } else {
        this.clear();
        this._router.navigate(['login']);
      }
    } else {
      callback(this.user);
    }
  }

  // Initialize user object and other user defaults
  initialize(user) {
    if (!user.user_id) {
      return;
    }
    this.setUser(user);
    this.setOrgList(user.organizations);
    this.setGroupList(user.groups);
    if (user.organizations && user.organizations.length > 0) {
      let defaultOrg = user.default_org_id;
      if (defaultOrg === null) {
        this.setOrgId(user.organizations[0].organization_id);
      } else {
        this.setOrgId(user.default_org_id);
      }
      this.setOldOrgId(this.getOrgId());
    }
  }



  setEventData(events) {
    this.events = events;
  }


  setFieldsData(fields_data) {
    this.fields_data = fields_data;
  }

  setGroupList(groupList) {
    this.groupList = groupList;
  }


  setOldOrgId(oldOrgId) {
    this.oldOrgId = oldOrgId;
  }

  setOrgId(orgId) {
    this.orgId = orgId;
  }

  setOrgList(orgList) {
    this.orgList = orgList;
  }



  setRefreshToken(refreshToken) {
    this._appService.createCookie('REFRESH_TOKEN', refreshToken, 1);
  }

  setRolesData(roles) {
    this.roles = roles;
  }

  setStatus(status) {
    this.status = status;
  }

  setToken(token) {
    this.token = token;
    this._appService.createCookie('AUTH_TOKEN', token, 1);
  }

  setTransactionColumnNames(columnNames) {
    this.columnNames = columnNames;
  }

  setTransactionRegisterData(transactionRegister) {
    this.transactionRegister = transactionRegister;
  }

  setUser(user) {
    this.user = user;
    // Creates a cookie called USER_ID and stores the logged in user id
    if (!user.user_id) {
      return;
    }
    this._appService.createCookie('USER_ID', user.user_id, 1);
  }
}
