import { Directive, EventEmitter, HostListener, Output } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

@Directive({
  selector: '[appFileUpload]',
  providers: [
    {
      provide: NG_VALUE_ACCESSOR, useExisting: FileUploadDirective, multi: true
    }
  ]
})
export class FileUploadDirective implements ControlValueAccessor {
  @Output()
  ngModelChange: EventEmitter<any> = new EventEmitter<any>();

  @HostListener('change', ['$event'])
  onFileUpload(event) {
    let file = event.dataTransfer ? event.dataTransfer.files[0] : event.target.files[0], attachment: any = {};
    if (file) {
      attachment = {
        filename: file.name,
        filetype: file.type,
        filesize: file.size,
      };
      let reader = new FileReader();
      reader.onload = (e) => {
        let base64 = (e.target as FileReader).result.toString();
        let index = base64.indexOf('base64');
        if (index !== -1) {
          base64 = base64.slice(index + 7);
        }
        attachment.base64 = base64;
        this.ngModelChange.emit(attachment);
      };
      reader.readAsDataURL(file);
    }
  }

  registerOnChange(fn: any): void {
  }

  registerOnTouched(fn: any): void {
  }

  setDisabledState(isDisabled: boolean): void {
  }

  writeValue(obj: any): void {
  }

}
