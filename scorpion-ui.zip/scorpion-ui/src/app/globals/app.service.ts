import { Injectable } from "@angular/core";
import { Subject } from "rxjs";
import { environment } from "../../environments/environment";
import jQuery from "../../../node_modules/jquery";

@Injectable({
  providedIn: "root",
})
export class AppService {
  public readonly _URL: string;
  public _window: Window;

  activityUserId: any;
  public account_id: any;
  public addpage: boolean;
  public editUser: null;
  public event: any;
  public eventEdit: any;
  group_id: any;
  group_msg: any;
  group_status: any;
  public kit: any;
  public leaveAppliedBy: number;
  public leaveId: any;
  public leaveAppliedOrgId: any;
  public leavesByUser: any;
  public ledger_id: any;
  loadData: boolean;
  public lovData: null;
  public msg: any;
  public notificationDetails: any;
  public notificationObserver: Subject<any>;
  public order_org: null;
  public orgId: null;
  public orgObserver: Subject<any>;
  public pageSize: number;
  public period: any;
  permission_id: any;
  public permission_msg: null;
  public permission_status: null;
  public request_id: any;
  public requestHeaderId: null;
  role_id: any;
  public role_msg: null;
  public role_status: null;
  public samplesQuantity: any;
  public saved_group: null;
  saveFromDate: any;
  saveToDate: any;
  public selectedGrp: null;
  public stateObserver: Subject<any>;
  user_id: any;

  constructor() {
    this._URL = environment.url;
    this._window = window;

    this.notificationObserver = new Subject();
    this.orgObserver = new Subject();
    this.pageSize = 25; // default page size for paginated tables
    this.stateObserver = new Subject();
  }

  // Clears the global values
  clear() {
    this.selectedGrp = null;
    this.addpage = null;
  }

  // Checks the size of the files uploaded and verifies if they are less than 25MB
  checkFileSize(attachment, attachmentList) {
    let attachedFileSize,
      totalSize = 0,
      sizeWithinLimit = false;
    if (attachment) {
      attachedFileSize = parseFloat(
        (attachment.filesize / Math.pow(1024, 2)).toFixed(2)
      );
      if (attachedFileSize > 25) {
        sizeWithinLimit = false;
      } else {
        if (attachmentList.length > 0) {
          attachmentList.forEach((attache) => {
            if (attache.filesize) {
              totalSize += parseFloat(
                (attache.filesize / Math.pow(1024, 2)).toFixed(2)
              );
            }
          });
          sizeWithinLimit = totalSize + attachedFileSize < 25 ? true : false;
        } else {
          sizeWithinLimit = true;
        }
      }
      return sizeWithinLimit;
    }
  }

  // Creates a cookie with given name and value, which expires
  // in given no. of days
  createCookie(name, value, days) {
    let expires;
    if (days) {
      const date = new Date();
      date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
      expires = "; expires=" + date.toUTCString();
    } else {
      expires = "";
    }
    document.cookie = name + "=" + value + expires + "; path=/";
  }

  clearLink(link) {
    window.setTimeout(() => {
      const aLink = document.getElementById(link) as HTMLAnchorElement;
      if (aLink) {
        aLink.href = "javascript:void(0)";
      }
    }, 3000);
  }

  downloadFile(data) {
    const form = document.createElement("form");
    form.id = "file-download-form";
    form.action = this._URL + "/login/filedownload/";
    form.method = "POST";
    form.innerHTML =
      '<input type="hidden" name="file_name" value="' +
      data.file_name +
      '">' +
      '<input type="hidden" name="content_type" value="' +
      data.content_type +
      '">' +
      '<input type="hidden" name="file_data" value="' +
      data.file_data +
      '">';
    document.body.appendChild(form);
    form.submit();
    window.setTimeout(() => {
      document.body.removeChild(form);
    }, 1000);
  }

  // Deletes a cookie from browser that matches with given name
  eraseCookie(name) {
    this.createCookie(name, "", -1);
  }

  // Export multiple tables into single excel file
  exportMultiTable(name, list, link) {
    let uri = "data:application/vnd.ms-excel;base64,",
      template =
        '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>',
      base64 = (s) => {
        return window.btoa(unescape(encodeURIComponent(s)));
      },
      format = (s, c) => {
        return s.replace(/{(\w+)}/g, (m, p) => {
          return c[p];
        });
      };
    let dummyTable = "";
    if (list) {
      let span, data, title, colspan;
      for (let i = 0; i < list.length; i++) {
        data = list[i].tableData;
        if (data.data[0]) {
          span = Object.keys(data.data[0]);
        }
        title = list[i].title;
        colspan = list[i].span ? list[i].span : span.length;
        dummyTable += "<tr>";
        dummyTable +=
          '<td colspan="' +
          colspan +
          '" align="left" style="font-size: 16px;"><b>' +
          title +
          "</b></td>";
        dummyTable += "</tr>";
        dummyTable += '<tr><td colspan="' + colspan + '"><table>';
        dummyTable += this.getExportTable(data);
        dummyTable += "</td></table>";
        dummyTable += "</tr>";
      }
    }
    if (dummyTable) {
      let ctx = { worksheet: name, table: dummyTable };

      let browser = window.navigator.appVersion;
      if (
        (browser.indexOf("Trident") !== -1 &&
          browser.indexOf("rv:11") !== -1) ||
        browser.indexOf("MSIE 10") !== -1
      ) {
        let builder = new MSBlobBuilder();
        builder.append(uri + format(template, ctx));
        let blob = builder.getBlob("data:application/vnd.ms-excel");
        window.navigator.msSaveBlob(blob, name + ".xls");
      } else if (this.isSafari()) {
        let fileData = {
          content_type: "application/vnd.ms-excel",
          file_data: base64(format(template, ctx)),
          file_name: name + ".xls",
        };
        this.downloadFile(fileData);
      } else {
        let element;
        element = document.getElementById(link);
        element.href = uri + base64(format(template, ctx));
        element.download = name + ".xls";
      }
    }

    this.clearLink(link);
  }

  // Export table directly from html
  exportUITable(table, name, link) {
    let uri = "data:application/vnd.ms-excel;base64,",
      template =
        '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>',
      base64 = (s) => {
        return window.btoa(unescape(encodeURIComponent(s)));
      },
      format = (s, c) => {
        return s.replace(/{(\w+)}/g, (m, p) => {
          return c[p];
        });
      };
    let dummyTable = document.getElementsByClassName(table);
    if (dummyTable && dummyTable.length > 0) {
      let ctx = { worksheet: name, table: dummyTable[0].innerHTML };

      let browser = window.navigator.appVersion;
      if (
        (browser.indexOf("Trident") !== -1 &&
          browser.indexOf("rv:11") !== -1) ||
        browser.indexOf("MSIE 10") !== -1
      ) {
        let builder = new MSBlobBuilder();
        builder.append(uri + format(template, ctx));
        let blob = builder.getBlob("data:application/vnd.ms-excel");
        window.navigator.msSaveBlob(blob, name + ".xls");
      } else if (this.isSafari()) {
        let fileData = {
          content_type: "application/vnd.ms-excel",
          file_data: base64(format(template, ctx)),
          file_name: name + ".xls",
        };
        this.downloadFile(fileData);
      } else {
        let element = document.getElementById(link) as HTMLAnchorElement;
        // element.href = uri + base64(format(templateVar, ctx));
        let xData = new Blob([format(template, ctx)], {
          type: "application/vnd.ms-excel",
        });
        element.href = this._window.URL.createObjectURL(xData);
        element.download = name + ".xls";
      }
    }
    this.clearLink(link);
  }

  exportToCSV(name, data, link) {
    let csvData = this.getExportCSV(data);
    let browser = window.navigator.appVersion;
    let uri = "data:attachment/csv;base64,",
      base64 = (s) => {
        return window.btoa(unescape(encodeURIComponent(s)));
      };

    // If browser is IE then export as Blob
    if (
      (browser.indexOf("Trident") !== -1 && browser.indexOf("rv:11") !== -1) ||
      browser.indexOf("MSIE 10") !== -1
    ) {
      let blob = new Blob([csvData], {
        type: "text/csv;charset=utf-8;",
      });
      window.navigator.msSaveBlob(blob, name + ".csv");
    } else if (this.isSafari()) {
      let fileData = {
        content_type: "text/csv",
        file_data: base64(csvData),
        file_name: name + ".csv",
      };
      this.downloadFile(fileData);
    } else {
      let element;
      if (link) {
        element = document.getElementById(link);
      } else {
        element = document.createElement("a");
      }

      element.href = uri + base64(csvData);
      element.download = name + ".csv";
      if (!link) {
        element.click();
      }
    }
  }

  getExportCSV(tableData) {
    let data = tableData.data;
    if (data && data.length > 0) {
      let i, text, row;
      let csvData = "";
      let keys = Object.keys(data[0]);
      for (i = 0; i < keys.length - 1; i++) {
        csvData += '"' + keys[i] + '",';
      }
      csvData += '"' + keys[keys.length - 1] + '"\n';
      for (i = 0; i < data.length; i++) {
        row = "";
        for (let column in data[i]) {
          if (data[i].hasOwnProperty(column)) {
            text = data[i][column].data;
            row += '"' + text + '",';
          }
        }
        row = row.substring(0, row.length - 1);
        csvData += row + "\n";
      }
      if (tableData.hasOwnProperty("footer")) {
        let footer = tableData.footer;
        row = "";
        for (i = 0; i < footer.length; i++) {
          text = footer[i].data;
          row += '"' + text + '",';
        }
        row = row.substring(0, row.length - 1);
        csvData += row + "\n";
      }
      return csvData;
    }
    return null;
  }

  // Build html table from the data
  getExportTable(tableData) {
    let data = tableData.data;
    if (data && data.length > 0) {
      let i, text, align;
      let tableMarkup = "<thead><tr>";
      let keys = Object.keys(data[0]);
      for (i = 0; i < keys.length; i++) {
        tableMarkup +=
          '<th style="background-color: #ddd" nowrap>' + keys[i] + "</th>";
      }
      tableMarkup += "</tr></thead><tbody>";
      for (i = 0; i < data.length; i++) {
        tableMarkup += "<tr>";
        for (let column in data[i]) {
          if (data[i].hasOwnProperty(column)) {
            text = data[i][column].data || "";
            align = data[i][column].hasOwnProperty("align")
              ? data[i][column].align
              : "left";
            tableMarkup += '<td align="' + align + '" nowrap>' + text + "</td>";
          }
        }
        tableMarkup += "</tr>";
      }
      if (tableData.hasOwnProperty("footer")) {
        let footer = tableData.footer;
        tableMarkup += "<tr>";
        for (i = 0; i < footer.length; i++) {
          text = footer[i].data || "";
          align = footer[i].hasOwnProperty("align") ? footer[i].align : "left";
          tableMarkup +=
            '<td align="' +
            align +
            '" style="background-color: #ddd" nowrap><b>' +
            text +
            "</b></td>";
        }
        tableMarkup += "</tr>";
      }
      tableMarkup += "</tbody>";
      return tableMarkup;
    }
    return '<tbody><tr><td colspan="10">No data found for selected parameters</td></tr></tbody>';
  }

  hexToRgb(hex) {
    let shortHand = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
    hex = hex.replace(shortHand, (m, r, g, b) => {
      return r + r + g + g + b + b;
    });

    let result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result
      ? {
          r: parseInt(result[1], 16),
          g: parseInt(result[2], 16),
          b: parseInt(result[3], 16),
        }
      : null;
  }

  // Check if the browser is Chrome is not

  isChrome() {
    // @ts-ignore
    let isChromium = window.chrome,
      winNav = window.navigator;
    // @ts-ignore
    let isOpera = typeof window.opr !== "undefined";
    let isIEdge = winNav.userAgent.indexOf("Edge") > -1;
    let isIOSChrome = winNav.userAgent.match("CriOS");

    if (isIOSChrome) {
      return true;
    } else if (
      isChromium !== null &&
      typeof isChromium !== "undefined" &&
      winNav.vendor === "Google Inc." &&
      isOpera === false &&
      isIEdge === false
    ) {
      return true;
    }

    return false;
  }

  // Checks if the browsers is IE or not
  isIE() {
    let browser = window.navigator.appVersion;
    return (
      (browser.indexOf("Trident") !== -1 && browser.indexOf("rv:11") !== -1) ||
      browser.indexOf("MSIE 10") !== -1
    );
  }

  isMobile() {
    let mobile = {
      Windows() {
        return /IEMobile/i.test(window.navigator.userAgent);
      },
      Android() {
        return /Android/i.test(window.navigator.userAgent);
      },
      BlackBerry() {
        return /BlackBerry/i.test(window.navigator.userAgent);
      },
      iOS() {
        return /iPhone|iPad|iPod/i.test(window.navigator.userAgent);
      },
    };

    return (
      mobile.Android() ||
      mobile.BlackBerry() ||
      mobile.iOS() ||
      mobile.Windows()
    );
  }

  // Checks if the browser is Safari or not
  isSafari() {
    let userAgent = window.navigator.userAgent.toLowerCase();
    return (
      userAgent.indexOf("safari") !== -1 && userAgent.indexOf("chrome") === -1
    );
  }

  notify(data) {
    this.notificationObserver.next(data);
  }

  onOrgChange(orgId) {
    this.orgObserver.next(orgId);
  }

  onStateChange(data) {
    this.stateObserver.next(data);
  }

  // Returns a cookie that matches with the given name
  readCookie(name) {
    let nameEQ = name + "=";
    let ca = document.cookie.split(";");
    for (let i = 0; i < ca.length; i++) {
      let c = ca[i];
      while (c.charAt(0) === " ") {
        c = c.substring(1, c.length);
      }
      if (c.indexOf(nameEQ) === 0) {
        return c.substring(nameEQ.length, c.length);
      }
    }
    return null;
  }

  replaceAll(str, src, tgt) {
    let index = str.indexOf(src);
    while (index !== -1) {
      str = str.replace(src, tgt);
      index = str.indexOf(src);
    }
    return str;
  }

  subscribeNotifications(callback) {
    return this.notificationObserver.subscribe(callback);
  }

  subscribeOrgChange(callback) {
    return this.orgObserver.subscribe(callback);
  }

  subscribeStateChange(callback) {
    return this.stateObserver.subscribe(callback);
  }

  // Export table data to excel
  tableToExcel(name, data, link?, className?) {
    let uri = "data:application/vnd.ms-excel;base64,",
      template =
        '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><meta http-equiv="content-type" content="application/vnd.ms-excel; charset=UTF-8"><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>',
      base64 = (s) => {
        return window.btoa(unescape(encodeURIComponent(s)));
      },
      format = (s, c) => {
        return s.replace(/{(\w+)}/g, (m, p) => {
          return c[p];
        });
      };

    let dummyTable = this.getExportTable(data);
    if (dummyTable) {
      let ctx = {
        worksheet: name,
        table: dummyTable,
      };

      // Use this functionality if total records > 2000 or each record has more than 80 columns
      if (
        data &&
        data.data &&
        (data.data.length > 2000 ||
          (data.data[0] && Object.keys(data.data[0]).length > 80))
      ) {
        let fileData = {
          file_name: name + ".xls",
          file_data: base64(format(template, ctx)),
          content_type: "application/vnd.ms-excel",
        };
        this.downloadFile(fileData);
        return;
      }

      let browser = window.navigator.appVersion;
      // If browser is IE then export as Blob
      if (
        (browser.indexOf("Trident") !== -1 &&
          browser.indexOf("rv:11") !== -1) ||
        browser.indexOf("MSIE 10") !== -1
      ) {
        let builder = new MSBlobBuilder();
        builder.append(uri + format(template, ctx));
        let blob = builder.getBlob("data:application/vnd.ms-excel");
        window.navigator.msSaveBlob(blob, name + ".xls");
      } else {
        let element;
        if (className) {
          let elementList = document.getElementsByClassName(className);
          if (elementList && elementList.length > 0) {
            element = elementList[elementList.length - 1];
          }
        } else if (link) {
          element = document.getElementById(link);
        } else {
          element = document.createElement("a");
        }
        element.href = uri + base64(format(template, ctx));
        element.download = name + ".xls";
        if (!link) {
          document.body.appendChild(element);
          element.click();
          document.body.removeChild(element);
        }
      }
    }
    // if (window.navigator.userAgent.indexOf('Mac') !== -1) {
    //   this.exportToCSV(name, data, link);
    // } else {
    // }

    this.clearLink(link);
  }

  // Returns date after the no. of days passed as param
  today(days) {
    let months = [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec",
    ];
    let date = new Date();
    if (days) {
      date.setDate(date.getDate() + days);
    }
    return (
      date.getDate() + "-" + months[date.getMonth()] + "-" + date.getFullYear()
    );
  }

  // Use to toggle filter
  toggleFilter() {
    return (e) => {
      if (e) {
        e.preventDefault();
      }
      let left;
      if (!jQuery(".filter ").hasClass("active")) {
        jQuery(".filter").addClass("active");
        jQuery(".filter-container-scorpion").show();
        jQuery(".filter-container-scorpion").css({ left: "0px" });
        left = "0px";
      } else {
        jQuery(".filter").removeClass("active");
        left = "-350px";
      }

      jQuery(".filter-wrapper").animate(
        {
          left,
        },
        500,
        "linear",
        () => {
          if (left === "-350px") {
            jQuery(".filter-container-scorpion").hide();
            jQuery(".filter-container-scorpion").css({ left: "-102%" });
          }
        }
      );

      jQuery(".filter-wrapper").click((event) => {
        event.stopPropagation();
      });

      jQuery(".filter-container-scorpion").click(() => {
        jQuery(".filter-wrapper").animate(
          {
            left: "-350px",
          },
          500,
          "linear",
          () => {
            jQuery(".filter").removeClass("active");
            jQuery(".filter-container-scorpion").hide();
            jQuery(".filter-container-scorpion").css({ left: "-102%" });
          }
        );
      });
    };
  }

  validateEmail(email, extn?) {
    let dotLastIndex = -1,
      atIndex,
      atCount = 0,
      i;
    for (i = 0; i < email.length; i++) {
      if (email[i] === "@") {
        atCount++;
      }
      if (email[i] === ".") {
        dotLastIndex = i;
      }
    }

    if (atCount > 1) {
      return false;
    }
    atIndex = email.indexOf("@");
    if (atIndex === -1) {
      return false;
    }
    if (dotLastIndex === -1) {
      return false;
    }
    if (atIndex > dotLastIndex) {
      return false;
    }
    if (dotLastIndex === email.length - 1) {
      return false;
    }
    if (dotLastIndex === atIndex + 1) {
      return false;
    }
    if (email[atIndex + 1] === ".") {
      return false;
    }
    let gTLD = email.substring(dotLastIndex + 1, email.length);
    if (gTLD.length < 2) {
      return false;
    }

    if (extn) {
      let mailArr = email.split("@");
      if (mailArr[1] !== extn) {
        return false;
      }
    }

    return true;
  }
}
