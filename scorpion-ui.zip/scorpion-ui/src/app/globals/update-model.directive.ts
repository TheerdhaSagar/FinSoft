import { Directive, EventEmitter, HostListener, Output } from '@angular/core';

@Directive({
  selector: '[appUpdateModel]'
})
export class UpdateModelDirective {
  @Output()
  ngModelChange: EventEmitter<any> = new EventEmitter<any>();
  oldValue: any;

  @HostListener('blur', ['$event'])
  onValueChange(event) {
    setTimeout(() => {
      if (this.oldValue !== event.target.value) {
        this.oldValue = event.target.value;
        this.ngModelChange.emit(event.target.value);
      }
    }, 200);
  }
}
