import { Injectable } from '@angular/core';
import { CacheService } from './cache.service';

@Injectable({
  providedIn: 'root'
})
export class FormatService {
  private _cacheService: CacheService;

  private readonly currencies: { EUR: string; GBP: string; USD: string };
  private readonly months: string[];
  private readonly separators: string[];
  private readonly weekDays: string[];

  constructor(cacheService: CacheService) {
    this._cacheService = cacheService;

    this.currencies = {USD: '$', EUR: '€', GBP: '£'};
    this.months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    this.separators = ['.', '-', '/']; // default separators used in date formats
    this.weekDays = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  }

  base64ToBlob(base64, type?) {
    if (base64) {
      let byteString = atob(base64);
      // Convert text into a byte array.
      let ab = new ArrayBuffer(byteString.length);
      let ia = new Uint8Array(ab);
      for (let i = 0; i < byteString.length; i++) {
        ia[i] = byteString.charCodeAt(i);
      }

      // Blob for saving.
      let dataBlob = new Blob([ia], {
        type: type || 'application/octet-stream'
      });
      if (dataBlob) {
        return dataBlob;
      }
    }
    return null;
  }

  checkNumber(number, separator) {
    let i, returnValue;
    if (Array.isArray(number)) {
      for (i = 0; i < number.length; i++) {
        returnValue = this.validateNumber(number[i], separator);
        if (!returnValue) {
          return false;
        }
      }
    } else {
      returnValue = this.validateNumber(number, separator);
      if (!returnValue) {
        return false;
      }
    }
    return true;
  }

  convertNumber(value) {
    let format, user = '', numArr;
    this._cacheService.getUser((data) => {
      user = data;
      if (!this._cacheService.user) {
        this._cacheService.initialize(data);
      }
    });

    format = (user as any).number_format;
    if (!format) {
      return parseFloat(value);
    }
    if (!value) {
      return value;
    }
    if (!isNaN(value)) {
      return parseFloat(value);
    }

    if (format === '999.999,99') {
      if (value.indexOf(',') !== -1) {
        numArr = value.split(',');
        return parseFloat(numArr[0] + '.' + numArr[1]);
      }
      return parseFloat(value);
    } else {
      return parseFloat(value);
    }
  }

  dateInMillis(date) {
    let dt, days, month, year, leapYears, i, numMonths, noOfDays = 0, noOfYears,
      calDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    if (date === null || date === undefined) {
      return 0;
    }

    dt = date.split('-');
    if (dt.length !== 3) {
      return 0;
    }
    days = dt[0];
    month = dt[1].charAt(0).toUpperCase() + dt[1].slice(1).toLowerCase();
    year = dt[2];

    numMonths = this.months.indexOf(month) + 1;

    if (numMonths > 1) {
      for (i = 0; i < numMonths - 1; i++) {
        noOfDays += calDays[i];
      }
      noOfDays += parseInt(days);
    } else {
      noOfDays = parseInt(days);
    }

    noOfYears = parseInt(year) - 1970;
    leapYears = numMonths > 2 ? parseInt(year) : parseInt(year) - 1;
    for (i = 1971; i < leapYears; i++) {
      if (((i % 4 === 0) && (i % 100 !== 0)) || (i % 400 === 0)) {
        noOfDays = noOfDays + 1;
      }
    }
    noOfDays += noOfYears * 365;

    return noOfDays * 24 * 60 * 60 * 1000;
  }

  encodeString(str) {
    let encoded = str;
    for (let i = 0; i < 5; i++) {
      encoded = btoa(this.reverseString(encoded));
    }
    return encoded;
  }

  formatColumnName(name) {
    let formattedName = '', nameSplit, i;
    if (name) {
      nameSplit = name.split('_');
      for (i = 0; i < nameSplit.length; i++) {
        formattedName += nameSplit[i].charAt(0).toUpperCase() +
          nameSplit[i].slice(1, nameSplit[i].length) + ' ';
      }
    }
    return formattedName.trim();
  }

  // Formats and returns date based on user preferences
  formatDate(date, format?) {
    let separator, formattedDate, dateFormat, dayIndex, monthIndex, yearIndex, dateArray,
      day, month, year, alphaMonth;

    if (format) {
      dateFormat = format;
    } else {
      this._cacheService.getUser((data) => {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        dateFormat = data.date_format;
      });
    }

    if (!dateFormat || date === null || date === undefined) {
      return date;
    }

    for (let i = 0; i < this.separators.length; i++) {
      if (dateFormat.indexOf(this.separators[i]) > 0) {
        separator = this.separators[i];
        break;
      }
    }

    dayIndex = dateFormat.indexOf('dd');
    monthIndex = dateFormat.indexOf('MMM');
    yearIndex = dateFormat.indexOf('yyyy');

    if (!this.isDateFormattable(date)) {
      return date;
    }

    try {
      dateArray = date.split('-');
      day = dateArray[0].length === 1 ? '0' + dateArray[0] : dateArray[0];
      month = dateArray[1];
      year = dateArray[2];

      alphaMonth = month.charAt(0).toUpperCase() +
        month.slice(1).toLowerCase();

      month = this.months.indexOf(alphaMonth) + 1;

      if (month < 10) {
        month = '0' + month;
      }

      if (monthIndex !== -1) { // This case will be true for alphabetic month
        if (dayIndex < yearIndex) {
          formattedDate = day + separator + alphaMonth + separator + year;
        } else {
          formattedDate = year + separator + alphaMonth + separator + day;
        }
      } else { // This case will be true for numeric month
        monthIndex = dateFormat.indexOf('MM');
        if ((monthIndex < dayIndex) && (dayIndex < yearIndex)) {
          formattedDate = month + separator + day + separator + year;
        } else if ((dayIndex < monthIndex) && (monthIndex < yearIndex)) {
          formattedDate = day + separator + month + separator + year;
        } else {
          formattedDate = year + separator + month + separator + day;
        }
      }
    } catch (err) {
      return date;
    }

    return formattedDate;
  }

  // Formats the given number based on user preferences
  formatNumber(number, decimals?, noDecimal?) {
    let fixedNum, format, user = '', num;
    this._cacheService.getUser((data) => {
      user = data;
      if (!this._cacheService.user) {
        this._cacheService.initialize(data);
      }
    });

    format = (user as any).number_format;

    if (number === null || number === undefined ||
      isNaN(number) || number === '') {
      num = '0';
    } else {
      if (decimals >= 0) {
        num = this.mathRound(parseFloat(number), decimals).toString();
      } else {
        num = this.mathRound(parseFloat(number), 2).toString();
      }
    }

    fixedNum = num.split('.');
    if (format && format === '999.999,99') {
      num = this.numberWithDots(fixedNum[0]) + ',';
    } else {
      num = this.numberWithCommas(fixedNum[0]) + '.';
    }

    if (!noDecimal) {
      if (fixedNum.length > 1) {
        switch (fixedNum[1].length) {
          case 0:
            fixedNum[1] = '00';
            break;
          case 1:
            fixedNum[1] += '0';
            break;
        }
        num += fixedNum[1];
      } else {
        num += '00';
      }
    } else {
      num = num.slice(0, num.length - 1);
    }

    return num;
  }

  // Formats the given number based on user preferences
  formatNumberInput(number, decimals?) {
    let fixedNum, format, user = '', num;
    this._cacheService.getUser((data) => {
      user = data;
      if (!this._cacheService.user) {
        this._cacheService.initialize(data);
      }
    });

    format = (user as any).number_format;

    if (number === null || number === undefined ||
      isNaN(number) || number === '') {
      num = '0';
    } else {
      if (decimals) {
        num = this.mathRound(parseFloat(number), decimals).toString();
      } else {
        num = this.mathRound(parseFloat(number), 2).toString();
      }
    }

    fixedNum = num.split('.');

    if (format && format === '999.999,99') {
      num = fixedNum[0] + ',';
    } else {
      num = fixedNum[0] + '.';
    }

    if (fixedNum.length > 1) {
      switch (fixedNum[1].length) {
        case 0:
          fixedNum[1] = '00';
          break;
        case 1:
          fixedNum[1] += '0';
          break;
      }
      num += fixedNum[1];
    } else {
      num += '00';
    }

    return num;
  }

  getCurrencyCode(currency) {
    return this.currencies[currency] || currency;
  }

  getMonth(monthIndex) {
    return this.months[monthIndex];
  }

  // This method replaces the '-' in date strings of any format with ' ' to 'dd MMM yyyy' format
  // To ensure dates are parsed correctly across all browsers
  getStandardDateFormat(dateString, format) {
    let date = this.parseDate(dateString, format);
    if (date) {
      return date.replace(new RegExp('-', 'g'), ' ');
    }
  }

  getTimeStamp() {
    let date = this.formatDate(this.today(0)),
      timestamp = new Date().toLocaleString(), dateStamp = [];
    if (timestamp.indexOf(',') !== -1) {
      dateStamp = timestamp.split(',');
    }
    if (dateStamp.length === 2) {
      return (date + dateStamp[1]);
    }
    return date;
  }

  getWeekDay(date) {
    return this.weekDays[date.getDay()];
  }

  getWeekNumber(d) {
    d = new Date(+d);
    d.setHours(0, 0, 0);
    d.setDate(d.getDate() + 4 - (d.getDay() || 7));
    let yearStart = new Date(d.getFullYear(), 0, 1);
    let weekNo = Math.ceil((((d - Number(yearStart)) / 86400000) + 1) / 7);
    return [d.getFullYear(), weekNo];
  }

  // Checks whether the given date is formattable or not
  isDateFormattable(date) {
    try {

      let splitDate = date.split('-');
      let alphaMonth = splitDate[1].charAt(0).toUpperCase() +
        splitDate[1].slice(1).toLowerCase();

      if (date.indexOf('-') > 0 &&
        (parseInt(splitDate[0]) < parseInt(splitDate[2])) &&
        this.months.indexOf(alphaMonth) !== -1) {
        return true;
      }

    } catch (err) {
      return false;
    }

    return false;
  }

  isLeapYear(year) {
    return year % 100 === 0 ? year % 400 === 0 : year % 4 === 0;
  }

  isValidDate(date) {
    let separator, dateFormat = '', i, dateArray;

    this._cacheService.getUser((data) => {
      if (!this._cacheService.user) {
        this._cacheService.initialize(data);
      } else {
        dateFormat = data.date_format;
      }
    });
    dateFormat = dateFormat || 'dd-MMM-yyyy';

    for (i = 0; i < this.separators.length; i++) {
      if (dateFormat.indexOf(this.separators[i]) !== -1) {
        separator = this.separators[i];
        break;
      }
    }

    dateArray = date.split(separator);

    if (dateArray.length !== 3) {
      return false;
    } else if (dateArray[0] === '' || dateArray[1] === '' || dateArray[2] === '') {
      return false;
    }

    return true;
  }

  // Round the given number to 2 decimal places
  mathRound(value, decimals) {
    decimals = decimals || 0;
    return Number(Math.round(Number(value + 'e' + decimals)) + 'e-' + decimals);
  }

  monthNumber(month) {
    return this.months.indexOf(month);
  }

  numberParser(number, decimals?) {
    let numStr = number + '', i, validDigits = '', user = '', format;

    this._cacheService.getUser((data) => {
      user = data;
      if (!this._cacheService.user) {
        this._cacheService.initialize(data);
      }
    });

    format = (user as any).number_format || '999,999.99';

    decimals = decimals || 2;
    for (i = 0; i < numStr.length; i++) {
      if (numStr[i] === '.' || numStr[i] === ',' || !isNaN(Number(numStr[i]))) {
        validDigits += numStr[i];
      }
    }

    if (validDigits.indexOf('.') === 0 || validDigits.indexOf(',') === 0) {
      return this.formatNumber(0);
    }

    if (this.validatePattern(validDigits, decimals, true)) {
      return this.formatNumber(this.parseNumber(validDigits), decimals);
    }

    if (format === '999,999.99') {
      return this.formatNumber(this.parseNumber(validDigits, '999.999,99'), decimals);
    }

    return this.formatNumber(this.parseNumber(validDigits, '999,999.99'), decimals);
  }

  // Returns a comma separated number
  numberWithCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  }

  // Returns a dot separated number
  numberWithDots(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  }

  // Parse the given date and return a new date in dd-MMM-yyyy format
  parseDate(date, format?) {
    let separator, parsedDate, dateFormat, dayIndex, monthIndex, yearIndex, dateArray, alphaMonth;

    if (format) {
      dateFormat = format;
    } else {
      this._cacheService.getUser((data) => {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        dateFormat = data.date_format;
      });
    }

    if (!dateFormat) {
      return date;
    }

    for (let i = 0; i < this.separators.length; i++) {
      if (dateFormat.indexOf(this.separators[i]) > 0) {
        separator = this.separators[i];
        break;
      }
    }

    dayIndex = dateFormat.indexOf('dd');
    monthIndex = dateFormat.indexOf('MMM');
    yearIndex = dateFormat.indexOf('yyyy');

    try {
      dateArray = date.split(separator);

      if (monthIndex === -1) { // This case will be true for numeric month
        monthIndex = dateFormat.indexOf('MM');

        if ((monthIndex < dayIndex) && (dayIndex < yearIndex)) {
          alphaMonth = this.months[Number(dateArray[0] - 1)];
          parsedDate = dateArray[1] + '-' + alphaMonth + '-' + dateArray[2];
        } else if ((dayIndex < monthIndex) && (monthIndex < yearIndex)) {
          alphaMonth = this.months[Number(dateArray[1] - 1)];
          parsedDate = dateArray[0] + '-' + alphaMonth + '-' + dateArray[2];
        } else {
          alphaMonth = this.months[Number(dateArray[1] - 1)];
          parsedDate = dateArray[2] + '-' + alphaMonth + '-' + dateArray[0];
        }
      } else { // This case will be true for alphabetic month
        if ((monthIndex < dayIndex) && (dayIndex < yearIndex)) {
          alphaMonth = dateArray[0].charAt(0).toUpperCase() +
            dateArray[0].slice(1).toLowerCase();
          parsedDate = dateArray[1] + '-' + alphaMonth + '-' + dateArray[2];
        } else if ((dayIndex < monthIndex) && (monthIndex < yearIndex)) {
          alphaMonth = dateArray[1].charAt(0).toUpperCase() +
            dateArray[1].slice(1).toLowerCase();
          parsedDate = dateArray[0] + '-' + alphaMonth + '-' + dateArray[2];
        } else {
          alphaMonth = dateArray[1].charAt(0).toUpperCase() +
            dateArray[1].slice(1).toLowerCase();
          parsedDate = dateArray[2] + '-' + alphaMonth + '-' + dateArray[0];
        }
      }
    } catch (err) {
      return date;
    }

    return parsedDate;
  }

  // Converts number from user preferred format
  parseNumber(number, numFormat?) {
    let format, user = '', num, tmpNum;
    this._cacheService.getUser((data) => {
      user = data;
      if (!this._cacheService.user) {
        this._cacheService.initialize(data);
      }
    });

    if ((user as any).number_format) {
      format = numFormat || (user as any).number_format;
    } else {
      format = numFormat || '999,999.99';
    }

    if (number === null || number === undefined ||
      number === '' || !number) {
      num = number;
    } else {
      number += '';
      if (format) {
        if (format === '999.999,99') {
          tmpNum = (number.indexOf('0.') !== 0 && number.indexOf(',') !== -1) ? this.replaceAll(number, '.', '') : number;
          num = parseFloat(tmpNum.replace(',', '.'));
        } else {
          tmpNum = this.replaceAll(number, ',', '');
          num = parseFloat(tmpNum);
        }
      } else {
        num = parseFloat(number);
      }
    }

    return num;
  }

  removeEscapeCharacter(str) {
    return str ? str.split("\\").join("") : '';
  }

  replaceAll(str, src, tgt) {
    str += '';
    let index = str.indexOf(src);
    while (index !== -1) {
      str = str.replace(src, tgt);
      index = str.indexOf(src);
    }
    return str;
  }

  reverseString(str) {
    if (!str) {
      return;
    }
    return str.split('').reverse().join('');
  }

  round(value, decimals?) {
    decimals = decimals || 2;
    return this.mathRound(value, decimals);
  }

  // Returns date after the no. of days passed as param
  today(days) {
    let date = new Date();
    if (days > 0) {
      date.setDate(date.getDate() + days);
    }
    return date.getDate() + '-' + this.months[date.getMonth()] + '-' + date.getFullYear();
  }

  // validate date
  validateDate(date) {
    let separator, f_date, dateFormat = '', f_dateFormat, dateIndex, yearIndex,
      monthIndex, month, alphaMonth, daysInMonth, day, year, i, days,
      monthInNum, yearInNum, dayInNum;
    this._cacheService.getUser((data) => {
      if (!this._cacheService.user) {
        this._cacheService.initialize(data);
      } else {
        dateFormat = data.date_format;
      }
    });
    dateFormat = dateFormat || 'dd-MMM-yyyy';

    for (i = 0; i < this.separators.length; i++) {
      if (dateFormat.indexOf(this.separators[i]) !== -1) {
        separator = this.separators[i];
        break;
      }
    }

    // split expense date
    f_date = date.split(separator);

    f_dateFormat = dateFormat.split(separator);
    if (f_date.length !== 3) {
      return false;
    }

    dateIndex = f_dateFormat.indexOf('dd');
    yearIndex = f_dateFormat.indexOf('yyyy');
    year = f_date[yearIndex];
    day = f_date[dateIndex];
    yearInNum = parseInt(year);
    dayInNum = parseInt(day);
    if (!year || !day || isNaN(year) || isNaN(day) || isNaN(yearInNum) || isNaN(dayInNum) ||
      year.length !== 4 || !yearInNum || day.length > 2 || !dayInNum) {
      return false;
    }

    days = [31, this.isLeapYear(year) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

    monthIndex = f_dateFormat.indexOf('MM');
    if (monthIndex === -1) {
      monthIndex = f_dateFormat.indexOf('MMM');
      month = f_date[monthIndex];
      month = month.charAt(0).toUpperCase() + month.substr(1).toLowerCase();
      f_date[monthIndex] = month;
      alphaMonth = this.months.indexOf(month);
      if (alphaMonth === -1 || alphaMonth > 11) {
        return false;
      }
      daysInMonth = days[alphaMonth];
    } else {
      month = f_date[monthIndex];
      monthInNum = parseInt(month);
      if (!month || isNaN(month) || monthInNum < 1 || monthInNum > 12 || isNaN(monthInNum) || month.length > 2) {
        return false;
      }
      daysInMonth = days[monthInNum - 1];
      if (month.length === 1) {
        month = '0' + month;
        f_date[monthIndex] = month;
      }
    }


    if (dayInNum < 1 || dayInNum > daysInMonth) {
      return false;
    }

    if (day.length === 1) {
      day = '0' + day;
      f_date[dateIndex] = day;
    }
    date = f_date.join(separator);
    return date;
  }

  validateNumber(number, separator) {
    let i, tmpArr;
    if (number.indexOf(separator) === -1) {
      if (isNaN(number)) {
        return false;
      }
    } else {
      tmpArr = number.split(separator);
      if (tmpArr[0].length === 0 || tmpArr[0].length > 3) {
        return false;
      }
      for (i = 0; i < tmpArr.length; i++) {
        if (i !== 0) {
          if (tmpArr[i].length !== 3) {
            return false;
          }
        }
        if (isNaN(tmpArr[i])) {
          return false;
        }
      }
    }
    return true;
  }

  validatePattern(value, decimal?, ignore?) {
    let format, user = '', numArr, returnValue;
    decimal = decimal || 2;
    this._cacheService.getUser((data) => {
      user = data;
      if (!this._cacheService.user) {
        this._cacheService.initialize(data);
      }
    });

    format = (user as any).number_format;
    if (!format) {
      format = '999,999.99';
    }
    if (!value) {
      return false;
    }

    if (format === '999.999,99') {
      if (value.indexOf(',') !== -1) {
        if (value.indexOf('.') !== -1 && value.indexOf(',') - value.lastIndexOf('.') !== 4) {
          return false;
        }

        numArr = value.split(',');
        if (numArr.length > 2) {
          return false;
        }
        if (numArr[1].length > decimal && !ignore) {
          return false;
        }

        returnValue = this.checkNumber(numArr, '.');
        if (!returnValue) {
          return false;
        }
      } else {
        returnValue = this.checkNumber(value, '.');
        if (!returnValue) {
          return false;
        }
      }
      return true;
    } else {
      if (value.indexOf('.') !== -1) {
        if (value.indexOf(',') !== -1 && value.indexOf('.') - value.lastIndexOf(',') !== 4) {
          return false;
        }

        numArr = value.split('.');
        if (numArr.length > 2) {
          return false;
        }
        if (numArr[1].length > decimal && !ignore) {
          return false;
        }

        returnValue = this.checkNumber(numArr, ',');
        if (!returnValue) {
          return false;
        }
      } else {
        returnValue = this.checkNumber(value, ',');
        if (!returnValue) {
          return false;
        }
      }
      return true;
    }
  }

  weeksInYear(year) {
    let d = new Date(year, 11, 31);
    let week = this.getWeekNumber(d)[1];
    return week === 1 ? this.getWeekNumber(d.setDate(24))[1] : week;
  }

}
