import { Component, ElementRef, forwardRef, Input, OnInit, ViewEncapsulation, DoCheck } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import jQuery from '../../../../node_modules/jquery';

const ValueProvider = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => AutocompleteComponent),
  multi: true
};

@Component({
  selector: 'app-autocomplete',
  templateUrl: './autocomplete.component.html',
  styleUrls: ['./autocomplete.component.scss'],
  providers: [ValueProvider],
  encapsulation: ViewEncapsulation.None
})
export class AutocompleteComponent implements OnInit, DoCheck, ControlValueAccessor {
  @Input() autoShow: any;
  @Input() autoWidth: any;
  @Input() bind: any;
  @Input() className: any;
  @Input() conditionalClass: any;
  @Input() focusCallback: any;
  @Input() id: any;
  @Input() isDisabled: any;
  @Input() isReadOnly: any;
  @Input() items: any;
  @Input() label: any;
  @Input() blurCallback: any;
  @Input() placeHolder: any;
  @Input() subLabel: any;
  @Input() style: any;
  @Input() updateValue: any;

  private bindValue: any;
  private element: any;
  private oldValue: any;
  value: any;

  propagateChange: any = () => {};

  constructor(element: ElementRef) {
    this.element = element.nativeElement;
  }

  ngOnInit() {
  }

  ngDoCheck() {
    if (this.items && this.items.length && this.updateValue && this.updateValue !== this.oldValue) {
      setTimeout(() => {
        this.oldValue = this.updateValue;
        this.writeValue(this.updateValue);
      }, 150);
    } else if (!this.updateValue) {
      this.value = null;
      this.bindValue = null;
    }
  }

  // Build the auto suggestions from the array of values
  buildSuggestions(value) {
    let container = this.element.getElementsByClassName('fd-suggestions')[0];
    if (container) {
      this.element.removeChild(container);
    }
    if (value.length > 0 && this.items) {
      container = document.createElement('div');
      container.className = 'fd-suggestions';
      if (!this.autoWidth) {
        container.style.width = '99.5%';
      }

      let template = '', results = [];
      if (value === '%') {
        results = this.items;
      } else if (value.indexOf('%') === value.length - 1) {
        let substr = value.substring(0, value.length - 1);
        results = this.matchItems(substr, true);
      } else {
        results = this.matchItems(value, true);
      }

      let count;
      if (value === '%' || value.indexOf('%') === value.length - 1) {
        count = results.length;
      } else {
        count = results.length > 10 ? 10 : results.length;
        // count = results.length;
      }
      for (let i = 0; i < count; i++) {
        if (this.bind && this.label) {
          template += '<div class="fd-suggestion-item" data-value="' + results[i][this.bind] +
            '" data-label="' + results[i][this.label] + '">';
          if (this.subLabel) {
            template += results[i][this.label] + ', ' + results[i][this.subLabel];
          } else {
            template += results[i][this.label];
          }
          template += '</div>';
        } else {
          template += '<div class="fd-suggestion-item" data-label="' + results[i] + '">' + results[i] + '</div>';
        }
      }

      this.element.appendChild(container);
      container.innerHTML = template;

      jQuery('.fd-suggestion-item').on('click', (event) => {
        this.onItemSelect(event);
      });
    }
  }

  // Get id for the input field, if `id` is passed then it will be used
  // else a random id is generated and returned
  getId() {
    this.id = this.id || 'id-' + Math.round(Math.random() * (100000 * 100000));
    return this.id;
  }

  matchItems(matchValue, anyIndex) {
    let index, results = [];
    for (let i = 0; i < this.items.length; i++) {
      if (this.bind && this.label) {
        if (this.items[i] && this.items[i].hasOwnProperty(this.label)) {
          index = this.items[i][this.label].toLowerCase().indexOf(matchValue);
          if ((anyIndex && index !== -1) || index === 0) {
            results.push(this.items[i]);
          }
        }
      } else {
        if (this.items[i]) {
          index = this.items[i].toLowerCase().indexOf(matchValue);
          if ((anyIndex && index !== -1) || index === 0) {
            results.push(this.items[i]);
          }
        }
      }
    }

    return results;
  }

  onChange(event) {
    this.value = event.target.value;
    if (this.value) {
      this.buildSuggestions(this.value.toLowerCase());
    } else if (this.autoShow) {
      this.buildSuggestions('%');
    } else {
      this.removeSuggestions();
    }
  }

  // This is called when an item from suggestions is selected
  onItemSelect(event) {
    let value;
    if (this.bind && this.label) {
      value = event.target.dataset.value;
    } else {
      value = event.target.dataset.label;
    }

    this.value = event.target.dataset.label;
    this.bindValue = value;
    this.removeSuggestions();
    this.propagateChange(this.bindValue);
  }

  // removes auto suggestions
  removeSuggestions() {
    let container = this.element.getElementsByClassName('fd-suggestions')[0];
    if (container) {
      this.element.removeChild(container);
    }
  }

  registerOnChange(fn: any): void {
    this.propagateChange = fn;
  }

  registerOnTouched(fn: any): void {
  }

  setDisabledState(isDisabled: boolean): void {
  }

  writeValue(value: any): void {
    if (value && value !== this.value) {
      if (this.items && this.items.length) {
        if (this.bind && this.label) {
          for (let i = 0; i < this.items.length; i++) {
            if (this.items[i][this.bind].toString() === value.toString()) {
              if (!this.subLabel) {
                this.value = this.items[i][this.label];
              } else {
                this.value = this.items[i][this.label] + ', ' + this.items[i][this.subLabel];
              }

              this.bindValue = this.items[i][this.bind];
              this.propagateChange(this.bindValue);
              break;
            }
          }
        }
      }
    }
  }
}
