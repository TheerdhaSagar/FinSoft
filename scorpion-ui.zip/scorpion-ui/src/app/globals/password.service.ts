import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PasswordService {
  conditions: any;
  conditionsMet: boolean;
  forceChange: boolean;
  passwordOnLogin: any;
  showPassword: boolean;

  constructor() {
    this.conditions = {
      pwd_length: { val: false, text: 'PWD_CON_LENGTH' },
      pwd_uppercase: { val: false, text: 'PWD_CON_UPPERCASE' },
      pwd_lowercase: { val: false, text: 'PWD_CON_LOWERCASE' },
      pwd_number: { val: false, text: 'PWD_CON_NUMBER' },
      pwd_specialChar: { val: false, text: 'PWD_CON_SPECIALCHAR' }
    };
    this.conditionsMet = true;
    this.forceChange = false;
    this.passwordOnLogin = '';
  }

  // This method disables or enables the button actions in nav bar
  toggleHeaderActions(action) {
    let pointerEvent = action === 'enable' ? 'auto' : 'none', buttonsToBeToggled;
    buttonsToBeToggled = ['home-icon', 'tmp-user-name', 'tmp-user-avatar', "organizations", "search-box"];
    for (let i = 0; i < buttonsToBeToggled.length; i++) {
      document.getElementById(buttonsToBeToggled[i]).style.pointerEvents = pointerEvent;
    }
  }

  togglePassword(ids) {
    for (let id of ids) {
      let pwdElement = document.getElementById(id) as HTMLFormElement;
      if (pwdElement.type === "password") {
        this.showPassword = true;
        pwdElement.type = "text";
      } else {
        this.showPassword = false;
        pwdElement.type = "password";
      }
    }
    return this.showPassword;
  }

  validateNewPassword(password, conditions) {
    if (password) {
      if (conditions.pwd_length.val && conditions.pwd_uppercase.val && conditions.pwd_lowercase.val
        && conditions.pwd_number.val && conditions.pwd_specialChar.val) {
        this.conditionsMet = true;
      } else {
        this.conditionsMet = false;
      }
    } else {
      this.conditionsMet = true;
    }
    return this.conditionsMet;
  }

  validatePasswordConditions(password, conditions) {
    const lowerCaseLetters = /[a-z]/g,
      upperCaseLetters = /[A-Z]/g,
      numbers = /[0-9]/g,
      specialCharacter = /[-!$%^&*()_+|~=`{}[:;<>?,.@#\]]/g;
    conditions.pwd_length.val = false;
    conditions.pwd_uppercase.val = false;
    conditions.pwd_lowercase.val = false;
    conditions.pwd_number.val = false;
    conditions.pwd_specialChar.val = false;
    if (password) {
      conditions.pwd_length.val = password.length >= 8 ? true : false;
      conditions.pwd_uppercase.val = password.match(upperCaseLetters) ? true : false;
      conditions.pwd_lowercase.val = password.match(lowerCaseLetters) ? true : false;
      conditions.pwd_number.val = password.match(numbers) ? true : false;
      conditions.pwd_specialChar.val = password.match(specialCharacter) ? true : false;
    }
    return conditions;
  }
}
