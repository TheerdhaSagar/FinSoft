import { Injectable } from '@angular/core';
import { AppService } from './app.service';
import { environment } from '../../environments/environment';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HttpService {
  private readonly _URL: string;
  private _router: Router;
  private _appService: AppService;
  private _http: HttpClient;

  constructor(appService: AppService, http: HttpClient, router: Router) {
    this._appService = appService;
    this._http = http;
    this._router = router;
    this._URL = environment.url;
  }

  // Method used to handle HTTP DELETE request
  deleteRequest(endPoint, callback) {
    this._http.delete(this._URL + endPoint)
      .subscribe((value) => {
        callback(value);
      }, () => {
        // console.log('Error in HttpService - deleteRequest');
        callback(null);
      });
  }

  // Generic HTTP request used to call the web services with Authorization header
  // method can be any of (GET, PUT, POST, DELETE etc)
  // endPoint of the target resource relative to Base URL
  // callback is called when the request is finished
  genericHttpRequest(method, endPoint, data, callback) {
    // Read the token from cookie
    let token = this._appService.readCookie('AUTH_TOKEN');
    let userId = this._appService.readCookie('USER_ID');

    if (token === null || token === undefined ||
      userId === null || userId === undefined) {
      this._router.navigate(['login']);
      return;
    }

    // Build the request object
    let headers = new HttpHeaders(
      {
        Authorization: 'Basic ' + btoa(token + ':' + userId),
        'Content-Type': 'application/json'
      }
    );

    let options = {
      body: null,
      headers,
      withCredentials: true
    };

    if (data) {
      options.body = data;
    }

    this._http.request(method, this._URL + endPoint, options)
      .subscribe((value) => {
        callback(value);
      }, (reason) => {
        if (reason) {
          // console.log('Error in HttpService - httpRequest');
        }

        // If the token is expired or request is unauthorized then clear the data
        // and go to login page
        if (reason.status === 401) {
          this.getAuthToken(method, endPoint, data, callback);
        } else if (reason.status === 408 || reason.status === 504) {
          this.genericHttpRequest(method, endPoint, data, callback);
        } else {
          callback(null);
        }
      });
  }

  getAuthToken(method, endPoint, data, callback) {
    let request = {
      refresh_token: this._appService.readCookie('REFRESH_TOKEN')
    };

    this._http.post(this._URL + '/login/re-requesttoken/', request)
      .subscribe((value) => {
        this._appService.createCookie('AUTH_TOKEN', (value as any).token, 1);
        this.retryRequest(method, endPoint, data, callback);
      }, (reason) => {
        // console.log('Error in HttpService - postRequest');
        if (reason.status === 401) {
          this._router.navigate(['login']);
        } else {
          callback(null);
        }
      });
  }

  // Method used to handle HTTP GET request
  getRequest(endPoint, callback) {
    this._http.get(this._URL + endPoint)
      .subscribe((value) => {
        callback(value);
      }, () => {
        // console.log('Error in HttpService - getRequest');
        callback(null);
      });
  }

  // Method used to handle HTTP GET request
  getRequestURL(URL, callback) {
    this._http.get(URL)
      .subscribe((value) => {
        callback(value);
      }, () => {
        // console.log('Error in HttpService - getRequestURL');
        callback(null);
      });
  }

  httpRequest(method, endPoint, data, callback) {
    this.genericHttpRequest(method, endPoint, data, callback);
  }

  // Method used to handle HTTP POST request
  postRequest(endPoint, postBody, callback) {
    this._http.post(this._URL + endPoint, postBody)
      .subscribe((value) => {
        callback(value);
      }, () => {
        // console.log('Error in HttpService - postRequest');
        callback(null);
      });
  }

  // Method used to handle HTTP PUT request
  putRequest(endPoint, putBody, callback) {
    this._http.put(this._URL + endPoint, putBody)
      .subscribe((value) => {
        callback(value);
      }, () => {
        // console.log('Error in HttpService - putRequest');
        callback(null);
      });
  }

  retryRequest(method, endPoint, data, callback) {
    this.genericHttpRequest(method, endPoint, data, callback);
  }

}
