import { Component, OnInit } from '@angular/core';
import { AppService } from '../globals/app.service';
import { CacheService } from '../globals/cache.service';
import { DataService } from '../globals/data.service';
import { FormatService } from '../globals/format.service';
import { HttpService } from '../globals/http.service';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import jQuery from '../../../node_modules/jquery';

@Component({
  selector: 'app-wfnpostvalidation',
  templateUrl: './wfnpostvalidation.component.html',
  styleUrls: ['./wfnpostvalidation.component.scss']
})
export class WfnpostvalidationComponent implements OnInit {
  private _appService: AppService;
  private _cacheService: CacheService;
  private _dataService: DataService;
  private _formatService: FormatService;
  private _httpService: HttpService;
  private _location: Location;
  private _router: Router;
  private _window: any;

  adprUpload:boolean;
  attachments: any;
  backButton: boolean;
  Clients: any;
  clientId: any;
  clientIdNew: any;
  clientName: any;
  clientNameNew: any;
  clientDropdown: boolean;
  currentState: string;
  conversionName: any;
  focusClientId: boolean;
  focusClientName: boolean;
  focusClient: boolean;
  focusConversion: boolean;
  focusUpload: boolean;
  goLiveDate: any;
  ic: any;
  inputDialog: boolean;
  mftDetails: any;
  modalPreviewDialog: boolean;
  nextButton: boolean;
  previewDialogue: boolean;
  projectManager: any;
  projectScopes: any;
  projectDate : any;
  runValidation: boolean;
  selectedScopes: any;
  sharedPath: any;
  showSpinner: boolean;
  uploadDialog: boolean;
  uploadedFile: any;
  user: any;

  constructor(appService: AppService, cacheService: CacheService, dataService: DataService, formatService: FormatService,
              httpService: HttpService, location: Location, router: Router) {

    this._appService = appService;
    this._cacheService = cacheService;
    this._dataService = dataService;
    this._httpService = httpService;
    this._location = location;
    this._router = router;
    this._window = window;

    this.adprUpload = false;
    this.backButton = false;
    this.attachments = null;
    this.Clients = '';
    this.clientId = 'select client';
    this.clientIdNew = '';
    this.clientName = '';
    this.clientDropdown = false;
    this.conversionName = '';
    this.clientNameNew = '';
    this.currentState = 'preview-upload';
    this.focusClient = false;
    this.focusClientId = false;
    this.focusClientName = false;
    this.focusConversion = false;
    this.focusUpload = false;
    this.goLiveDate = '';
    this.ic = '';
    this.inputDialog = false;
    this.mftDetails = '';
    this.modalPreviewDialog = false;
    this.nextButton = true;
    this.previewDialogue = true;
    this.projectManager = '';
    this.projectScopes = ['Launch_Pad', 'New_Logo', 'Balances', 'Monarch'];
    this.projectDate = '';
    this.runValidation = false;
    this.selectedScopes = '';
    this.sharedPath = '';
    this.showSpinner = false;
    this.uploadDialog = false;
    this.uploadedFile = '';
    this.user = '';

  }

  ngOnInit() {
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this.user = data;
      }
      this.loadClients();
      this.setUpDOMHandlers();
    });
  }

  changeView(type) {
    if(type == 'preview-upload') {
      this.previewDialogue = true;
      this.adprUpload = false;
      this.runValidation = false;
      this.backButton = false;
      this.nextButton = true;
      this.currentState = 'preview-upload';

    } else if(type == 'adpr-upload') {
      this.adprUpload = true;
      this.previewDialogue = false;
      this.runValidation = false;
      this.backButton = true;
      this.nextButton = true;
      this.currentState = 'adpr-upload';
    }  else if(type == 'run-validation') {
      this.runValidation = true;
      this.adprUpload = false;
      this.previewDialogue = false;
      this.backButton = true;
      this.nextButton = false;
      this.currentState = 'run-validation';
    }

  }

  changeViewButton(type, action) {
    console.log(type);
    console.log(action);
    if(type == 'preview-upload') {
      if(action === 'next') {
        this.adprUpload = true;
        this.previewDialogue = false;
        this.runValidation = false;
        this.backButton = true;
        this.nextButton = true;
        this.currentState = 'adpr-upload';
      }
    } else if(type == 'adpr-upload') {
      if(action === 'next') {
        this.runValidation = true;
        this.adprUpload = false;
        this.previewDialogue = false;
        this.backButton = true;
        this.nextButton = false;
        this.currentState = 'run-validation';
      } else if (action === 'back') {
        this.previewDialogue = true;
        this.adprUpload = false;
        this.runValidation = false;
        this.backButton = false;
        this.nextButton = true;
        this.currentState = 'preview-upload';
      }
    } else if(type == 'run-validation') {
      if (action === 'back') {
        this.adprUpload = true;
        this.previewDialogue = false;
        this.runValidation = false;
        this.backButton = true;
        this.nextButton = true;
        this.currentState = 'adpr-upload';
      }
    }
  }

  getClients(){
    this.clientDropdown = !this.clientDropdown;
  }

  loadClients() {
    let endPoint = '/wfn/clients/' + this._dataService.orgId + '/';
    this.showSpinner = true;
    this._httpService.httpRequest('GET', endPoint, null, (data) => {
      try {
        this.showSpinner = false;
        if (data === null || data === undefined) {
          this._appService.notify({ status: 1, msg: 'Server Error: loadClients()' });
        } else {
          if (data.hasOwnProperty('status') && data.status === 0) {
            let result = data.result;
            this.Clients = result;
          }
        }
      } catch (e) {
        this._appService.notify({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    });
  }

  onClientSelect(client_id, client_name){
    this.clientId = client_id;
    this.clientName = client_name;
  }

  setUpDOMHandlers() {
    jQuery(document).on('click', function (e) {
      if(e.target.className.indexOf('vdl-dropdown-list') != -1){
        jQuery(".vdl-popup").show();
      }
      else{
        jQuery(".vdl-popup").hide();
      }
    });
  }

  // to validate the uploaded file is csv
  validateFile() {
    let fileExtension, nameLength, fileName;
    fileName = this.uploadedFile.filename.split('.');
    nameLength = fileName.length - 1;
    fileExtension = fileName[nameLength];
    this.focusUpload = false;
    if (fileExtension.toUpperCase() !== 'CSV') {
      this.uploadedFile.filename = '';
      this.uploadedFile.base64 = '';
      this.uploadedFile = '';
      (document.getElementsByClassName('file-upload-btn')[0] as HTMLFormElement).value = '';
      this.focusUpload = true;
    }
    if (!this.focusUpload) {
      this.modalPreviewDialog = true;
    }
  }

}
