import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WfnpostvalidationComponent } from './wfnpostvalidation.component';

describe('WfnpostvalidationComponent', () => {
  let component: WfnpostvalidationComponent;
  let fixture: ComponentFixture<WfnpostvalidationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WfnpostvalidationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WfnpostvalidationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
