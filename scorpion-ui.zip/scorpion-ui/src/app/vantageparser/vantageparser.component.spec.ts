import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VantageparserComponent } from './vantageparser.component';

describe('VantageparserComponent', () => {
  let component: VantageparserComponent;
  let fixture: ComponentFixture<VantageparserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VantageparserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VantageparserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
