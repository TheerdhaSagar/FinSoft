import { Component, OnInit } from '@angular/core';
import { AppService } from '../globals/app.service';
import { CacheService } from '../globals/cache.service';
import { DataService } from '../globals/data.service';
import { FormatService } from '../globals/format.service';
import { HttpService } from '../globals/http.service';
import { Router } from '@angular/router';
import { Location } from '@angular/common';

@Component({
  selector: 'app-vantageparser',
  templateUrl: './vantageparser.component.html',
  styleUrls: ['./vantageparser.component.scss']
})
export class VantageparserComponent implements OnInit {


  private _appService: AppService;
  private _cacheService: CacheService;
  private _dataService: DataService;
  private _formatService: FormatService;
  private _httpService: HttpService;
  private _location: Location;
  private _router: Router;
  private _window: any;

  fileName: string;
  fileData: any;
  fileExtension: any;
  focusType: boolean;
  focusUpload: boolean;
  runType: string;
  showSpinner: boolean;
  uploadedFile: any;
  user: any;

  constructor(appService: AppService, cacheService: CacheService, dataService: DataService, formatService: FormatService,
              httpService: HttpService, location: Location, router: Router) {

    this._appService = appService;
    this._cacheService = cacheService;
    this._dataService = dataService;
    this._httpService = httpService;
    this._location = location;
    this._router = router;
    this._window = window;

    this.fileName = '';
    this.fileData = '';
    this.fileExtension = '';
    this.focusType = false;
    this.focusUpload = false;
    this.runType = '';
    this.showSpinner = false;
    this.uploadedFile = '';
    this.user = '';

  }

  ngOnInit() {
    this._cacheService.getUser((data) => {
      if (!data) {
        this._router.navigate(['login']);
      } else {
        if (!this._cacheService.user) {
          this._cacheService.initialize(data);
        }
        this.user = data;
      }
    });
  }

  downloadFile(attachment) {
    this.fileData = attachment.file_data;
    // Convert base64 to blob formatHelper
    let blobFile = this.base64ToBlob(this.fileData, attachment.file_type);
    if (this._appService.isIE()) {
      let builder = new MSBlobBuilder();
      builder.append(blobFile);

      let blob = builder.getBlob(attachment.file_type);
      window.navigator.msSaveBlob(blob, attachment.file_name);
    } else {
      let url = this._window.URL.createObjectURL(blobFile);
      let a = document.createElement('a');
      document.body.appendChild(a);
      a.style.display = 'none';
      a.href = url;
      a.download = attachment.file_name;
      a.click();
    }
  }

  base64ToBlob(base64, type?) {
    if (base64) {
      let byteString = atob(base64);
      // Convert text into a byte array.
      let ab = new ArrayBuffer(byteString.length);
      let ia = new Uint8Array(ab);
      for (let i = 0; i < byteString.length; i++) {
        ia[i] = byteString.charCodeAt(i);
      }

      // Blob for saving.
      let dataBlob = new Blob([ia], {
        type: type || 'application/octet-stream'
      });
      if (dataBlob) {
        return dataBlob;
      }
    }
    return null;
  }

  upload() {
    if (!this.uploadedFile || !this.uploadedFile.base64) {
      this.focusUpload = true;
      return;
    } else {
      this.focusUpload = false;
    }
    this.showSpinner = true;
    let dict: any = {}, endPoint = '/wfn/parser/', attachment = {
      file_data: '',
      file_name: '',
      file_type: ''
    };
    dict.base64 = this.uploadedFile.base64;
    dict.user_id = this.user.user_id;
    dict.run_type = 'preview';
    dict.file_extension = this.fileExtension;
    this._httpService.httpRequest('POST', endPoint, dict, (data) => {
      if (data === null || data === undefined) {
        this._appService.notify({ status: 1, msg: 'Server Error - generateParser()' });
      } else {
        if (data.status === 1) {
          this._appService.notify({ msg: data.msg, status: data.status });
        } else {
          if (data.hasOwnProperty('file_data')) {
            attachment.file_data = data.file_data;
            attachment.file_type = 'application/vnd.ms-excel';
            attachment.file_name = this.fileName;
            this.downloadFile(attachment);
          }
        }
      }
      this.showSpinner = false;
    });
  }

  // to validate the uploaded file is csv
  validateFile() {
    let fileExtension, nameLength, fileName;
    fileName = this.uploadedFile.filename.split('.');
    this.fileName = fileName[0] + '.xlsx';
    nameLength = fileName.length - 1;
    fileExtension = fileName[nameLength];
    this.focusUpload = false;
    this.fileExtension = fileExtension.toUpperCase();
    if ((fileExtension.toUpperCase() !== 'TXT') && (fileExtension.toUpperCase() !== 'LOG')) {
      this.uploadedFile.filename = '';
      this.uploadedFile.base64 = '';
      this.uploadedFile = '';
      (document.getElementsByClassName('file-upload-btn')[0] as HTMLFormElement).value = '';
      this.focusUpload = true;
    }
  }


}
