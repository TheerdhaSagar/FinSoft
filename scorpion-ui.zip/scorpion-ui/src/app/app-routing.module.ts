import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { TemplateComponent } from './template/template.component';
import { BalanceauditComponent } from "./balanceaudit/balanceaudit.component";
import { SummaryComponent } from './balanceaudit/summary/summary.component';
import { BalanceUploadComponent } from './balanceaudit/balance-upload/balance-upload.component';
import { WfnprevalidationComponent } from "./wfnprevalidation/wfnprevalidation.component";
import { SetupSummaryComponent } from "./wfnprevalidation/setup-summary/setup-summary.component";
import { PreviewSummaryComponent } from "./wfnprevalidation/preview-summary/preview-summary.component"
import { PreviewUploadComponent } from "./wfnprevalidation/preview-upload/preview-upload.component";
import { AddClientComponent } from "./wfnprevalidation/add-client/add-client.component";
import { ClientSummaryComponent } from "./wfnprevalidation/client-summary/client-summary.component";
import { ReportsComponent } from "./wfnprevalidation/reports/reports.component";
import { WfnpostvalidationComponent } from "./wfnpostvalidation/wfnpostvalidation.component";
import { WfndualmaintenanceComponent } from "./wfndualmaintenance/wfndualmaintenance.component";
import { WfnparserComponent } from "./wfnparser/wfnparser.component";
import { VantageparserComponent } from "./vantageparser/vantageparser.component";
import { BalanceAuditSummaryComponent } from "./balanceaudit/balance-audit-summary/balance-audit-summary.component";
import { ReportSummaryComponent } from "./balanceaudit/report-summary/report-summary.component";
import { EmployeeReportSummaryComponent } from "./balanceaudit/employee-report-summary/employee-report-summary.component";
import { EmpDeltaReportSummaryComponent } from "./balanceaudit/emp-delta-report-summary/emp-delta-report-summary.component";


const loginRoutes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'login/:token', component: LoginComponent }
];

const dashboardRoutes: Routes = [
  { path: 'dashboard', component: DashboardComponent }
];

const balanceAuditRoutes: Routes = [
  { path: 'balance/summary', component: SummaryComponent },
  { path: 'balance/audit', component: BalanceauditComponent },
  { path: 'balance/audit/upload', component: BalanceUploadComponent },
  {path: 'balance/audit/summary', component: BalanceAuditSummaryComponent},
  {path: 'balance/emp/report/summary', component: EmployeeReportSummaryComponent},
  {path: 'balance/emp/delta/report/summary', component: EmpDeltaReportSummaryComponent}
];

const wfnAuditRoutes: Routes = [
  { path: 'wfn/setup', component: WfnprevalidationComponent },
  { path: 'wfn/add/client', component: AddClientComponent },
  { path: 'wfn/client/summary', component: ClientSummaryComponent },
  { path: 'wfn/setup/summary', component: SetupSummaryComponent },
  { path: 'wfn/preview/summary', component: PreviewSummaryComponent },
  { path: 'wfn/preview/upload', component: PreviewUploadComponent },
  { path: 'wfn/reports', component: ReportsComponent },
  { path: 'wfn/error/parser', component: WfnparserComponent },
  { path: 'wfn/postvalidations', component: WfnpostvalidationComponent },
  { path: 'wfn/dual/maintenance', component: WfndualmaintenanceComponent },
  {path: 'balance/report/summary', component: ReportSummaryComponent}
];

const vantageRoutes: Routes = [
  { path: 'vantage/parser', component: VantageparserComponent }
];

const routes: Routes = [
  ...loginRoutes,
  {path: '', redirectTo:'/dashboard', pathMatch: 'full'},
  {
    path: '', component: TemplateComponent,
    children:[
      ...dashboardRoutes,
      ...balanceAuditRoutes,
      ...wfnAuditRoutes,
      ...vantageRoutes
    ],
    runGuardsAndResolvers: 'always'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { onSameUrlNavigation: 'reload' })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
