/*
 * Author: Theerdha Sagar
 * Date: 17-10-2018
 */

(function() {
  'use strict';

  angular.module('scorpion')
    .controller('ProfileController', ProfileController);

  function ProfileController($scope, $window, $location, $cacheHelper,
    $httpHelper, $state, $rootScope) {

    // google analytics code
    $scope.$on('$viewContentLoaded', function() {
      $window.ga('send', 'pageview', { page: $location.url()});
    });

    var user;
    $cacheHelper.getUser(function(data) {
      if (!data) {
        $state.go('login');
      } else {
        if (!$cacheHelper.user) {
          $cacheHelper.initialize(data);
        }

        user = data;
        $scope.knownAs = user.user_description;
        $scope.email = user.email_address;
        $scope.reporting_manager = user.reporting_manager;
        $scope.phoneNo = user.phone;
        $scope.time_zone = user.time_zone;
      }
      loadTimeZones();
    });

    function loadTimeZones() {
      $scope.all_time_zones = [{
        zone_code: 'EST',
        zone_name:'Eastern Standard Time'
      }, {
        zone_code: 'PST',
        zone_name: 'Pacific Standard Time'
      }, {
        zone_code: 'CST',
        zone_name: 'Central Standard Time'
      }];
    }

    // This method is called to update the user profile
    $scope.updateProfile = function() {
      var req = {};
      if (!$scope.knownAs) { $scope.focusknownas = false; return; }
      req.user_description = $scope.knownAs;
      req.email_address = $scope.email;
      req.user_id = user.user_id;
      req.phone = $scope.phoneNo;
      req.reporting_manager = $scope.reporting_manager ? $scope.reporting_manager : '';
      req.time_zone = $scope.time_zone;

      if ($scope.oldPassword) {
        $scope.passMatchError = true;
        if ($scope.passwordChange()) {
          req.old_password = $scope.oldPassword;
          req.new_password = $scope.newPassword;
          $scope.passMatchError = false;
        } else {
          $scope.passMatchError = true;
          $scope.notifications.push({status: 1, msg: 'Passwords do not match'});
          return;
        }
      }

      $scope.pageDim = true;
      var endPoint = '/preferences/';
      $httpHelper.httpRequest('POST', endPoint, req, function (data) {
        try {
          if (data === null || data === undefined) {
            throw new Error('Server Error');
          } else {
            $scope.notifications.push({status: data.status, msg: data.msg});
            if (data.status === 0) {
              updateUserData();
              clearScopeValues();
            }
            $scope.pageDim = false;
          }
        } catch (e) {
          $scope.pageDim = false;
          $scope.notifications.push({status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>'});
        }
      });
    };

    $scope.passwordChange = function() {
      var newPassword = $scope.newPassword;
      var reTypePassword = $scope.reTypePassword;
      if ($scope.passMatchError &&
        newPassword && reTypePassword) {
        if (newPassword.length > 0 &&
          reTypePassword.length > 0) {
          if (newPassword !== reTypePassword) {
            return false;
          } else {
            return true;
          }
        } else {
          return true;
        }
      }
    };

    function updateUserData() {
      user.user_description = $scope.knownAs;
      user.email_address = $scope.email;
      user.reporting_manager = $scope.reporting_manager;
      user.phone = $scope.phoneNo;
      user.order_emails = $scope.orderEmails ? 'Y' : 'N';
      user.other_emails = $scope.otherEmails ? 'Y' : 'N';
      $cacheHelper.setUser(user);

      $rootScope.userName = user.user_description;

    }

    function clearScopeValues() {
      $scope.oldPwdError = '';
      $scope.errorMsg = null;
      $scope.oldPassword = null;
      $scope.newPassword = null;
      $scope.reTypePassword = null;
    }

  }

})();
