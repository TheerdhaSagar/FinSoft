/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 16-12-2018
 */

(function() {
  'use strict';

  angular.module('scorpion')
    .controller('WfnDashboard', WfnDashboard);

  function WfnDashboard($state, $scope, $window, $location,
    $cacheHelper, $rootScope) {

    var user;

    $cacheHelper.getUser(function(data) {
      if (!data) {
        $state.go('login');
      } else {
        if (!$cacheHelper.user) {
          $cacheHelper.initialize(data);
        }
        user = data;
        $rootScope.currentState = $state.current.name;
      }
    });

    $scope.showValidationType = function(state, action) {
      $rootScope.action = action;
      $state.go(state);
    };

    $scope.moveToDashboard = function() {
      $state.go('app.dashboard');
    };

  }
})();
