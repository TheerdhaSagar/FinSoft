/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 16-12-2018
 */

(function() {
  'use strict';

  angular.module('scorpion')
    .controller('WfnValidation', WfnValidation);

  function WfnValidation($state, $scope) {


    $scope.moveToDcDashboard = function () {
      $state.go('app.wfnautomation');
    };
    
    

  }
})();
