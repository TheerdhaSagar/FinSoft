/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 16-12-2018
 */

(function () {
    'use strict';

    angular.module('scorpion')
        .controller('WfnSourceValidation', WfnSourceValidation);

    function WfnSourceValidation($state, $scope, $formatHelper, $appHelper,
        $cacheHelper, $location, $window, $httpHelper, $filter, $rootScope, URL) {

        var user;
        $scope.showDialog = false;
        $scope.clear = false;
        $scope.focusList = false;
        $scope.toggleFilter = $appHelper.toggleFilter();
        $scope.desc = false;
        $scope.url = URL;        
        $cacheHelper.getUser(function (data) {
            if (!data) {
                $state.go('login');
            } else {
                if (!$cacheHelper.user) {
                    $cacheHelper.initialize(data);
                }
                // $scope.toggleFilter();
                getClientNames();
                user = data;
            }
        });

        function initializeData() {
            $scope.orgId = $rootScope.orgId;
            $scope.focusWfnValidations = false;
            $scope.alertShown = false;
            $scope.notifyUpdate = false;
            $scope.listName = '';
            $scope.focusList = false;
        }        

        $scope.$watch(function () {
            return $rootScope.orgId;
        }, function (newValue, oldValue) {
            if (newValue !== oldValue) {
                $state.go($state.current, {}, {
                    reload: true
                });
                getClientNames();
                initializeData();
            }
        });  

        $scope.moveToDcDashboard = function () {
            $state.go('app.wfnautomation');
        };

        // load Client names
        function getClientNames() {
            var endPoint = '/wfn/clients/' + $rootScope.orgId + '/';
            $scope.clientNames = '';
            $scope.listName = '';
            $httpHelper.httpRequest('GET', endPoint, null, function (clientData) {
                try {
                    if (clientData === null || clientData === undefined) {
                        throw new Error('Server Error');
                    } else {
                        if (clientData.status === 1) {
                            $scope.showSpinner = false;
                            $scope.notifications.push({ msg: clientData.msg, status: clientData.status });
                        } else {
                            $scope.clients = clientData.result;                                                                              
                        }
                    }
                    $scope.showSpinner = false;  
                } catch (e) {
                    $scope.showSpinner = false;
                    $scope.notifications.push({ msg: e.message, status: 1, details: '<pre>' + e.stack + '</pre>' });
                }
            });
        }


// upload data with mapped column names
      $scope.map = function() {
        $scope.alertMapping = false;
        var requiredColumns = ['PositionID', 'Change Effective On', 'Is Paid By WFN', 'Co Code', 'File #'];
        var i, index, msg = '', endPoint, dict = {}, data;
        for (i = 0; i < requiredColumns.length; i++) {
          index = $scope.mappedColumns.map(function(x) {
            return x.oracle_column_name;
          }).indexOf(requiredColumns[i]);
          if (index === -1 || $scope.mappedColumns[index].column_name === '') {
            msg = msg ? ', ' : '';
            msg += requiredColumns[i];
          }
        }

        if (msg) {
          $scope.alertMapping = true;
          $('#columns-div').animate({
            scrollTop: 0
          }, 100, 'linear');
        } else {
          $scope.showSpinner = true;
          data = mapData();
          if (!data) {
            return;
          }
          $scope.mapColumns = false;
          endPoint = '/storelocator/map/';
          dict.column_names = $scope.sheetColumnNames;
          dict.data = data;
          dict.category_id = $scope.category_ids;
          dict.user_id = user.user_id || '';
          $httpHelper.httpRequest('POST', endPoint, dict, function(data) {
            try {
              if (data === null || data === undefined) {
                throw new Error('Server Error');
              } else {
                if (data.status === 1) {
                  $scope.showSpinner = false;
                  $scope.notifications.push({msg: data.msg, status: data.status});
                } else {
                  formatData(data.data);
                  $scope.showSpinner = false;
                }
              }
            } catch (e) {
              $scope.notifications.push({msg: e.message, status: 1, details: '<pre>' + e.stack + '</pre>'});
              $scope.showSpinner = false;
            }
          });
        }
      };

      function formatData(uploadedData) {
        var i, data;
        data = uploadedData.data;
        $scope.invalidLines = uploadedData.invalid_lines;

        // invalid lines in uploaded file
        if ($scope.invalidLines.length > 0) {
          for(i = 0; i < $scope.invalidLines.length; i++) {
            $scope.invalidLines[i].name_of_the_shop = $scope.invalidLines[i].name_of_the_shop || '';
            $scope.invalidLines[i].index = i + 1;
            $scope.invalidLines[i].verified_by_google = $scope.invalidLines[i].verified_by_google === 'VALID' ? true : false;
            $scope.invalidLines[i].brand_codes = $scope.selectedCatBrands_array.concat($scope.selectedDogBrands_array);
            $scope.invalidLines[i].category_id = $scope.selectedCatIds.concat($scope.selectedDogIds);
          }
        }
        if ($scope.invalidLines.length === 0 && data.length === 0) {
          $scope.showSpinner = false;
          $scope.clearScreen();
          return;
        }
        $scope.listView = true;
        $scope.sheet_names = [];
        $scope.shop_index = '';
        $scope.count = 0;
        for (i = 0; i < data.length; i++) {
          data[i].country = data[i].nation || '';
          data[i].index = i + 1;
          data[i].brand_codes = data[i].brand_code ? data[i].brand_code.split(",") : [];
          data[i].category_id = data[i].category_id ? data[i].category_id.split(",") : [];
          data[i].batch_id = uploadedData.batch_id;
          data[i].tel = data[i].phone || '';
        }
        $scope.locationData = data;
        $scope.noofPages = Math.ceil($scope.locationData.length/$scope.pageLimit);
        $scope.currentPage = 1;
        $scope.pageNumbers = [];
        for (i = 0; i < $scope.noofPages; i++) {
          $scope.pageNumbers.push(i + 1);
        }
        $scope.showSpinner = false;
      }

      // to validate the uploaded excel sheet
      $scope.validateFile = function() {
        var fileExtension, nameLength, fileName;
        fileName = $scope.uploadedFile.filename.split('.');
        nameLength = fileName.length - 1;
        fileExtension = fileName[nameLength];
        $scope.focusUpload = false;
        if (fileExtension.toUpperCase() !== 'XLS' && fileExtension.toUpperCase() !== 'XLSX') {
          $scope.uploadedFile.filename = '';
          $scope.uploadedFile.base64 = '';
          $scope.uploadedFile = '';
          document.getElementsByClassName('file-upload-btn')[0].value = '';
          $scope.focusUpload = true;
        }
      };

      $scope.upload = function() {
        if (!$scope.uploadedFile  || !$scope.uploadedFile.base64) {
          $scope.focusUpload = true;
          return;
        }
        $scope.showSpinner = true;
        var dict = {}, endPoint = '/wfn/', index;
        dict.base64 = $scope.uploadedFile.base64;
        dict.user_id = user.user_id || '';
        $httpHelper.httpRequest('POST', endPoint, dict, function(data) {
          try {
            if (data === null || data === undefined) {
              throw new Error('Server Error');
            } else {
              if (data.status === 1) {
                $scope.notifications.push({msg: data.msg, status: data.status});
                $scope.showSpinner = false;
              } else {
                if (data.mapped_columns && data.mapped_columns.length > 0) {
                  $scope.oracleColumns = data.oracle_columns;
                  $scope.sheetColumns = data.sheet_columns;
                  for (i = 0; i < data.mapped_columns.length; i++) {
                    data.mapped_columns[i].status = data.mapped_columns[i].oracle_column_name ? true : false;
                    data.mapped_columns[i].oracle_column_name = data.mapped_columns[i].oracle_column_name.split('_').join(' ');
                    data.mapped_columns[i].column_name = data.mapped_columns[i].column_name.split('_').join(' ');
                  }
                  $scope.mappedColumns = data.mapped_columns;
                  $scope.f_oracleColumns = [];

                  // To get unselected oracle column names
                  for (i = 0; i < $scope.oracleColumns.length; i++) {
                    $scope.oracleColumns[i] = $scope.oracleColumns[i].split('_').join(' ');
                  }

                  for (i = 0; i < $scope.sheetColumns.length; i++) {
                    $scope.sheetColumns[i] = $scope.sheetColumns[i].split('_').join(' ');
                  }

                  for (var i = 0; i < $scope.mappedColumns.length; i++) {
                    var list = [];
                    for (var j = 0; j < $scope.sheetColumns.length; j++) {
                      index = $scope.mappedColumns.map(function(x) {
                        return x.column_name;
                      }).indexOf($scope.sheetColumns[j]);
                      if (index === -1 || ($scope.sheetColumns[j] === $scope.mappedColumns[i].column_name)) {
                        list.push($scope.sheetColumns[j]);
                      }
                    }
                    $scope.mappedColumns[i].list = angular.copy(list);
                  }

                  $scope.showSpinner = false;
                  $scope.alertMapping = false;
                  $scope.mapError = false;
                  $scope.mapColumns = true;
                  $scope.fileData = data.data;
                  $scope.category_ids = data.category_id;
                } else {
                  // loadShops();
                  // loadCountries();
                  // loadCities();
                  formatData(data.data);
                  $scope.showSpinner = false;
                }
              }
            }
          } catch (e) {
            $scope.notifications.push({msg: e.message, status: 1, details: '<pre>' + e.stack + '</pre>'});
            $scope.showSpinner = false;
          }
        });
      };

      function mapData() {
        var i, j, data = [], line, column_name, oracle_column_name, value;
        for (i = 0; i < $scope.fileData.length; i++) {
          line = {};
          for (j = 0; j < $scope.mappedColumns.length; j++) {
            value = '';
            if ($scope.mappedColumns[j].oracle_column_name) {
              oracle_column_name = $scope.mappedColumns[j].oracle_column_name.split(' ').join('_');
              if ($scope.mappedColumns[j].column_name) {
                column_name = $scope.mappedColumns[j].column_name.split(' ').join('_');
                if (oracle_column_name === 'zip_code' && $scope.fileData[i][column_name]) {
                  value = $scope.fileData[i][column_name].toString().split('.')[0].toString();
                  if (value.length > 20) {
                    $scope.showSpinner = false;
                    $('#columns-div').animate({
                      scrollTop: 0
                    }, 100, 'linear');
                    $scope.mapError = true;
                    return;
                  }
                } else {
                  if ((oracle_column_name === 'country' || oracle_column_name === 'vat') && $scope.fileData[i][column_name]) {
                    if ($scope.fileData[i][column_name].length > 20) {
                      $scope.showSpinner = false;
                      $('#columns-div').animate({
                        scrollTop: 0
                      }, 100, 'linear');
                      $scope.mapError = true;
                      return;
                    }
                  }
                  value = $scope.fileData[i][column_name];
                }
              } else {
                value = '';
              }
              line[oracle_column_name] = value;
              // line[oracle_column_name] = $scope.mappedColumns[j].column_name ?
              //         $scope.fileData[i][column_name] : '';
            }
          }
          data.push(line);
        }
        return data;
      }

      $scope.addClient = function(){
        $state.go('app.wfnaddclient');
      };


    }
})();
