/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 16-12-2018
 */

(function () {
    'use strict';

    angular.module('scorpion')
        .controller('wfnAddClient', wfnAddClient);

    function wfnAddClient($state, $scope, $formatHelper, $appHelper,
        $cacheHelper, $location, $window, $httpHelper, $filter, $rootScope) {

        
        $scope.toggleFilter = $appHelper.toggleFilter();
        $scope.moveToDcDashboard = function () {
            $state.go('app.wfnautomation');
        };
        var user;
        $cacheHelper.getUser(function (data) {
            if (!data) {
                $state.go('app.login');
            } else {
                if (!$cacheHelper.user) {
                    $cacheHelper.initialize(data);
                }
                user = data;
                $scope.showSpinner = true;   
                
                loadClients();
            }
        });        

        $scope.applyFilter = function () {
            $scope.toggleFilter();
            $scope.showSpinner = true;
        };


        function loadClients() {
            var endPoint = '/wfn/clients/';
            var requestObj = {
                org_id: $rootScope.orgId,
                client_id_sq: ''
            };
            $httpHelper.httpRequest('GET', endPoint, requestObj, function (data) {
                if (data === null || data === undefined) {
                    $scope.notifications.push({ msg: 'Server Error - loadClients()', status: 1 });
                } else {
                    if (data.status === 1) {
                        $scope.notifications.push({ msg: data.msg, status: data.status });
                    } else {
                        $scope.desc = false;
                        $scope.clientList = data.result;
                    }
                }
                $scope.showSpinner = false;
            });
        }


        $scope.$watch(function () {
            return $rootScope.orgId;
        }, function (newValue, oldValue) {
            if (newValue !== oldValue) {
                $state.go($state.current, {}, {
                    reload: true
                });
            }
        });        


        $scope.editLine = function (record) {
            $scope.alertShown = false;
            $scope.client_name = record.client_name;
            $scope.client_id = record.client_id;
            $scope.assign_employee = record.assigned_employee;
            $scope.project_manager = record.project_manager;            
            $scope.shared_path = record.shared_path;
            $scope.edit = true;
            $scope.id = record.client_id_sq;
            $scope.showAddNewDialog = true;
        };        

        $scope.addNew = function () {
            $scope.focusAddNew = false;
            $scope.focusClientId = false;
            $scope.focusEmployee = false;
            $scope.focusProjectManager = false;
            $scope.focusSharedPath = false;
            $scope.showAddNewDialog = true;
            $scope.client_name = '';
            $scope.client_id = '';
            $scope.assign_employee = '';
            $scope.project_manager = '';
            $scope.shared_path = '';
        };        

        $scope.cancel = function () {
            $scope.showAddNewDialog = false;
            $scope.focusAddNew = false;
            $scope.edit = false;
            $scope.addNewType = '';
            $scope.deleteLine = '';
            $scope.deleteDialog = false;
        };

        $scope.delete = function (line) {
            if (line) {
                $scope.deleteLine = line;
                $scope.deleteDialog = true;
            } else {                
                $scope.showSpinner = true;
                var endPoint = '/wfn/client/', list, index;
                $scope.deleteDialog = false;
                endPoint += $scope.deleteLine.client_id_sq + '/';
                $httpHelper.httpRequest('DELETE', endPoint, null, function (data) {
                    if (data === null || data === undefined) {
                        $scope.notifications.push({ msg: 'Server Error - delete()', status: 1 });
                    } else {
                        $scope.notifications.push({ msg: data.msg, status: data.status });
                        if (data.status === 0) {
                            list = $scope.clientList;                            
                            index = list.map(function (x) {
                                return x;
                            }).indexOf($scope.deleteLine);
                            if (index !== -1) {
                                list.splice(index, 1);
                            }
                        }
                    }
                    $scope.showSpinner = false;
                });
            }
        };


        $scope.saveClient = function () {

            $scope.showSpinner = true;  
            var endPoint;
            if (!$scope.client_name){
                $scope.focusAddNew = true;
                return;
            }            
            if(!$scope.client_id){
                $scope.focusClientId = true;                                
                return;
            }            
            if(!$scope.assign_employee){
                $scope.focusEmployee = true;
                return;
            }
            if(!$scope.project_manager){
                $scope.focusProjectManager = true;
                return;
            }                        
            if(!$scope.shared_path) {                
                $scope.focusSharedPath = true;
                return;
            }         
            var requestObj = {
                user_id: user.user_id,                
                org_id: $rootScope.orgId
            };
            if ($scope.edit) {
                requestObj.client_id_sq = $scope.id;
            }                         
            requestObj.client_name = $scope.client_name;
            requestObj.client_id = parseInt($scope.client_id);
            requestObj.assign_employee = parseInt($scope.assign_employee);
            requestObj.project_manager = parseInt($scope.project_manager);
            requestObj.shared_path = $scope.shared_path;

            endPoint = '/wfn/client/';
            endPoint += $scope.edit ? 'update/' : 'add/';
            $scope.showAddNewDialog = false;
            $scope.showSpinner = true;
            $httpHelper.httpRequest('POST', endPoint, requestObj, function (data) {
                if (data === null || data === undefined) {
                    $scope.notifications.push({ msg: 'Server Error: saveClient()', status: 1 });
                } else {
                    $scope.notifications.push({ msg: data.msg, status: data.status });
                    $scope.showSpinner = false;
                    if (data.status === 0) {
                        // To insert new record or update exixsting record if it is update
                        updateData(data);
                        $scope.showAddNewDialog = false;
                        $scope.showSpinner = false;
                        $scope.cancel();
                    }
                }
            });            

        };


        function updateData(result) {
            var data, typeId, index, i;
            data = $scope.clientList;
            typeId = $scope.client_id_sq;
            var datesLength = 1;
            if (!$scope.edit) {
                index = data.length;
                for (i = 0; i < datesLength; i++) {
                    data.push({});
                }
                
            } else {
                index = data.map(function (x) {
                    return x[typeId];
                }).indexOf($scope.id);
            }

            data[index].client_name = $scope.client_name;
            data[index].client_id = parseInt($scope.client_id);
            data[index].client_id_sq = parseInt(result.client_id_seq);
            data[index].project_manager = $scope.project_manager;
            data[index].assigned_employee = $scope.assign_employee;
            data[index].org_id = $rootScope.orgId;
            data[index].shared_path = $scope.shared_path;
        }        


    }
})();
