/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 16-10-2018
 */

(function() {
  'use strict';

  angular.module('scorpion')
    .controller('NotificationsController', NotificationsController);

  function NotificationsController($scope, $window, $location, $state, $cacheHelper,
  $httpHelper, $formatHelper, $filter, $compile, $appHelper, $sce, $rootScope) {

    // google analytics code
    $scope.$on('$viewContentLoaded', function() {
      $window.ga('send', 'pageview', { page: $location.url()});
    });

    var user, openNotifications = [], closeNotifications = [];

    $scope.reqattachments = [];

    $scope.showNotifications = function(status) {
      if (status === 'O') {
        $scope.displayStatus = 'OPEN';
        if (openNotifications && openNotifications.length) {
          $scope.data = openNotifications;
        } else {
          loadNotifications($scope.displayStatus);
        }
      } else {
        $scope.displayStatus = 'CLOSED';
        if (closeNotifications && closeNotifications.length) {
          $scope.data = closeNotifications;
        } else {
          loadNotifications($scope.displayStatus);
        }
      }
      $scope.detailsView = false;
    };

    $cacheHelper.getUser(function(data) {
      if (!data) {
        $state.go('login');
      } else {
        if (!$cacheHelper.user) {
          $cacheHelper.initialize(data);
        }
        user = data;
        $scope.time_zone = user.time_zone;
        if ($rootScope.fromState && $rootScope.fromState.name === 'app.createexpense') {
          $scope.fromExpenses = true;
        } else {
          $scope.fromExpenses = false;
        }

        $scope.showNotifications('O');
      }
    });

    function loadNotifications(status) {
      var endPoint = '/users/notifications/' + user.user_id + '/' + status + '/';
      $scope.showSpinner = true;
      $scope.data = [];
      $scope.detailsView = false;
      $httpHelper.httpRequest('GET', endPoint, null, function(data) {
        try {
          if (data === null || data === undefined) {
            throw new Error('Server Error');
          } else {
            var i;
            for (i = 0; i < data.length; i++) {
              data[i].f_begin_date = $formatHelper.formatDate(data[i].begin_date);
              data[i].f_end_date = $formatHelper.formatDate(data[i].end_date);
              data[i].f_due_date = $formatHelper.formatDate(data[i].due_date);
              switch (data[i].message_type) {
                case 'QPXSTAPR':
                  data[i].notification_type = 'Stands';
                  break;
                case 'QPXCMAPR':
                  data[i].notification_type = 'Tasks';
                  break;
                case 'QPEX_EXP':
                  data[i].notification_type = 'Leave management';
                  break;
                case 'SCHEDULER':
                  data[i].notification_type = 'Scheduler';
                  break;
                default:
                  data[i].notification_type = data[i].message_type;

              }
            }

            if (status === 'OPEN') {
              openNotifications = data;
            } else {
              closeNotifications = data;
            }
            $scope.displayStatus = status;
            $scope.data = data;
            if ($scope.windowWidth > 480) {

            }
            $scope.showSpinner = false;
          }
        } catch (e) {
          $scope.showSpinner = false;
          $scope.notifications.push({status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>'});
        }
      });
    }

    $scope.showDetail = function(d, index) {
      switch ($scope.wfType) {
        case 'SCHEDULER':
          schedulerDetails(d, index);
          break;
        default:
      }
    };


    function schedulerDetails(d, index) {
      if ($('#SCHEDULER-' + index).hasClass('expanded')) {
        $( '.procurement-notification .master-table' ).find('.child-row').remove();
        $('.expanded').each(function() {
          $(this).html('<i class="icon-plus-circle"></i>');
        });
        $('td').removeClass('expanded');
      } else {
        $scope.details = d;
        $( '.procurement-notification .master-table' ).find('.child-row').remove();
        $('.expanded').each(function() {
          $(this).html('<i class="icon-plus-circle"></i>');
        });
        $('td').removeClass('expanded');
        var row = $('<tr class="child-row"><td colspan="3"></td></tr>');
        row.insertAfter($( '#m-SCHEDULER-' + index));
        $( '#SCHEDULER-' + index).addClass('expanded');
        $( '#SCHEDULER-' + index).html('<i class="icon-circle-minus"></i>');
        row.find('td').append($compile('<procurementmobile></procurementmobile>')($scope));
      }
    }

    $scope.showReqHistoryDetail = function(d, index) {
      if ($('#h-SCHEDULER-' + index).hasClass('expanded')) {
        $( '.procurement-notification .history-table' ).find('.child-row').remove();
        $('.expanded').each(function() {
          $(this).html('<i class="icon-plus-circle"></i>');
        });
        $('td').removeClass('expanded');
      } else {
        $scope.details = d;
        $( '.procurement-notification .history-table' ).find('.child-row').remove();
        $('.expanded').each(function() {
          $(this).html('<i class="icon-plus-circle"></i>');
        });
        $('td').removeClass('expanded');
        var row = $('<tr class="child-row"><td colspan="4"></td></tr>');
        row.insertAfter($( '#mh-SCHEDULER-' + index));
        $( '#h-SCHEDULER-' + index).addClass('expanded');
        $( '#h-SCHEDULER-' + index).html('<i class="icon-circle-minus"></i>');
        row.find('td').append($compile('<procurementhistory></procurementhistory>')($scope));
      }
    };

    $scope.viewDetails = function(d) {
      $scope.procurement = null;
      $scope.benefitsscheduler = null;
      $scope.wfUserKey = d.user_key;
      $scope.wfItemKey = d.item_key;
      $scope.wfUsername = d.responder;
      $scope.wfStatus = d.status;
      $scope.wfSubject = d.subject;
      switch (d.message_type) {
        case 'SCHEDULER':
          $scope.wfType = 'SCHEDULER';
          $scope.wfUserKey = d.item_key.split('-')[0];
          loadScheduler();
          break;
        case 'SCHEDULER':
          $scope.wfType = 'SCHEDULER';
          $scope.wfUserKey = d.item_key.split('-')[0];
          // loadScheduler();
          break;
        default:
          break;
      }
    };

    $scope.wfAction = function(action) {
      if (action) {
        $scope.showDialog = true;
        $scope.userAction = action;
      } else {
        var req = {};
        req.item_key = $scope.wfItemKey;
        if ($scope.wfType === 'SCHEDULER') {
          req.result = $scope.userAction === 'A' ? 'COMPLETE' : 'OPEN';
        }
        req.type = $scope.wfType;
        req.comment = $scope.comment ? $scope.comment : '';
        req.login_user_name = $scope.wfUsername;
        var endPoint = '/users/workflow/';
        $scope.pageDim = true;
        $httpHelper.httpRequest('POST', endPoint, req, function(data) {
          try {
            if (data === null || data === undefined) {
              throw new Error('Server Error');
            } else {
              $scope.pageDim = false;
              loadNotifications('OPEN');
              $scope.notifications.push({status: data.status, msg: data.msg});
            }
            $scope.closeDialog();
          } catch (e) {
            $scope.pageDim = false;
            $scope.notifications.push({status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>'});
          }
        });
      }
    };


    $scope.closeDialog = function() {
      $scope.showDialog = false;
      $scope.focuscomment = true;
      $scope.comment = null;
      $scope.selectedLine = null;
    };

    function loadScheduler() {
      var endPoint = '/schedules/header/' + $scope.wfUserKey + '/';
      $scope.pageDim = true;
      $httpHelper.httpRequest('GET', endPoint, null, function (data) {
        try {
          if (data === null || data === undefined) {
            throw new Error('Server Error');
          } else {
            if (data && data.length > 0) {
              var i, line;
              for (i = 0; i < data[0].lines.length; i++) {
                line = data[0].lines[i];
              }
              // for (i = 0; i < data[0].history.length; i++) {
              //   data[0].history[i].amount = $formatHelper.formatNumber(data[0].history[i].amount);
              // }
              data[0].creation_date = $formatHelper.formatDate(data[0].creation_date);
              data[0].total = $formatHelper.formatNumber(data[0].total);
              $scope.reqattachments = [];
              for (i = 0; i < data[0].attachments.length; i++) {
                var attachment = {};
                attachment.base64 = data[0].attachments[i].file_data;
                attachment.filetype = data[0].attachments[i].file_content_type;
                attachment.filename = data[0].attachments[i].file_name;
                attachment.file_id = data[0].attachments[i].file_id;
                $scope.reqattachments.push(attachment);
              }

              $scope.procurement = data[0];
              $scope.time = data[0].time_slot.split('.');
              $scope.time_hours = $formatHelper.formatTimeZone($scope.time[0], 'EST', user.time_zone);
              $scope.time_slot = $scope.time_hours.toString().concat(':', $scope.time[1]);
            } else if (data.hasOwnProperty('status')) {
              $scope.notifications.push({status: data.status, msg: data.msg});
            }
            $scope.pageDim = false;
            $scope.detailsView = true;
          }
        } catch (e) {
          $scope.pageDim = false;
          $scope.notifications.push({status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>'});
        }
      });
    }

    $scope.moveToSummary = function() {
      $state.go('app.dashboard');
    };

    $scope.download = function(attachment) {
      try {
        var blobFile = $formatHelper.base64ToBlob(attachment.file_content, attachment.file_type);  //Convert blob to base64 formatHelper
        if($appHelper.isIE()) {
          var builder = new window.MSBlobBuilder();
          builder.append(blobFile);

          var blob = builder.getBlob(attachment.file_type);
          window.navigator.msSaveBlob(blob, attachment.file_name);
        } else if ($appHelper.isMobile()) {
          var endPoint = '/supplier/tmpfile/';
          var requestObj = {};
          requestObj.base64 = attachment.file_content;
          $scope.pageDim = true;

          $httpHelper.httpRequest('POST', endPoint, requestObj, function(data) {
            try {
              if (data === null || data === undefined) {
                throw new Error('Server Error');
              } else {
                $scope.pageDim = false;
                if (data) {
                  $window.open('https://ayodhya.finday.com/cdn/' + data);
                }
              }
            } catch (e) {
              $scope.pageDim = false;
              $scope.notifications.push({msg: e.message, status: 1, details: '<pre>' + e.stack + '</pre>'});
            }
          });
        } else if (blobFile){
          var url = $window.URL.createObjectURL(blobFile);
          if(attachment.file_type === 'application/pdf' && $appHelper.isSafari()) {
            $window.open(url);
          } else {
            var a = document.createElement('a');
            document.body.appendChild(a);
            a.style.display = 'none';
            a.href = url;
            a.download = attachment.file_name;
            a.click();
          }
        }
      } catch (e) {
        $scope.notifications.push({msg: e.message, status: 1, details: '<pre>' + e.stack + '</pre>'});
      }
    };

    $scope.downloadAttachment = function(attachment) {
      var blobFile = $formatHelper.base64ToBlob(attachment.base64 || attachment.file_content),
        url;
      if (blobFile) {
        var a = document.createElement('a');
        document.body.appendChild(a);
        url = $window.URL.createObjectURL(blobFile);
        a.href = url;
        a.download = attachment.filename || attachment.file_name;
        a.click();
        $window.URL.revokeObjectURL(url);
      }
    };

    $scope.onDownload = function(attachment, event) {
      event.stopPropagation();
      if (attachment.file_content) {
        $scope.downloadAttachment(attachment);
        return;
      }
      $scope.showSpinner = false;
      /* to service */
      if (attachment.file_id) {
        var endPoint = '/tasks/attachment/' + attachment.file_id + '/';
        $httpHelper.httpRequest('GET', endPoint, null, function (data) {
          try {
            if (data === null || data === undefined) {
              $scope.notifications.push({msg: data.msg, status: data.status});
            } else {
              if (data.status === 1) {
                $scope.notifications.push({msg: data.msg, status: data.status});
              } else {
                attachment.base64 = data[0].file_content;
                $scope.downloadAttachment(attachment);
              }
            }
            $scope.showSpinner = false;
          } catch (e) {
            $scope.notifications.push({msg: e.message, status: 1, details: '<pre>' + e.stack + '</pre>'});
          }
        });
      }
    };


  }

})();
