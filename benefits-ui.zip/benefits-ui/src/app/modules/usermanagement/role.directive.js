/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 17-10-2018
 */

(function() {
  'use strict';

  angular.module('scorpion')
    .directive('roledetails', RoleDetails);

  // Directive used to create dynamic child tables
  function RoleDetails() {
    return {
      restrict: 'E',
      transclude: true,
      templateUrl: 'app/modules/usermanagement/roledetails.html'
    };
  }
})();
