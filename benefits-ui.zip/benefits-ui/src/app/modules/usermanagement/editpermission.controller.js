/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 17-10-2018
 */


(function () {
  'use strict';

  angular.module('scorpion')
    .controller('EditPermissionController', EditPermissionController);

  function EditPermissionController($scope, $window, $location, $cacheHelper, $state,
    $httpHelper, $formatHelper, $filter, $appHelper, $rootScope, $sce, $timeout) {

    // google analytics code
    $scope.$on('$viewContentLoaded', function () {
      $window.ga('send', 'pageview', { page: $location.url() });
    });

    var user, org, lineTypes, invoiceTotal, awt_flag, deleteLines = [], vatCode;
    $scope.fileUpload = false;
    $scope.showDashboard = false;
    $scope.showSummary = false;
    // $scope.rejectDialog = false;

    $cacheHelper.getUser(function (data) {
      if (!data) {
        $state.go('login');
      } else {
        if (!$cacheHelper.user) {
          $cacheHelper.initialize(user);
        }

        user = data;
        if (!user.number_format) {
          user.number_format = '999,999.99';
        }
        if ($rootScope.fromState) {
          if ($rootScope.fromState.name === 'app.supplierdashboard') {
            $scope.showDashboard = true;
          } else if ($rootScope.fromState.name === 'app.supplierinvoicesummary') {
            $scope.showSummary = true;
          }
        }
        // Table sorting
        org = $cacheHelper.getOrgId();
        if (user) {
          var permissions = user.permissions;
          var appIndex = permissions.indexOf('OTHER-UI-INVOICE-APPROVE');
          var rejIndex = permissions.indexOf('OTHER-UI-INVOICE-REJECT');
          $scope.showApprove = appIndex !== -1 ? true : false;
          $scope.showReject = rejIndex !== -1 ? true : false;
          loadLineType();
          loadTaxCodes();
          loadAwtTaxCodes();
          loadData();
        }
        if (!user.date_format) {
          user.date_format = 'dd-MMM-yyyy';
        }
        $timeout(function () {
          new FooPicker({
            id: 'invDate',
            dateFormat: user.date_format
          });
        }, 100);

        $scope.invoiceTotal = $formatHelper.formatNumber(0);
        $scope.subTotal = $formatHelper.formatNumber(0);
        $scope.taxTotal = $formatHelper.formatNumber(0);
        $scope.awtTotal = $formatHelper.formatNumber(0);
        $scope.enasarcoTotal = $formatHelper.formatNumber(0);
        $scope.RplusTotal = $formatHelper.formatNumber(0);
        $scope.RminusTotal = $formatHelper.formatNumber(0);

        $scope.$watch(function () {
          return $rootScope.orgId;
        }, function (newValue, oldValue) {
          if (newValue !== oldValue) {
            $state.go('app.supplierinvoicesummary');
          }
        });

      }
    });

    $scope.deleteAttachment = function () {
      $scope.attachments = [];
      $scope.attachmentMsg = 'No files selected';
      $scope.fileUpload = true;
    };

    $scope.uploadAttachment = function () {
      var attachments = [];
      if ($scope.attachment) {
        attachments.push($scope.attachment);
      }
      $scope.attachmentMsg = attachments.length + ' file selected';
      $scope.attachments = attachments;
      // document.getElementById('inv-attachment').reset();
    };

    $scope.approve = function () {
      $scope.pageDim = true;
      var obj = {};
      obj.invoice_num = $scope.header.invoice_num;
      obj.vendor_id = $scope.header.vendor_id;
      obj.vendor_site_id = $scope.header.vendor_site_id;
      var endPoint = '/supplier/invoice/approve/';
      $httpHelper.httpRequest('POST', endPoint, obj, function (data) {
        try {
          if (data === null || data === undefined) {
            throw new Error('Server Error');
          } else {
            if (data.hasOwnProperty('status')) {
              if (data.status === 0) {
                var str = 'Invoice #' + $scope.header.invoice_num + ' has ' + data.msg;
                $appHelper.statusMsg = str;
                $scope.pageDim = false;
                $timeout(function () {
                  $state.go('app.supplierinvoicesummary');
                }, 200);
              } else {
                $scope.error_msg = data.msg;
              }
            }
          }
        } catch (e) {
          $scope.notifications.push({
            status: 1,
            msg: e.message,
            details: '<pre>' + e.stack + '</pre>'
          });
        }
      });
    };

    function loadTaxCodes() {
      var endPoint = '/supplier/taxcode/' + org + '/';
      $httpHelper.httpRequest('GET', endPoint, null, function (data) {
        try {
          if (data === null || data === undefined) {
            throw new Error('Server Error');
          } else {
            $scope.taxCodes = data;
          }
        } catch (e) {
          $scope.notifications.push({
            status: 1,
            msg: e.message,
            details: '<pre>' + e.stack + '</pre>'
          });
        }
      });
    }

    function loadAwtTaxCodes() {
      var endPoint = '/supplier/awttaxcode/' + org + '/';
      $httpHelper.httpRequest('GET', endPoint, null, function (data) {
        try {
          if (data === null || data === undefined) {
            throw new Error('Server Error');
          } else {
            var tax = {};
            tax.tax_rate = 0;
            tax.tax_rate_id = -1;
            tax.tax_name = '';
            var tmpData = [];
            tmpData.push(tax);
            for (var i = 0; i < data.length; i++) {
              tmpData.push(data[i]);
            }
            $scope.awtTaxCodes = tmpData;
          }
        } catch (e) {
          $scope.notifications.push({
            status: 1,
            msg: e.message,
            details: '<pre>' + e.stack + '</pre>'
          });
        }
      });
    }

    function loadLineType() {
      var endPoint = '/supplier/linetype/';
      $httpHelper.httpRequest('GET', endPoint, null, function (data) {
        try {
          if (data === null || data === undefined) {
            throw new Error('Server Error');
          } else {
            lineTypes = data;
            prepareLineTypes();
          }
        } catch (e) {
          $scope.notifications.push({
            status: 1,
            msg: e.message,
            details: '<pre>' + e.stack + '</pre>'
          });
        }
      });
    }

    function prepareLineTypes() {
      var tmpTypes = [];
      for (var i = 0; i < lineTypes.length; i++) {
        if (lineTypes[i].lookup_code === 'TAX') {
          if ($rootScope.isAdmin || $rootScope.isManager) {
            tmpTypes.push(lineTypes[i]);
          }
        } else if (lineTypes[i].lookup_code === 'AWT' ||
          lineTypes[i].lookup_code === 'ENASARCO' ||
          lineTypes[i].lookup_code === 'ENPACL') {
          if (awt_flag === 'Y') {
            tmpTypes.push(lineTypes[i]);
          }
        } else {
          tmpTypes.push(lineTypes[i]);
        }
      }
      $scope.lineTypes = tmpTypes;
    }

    function loadData() {
      $scope.pageDim = true;
      var endPoint;
      var d = $appHelper.invoiceDetails;
      endPoint = '/supplier/invoicedata/get/';
      var obj = {};
      obj.inv_num = d.invoice_num;
      obj.vendor_id = d.vendor_id;
      obj.vendor_site = d.vendor_site_id;

      $httpHelper.httpRequest('POST', endPoint, obj, function (data) {
        try {
          if (data === null || data === undefined) {
            throw new Error('Server Error');
          } else {
            $appHelper.invoiceDetails = null;

            var tmpJson = JSON.stringify(data[0]);
            tmpJson = tmpJson;
            data[0].invoicedDate = $formatHelper.formatDate(data[0].invoice_date);
            if (data[0].po_number) {
              $scope.po_num = data[0].po_number;
            }

            var header_seq = data[0].header_seq;
            if (header_seq) {
              $scope.header_seq = header_seq;
              getAdditionalData(header_seq);
            }
            var addressOne = data[0].address_line1 ? data[0].address_line1 + '<br/>' : '';
            var addressTwo = data[0].address_line2 ? data[0].address_line2 + '<br/>' : '';
            var city = data[0].city ? data[0].city + '<br/>' : '';
            var country = data[0].country ? data[0].country : '';
            var zip = data[0].zip ? data[0].zip : '';
            if (country && zip) {
              zip = ' - ' + zip;
            }

            $scope.header = data[0];
            awt_flag = data[0].allow_awt_flag;
            if (awt_flag) {
              $scope.allow_awt_flag = awt_flag;
              loadLineType();
            }

            vatCode = data[0].vat_code;
            $scope.old_invoice = data[0].invoice_num;
            $scope.invoice_no = $scope.header.invoice_num;
            $scope.header.invoicedDate = formatDate($scope.header.invoicedDate);
            $scope.invDateVal = $formatHelper.formatDate($scope.header.invoicedDate);
            document.getElementById('invDate').value = $formatHelper.formatDate($scope.header.invoicedDate);
            invoiceTotal = data[0].invoice_amount;
            $scope.invoiceTotal = $formatHelper.formatNumber(data[0].invoice_amount);
            $scope.attachments = data[0].attachments;
            $scope.attachment_file_id = $scope.attachments[0].file_id;
            $scope.attachmentMsg = $scope.attachments.length + ' file selected';
            $scope.address = $sce.trustAsHtml(addressOne + addressTwo + city + country + zip);
            var tmp_lines = data[0].lines;
            var tax_codes = $scope.taxCodes;
            for (var k = 0; k < tmp_lines.length; k++) {
              if (tmp_lines[k].tax_id) {
                for (var j = 0; j < tax_codes.length; j++) {
                  if (tmp_lines[k].tax_id === tax_codes[j].tax_id) {
                    tmp_lines[k].tax_percent = tax_codes[j].tax_rate;
                    break;
                  } else {
                    tmp_lines[k].tax_percent = 0;
                  }
                }
              } else {
                tmp_lines[k].tax_percent = 0;
              }
            }

            $scope.invoiceLines = tmp_lines;
            calculateTotal();
            for (var i = 0; i < $scope.invoiceLines.length; i++) {
              $scope.invoiceLines[i].creationDate = $formatHelper.formatDate($scope.invoiceLines[i].creation_date);
              $scope.invoiceLines[i].creation_date_millis = $formatHelper.dateInMillis($scope.invoiceLines[i].creation_date);

              $scope.invoiceLines[i].invoiced_date = $formatHelper.formatDate($scope.invoiceLines[i].invoice_date);
              $scope.invoiceLines[i].invoice_date_millis = $formatHelper.dateInMillis($scope.invoiceLines[i].invoice_date);

              $scope.invoiceLines[i].lastUpdatedDate = $formatHelper.formatDate($scope.invoiceLines[i].last_updated_date);
              $scope.invoiceLines[i].last_updated_date_millis = $formatHelper.dateInMillis($scope.invoiceLines[i].last_updated_date);

              $scope.invoiceLines[i].f_quantity_invoiced = $scope.invoiceLines[i].quantity_invoiced;
              if ($scope.invoiceLines[i].amount) {
                $scope.invoiceLines[i].amount_new = $formatHelper.formatNumber($scope.invoiceLines[i].amount);
              }

              if ($scope.invoiceLines[i].taxable_amount) {
                $scope.invoiceLines[i].tax_amount_old = $scope.invoiceLines[i].taxable_amount;
                $scope.invoiceLines[i].tax_amount_new = $formatHelper.formatNumber($scope.invoiceLines[i].taxable_amount);
              }
            }
            $scope.pageDim = false;
          }
        } catch (e) {
          $scope.notifications.push({
            status: 1,
            msg: e.message,
            details: '<pre>' + e.stack + '</pre>'
          });
        }
      });
    }

    $scope.saveInvoice = function () {
      if ($scope.attachments.length > 0) {
        var tmpLines = $scope.invoiceLines;
        var val = true;
        for (var k = 0; k < tmpLines.length; k++) {
          if (parseFloat(tmpLines[k].amount) <= 0) {
            val = false;
            break;
          }
        }
        if (val) {
          var header = {}, str, tmp_str;
          header.invoice_num = $scope.header.invoice_num;
          header.old_invoice = $scope.old_invoice;
          header.invoice_date = $formatHelper.parseDate(document.getElementById('invDate').value);
          if ($scope.header.description) {
            header.description = $scope.header.description;
          } else {
            header.description = '';
          }
          header.vendor_id = $scope.header.vendor_id;
          header.vendor_site_id = $scope.header.vendor_site_id;
          str = $scope.invoiceTotal;
          if (user.number_format === '999,999.99') {
            tmp_str = str.replace(/,/g, '');
          } else {
            tmp_str = str.split('.').join("");
            tmp_str = tmp_str.replace(',', '.');
          }
          header.invoice_amount = parseFloat(tmp_str);
          header.invoice_currency_code = $scope.header.invoice_currency_code;
          header.creation_date = $scope.header.creation_date;
          header.last_updated_date = $appHelper.today(0);
          if ($scope.header.invoice_status !== 'N') {
            header.invoice_status = 'N';
          }

          var lines = [];
          for (var i = 0; i < tmpLines.length; i++) {
            var line = {};
            line.invoice_num = $scope.header.invoice_num;
            line.vendor_id = $scope.header.vendor_id;
            line.vendor_site_id = $scope.header.vendor_site_id;
            if (tmpLines[i].line_number) {
              line.line_number = tmpLines[i].line_number;
            } else {
              line.line_number = '';
            }
            line.amount = parseFloat(tmpLines[i].amount);
            line.quantity_invoiced = tmpLines[i].quantity_invoiced ? parseInt(tmpLines[i].quantity_invoiced) : '';
            line.line_type_lookup_code = tmpLines[i].line_type_lookup_code;
            line.taxable_amount = tmpLines[i].taxable_amount ? parseFloat(tmpLines[i].taxable_amount) : 0;
            if (tmpLines[i].tax_id) {
              line.tax_id = tmpLines[i].tax_id;
            } else {
              line.tax_id = '';
            }
            if (tmpLines[i].awt_tax_id) {
              line.awt_tax_id = tmpLines[i].awt_tax_id;
            } else {
              line.awt_tax_id = '';
            }
            line.line_description = tmpLines[i].line_description;
            line.creation_date = $scope.header.creation_date;
            line.last_updated_date = $appHelper.today(0);
            lines.push(line);
          }
          var attachment = {};
          if ($scope.fileUpload) {
            attachment.file_id = '' + $scope.attachment_file_id;
            attachment.file_data = $scope.attachments[0].base64;
            attachment.file_name = $scope.attachments[0].filename;
            if ($scope.attachments[0].filetype) {
              attachment.file_content_type = $scope.attachments[0].filetype;
            } else {
              attachment.file_content_type = '';
            }
          }
          if (attachment.file_data) {
            header.attachments = attachment;
          }
          header.lines = lines;
          header.deleteLines = deleteLines;
          var dict = {};
          if ($scope.header.invoice_status === 'R') {
            dict.user = user.user_description;
            dict.creation_date = $scope.header.creation_date;
            dict.status = 'N';
            dict.seq = $scope.header_seq;
            dict.comments = 'Re inserted';
            dict.name = user.user_description;
            header.history = dict;
          }
          var endPoint = '/supplier/invheaderupdate/';
          $scope.pageDim = true;
          $httpHelper.httpRequest('PUT', endPoint, header, function (data) {
            try {
              if (data === null || data === undefined) {
                throw new Error('Server Error');
              } else {
                if (data.hasOwnProperty('status')) {
                  if (data.status === 0) {
                    $scope.msg = data.msg;
                    $scope.pageDim = false;
                    $scope.notifications.push({
                      status: 0,
                      msg: $scope.msg
                    });
                  } else {
                    $scope.error_msg = data.msg;
                    $scope.notifications.push({
                      status: 0,
                      msg: $scope.error_msg
                    });

                  }
                }
              }
            } catch (e) {
              $scope.notifications.push({
                status: 1,
                msg: e.message,
                details: '<pre>' + e.stack + '</pre>'
              });
            }
          });
        } else {
          $scope.error_msg = 'please fill all lines';
          $scope.notifications.push({
            status: 0,
            msg: $scope.error_msg
          });
        }
      } else {
        $scope.error_msg = 'attachment is mandatory';
        $scope.notifications.push({
          status: 0,
          msg: $scope.error_msg
        });
      }
    };

    // Switched to responsive layout if width less than/equals 1270
    function showResponsive() {
      $('.left-section').removeClass('visible');
      $('.left-section').addClass('hidden');
      $('.top-nav').removeClass('hidden');
      $('.top-nav').addClass('visible');
      $('.right-section').removeClass('scale');
      $('.right-section').addClass('full');
    }

    // Hides responsive layout if width greater than 1270
    function hideResponsive() {
      $('.left-section').removeClass('hidden');
      $('.left-section').addClass('visible');
      $('.top-nav').removeClass('visible');
      $('.top-nav').addClass('hidden');
      $('.right-section').removeClass('full');
      $(' .right-section').addClass('scale');
    }

    // create pdf
    function loadPdf(data) {
      var frame = document.getElementById('preview-frame');
      if (frame) {
        if (!$appHelper.isIE()) {
          frame.src = 'data:application/pdf;base64,' + data;
          if ($('.content-frame').hasClass('full')) {
            $('.content-frame').removeClass('full');
            $('.content-frame').addClass('scale');
            $('.preview-section').addClass('scale');
            $('#main').addClass('grid__item--6').removeClass('grid__item--12');
            $('#containerFull').addClass('').removeClass('container-full');
            $('#stepContainer').addClass('').removeClass('step-container');
            showResponsive();
          }
          frame.style.display = 'block';
        } else {
          var endPoint = '/supplier/tmpfile/';
          var requestObj = {};
          requestObj.base64 = data;
          //AppService.beginAnimation(60, 1);
          $httpHelper.httpRequest('POST', endPoint, requestObj, function (data) {
            try {
              if (data === null || data === undefined) {
                throw new Error('Server Error');
              } else {
                //AppService.endAnimation();
                frame.src = 'https://ayodhya.finday.com/cdn/' + data;
                if ($('.content-frame').hasClass('full')) {
                  $('.content-frame').removeClass('full');
                  $('.content-frame').addClass('scale');
                  $('.preview-section').addClass('scale');
                  $('#main').addClass('grid__item--6').removeClass('grid__item--12');
                  $('#containerFull').addClass('').removeClass('container-full');
                  $('#stepContainer').addClass('').removeClass('step-container');
                  showResponsive();
                }
                frame.style.display = 'block';
              }
            } catch (e) {
              $scope.notifications.push({
                status: 1,
                msg: e.message,
                details: '<pre>' + e.stack + '</pre>'
              });
            }
          });
        }
      }
    }

    $scope.togglePreview = function (attachment) {
      var frame;
      if (!$scope.fileUpload) {
        if ($scope.attachment_data) {
          var tmp_attachment = $scope.attachment_data;
          if (tmp_attachment.file_content_type === 'application/pdf') {
            if ($('.content-frame').hasClass('full')) {
              loadPdf(tmp_attachment.file_data);
            } else {
              frame = document.getElementById('preview-frame');
              $('.content-frame').removeClass('scale');
              $('.content-frame').addClass('full');
              $('.preview-section').removeClass('scale');
              $('#main').addClass('grid__item--12').removeClass('grid__item--6');
              $('#containerFull').addClass('container-full');
              $('#stepContainer').addClass('step-container');
              frame.style.display = 'none';
              hideResponsive();
            }
          } else {
            $scope.error_msg = 'You can preview only PDF files';
            $scope.notifications.push({
              status: 0,
              msg: $scope.error_msg
            });
          }

        } else {
          var id = attachment.pk1_value;
          var endPoint = '/supplier/attachments/' + id + '/';
          $httpHelper.httpRequest('GET', endPoint, null, function (data) {
            try {
              if (data === null || data === undefined) {
                throw new Error('Server Error');
              } else {
                attachment = data[0];
                $scope.attachment_data = attachment;
              }
            } catch (e) {
              $scope.notifications.push({
                status: 1,
                msg: e.message,
                details: '<pre>' + e.stack + '</pre>'
              });
            }
            if (attachment.file_content_type === 'application/pdf') {
              if ($('.content-frame').hasClass('full')) {
                loadPdf(attachment.file_data);
              } else {
                var frame = document.getElementById('preview-frame');
                $('.content-frame').removeClass('scale');
                $('.content-frame').addClass('full');
                $('.preview-section').removeClass('scale');
                $('#main').addClass('grid__item--12').removeClass('grid__item--6');
                $('#containerFull').addClass('container-full');
                $('#stepContainer').addClass('step-container');
                frame.style.display = 'none';
                hideResponsive();
              }
            } else {
              $scope.error_msg = 'You can preview only PDF files';
              $scope.notifications.push({
                status: 1,
                msg: $scope.error_msg
              });
            }
          });
        }
      } else {
        if ($scope.attachment.filetype === 'application/pdf') {
          if ($('.content-frame').hasClass('full')) {
            loadPdf($scope.attachment.base64);
          } else {
            frame = document.getElementById('preview-frame');
            $('.content-frame').removeClass('scale');
            $('.content-frame').addClass('full');
            $('.preview-section').removeClass('scale');
            $('#main').addClass('grid__item--12').removeClass('grid__item--6');
            $('#containerFull').addClass('container-full');
            $('#stepContainer').addClass('step-container');
            frame.style.display = 'none';
          }
        } else {
          $scope.error_msg = 'You can preview only PDF files';
          $scope.notifications.push({
            status: 1,
            msg: $scope.error_msg
          });
        }
      }
    };

    String.prototype.replaceAt = function (index, character) {
      return this.substr(0, index) + character + this.substr(index + character.length);
    };

    $scope.downloadAttachment = function (attachment) {
      if (!$scope.fileUpload) {
        var id = attachment.pk1_value;
        var endPoint = '/supplier/attachments/' + id + '/';
        $httpHelper.httpRequest('GET', endPoint, null, function (data) {
          try {
            if (data === null || data === undefined) {
              throw new Error('Server Error');
            } else {
              attachment = data[0];
            }
          } catch (e) {
            $scope.notifications.push({
              status: 1,
              msg: e.message,
              details: '<pre>' + e.stack + '</pre>'
            });
          }
          if (attachment) {
            try {
              var blobFile = $formatHelper.base64ToBlob(attachment.file_data); //convert blob to base64 format
              if ($appHelper.isIE()) {
                var builder = new window.MSBlobBuilder();
                builder.append(blobFile);
                var blob = builder.getBlob(attachment.file_content_type);
                window.navigator.msSaveBlob(blob, attachment.file_name);
              } else if (blobFile) {
                var a = document.createElement('a');
                document.body.appendChild(a);
                a.style.display = 'none';
                var url = $window.URL.createObjectURL(blobFile);
                a.href = url;
                a.download = attachment.file_name;
                a.click();
                $window.URL.revokeObjectURL(url);
              }
            } catch (e) {
              $scope.notifications.push({
                status: 1,
                msg: e.message,
                details: '<pre>' + e.stack + '</pre>'
              });
            }
          }
        });
      } else {
        try {
          var blobFile = $formatHelper.base64ToBlob(attachment.base64); //convert blob to base64 format
          if ($appHelper.isIE()) {
            var builder = new window.MSBlobBuilder();
            builder.append(blobFile);
            var blob = builder.getBlob(attachment.filetype);
            window.navigator.msSaveBlob(blob, attachment.filename);
          } else if (blobFile) {
            var a = document.createElement('a');
            document.body.appendChild(a);
            a.style.display = 'none';
            var url = $window.URL.createObjectURL(blobFile);
            a.href = url;
            a.download = attachment.filename;
            a.click();
            $window.URL.revokeObjectURL(url);
          }
        } catch (e) {
          $scope.notifications.push({
            status: 1,
            msg: e.message,
            details: '<pre>' + e.stack + '</pre>'
          });
        }
      }
    };

    $scope.lineAmountChange = function (line) {
      var str, tmp_str;
      if (line.hasOwnProperty('new_line')) {
        delete line.new_line;
      }
      var index = $scope.invoiceLines.indexOf(line);
      var number_format;
      var val = validatePattern($scope.invoiceLines[index].amount_new);
      if (user.number_format) {
        number_format = user.number_format;
      } else {
        number_format = '999,999.99';
      }
      if (val) {
        var comma_index = $scope.invoiceLines[index].amount_new.lastIndexOf(',');
        var dot_index = $scope.invoiceLines[index].amount_new.lastIndexOf('.');
        if (number_format) {
          var no_comma_index = number_format.lastIndexOf(',');
          var no_dot_index = number_format.lastIndexOf('.');
          if ((comma_index >= dot_index) && (no_comma_index >= no_dot_index)) {
            // If user number format is '999.999.999,99'
            var point = $scope.invoiceLines[index].amount_new.lastIndexOf(',');
            // we need to replace ',' with '.'
            if (point !== -1) {
              str = $scope.invoiceLines[index].amount_new;
              tmp_str = str.replaceAt(point, '.');
              $scope.invoiceLines[index].amount_new = removeAllButLast(tmp_str, '.');
              $scope.invoiceLines[index].amount = $scope.invoiceLines[index].amount_new;
              $scope.invoiceLines[index].amount_new = str;
            } else {
              $scope.invoiceLines[index].amount = $scope.invoiceLines[index].amount_new;
            }
          } else if ((dot_index >= comma_index) && (no_dot_index >= no_comma_index)) {
            // If user number format is '999,999,999.99'
            str = $scope.invoiceLines[index].amount_new;
            tmp_str = str.replace(/,/g, '');
            $scope.invoiceLines[index].amount_new = str;
            $scope.invoiceLines[index].amount = tmp_str;
          } else {
            $scope.invoiceLines[index].amount_new = '';
            $scope.invoiceLines[index].amount = '';
            $scope.error_msg = 'please check your number format';
            $scope.notifications.push({
              status: 1,
              msg: $scope.error_msg
            });
          }
          // $scope.invoiceLines[index].amount_new = $formatHelper.formatNumber($scope.invoiceLines[index].amount);
          calculateTotal(true);
        }
      } else {
        $scope.error_msg = 'please check your input';
        $scope.invoiceLines[index].amount_new = $scope.invoiceLines[index].amount ? $formatHelper.formatNumber($scope.invoiceLines[index].amount) : '';
        $scope.notifications.push({
          status: 1,
          msg: $scope.error_msg
        });
      }
    };

    // Delete rows from roles table
    $scope.deleteRow = function () {
      var line = $scope.selectedRow;
      if (line.line_number) {
        for (var i = 0; i < $scope.invoiceLines.length; i++) {
          if ($scope.invoiceLines[i].line_number === line.line_number) {
            $scope.invoiceLines.splice(i, 1);
            deleteLines.push(line.line_number);
            break;
          }
        }
      } else {
        var index = $scope.invoiceLines.map(function (x) { return x.line_id; }).indexOf(line.line_id);
        if (index !== -1) {
          $scope.invoiceLines.splice(index, 1);
        }
      }
      calculateTotal();
      $scope.showDialog = false;
    };

    $scope.selectedrow = function (line) {
      $scope.showDialog = true;
      $scope.selectedRow = line;
    };

    $scope.cancelModal = function () {
      $scope.selectedRow = '';
      $scope.showDialog = false;
    };

    $scope.onTypeChange = function (line) {
      var index = $scope.invoiceLines.indexOf(line);
      var type = $scope.invoiceLines[index].line_type_lookup_code;
      if (type !== 'ITEM' && type !== 'GOODS' && type !== 'ENPACL') {
        $scope.invoiceLines[index].withholding_tax = -1;
        $scope.invoiceLines[index].awt_tax = 0;
        $scope.invoiceLines[index].tax_id = null;
        $scope.invoiceLines[index].tax_percent = null;
        if ($scope.invoiceLines[index].tax_amount_new && $scope.invoiceLines[index].quantity_invoiced) {
          $scope.invoiceLines[index].amount_new = $formatHelper.formatNumber($scope.invoiceLines[index].taxable_amount * $scope.invoiceLines[index].quantity_invoiced);
          $scope.invoiceLines[index].amount = $scope.invoiceLines[index].taxable_amount * $scope.invoiceLines[index].quantity_invoiced;
          $scope.invoiceLines[index].tax_amount_new = '';
          $scope.invoiceLines[index].quantity_invoiced = '';
          $scope.invoiceLines[index].taxable_amount = '';
        }
      } else {
        var tax = getTaxId(vatCode);
        $scope.invoiceLines[index].tax_id = tax;
        $scope.changeTax($scope.invoiceLines[index], 'tax');
      }
      calculateTotal();
    };

    function getTaxId(code) {
      if (code) {
        var index = $scope.taxCodes.map(function (x) { return x.name; }).indexOf(code);
        if (index !== -1) {
          return $scope.taxCodes[index].tax_id;
        }
      }
      return null;
    }

    // Add empty rows to roles table
    $scope.addRow = function () {
      var length = $scope.invoiceLines.length;
      var line = {};
      line.line_id = 99999 + length;
      line.line_type_lookup_code = 'ITEM';
      line.new_line = 's';
      var tax = getTaxId(vatCode);
      if (tax) {
        line.tax_id = tax;
      }
      $scope.invoiceLines.push(line);
      if (tax) {
        $scope.changeTax(line, 'tax');
      }
    };

    $scope.qtyChange = function (line) {
      var tmp, amount;
      var index = $scope.invoiceLines.indexOf(line);
      if ($scope.invoiceLines[index].tax_percent && $scope.invoiceLines[index].tax_percent !== 0) {
        tmp = $scope.invoiceLines[index].taxable_amount * $scope.invoiceLines[index].quantity_invoiced;
        amount = tmp + tmp * ($scope.invoiceLines[index].tax_percent / 100);
        $scope.invoiceLines[index].amount = parseFloat(amount);
        $scope.invoiceLines[index].amount_new = $formatHelper.formatNumber(amount);
      } else if ($scope.invoiceLines[index].tax_percent === 0 || $scope.invoiceLines[index].tax_percent === undefined || $scope.invoiceLines[index].tax_percent === null) {
        amount = $scope.invoiceLines[index].taxable_amount * $scope.invoiceLines[index].quantity_invoiced;
        $scope.invoiceLines[index].amount = amount;
        $scope.invoiceLines[index].amount_new = $formatHelper.formatNumber(amount);
      }
      calculateTotal();
    };

    $scope.showRejectDialog = function () {
      if ($scope.attachments.length > 0) {
        $scope.rejectDialog = true;
      } else {
        $scope.error_msg = 'attachment is mandatory';
        $scope.notifications.push({
          status: 1,
          msg: $scope.error_msg
        });
      }
    };

    $scope.rejectCancel = function () {
      $scope.reject_reason = '';
      $scope.rejectDialog = false;
    };

    $scope.goToPrevious = function () {
      $state.go('app.supplierinvoicesummary');
    };

    $scope.goToDashBoard = function () {
      $state.go('app.supplierdashboard');
    };

    $scope.reject = function () {
      $scope.rejectDialog = false;
      if ($scope.reject_reason) {
        $scope.pageDim = true;
        var endPoint = '/supplier/reject/';
        var dict = {};
        dict.vendor_id = $scope.header.vendor_id;
        dict.invoice_no = $scope.header.invoice_num;
        dict.reason = $scope.reject_reason;

        var history = {};
        history.user = user.user_description;
        history.creation_date = $scope.header.creation_date;
        history.status = 'R';
        history.seq = $scope.header_seq;
        history.comments = $scope.reject_reason;
        history.name = user.user_description;

        dict.history = history;

        $httpHelper.httpRequest('POST', endPoint, dict, function (data) {
          try {
            if (data === null || data === undefined) {
              throw new Error('Server Error');
            } else {
              if (data.hasOwnProperty('status')) {
                if (data.status === 0) {
                  $appHelper.statusMsg = data.msg;
                  $scope.pageDim = false;
                  $timeout(function () {
                    $state.go('app.supplierinvoicesummary');
                  }, 200);
                } else {
                  $scope.error_msg = data.msg;
                  $scope.notifications.push({
                    status: 1,
                    msg: $scope.error_msg
                  });
                }
              }
            }
          } catch (e) {
            $scope.notifications.push({
              status: 1,
              msg: e.message,
              details: '<pre>' + e.stack + '</pre>'
            });
          }
        });
      } else {
        $scope.rejectDialog = false;
        $scope.error_msg = 'Please insert reason for rejection';
        $scope.notifications.push({
          status: 1,
          msg: $scope.error_msg
        });
      }
    };

    function removeAllButLast(string, token) {
      /* Requires STRING not contain TOKEN */
      var parts = string.split(token);
      return parts.slice(0, -1).join('') + token + parts.slice(-1);
    }

    function validatePattern(input) {
      var regex = /^[+-]?[0-9]{1,3}(?:[0-9]*(?:[.,][0-9]{1,2})?|(?:,[0-9]{3})*(?:\.[0-9]{1,2})?|(?:\.[0-9]{3})*(?:,[0-9]{1,2})?)$/;
      if ((input.match(regex))) {
        return true;
      } else {
        return false;
      }
    }

    $scope.taxAmountChange = function (line) {
      if (line.hasOwnProperty('new_line')) {
        delete line.new_line;
      }
      var tmp_calc = true, str;
      var index = $scope.invoiceLines.indexOf(line);
      var tax = $scope.invoiceLines[index].taxable_amount;
      var org_amount = $scope.invoiceLines[index].amount;
      if ($scope.invoiceLines[index].tax_amount_new) {
        var val = validatePattern($scope.invoiceLines[index].tax_amount_new);
        var number_format;
        if (user.number_format) {
          number_format = user.number_format;
        } else {
          number_format = '999,999.99';
        }
        if (val) {
          var comma_index = $scope.invoiceLines[index].tax_amount_new.lastIndexOf(',');
          var dot_index = $scope.invoiceLines[index].tax_amount_new.lastIndexOf('.');
          var no_comma_index = number_format.lastIndexOf(',');
          var no_dot_index = number_format.lastIndexOf('.');
          if ((comma_index >= dot_index) && (no_comma_index >= no_dot_index)) {
            // If user number format is '999.999.999,99'
            var point = $scope.invoiceLines[index].tax_amount_new.lastIndexOf(',');
            // we need to replace ',' with '.'
            str = $scope.invoiceLines[index].tax_amount_new;
            if (point !== -1) {
              $scope.invoiceLines[index].tax_amount_new = str;
              str = str.replaceAt(point, '.');
              $scope.invoiceLines[index].taxable_amount = str;
            } else {
              $scope.invoiceLines[index].tax_amount_new = $formatHelper.formatNumber(str);
              $scope.invoiceLines[index].taxable_amount = str;
            }
          } else if ((dot_index >= comma_index) && (no_dot_index >= no_comma_index)) {
            // If user number format is '999,999,999.99'
            str = $scope.invoiceLines[index].tax_amount_new;
            str = str.replace(/,/g, '');
            $scope.invoiceLines[index].tax_amount_new = str;
            $scope.invoiceLines[index].taxable_amount = $scope.invoiceLines[index].tax_amount_new;
          } else {
            tmp_calc = false;
            $scope.invoiceLines[index].tax_amount_new = $formatHelper.formatNumber(tax);
            $scope.invoiceLines[index].amount_new = $formatHelper.formatNumber(org_amount);
            $scope.error_msg = 'please check your number format';
            $scope.notifications.push({
              status: 1,
              msg: $scope.error_msg
            });
          }
          if (tmp_calc) {
            var amount, tmp;
            if ($scope.invoiceLines[index].tax_percent && $scope.invoiceLines[index].tax_percent !== 0) {
              tmp = $scope.invoiceLines[index].taxable_amount * $scope.invoiceLines[index].quantity_invoiced;
              amount = tmp + tmp * ($scope.invoiceLines[index].tax_percent / 100);
              $scope.invoiceLines[index].amount = parseFloat(amount);
              $scope.invoiceLines[index].amount_new = $formatHelper.formatNumber(amount);
              calculateTotal();
            } else if ($scope.invoiceLines[index].tax_percent === 0 || $scope.invoiceLines[index].tax_percent === undefined || $scope.invoiceLines[index].tax_percent === null) {
              amount = $scope.invoiceLines[index].taxable_amount * $scope.invoiceLines[index].quantity_invoiced;
              $scope.invoiceLines[index].amount = amount;
              $scope.invoiceLines[index].amount_new = $formatHelper.formatNumber(amount);
              calculateTotal();
            }
          }
        } else {
          $scope.error_msg = 'please check your input';
          $scope.invoiceLines[index].taxable_amount = $scope.invoiceLines[index].tax_amount_old;
          $scope.invoiceLines[index].tax_amount_new = $formatHelper.formatNumber($scope.invoiceLines[index].taxable_amount);
          $scope.notifications.push({
            status: 1,
            msg: $scope.error_msg
          });
        }
      }
    };

    $scope.changeTax = function (line, type) {
      var index = $scope.invoiceLines.indexOf(line);
      var taxIndex, taxable_amount = 0, line_amount;
      if (type === 'tax') {
        taxIndex = $scope.taxCodes.map(function (x) { return x.tax_id; }).indexOf($scope.invoiceLines[index].tax_id);
        var tax_rate = $scope.taxCodes[taxIndex].tax_rate;
        $scope.invoiceLines[index].tax_percent = $scope.taxCodes[taxIndex].tax_rate;
        if ($scope.invoiceLines[index].tax_amount_new && $scope.invoiceLines[index].tax_amount_old) {
          taxable_amount = $scope.invoiceLines[index].tax_amount_old;
        } else if ($scope.invoiceLines[index].tax_amount_new) {
          taxable_amount = $scope.invoiceLines[index].taxable_amount;
        } else {
          taxable_amount = $scope.invoiceLines[index].amount;
        }
        if (tax_rate) {
          var tax = parseFloat(taxable_amount) * (tax_rate / 100);
          line_amount = $scope.invoiceLines[index].quantity_invoiced * parseFloat(taxable_amount) + tax;
          $scope.invoiceLines[index].taxable_amount = parseFloat(taxable_amount);
          $scope.invoiceLines[index].tax_amount_new = $formatHelper.formatNumber(line.taxable_amount);
          $scope.invoiceLines[index].amount = line_amount;
          $scope.invoiceLines[index].amount_new = $formatHelper.formatNumber(line_amount);
        } else {
          line_amount = $scope.invoiceLines[index].quantity_invoiced * parseFloat(taxable_amount);
          $scope.invoiceLines[index].taxable_amount = parseFloat(taxable_amount);
          $scope.invoiceLines[index].tax_amount_new = $formatHelper.formatNumber(line.taxable_amount);
          $scope.invoiceLines[index].amount = line_amount;
          $scope.invoiceLines[index].amount_new = $formatHelper.formatNumber(line_amount);
        }
      } else if (type === 'awt') {
        taxIndex = $scope.awtTaxCodes.map(function (x) { return x.tax_rate_id; }).indexOf($scope.invoiceLines[index].withholding_tax);
        $scope.invoiceLines[index].awt_tax = $scope.awtTaxCodes[taxIndex].tax_rate;
      }
      calculateTotal();
    };

    function formatDate(date) {
      $scope.invoiceDate = date;
      date = $formatHelper.formatDate(date);
      return date;
    }

    // check for duplicate invoice #
    $scope.checkDuplicate = function () {
      var obj = {};
      obj.inv_num = $scope.header.invoice_num;
      obj.vendor_id = $scope.header.vendor_id;
      obj.vendor_site = $scope.header.vendor_site_id;
      var endPoint = '/supplier/invnumvalidation/';
      $httpHelper.httpRequest('POST', endPoint, obj, function (data) {
        try {
          if (data === null || data === undefined) {
            throw new Error('Server Error');
          } else {
            if (data.hasOwnProperty('status')) {
              if (data.status !== 0) {
                $scope.error_msg = 'Duplicate Invoice #';
                $scope.header.invoice_num = $scope.invoice_no;
                $scope.notifications.push({
                  status: 1,
                  msg: $scope.error_msg
                });
              }
            }
          }
        } catch (e) {
          $scope.notifications.push({
            status: 1,
            msg: e.message,
            details: '<pre>' + e.stack + '</pre>'
          });
        }
      });
    };


    function calculateTotal(isTotal) {
      var total = 0, qty;
      var tmpLines = $scope.invoiceLines;
      var subTotal = 0, taxTotal = 0, awtTax = 0, enasarco = 0, roundingPlus = 0, roundingMinus = 0;
      for (var i = 0; i < tmpLines.length; i++) {
        var line = tmpLines[i];
        if (!line.hasOwnProperty('new_line')) {
          var amount = line.amount ? parseFloat(tmpLines[i].amount) : 0;
          switch (line.line_type_lookup_code) {
            case 'ITEM':
            case 'GOODS':
            case 'ENPACL':
              if (line.hasOwnProperty('quantity_invoiced')) {
                qty = parseFloat(line.quantity_invoiced);
              } else {
                qty = 0;
              }
              if (!qty) {
                $scope.error_msg = 'Please enter valid quantity';
                $scope.notifications.push({
                  status: 1,
                  msg: $scope.error_msg
                });
                return;
              }
              if (!line.taxable_amount) {
                return;
              }
              subTotal += line.taxable_amount ? parseFloat(line.taxable_amount) * qty : 0;
              var taxRate = tmpLines[i].tax_percent ? parseFloat(tmpLines[i].tax_percent) : 0;
              var awtRate = tmpLines[i].awt_tax ? parseFloat(tmpLines[i].awt_tax) : 0;
              var taxableAmount = tmpLines[i].taxable_amount ? parseFloat(tmpLines[i].taxable_amount) : 0;
              if (taxableAmount) {
                var tax = taxableAmount * qty * (taxRate / 100);
                var withholdingTax = taxableAmount * qty * (awtRate / 100);
                if (!isTotal) {
                  tmpLines[i].amount = (tax + (taxableAmount * qty) - withholdingTax).toFixed(2);
                }
                taxTotal += tax;
                awtTax += withholdingTax;
              } else {
                tmpLines[i].amount = null;
              }
              total += tmpLines[i].amount ? parseFloat(tmpLines[i].amount) : 0;
              break;
            case 'R+':
              roundingPlus += amount;
              break;
            case 'R-':
              roundingMinus += amount;
              break;
            case 'AWT':
              awtTax += amount;
              break;
            case 'TAX':
              taxTotal += amount;
              break;
            case 'ENASARCO':
              enasarco += amount;
              break;
          }
        }
      }
      invoiceTotal = subTotal + taxTotal + roundingPlus - awtTax - enasarco - roundingMinus;
      $scope.invoiceTotal = $formatHelper.formatNumber(invoiceTotal);
      $scope.subTotal = $formatHelper.formatNumber(subTotal);
      $scope.taxTotal = $formatHelper.formatNumber(taxTotal);
      $scope.awtTotal = $formatHelper.formatNumber(awtTax);
      $scope.enasarcoTotal = $formatHelper.formatNumber(enasarco);
      $scope.RplusTotal = $formatHelper.formatNumber(roundingPlus);
      $scope.RminusTotal = $formatHelper.formatNumber(roundingMinus);
      $scope.invoiceLines = tmpLines;
    }


    function getAdditionalData(header_seq) {
      var endData = '/supplier/invoice/history/' + header_seq + '/';
      $httpHelper.httpRequest('GET', endData, null, function (tmp) {
        try {
          if (tmp === null || tmp === undefined) {
            throw new Error('Server Error');
          } else {
            for (var i = 0; i < tmp.length; i++) {
              if (tmp[i].creation_date) {
                tmp[i].create_date = $formatHelper.formatDate(tmp[i].creation_date);
              }
            }
            $scope.history = tmp;
          }
        } catch (e) {
          $scope.notifications.push({
            status: 1,
            msg: e.message,
            details: '<pre>' + e.stack + '</pre>'
          });
        }
      });
    }



  }
})();
