/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 17-10-2018
 */

(function() {
  'use strict';

  angular.module('scorpion')
    .controller('GroupsController', GroupsController);

  function GroupsController($scope, $window, $location, $cacheHelper, $state,
  $httpHelper, $formatHelper, $filter, $appHelper, $rootScope, $compile, $timeout) {

    // google analytics code
    $scope.$on('$viewContentLoaded', function() {
      $window.ga('send', 'pageview', { page: $location.url() });
    });

    var user;
    $cacheHelper.getUser(function(data) {
      if (!data) {
        $state.go('login');
      } else {
        if (!$cacheHelper.user) {
          $cacheHelper.initialize(data);
        }
        user = data;
        if($appHelper.group_msg) {
          $scope.msg = $appHelper.group_msg;
          $scope.status = $appHelper.group_status;
          $appHelper.group_msg = null;
          $appHelper.group_status = null;
          $scope.notifications.push({status: 1, msg: $scope.msg});
        }
        loadGroups();
      }
    });

    $scope.close = function() {
      $scope.msg = null;
      $scope.status = null;
    };

    $scope.$watch(function() {
      return $scope.msg;
    }, function(newValue) {
      if (newValue) {
        $timeout(function() {
          $scope.msg = null;
          $scope.status = null;
        }, 5000);
      }
    });

    // Load group details when expanded
    $scope.loadDetails = function(row) {
      var endPoint;

      try {
        endPoint = '/groups/details/' + row.group_id + '/';

        $( '.child-data' ).remove();
        $( '.master-table' ).find('.child-row').remove();

        if ($( '#' + row.group_id ).hasClass('expanded')) {
          $( '#' + row.group_id ).removeClass('expanded');
          $( '#' + row.group_id).find('.expand-icon').removeClass('icon-circle-minus');
          $( '#' + row.group_id).find('.expand-icon').addClass('icon-circle-plus');
          $scope.isExpanded = false;
        } else {
          $( 'tr' ).removeClass('expanded');
          $( 'tr' ).find('.expand-icon').removeClass('icon-circle-minus');
          $( 'tr' ).find('.expand-icon').addClass('icon-circle-plus');
          var childRow = $( '<tr class="child-row"><td colspan="7"></td></tr>' );
          childRow.find('td').append($compile('<div class="sub-spinner"><spinner></spinner></div>')($scope));
          childRow.insertAfter($( '#' + row.group_id));
          $( '#' + row.group_id).addClass('expanded');
          $( '#' + row.group_id).find('.expand-icon').removeClass('icon-circle-plus');
          $( '#' + row.group_id).find('.expand-icon').addClass('icon-circle-minus');

          $httpHelper.httpRequest('GET', endPoint, null, function (data) {
            try {
              if (data === null || data === undefined) {
                throw new Error('Server Error');
              } else {
                if ($( '#' + row.group_id ).hasClass('expanded')) {
                  var roles = data.roles, users = data.users, i;
                  for (i = 0; i < roles.length; i++) {
                    if (roles[i].active_date) {
                      roles[i].f_active_date = $formatHelper.formatDate(roles[i].active_date);
                    }
                    if (roles[i].inactive_date) {
                      roles[i].f_inactive_date = $formatHelper.formatDate(roles[i].inactive_date);
                    }
                    roles[i].name = roles[i].role_name;
                  }

                  for (i = 0; i < users.length; i++) {
                    if (users[i].active_date) {
                      users[i].f_active_date = $formatHelper.formatDate(users[i].active_date);
                    }
                    if (users[i].inactive_date) {
                      users[i].f_inactive_date = $formatHelper.formatDate(users[i].inactive_date);
                    }
                    users[i].name = users[i].user_name;
                  }

                  $scope.childOne = roles;
                  $scope.childOneLabel = 'Roles';
                  $scope.childTwo = users;
                  $scope.childTwoLabel = 'Users';

                  childRow.find('spinner').remove();
                  childRow.find('td').append($compile('<groupdetails></groupdetails>')($scope));
                }
              }
            } catch (e) {
              $scope.notifications.push({status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>'});
            }
          });
        }
      } catch (e) {
        $scope.notifications.push({status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>'});
      }
    };

    $scope.manageGroup = function(which, group) {
        if (which === 'edit') {
          $appHelper.group_id = group.group_id;
        } else if (which === 'create') {
          $appHelper.group_id = null;
        }
        $state.go('app.managegroup');
    };

    $scope.toggleFilter = $appHelper.toggleFilter();


    // Table sorting
    $scope.predicate = 'group_id';
    $scope.desc = true;

    $scope.sort = function(key) {
      if ($scope.predicate === key) {
        $scope.desc = !$scope.desc;
      } else {
        $scope.predicate = key;
      }
    };

    function loadGroups() {
      $scope.showSpinner = true;
      var endPoint = '/groups/';
      $httpHelper.httpRequest('GET', endPoint, null, function (data) {
        try {
          if (data === null || data === undefined) {
            throw new Error('Server Error');
          } else {
            $scope.groups = data;
            $scope.showSpinner = false;
          }
        } catch (e) {
          $scope.notifications.push({status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>'});

        }
      });
    }
    
    $('.scroll-top').click(function() {
      $appHelper.scrollTop();
    });

    // Exports the table data into spreadsheet
    $scope.export = function() {
      $scope.toggleFilter();
      var data = $filter('orderBy')($scope.groups, $scope.predicate, $scope.desc);
      var tableData = {};
      var tmpReports = [];
      try {
        for (var i = 0; i < data.length; i++) {
          var tmpReport = {};
          tmpReport['Group Code'] = {data: data[i].group_code ? data[i].group_code : ''};
          tmpReport.Name = {data: data[i].group_name ? data[i].group_name : ''};
          tmpReport.Description = {data: data[i].group_description ? data[i].group_description : ''};
          tmpReports.push(tmpReport);
        }
        tableData.data = tmpReports;
        $appHelper.tableToExcel('Groups', tableData, 'export-data');
      } catch (e) {
        $scope.notifications.push({status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>'});
      }
    };
  }
})();
