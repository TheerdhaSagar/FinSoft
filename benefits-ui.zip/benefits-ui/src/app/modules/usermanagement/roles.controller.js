/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 17-10-2018
 */

(function() {
  'use strict';

  angular.module('scorpion')
    .controller('RolesController', RolesController);

  function RolesController($scope, $window, $location, $cacheHelper, $state,
  $httpHelper, $formatHelper, $filter, $appHelper, $rootScope, $compile, $timeout) {

    // google analytics code
    $scope.$on('$viewContentLoaded', function() {
      $window.ga('send', 'pageview', { page: $location.url() });
    });

    var user;
    $cacheHelper.getUser(function(data) {
      if (!data) {
        $state.go('login');
      } else {
        if (!$cacheHelper.user) {
          $cacheHelper.initialize(data);
        }
        user = data;
        if($appHelper.role_msg) {
          $scope.msg = $appHelper.role_msg;
          $scope.status = $appHelper.role_status;
          $appHelper.role_msg = null;
          $appHelper.role_status = null;
          $scope.notifications.push({status: 0, msg: $scope.msg});
        }
        loadRoles();
      }
    });

    $scope.$watch(function() {
      return $scope.msg;
    }, function(newValue) {
      if (newValue) {
        $timeout(function() {
          $scope.msg = null;
          $scope.status = null;
        }, 5000);
      }
    });

    $scope.toggleFilter = $appHelper.toggleFilter();

    // Load role details when expanded
    $scope.loadDetails = function(row) {
      var endPoint;
      try {
        endPoint = '/roles/permissions/' + row.role_id + '/';
        $( '.child-data' ).remove();
        $( '.master-table' ).find('.child-row').remove();
        if ($( '#' + row.role_id ).hasClass('expanded')) {
          $( '#' + row.role_id ).removeClass('expanded');
          $( '#' + row.role_id).find('.expand-icon').removeClass('icon-circle-minus');
          $( '#' + row.role_id).find('.expand-icon').addClass('icon-circle-plus');
          $scope.isExpanded = false;
        } else {
          $( 'tr' ).removeClass('expanded');
          $( 'tr' ).find('.expand-icon').removeClass('icon-circle-minus');
          $( 'tr' ).find('.expand-icon').addClass('icon-circle-plus');
          var childRow = $( '<tr class="child-row"><td colspan="7"></td></tr>' );
          childRow.find('td').append($compile('<div class="sub-spinner"><spinner></spinner></div>')($scope));
          childRow.insertAfter($( '#' + row.role_id));
          $( '#' + row.role_id).addClass('expanded');
          $( '#' + row.role_id).find('.expand-icon').removeClass('icon-circle-plus');
          $( '#' + row.role_id).find('.expand-icon').addClass('icon-circle-minus');
          $httpHelper.httpRequest('GET', endPoint, null, function (data) {
            try {
              if (data === null || data === undefined) {
                throw new Error('Server Error');
              } else {
                if ($( '#' + row.role_id ).hasClass('expanded')) {
                  for (var i = 0; i < data.length; i++) {
                    if (data[i].active_date) {
                      data[i].f_active_date = $formatHelper.formatDate(data[i].active_date);
                    }
                    if (data[i].inactive_date) {
                      data[i].f_inactive_date = $formatHelper.formatDate(data[i].inactive_date);
                    }
                    data[i].name = data[i].permission_name;
                  }
                  $scope.childOne = data;
                  $scope.childOneLabel = 'Permissions';
                  childRow.find('spinner').remove();
                  childRow.find('td').append($compile('<roledetails></roledetails>')($scope));
                }
              }
            } catch (e) {
              $scope.notifications.push({status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>'});
            }
          });
        }
      } catch (e) {
        $scope.notifications.push({status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>'});
      }
    };


    function loadRoles() {
      $scope.showSpinner = true;
      var endPoint = '/roles/';
      $httpHelper.httpRequest('GET', endPoint, null, function (data) {
        try {
          if (data === null || data === undefined) {
            throw new Error('Server Error');
          } else {
            for(var i=0;i<data.length;i++) {
              data[i].creation_date_millis = $formatHelper.dateInMillis(data[i].create_date);
            }
            $scope.roles = data;
            $scope.showSpinner = false;
          }
        } catch (e) {
          $scope.notifications.push({status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>'});
        }
      });
    }

    $scope.manageRole = function(which, role) {
        if (which === 'edit') {
          $appHelper.role_id = role.role_id;
        } else if (which === 'create') {
          $appHelper.role_id = null;
        }
        $state.go('app.managerole');
    };

    // Table sorting
    $scope.predicate = 'creation_date_millis';
    $scope.desc = true;

    $scope.sort = function(key) {
      if ($scope.predicate === key) {
        $scope.desc = !$scope.desc;
      } else {
        $scope.predicate = key;
      }
    };

    $('.scroll-top').click(function() {
      $appHelper.scrollTop();
    });

    // Exports the table data into spreadsheet
    $scope.export = function() {
      $scope.toggleFilter();
      var data = $filter('orderBy')($scope.roles, $scope.predicate, $scope.desc);
      var tableData = {};
      var tmpReports = [];
      try {
        for (var i = 0; i < data.length; i++) {
          var tmpReport = {};
          tmpReport['Role Code'] = {data: data[i].role_code ? data[i].role_code : ''};
          tmpReport.Name = {data: data[i].role_name ? data[i].role_name : ''};
          tmpReport.Description = {data: data[i].role_description ? data[i].role_description : ''};
          tmpReports.push(tmpReport);
        }
        tableData.data = tmpReports;
        $appHelper.tableToExcel('Roles', tableData, 'export-data');
      } catch (e) {
        $scope.notifications.push({status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>'});
      }
    };
  }
})();
