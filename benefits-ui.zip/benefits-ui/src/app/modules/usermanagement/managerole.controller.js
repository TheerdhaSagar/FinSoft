/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 17-10-2018
 */

(function() {
  'use strict';

  angular.module('scorpion')
    .controller('ManageRoleController', ManageRoleController);

  function ManageRoleController($scope, $window, $location, $cacheHelper, $state,
    $httpHelper, $formatHelper, $filter, $appHelper, $rootScope, $sce, $timeout) {

    // google analytics code
    $scope.$on('$viewContentLoaded', function() {
      $window.ga('send', 'pageview', {
        page: $location.url()
      });
    });

    var permissionIds = [],
      rolePerms = [],
      user, editRole, roleDetails, org;
    $scope.checkedCount = 0;
    $scope.allowed = false;
    $scope.disableFields = false;
    $scope.manageRole = {
      msg: '',
      showError: false,
      showDialog: false
    };

    //user
    $cacheHelper.getUser(function(data) {
      if (!data) {
        $state.go('login');
      } else {
        if (!$cacheHelper.user) {
          $cacheHelper.initialize(user);
        }
        user = data;
        if (!user.number_format) {
          user.number_format = '999,999.99';
        }
        org = $cacheHelper.getOrgId();
        if (!user.date_format) {
          user.date_format = 'dd-MMM-yyyy';
        }
        if ($appHelper.role_id) {
          $scope.type = 'Role Details';
          editRole = $appHelper.role_id;
          $appHelper.role_id = null;
          $scope.disableFields = true;
          loadRoleDetails();
        } else {
          $scope.type = 'Create Role';
          $timeout(function() {
            for (var i = 99999; i < 100004; i++) {
              new FooPicker({
                id: 'active' + i,
                dateFormat: user.date_format
              });
              new FooPicker({
                id: 'inactive' + i,
                dateFormat: user.date_format
              });
            }
          }, 100);
          for (var i = 99999; i < 100004; i++) {
            var permission = {};
            permission.permission_id = i;
            permission.active_date = $formatHelper.formatDate($appHelper.today(-1));
            rolePerms.push(permission);
          }
          $scope.rolePerms = rolePerms;
        }
        $timeout(function() {
          if (editRole) {
            $scope.allowed = true;
          }
        }, 1000);

        $timeout(function() {
          new FooPicker({
            id: 'activeDate',
            dateFormat: user.date_format
          });
          new FooPicker({
            id: 'inactiveDate',
            dateFormat: user.date_format
          });
        }, 100);
        loadPermissions();
      }
    });

    $scope.$watch(function() {
      return $scope.msg;
    }, function(newValue) {
      if (newValue) {
        $timeout(function() {
          $scope.msg = null;
          $scope.status = null;
        }, 5000);
      }
    });

    $scope.close = function() {
      $scope.msg = null;
      $scope.status = null;
    };

    $scope.checkDuplicate = function(permission) {
      var index = $scope.rolePerms.indexOf(permission);
      var count = 0;
      for (var i = 1; i < $scope.rolePerms.length; i++) {
        if ($scope.rolePerms[i].permission_name &&
          $scope.rolePerms[i].permission_name === permission.permission_name) {
          count++;
          $scope.msg = "Permissions Don't repeat";
          $scope.status = 1;
          $scope.rolePerms[index].permission_name = '';
          break;
        }
      }
    };

    // Load all permissions
    function loadPermissions() {
      var endPoint = '/permission/';
      $httpHelper.httpRequest('GET', endPoint, null, function(data) {
        try {
          if (data === null || data === undefined) {
            throw new Error('Server Error');
          } else {
            $scope.permissions = data;
          }
        } catch (e) {
          $scope.notifications.push({
            status: 1,
            msg: e.message,
            details: '<pre>' + e.stack + '</pre>'
          });
        }
      });
    }

    // Load role details based on role id
    function loadRoleDetails() {
      var endPoint = '/roles/id/' + editRole + '/';
      $httpHelper.httpRequest('GET', endPoint, null, function(data) {
        try {
          if (data === null || data === undefined) {
            throw new Error('Server Error');
          } else {
            roleDetails = data[0];
            $scope.roleCode = roleDetails.role_code;
            $scope.roleName = roleDetails.role_name;
            $scope.roleDescription = roleDetails.role_description;
            if (roleDetails.active_date) {
              $scope.activeDate = $formatHelper.formatDate(roleDetails.active_date);
            }
            if (roleDetails.inactive_date) {
              $scope.inactiveDate = $formatHelper.formatDate(roleDetails.inactive_date);
            }
            rolePerms = roleDetails.role_permissions;
            for (var i = 0; i < rolePerms.length; i++) {
              if (rolePerms[i].active_date) {
                rolePerms[i].active_date = $formatHelper.formatDate(rolePerms[i].active_date);
              }
              if (rolePerms[i].inactive_date) {
                rolePerms[i].inactive_date = $formatHelper.formatDate(rolePerms[i].inactive_date);
              }
            }
            $scope.rolePerms = rolePerms;
            $timeout(function() {
              for (var i = 0; i < $scope.rolePerms.length; i++) {
                new FooPicker({
                  id: 'active' + $scope.rolePerms[i].permission_id,
                  dateFormat: user.date_format
                });
                new FooPicker({
                  id: 'inactive' + $scope.rolePerms[i].permission_id,
                  dateFormat: user.date_format
                });
              }
            }, 1000);
          }
        } catch (e) {
          $scope.notifications.push({
            status: 1,
            msg: e.message,
            details: '<pre>' + e.stack + '</pre>'
          });
        }
      });
    }

    // Check if the role name already exists or not
    $scope.checkRole = function() {
      $scope.focusCode = false;
      if ($scope.roleCode) {
        var endPoint = '/roles/validate/' + $scope.roleCode + '/';
        $httpHelper.httpRequest('GET', endPoint, null, function(data) {
          try {
            if (data === null || data === undefined) {
              throw new Error('Server Error');
            } else {
              if (data.status === 1) {
                $scope.status = data.status;
                $scope.msg = 'Role ' + data.msg;
                $scope.roleCode = '';
                $scope.notifications.push({
                  status: 1,
                  msg: $scope.msg
                });
              }
            }
          } catch (e) {
            $scope.notifications.push({
              status: 1,
              msg: e.message,
              details: '<pre>' + e.stack + '</pre>'
            });
          }
        });
      }
    };

    $scope.permissionSelected = function(event, permission) {
      event.stopPropagation();
      try {
        if (event.target.nodeName === 'INPUT') {
          if (event.target.checked) {
            permissionIds.push(permission.permission_id);
            $scope.checkedCount += 1;
          } else {
            var sIndex = permissionIds.indexOf(permission.permission_id);
            if (sIndex > -1) {
              permissionIds.splice(sIndex, 1);
            }
            $scope.checkedCount -= 1;
          }
        }
      } catch (e) {
        $scope.notifications.push({
          status: 1,
          msg: e.message,
          details: '<pre>' + e.stack + '</pre>'
        });
      }
    };

    // Add rows to permissions table
    $scope.addPermissions = function() {
      var length = rolePerms.length;
      for (var i = 99999 + length; i < 99999 + length + 5; i++) {
        var permission = {};
        permission.permission_id = i;
        permission.active_date = $formatHelper.formatDate($appHelper.today(-1));
        rolePerms.push(permission);
      }
      $timeout(function() {
        for (var i = 99999 + length; i < 99999 + length + 5; i++) {
          new FooPicker({
            id: 'active' + i,
            dateFormat: user.date_format
          });
          new FooPicker({
            id: 'inactive' + i,
            dateFormat: user.date_format
          });
        }
      }, 100);
      $scope.rolePerms = rolePerms;
      $timeout(function() {
        loadPermissions();
      }, 1000);
    };

    $scope.selectedrow = function(permission) {
      $scope.manageRole.showDialog = true;
      $scope.selectedRow = permission;
    };

    $scope.cancelModal = function() {
      $scope.selectedRow = '';
      $scope.manageRole.showDialog = false;
    };
    // Delete rows from permissions table
    $scope.deleteRow = function() {
      var permission = $scope.selectedRow;
      for (var i = 0; i < rolePerms.length; i++) {
        if (permission.permission_id === rolePerms[i].permission_id) {
          rolePerms.splice(i, 1);
          break;
        }
      }
      $scope.selectedRow = '';
      $scope.manageRole.showDialog = false;
    };

    function validation() {
      var count = 0;
      if (!$scope.roleCode) {
        $scope.focusCode = false;
        count = count + 1;
      }
      if (!$scope.roleName) {
        $scope.focusName = false;
        count = count + 1;
      }
      if (!$scope.roleDescription) {
        $scope.focusDesc = false;
        count = count + 1;
      }
      if (!$('#activeDate').val()) {
        $scope.focusActive = false;
        count = count + 1;
      }

      var flag = count === 0 ? true : false;
      return flag;
    }

    // This method is called to create a role
    $scope.createRole = function() {
      $scope.pageDim = true;
      var val = validation();
      if (val) {
        if ($scope.allowed) {
          $scope.pageDim = true;
          var roleObj = {};
          if (editRole) {
            roleObj.role_id = parseInt(editRole);
          }
          roleObj.role_code = $scope.roleCode;
          roleObj.role_description = $scope.roleDescription;
          roleObj.active_date = $formatHelper.parseDate($scope.activeDate);
          if ($scope.inactiveDate) {
            roleObj.inactive_date = $formatHelper.parseDate($scope.inactiveDate);
          } else {
            roleObj.inactive_date = '';
          }
          if (!editRole) {
            roleObj.created_date = $appHelper.today(0);
            roleObj.created_id = user.user_id;
          }
          roleObj.recent_update_date = $appHelper.today(0);
          var permissions = [];
          for (var i = 0; i < rolePerms.length; i++) {
            var permission = {};
            var tmp = rolePerms[i];
            if (tmp.permission_name) {
              if (tmp.role_id) {
                permission.permission_id = parseInt(tmp.permission_id);
              } else {
                permission.permission_id = parseInt(tmp.permission_name);
              }
              permission.active_date = tmp.active_date !== '' ? $formatHelper.parseDate(tmp.active_date) : '';
              permission.inactive_date = tmp.inactive_date !== '' ? $formatHelper.parseDate(tmp.inactive_date) : '';
              if (!tmp.role_id) {
                permission.created_date = $appHelper.today(0);
                permission.created_id = user.user_id;
              }
              permission.recent_update_date = $appHelper.today(0);
              permissions.push(permission);
            }
          }
          roleObj.role_permissions = permissions;
          var button, endPoint;
          if (editRole) {
            button = $('#update-role');
            endPoint = '/roles/update/';
          } else {
            button = $('#create-role');
            endPoint = '/roles/save/';
          }
          $httpHelper.httpRequest('POST', endPoint, roleObj, function(data) {
            try {
              if (data === null || data === undefined) {
                throw new Error('Server Error');
              } else {
                if (data.status === 0) {
                  $appHelper.role_status = data.status;
                  $appHelper.role_msg = data.msg;
                  $state.go('app.roles');
                } else {
                  $scope.pageDim = false;
                  $scope.status = data.status;
                  $scope.msg = data.msg;
                  $scope.notifications.push({
                    status: 1,
                    msg: data.msg
                  });
                }
              }
            } catch (e) {
              $scope.notifications.push({
                status: 1,
                msg: e.message,
                details: '<pre>' + e.stack + '</pre>'
              });
            }
          });
        } else {
          $scope.pageDim = false;
          $scope.msg = 'Please check your input';
          $scope.status = 1;
          $scope.notifications.push({
            status: 1,
            msg: 'Please check your input'
          });
        }
      } else {
        $scope.pageDim = false;
      }
    };

    $scope.cancel = function() {
      $state.go('app.roles');
    };

    $('.scroll-top').click(function() {
      $appHelper.scrollTop();
    });

    $scope.compareDates = function(permission) {
      var startDate, endDate, activeDate, inactiveDate, index;
      try {
        if (permission) {
          index = rolePerms.indexOf(permission);
          activeDate = $formatHelper.formatDate(permission.active_date);
          inactiveDate = $formatHelper.formatDate(permission.inactive_date);
        } else {
          if ($scope.activeDate) {
            activeDate = $formatHelper.formatDate($scope.activeDate);
            $scope.allowed = false;
          }
          if ($scope.inactiveDate) {
            inactiveDate = $formatHelper.formatDate($scope.inactiveDate);
            $scope.allowed = false;
          }
        }
        startDate = $formatHelper.dateInMillis($formatHelper.parseDate(activeDate));
        endDate = $formatHelper.dateInMillis($formatHelper.parseDate(inactiveDate));
        if (startDate === endDate) {
          $scope.allowed = true;
        } else {
          if (startDate > 0 && endDate > 0) {
            if (startDate <= endDate) {
              $scope.allowed = true;
            } else {
              $scope.allowed = false;
              $scope.msg = 'Inactive date is less than Active date';
              $scope.status = 1;
            }
          } else if ((!startDate && !endDate) || (startDate && !endDate)) {
            $scope.allowed = true;
          }
        }
        if ($scope.allowed) {
          if (permission) {
            rolePerms[index].active_date = activeDate;
            rolePerms[index].inactive_date = inactiveDate;
          } else {
            $scope.activeDate = activeDate;
            $scope.inactiveDate = inactiveDate;
          }
        } else {
          if (permission) {
            rolePerms[index].active_date = activeDate;
            rolePerms[index].inactive_date = null;
          } else {
            $scope.activeDate = activeDate;
            $scope.inactiveDate = null;
          }
        }
        $scope.rolePerms = rolePerms;
      } catch (e) {
        $scope.notifications.push({
          status: 1,
          msg: e.message,
          details: '<pre>' + e.stack + '</pre>'
        });
      }
    };
  }
})();
