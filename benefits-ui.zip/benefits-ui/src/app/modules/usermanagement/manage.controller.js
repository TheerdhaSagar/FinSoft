/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 17-10-2018
 */

(function() {
  'use strict';

  angular.module('scorpion')
    .controller('UserManagementController', UserManagementController);

  function UserManagementController($scope, $window, $location, $cacheHelper, $state) {

    // google analytics code
    $scope.$on('$viewContentLoaded', function() {
      $window.ga('send', 'pageview', { page: $location.url() });

      // Highlight the tab based on the current view
      $( '.user-navigation button' ).removeClass('success');
      switch ($state.current.name) {
        case 'app.manage.users':
          $( '.btn-users' ).addClass('btn--success');
          break;
        case 'app.manage.groups':
          $( '.btn-groups' ).addClass('btn--success');
          break;
        case 'app.manage.roles':
          $( '.btn-roles' ).addClass('btn--success');
          break;
        case 'app.manage.permissions':
          $( '.btn-permissions' ).addClass('btn--success');
          break;
      }
    });

    // Go to view i.e user / groups / roles / permissions
    $scope.loadView = function(view) {
      $( '.tabs__menu li' ).removeClass('tabs__menu__item--selected');
      switch (view) {
        case 'users':
          $( '#users' ).addClass('tabs__menu__item--selected');
          $state.go('app.manage.users');
          break;
        case 'groups':
          $( '#groups' ).addClass('tabs__menu__item--selected');
          $state.go('app.manage.groups');
          break;
        case 'roles':
          $( '#roles' ).addClass('tabs__menu__item--selected');
          $state.go('app.manage.roles');
          break;
        case 'permissions':
          $( '#permissions' ).addClass('tabs__menu__item--selected');
          $state.go('app.manage.permissions');
          break;
      }
    };
  }
})();
