/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 17-10-2018
 */

(function () {
  'use strict';

  angular.module('scorpion')
    .controller('CreatePermissionController', CreatePermissionController);

  function CreatePermissionController($scope, $window, $location, $cacheHelper, $state,
    $httpHelper, $formatHelper, $filter, $appHelper, $timeout) {

    // google analytics code
    $scope.$on('$viewContentLoaded', function () {
      $window.ga('send', 'pageview', {
        page: $location.url()
      });
      var permissionId = $appHelper.permission_id;
      $scope.pageDim = true;
      if (permissionId && $state.current.name === 'app.editPermission') {
        $scope.permissions = [];

        if (permissionId) {
          var endPoint = '/permission/id/' + permissionId + '/';
          $httpHelper.httpRequest('GET', endPoint, null, function (data) {
            try {
              if (data === null || data === undefined) {
                throw new Error('Server Error');
              } else {
                $scope.permission = data[0];
                if ($scope.permission.permission_type) {
                  callPermissionService($scope.permission.permission_type);
                  if ($scope.permission.reference_type) {
                    callRefTypeService($scope.permission.reference_type);
                  }
                }
              }
              $timeout(function () {
                $('.fd-suggestions').hide();
              }, 2000);
            } catch (e) {
              $scope.notifications.push({
                status: 1,
                msg: e.message,
                details: '<pre>' + e.stack + '</pre>'
              });
            }
          });
        }
      }

      var endPoint2 = '/permission/types/';

      $httpHelper.httpRequest('GET', endPoint2, null, function (data) {
        try {
          if (data === null || data === undefined) {
            throw new Error('Server Error');
          } else {
            $scope.pageDim = false;
            $scope.permissionTypes = data;
          }
        } catch (e) {
          $scope.notifications.push({
            status: 1,
            msg: e.message,
            details: '<pre>' + e.stack + '</pre>'
          });
        }
        $scope.pageDim = false;
      });
    });

    var user, org, value_change = false;

    $cacheHelper.getUser(function (data) {
      if (!data) {
        $state.go('login');
      } else {
        if (!$cacheHelper.user) {
          $cacheHelper.initialize(user);
        }
        user = data;
        if (!user.number_format) {
          user.number_format = '999,999.99';
        }
        org = $cacheHelper.getOrgId();
        if (!user.date_format) {
          user.date_format = 'dd-MMM-yyyy';
        }
      }
    });

    $scope.$watch(function () {
      return $scope.msg;
    }, function (newValue) {
      if (newValue) {
        $timeout(function () {
          $scope.msg = null;
          $scope.status = null;
        }, 5000);
      }
    });

    $scope.onTypeChange = function () {
      $scope.pageDim = true;
      if ($state.current.name === 'app.editPermission') {
        callPermissionService($scope.permission.permission_type);
      } else {
        callPermissionService($scope.permsnType);
      }
    };

    // Check if the role name already exists or not
    $scope.checkPermission = function () {
      $scope.focusCode = false;
      if ($scope.permissionCode) {
        var endPoint = '/permission/validate/' + $scope.permissionCode + '/';
        $httpHelper.httpRequest('GET', endPoint, null, function (data) {
          try {
            if (data === null || data === undefined) {
              throw new Error('Server Error');
            } else {
              if (data.status === 1) {
                $scope.status = data.status;
                $scope.msg = 'Permission code ' + data.msg;
                $scope.permissionCode = '';
                $scope.notifications.push({
                  status: 1,
                  msg: $scope.msg
                });
              }
            }
          } catch (e) {
            $scope.notifications.push({
              status: 1,
              msg: e.message,
              details: '<pre>' + e.stack + '</pre>'
            });
          }
        });
      }
    };


    $scope.cancel = function () {
      $state.go('app.permissions');
    };

    var callPermissionService = function (permsnType) {
      var endPoint = '/permission/types/' + permsnType + '/';
      $httpHelper.httpRequest('GET', endPoint, null, function (data) {
        try {
          if (data === null || data === undefined) {
            throw new Error('Server Error');
          } else {
            $scope.refTypes = data;
          }
        } catch (e) {
          $scope.notifications.push({
            status: 1,
            msg: e.message,
            details: '<pre>' + e.stack + '</pre>'
          });
        }
        $scope.pageDim = false;
      });
    };

    $scope.onRefTypeChange = function () {
      $scope.pageDim = true;
      $scope.refValue = '';
      $scope.refValues = '';
      $scope.referenceValue = '';
      if ($state.current.name === 'app.editPermission') {
        callRefTypeService($scope.permission.reference_type);
      } else {
        callRefTypeService($scope.refType);
      }
      $scope.pageDim = false;
    };

    var callRefTypeService = function (refType) {
      var endPoint, i;
      if (refType === 'VENDOR_ID') {
        endPoint = '/supplier/vendorlov/';
      } else {
        endPoint = '/permission/types/' + refType + '/';
      }
      $httpHelper.httpRequest('GET', endPoint, null, function (data) {
        try {
          if (data === null || data === undefined) {
            throw new Error('Server Error');
          } else {
            if (refType === 'VENDOR_ID') {
              var tmpData = [];
              for (i = 0; i < data.length; i++) {
                var obj = {};
                obj.key = data[i].vendor_id + '';
                obj.name = data[i].vendor_name;
                tmpData.push(obj);
              }
              $scope.refValues = tmpData;
            } else {
              $scope.refValues = data;
            }
          }
          if ($state.current.name === 'app.editPermission') {
            var refValue = $scope.permission.reference_value;
            for (i = 0; i < $scope.refValues.length; i++) {
              if ($scope.refValues[i].key === refValue) {
                $scope.referenceValue = $scope.refValues[i].name;
                $scope.refValue = $scope.refValues[i].key;
              }
            }
          }
        } catch (e) {
          $scope.notifications.push({
            status: 1,
            msg: e.message,
            details: '<pre>' + e.stack + '</pre>'
          });
        }
      });
    };

    $scope.changeKey = function () {
      $scope.refValue = $scope.referenceValue;
    };

    $scope.changeValue = function () {
      value_change = true;
    };

    $scope.refCheck = function (value) {
      if (value.length === 0) {
        value_change = false;
      }
    };

    $scope.close = function () {
      $scope.msg = null;
      $scope.status = null;
    };

    $scope.goToSummary = function () {
      $state.go('app.permissions');
    };

    var save = function (permission, satus) {
      var endUrl = '/permission/' + satus + '/';
      $httpHelper.httpRequest('POST', endUrl, permission, function (data) {
        try {
          if (data === null || data === undefined) {
            throw new Error('Server Error');
          } else {
            if (data && data.msg) {
              $scope.status = data.status;
              if (data.status === 0) {
                $appHelper.permission_msg = data.msg;
                $appHelper.permission_status = data.status;
                $state.go('app.permissions');
              } else {
                $scope.pageDim = false;
                $scope.msg = 'Unexpected Error while creating the Permission';
                $scope.notifications.push({
                  status: 1,
                  msg: $scope.msg
                });
              }
            }
          }
        } catch (e) {
          $scope.pageDim = false;
          $scope.notifications.push({
            status: 1,
            msg: e.message,
            details: '<pre>' + e.stack + '</pre>'
          });
        }
      });
    };

    $scope.savePermission = function () {
      $scope.pageDim = true;
      var user;
      $cacheHelper.getUser(function (data) {
        user = data;
      });
      if ($state.current.name === 'app.editPermission') {
        var val = validation();
        if (val) {
          var permission = {};
          permission.permission_description = $scope.permission.permission_description;
          permission.reference_value = $scope.refValue;
          permission.reference_type = $scope.permission.reference_type;
          permission.permission_type = $scope.permission.permission_type;
          permission.permission_name = $scope.permission.permission_name;
          permission.permission_code = $scope.permission.permission_code;
          permission.CREATED_USER_ID = user.user_id;
          permission.RECENT_UPDATED_USER_ID = user.user_id;
          permission.permission_id = $scope.permission.permission_id;
          save(permission, 'update');
        }
      } else {
        var create_val = create_validation();
        if (create_val) {
          if ($scope.refValue !== undefined && value_change !== false) {
            var permissionNew = {};
            permissionNew.permission_description = $scope.permissionDescription;
            permissionNew.reference_value = $scope.refValue;
            permissionNew.reference_type = $scope.refType;
            permissionNew.permission_type = $scope.permsnType;
            permissionNew.permission_name = $scope.permissionName;
            permissionNew.permission_code = $scope.permissionCode;
            permissionNew.CREATED_USER_ID = user.user_id;
            permissionNew.RECENT_UPDATED_USER_ID = user.user_id;

            var endUrlNew = '/permission/validate/' + permissionNew.permission_code + '/';
            $httpHelper.httpRequest('GET', endUrlNew, null, function (data) {
              try {
                if (data === null || data === undefined) {
                  throw new Error('Server Error');
                } else {
                  if (data && data.msg) {
                    if (data.status === 0) {
                      save(permissionNew, 'save');
                    } else {
                      $scope.msg = 'permission' + data.msg;
                      $scope.notifications.push({
                        status: 1,
                        msg: data.msg
                      });
                    }
                  }
                }
              } catch (e) {
                $scope.notifications.push({
                  status: 1,
                  msg: e.message,
                  details: '<pre>' + e.stack + '</pre>'
                });
              }
            });
          } else {
            $scope.msg = "Please choose reference value from suggestions";
            $scope.status = 1;
          }

        }
      }
    };

    var validation = function () {
      var count = 0;
      if (!$scope.permission.permission_description) {
        $scope.focusDesc = false;
        count = count + 1;
      }
      if (!$scope.refValue) {
        $scope.focusVal = false;
        count = count + 1;
      }
      if (!$scope.permission.reference_type) {
        $scope.focusRef = false;
        count = count + 1;
      }
      if (!$scope.permission.permission_type) {
        $scope.focusType = false;
        count = count + 1;
      }
      if (!$scope.permission.permission_name) {
        $scope.focusName = false;
        count = count + 1;
      }
      if (!$scope.permission.permission_code) {
        $scope.focusCode = false;
        count = count + 1;
      }

      var flag = count === 0 ? true : false;
      return flag;
    };

    var create_validation = function () {
      var count = 0;
      if (!$scope.permissionDescription) {
        $scope.focusDesc = false;
        count = count + 1;
      }
      if (!$scope.refValue) {
        $scope.focusVal = false;
        count = count + 1;
      }
      if (!$scope.refType) {
        $scope.focusRef = false;
        count = count + 1;
      }
      if (!$scope.permsnType) {
        $scope.focusType = false;
        count = count + 1;
      }
      if (!$scope.permissionName) {
        $scope.focusName = false;
        count = count + 1;
      }
      if (!$scope.permissionCode) {
        $scope.focusCode = false;
        count = count + 1;
      }

      var flag = count === 0 ? true : false;
      return flag;
    };

    // var allFieldsFilled = function(status) {
    //   var flag = false;
    //   if (status === 'update') {
    //     if ($scope.permission.permission_description && $scope.refValue &&
    //         $scope.permission.reference_type && $scope.permission.permission_type &&
    //         $scope.permission.permission_name && $scope.permission.permission_code &&
    //         $scope.permission.permission_id) {
    //         flag = true;
    //       }
    //     } else {
    //       if ($scope.permissionDescription && $scope.refValue && $scope.refType &&
    //         $scope.permsnType && $scope.permissionName && $scope.permissionCode) {
    //           flag = true;
    //         }
    //       }
    //       return flag;
    // };

  }
})();
