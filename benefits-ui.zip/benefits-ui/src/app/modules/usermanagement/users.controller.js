/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 17-10-2018
 */

(function () {
  'use strict';

  angular.module('scorpion')
    .controller('UsersController', UsersController);

  function UsersController($scope, $window, $location, $cacheHelper, $state,
    $httpHelper, $formatHelper, $filter, $appHelper, $rootScope, $compile) {


    var user, allUsers, pageSize = $appHelper.pageSize;
    $scope.currentPage = 1;
    $scope.user = {
      showSuccess: false,
      msg: ''
    };
    $cacheHelper.getUser(function (data) {
      if (!data) {
        $state.go('login');
      } else {
        if ($appHelper.userSuccess) {
          $scope.user.showSuccess = true;
          $scope.user.msg = "User " + $appHelper.userSuccess.username + " " + $appHelper.userSuccess.msg + " successfully";
          $appHelper.userSuccess = null;
          $scope.notifications.push({ status: 0, msg: $scope.user.msg });
        }
        if (!$cacheHelper.user) {
          $cacheHelper.initialize(data);
        }
        user = data;
        $scope.toggleFilter = $appHelper.toggleFilter();

        $scope.$watch(function () {
          return $rootScope.orgId;
        }, function (newValue, oldValue) {
          if (newValue !== oldValue) {
            loadUsers();
          }
        });
        loadUsers();
      }
    });

   

    // Table sorting
    $scope.predicate = 'user_id';
    $scope.desc = true;

    $scope.sort = function (key) {
      if ($scope.predicate === key) {
        $scope.desc = !$scope.desc;
      } else {
        $scope.predicate = key;
      }
    };

    function loadUsers() {
      $scope.showSpinner = true;
      var endPoint = '/users/';
      $httpHelper.httpRequest('GET', endPoint, null, function (data) {
        try {
          if (data === null || data === undefined) {
            throw new Error('Server Error');
          } else {
            var users = data;
            for (var i = 0; i < users.length; i++) {
              users[i].active_date_millis = $formatHelper.dateInMillis(users[i].active_date);
              users[i].f_active_date = $formatHelper.formatDate(users[i].active_date);
              if (users[i].inactive_date) {
                users[i].inactive_date_millis = $formatHelper.dateInMillis(users[i].inactive_date);
                users[i].f_inactive_date = $formatHelper.formatDate(users[i].inactive_date);
              }
            }
            allUsers = $filter('orderBy')(users, $scope.predicate, $scope.desc);
            $scope.users = allUsers.slice($scope.currentPage - 1, pageSize);
            $scope.showSpinner = false;
          }
        } catch (e) {
          $scope.pageDim = false;
          $scope.notifications.push({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
        }
      });
    }

    // Load user details when expanded
    $scope.loadDetails = function (row) {
      var endPoint;

      try {
        endPoint = '/users/details/' + row.user_id + '/';

        $('.child-data').remove();
        $('.master-table').find('.child-row').remove();

        if ($('#' + row.user_id).hasClass('expanded')) {
          $('#' + row.user_id).removeClass('expanded');
          $('#' + row.user_id).find('.expand-icon').removeClass('icon-circle-minus');
          $('#' + row.user_id).find('.expand-icon').addClass('icon-circle-plus');
          $scope.isExpanded = false;
        } else {
          $('tr').removeClass('expanded');
          $('tr').find('.expand-icon').removeClass('icon-circle-minus');
          $('tr').find('.expand-icon').addClass('icon-circle-plus');
          var childRow = $('<tr class="child-row"><td colspan="7"></td></tr>');
          childRow.find('td').append($compile('<div class="sub-spinner"><spinner></spinner></div>')($scope));
          childRow.insertAfter($('#' + row.user_id));
          $('#' + row.user_id).addClass('expanded');
          $('#' + row.user_id).find('.expand-icon').removeClass('icon-circle-plus');
          $('#' + row.user_id).find('.expand-icon').addClass('icon-circle-minus');

          $httpHelper.httpRequest('GET', endPoint, null, function (data) {
            try {
              if (data === null || data === undefined) {
                throw new Error('Server Error');
              } else {
                if ($('#' + row.user_id).hasClass('expanded')) {
                  var roles = data.roles,
                    i;
                  for (i = 0; i < roles.length; i++) {
                    if (roles[i].active_date) {
                      roles[i].f_active_date = $formatHelper.formatDate(roles[i].active_date);
                    }
                    if (roles[i].inactive_date) {
                      roles[i].f_inactive_date = $formatHelper.formatDate(roles[i].inactive_date);
                    }
                    roles[i].name = roles[i].role_name;
                  }

                  $scope.childOne = roles;
                  $scope.childOneLabel = 'Roles';
                  childRow.find('spinner').remove();
                  childRow.find('td').append($compile('<userdetails></userdetails>')($scope));
                }
              }
            } catch (e) {
              $scope.notifications.push({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
            }
          });
        }
      } catch (e) {
        $scope.notifications.push({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    };

    $scope.manageUser = function (which, user) {
      if (which === 'edit') {
        $appHelper.editUser = user.user_id;
      } else if (which === 'create') {
        $appHelper.editUser = null;
      }
      $state.go('app.manageuser');
    };


    $scope.filterData = function () {
      var search = $scope.searchText;
      var tmp_data;
      if (search) {
        tmp_data = $filter('filter')(allUsers, search, $scope.predicate);
        $scope.currentPage = 1;
        $scope.users = tmp_data.slice($scope.currentPage - 1, pageSize);
      } else {
        $scope.currentPage = 1;
        $scope.users = allUsers.slice($scope.currentPage - 1, pageSize);
      }
    };
    // Load more creidtnotes when the page is scrolled down
    $scope.loadMore = function () {
      try {
        var page = $scope.currentPage + 1;
        var startIndex = (page - 1) * pageSize;
        var endIndex = page * pageSize;
        $scope.currentPage = page;
        if (allUsers) {
          var tempData = allUsers.slice(startIndex, endIndex);
          for (var i = 0; i < tempData.length; i++) {
            $scope.users.push(tempData[i]);
          }
        }
      } catch (e) {
        $scope.notifications.push({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    };

    // Exports the table data into spreadsheet
    $scope.export = function () {
      $scope.toggleFilter();
      var data = $filter('orderBy')(allUsers, $scope.predicate, $scope.desc);
      var tableData = {};
      var tmpReports = [];
      try {
        for (var i = 0; i < data.length; i++) {
          var tmpReport = {};
          tmpReport['User Name'] = {
            data: data[i].user_name ? data[i].user_name : ''
          };
          tmpReport['Known As'] = {
            data: data[i].user_description ? data[i].user_description : ''
          };
          tmpReport['Email Address'] = {
            data: data[i].email_address ? data[i].email_address : ''
          };
          tmpReport['Active Date'] = {
            data: data[i].f_active_date ? data[i].f_active_date : ''
          };
          tmpReport['In Active Date'] = {
            data: data[i].f_inactive_date ? data[i].f_inactive_date : ''
          };
          tmpReports.push(tmpReport);
        }
        tableData.data = tmpReports;
        $appHelper.tableToExcel('Users', tableData, 'export-data');
      } catch (e) {
        $scope.notifications.push({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    };
  }
})();
