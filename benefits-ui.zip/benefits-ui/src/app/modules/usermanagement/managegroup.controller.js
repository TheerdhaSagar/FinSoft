/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 17-10-2018
 */

(function() {
  'use strict';

  angular.module('scorpion')
    .controller('ManageGroupController', ManageGroupController);

  function ManageGroupController($scope, $window, $location, $cacheHelper, $state,
    $httpHelper, $formatHelper, $filter, $appHelper, $rootScope, $sce, $timeout) {

    // google analytics code
    $scope.$on('$viewContentLoaded', function() {
      $window.ga('send', 'pageview', {
        page: $location.url()
      });
    });

    var roleIds = [],
      userIds = [],
      groupUsers = [],
      groupRoles = [],
      user, editGroup, groupDetails;
    $scope.userCheckedCount = 0;
    $scope.roleCheckedCount = 0;
    $scope.allowed = false;
    $scope.disableFields = false;

    //user
    $cacheHelper.getUser(function(data) {
      if (!data) {
        $state.go('login');
      } else {
        if (!$cacheHelper.user) {
          $cacheHelper.initialize(user);
        }
        user = data;
        if (!user.number_format) {
          user.number_format = '999,999.99';
        }
        if (!user.date_format) {
          user.date_format = 'dd-MMM-yyyy';
        }
        if ($appHelper.group_id) {
          $scope.type = 'Group Details';
          editGroup = $appHelper.group_id;
          $appHelper.group_id = null;
          $scope.disableFields = true;
          loadGroupDetails();
        } else {
          $scope.type = 'Create Group';
          $timeout(function() {
            for (var i = 99999; i < 100004; i++) {
              new FooPicker({
                id: 'useractive' + i,
                dateFormat: user.date_format
              });
              new FooPicker({
                id: 'userinactive' + i,
                dateFormat: user.date_format
              });
              new FooPicker({
                id: 'roleactive' + i,
                dateFormat: user.date_format
              });
              new FooPicker({
                id: 'roleinactive' + i,
                dateFormat: user.date_format
              });
            }
          }, 100);
          for (var i = 99999; i < 100004; i++) {
            var gUser = {},
              gRole = {};

            gUser.user_id = i;
            gUser.active_date = $formatHelper.formatDate($appHelper.today(-1));
            gRole.role_id = i;
            gRole.active_date = $formatHelper.formatDate($appHelper.today(-1));

            groupUsers.push(gUser);
            groupRoles.push(gRole);
          }
          $scope.groupUsers = groupUsers;
          $scope.groupRoles = groupRoles;
        }
        $timeout(function() {
          if (editGroup) {
            $scope.allowed = true;
          }
        }, 1000);
        loadUsers();
      }
    });

    // Load all users
    function loadUsers() {
      var endPoint = '/users/';
      $httpHelper.httpRequest('GET', endPoint, null, function(data) {
        try {
          if (data === null || data === undefined) {
            throw new Error('Server Error');
          } else {
            $scope.users = data;
            loadRoles();
          }
        } catch (e) {
          $scope.notifications.push({
            status: 1,
            msg: e.message,
            details: '<pre>' + e.stack + '</pre>'
          });
        }
      });
    }

    // Load all roles
    function loadRoles() {
      var endPoint = '/roles/';
      $httpHelper.httpRequest('GET', endPoint, null, function(data) {
        try {
          if (data === null || data === undefined) {
            throw new Error('Server Error');
          } else {
            $scope.roles = data;
          }
        } catch (e) {
          $scope.notifications.push({
            status: 1,
            msg: e.message,
            details: '<pre>' + e.stack + '</pre>'
          });
        }
      });
    }

    // Load group details based on group id
    function loadGroupDetails() {
      var endPoint = '/groups/id/' + editGroup + '/';
      $httpHelper.httpRequest('GET', endPoint, null, function(data) {
        try {
          if (data === null || data === undefined) {
            throw new Error('Server Error');
          } else {
            groupDetails = data.group_details[0];
            $scope.groupCode = groupDetails.group_code;
            $scope.groupName = groupDetails.group_name;
            $scope.groupDescription = groupDetails.group_description;
            groupUsers = data.users;
            groupRoles = data.roles;
            var i;
            for (i = 0; i < groupUsers.length; i++) {
              if (groupUsers[i].active_date) {
                groupUsers[i].active_date = $formatHelper.formatDate(groupUsers[i].active_date);
              }
              if (groupUsers[i].inactive_date) {
                groupUsers[i].inactive_date = $formatHelper.formatDate(groupUsers[i].inactive_date);
              }
            }
            for (i = 0; i < groupRoles.length; i++) {
              if (groupRoles[i].active_date) {
                groupRoles[i].active_date = $formatHelper.formatDate(groupRoles[i].active_date);
              }
              if (groupRoles[i].inactive_date) {
                groupRoles[i].inactive_date = $formatHelper.formatDate(groupRoles[i].inactive_date);
              }
            }
            $scope.groupUsers = groupUsers;
            $scope.groupRoles = groupRoles;
            $timeout(function() {
              for (var i = 0; i < $scope.groupUsers.length; i++) {
                new FooPicker({
                  id: 'useractive' + $scope.groupUsers[i].user_id,
                  dateFormat: user.date_format
                });
                new FooPicker({
                  id: 'userinactive' + $scope.groupUsers[i].user_id,
                  dateFormat: user.date_format
                });
              }
            }, 1000);
            $timeout(function() {
              for (var i = 0; i < $scope.groupRoles.length; i++) {
                new FooPicker({
                  id: 'roleactive' + $scope.groupRoles[i].role_id,
                  dateFormat: user.date_format
                });
                new FooPicker({
                  id: 'roleinactive' + $scope.groupRoles[i].role_id,
                  dateFormat: user.date_format
                });
              }
            }, 1000);
          }
        } catch (e) {
          $scope.notifications.push({
            status: 1,
            msg: e.message,
            details: '<pre>' + e.stack + '</pre>'
          });
        }
      });
    }

    // Check if the group name already exists
    $scope.checkGroup = function() {
      $scope.focusCode = false;
      if ($scope.groupCode) {
        var endPoint = '/groups/validate/' + $scope.groupCode + '/';
        $httpHelper.httpRequest('GET', endPoint, null, function(data) {
          try {
            if (data === null || data === undefined) {
              throw new Error('Server Error');
            } else {
              if (data.status === 1) {
                $scope.msg = data.msg;
              }
            }
          } catch (e) {
            $scope.notifications.push({
              status: 1,
              msg: e.message,
              details: '<pre>' + e.stack + '</pre>'
            });
          }
        });
      }
    };

    $scope.userSelected = function(event, user) {
      event.stopPropagation();
      try {
        if (event.target.nodeName === 'INPUT') {
          if (event.target.checked) {
            userIds.push(user.user_id);
            $scope.userCheckedCount += 1;
          } else {
            var sIndex = userIds.indexOf(user.user_id);
            if (sIndex > -1) {
              userIds.splice(sIndex, 1);
            }
            $scope.userCheckedCount -= 1;
          }
        }
      } catch (e) {
        $scope.notifications.push({
          status: 1,
          msg: e.message,
          details: '<pre>' + e.stack + '</pre>'
        });
      }
    };

    // Add empty rows to roles table
    $scope.addUsers = function() {
      var length = groupUsers.length;
      for (var i = 99999 + length; i < 99999 + length + 5; i++) {
        var d_user = {};
        d_user.user_id = i;
        d_user.active_date = $formatHelper.formatDate($appHelper.today(-1));
        groupUsers.push(d_user);
      }
      $timeout(function() {
        for (var i = 99999 + length; i < 99999 + length + 5; i++) {
          new FooPicker({
            id: 'useractive' + i,
            dateFormat: user.date_format
          });
          new FooPicker({
            id: 'userinactive' + i,
            dateFormat: user.date_format
          });
        }
      }, 100);
      $scope.groupUsers = groupUsers;
      $timeout(function() {
        loadUsers();
      }, 1000);
    };

    // Add empty rows to roles table
    $scope.addRoles = function() {
      var length = groupRoles.length;
      for (var i = 99999 + length; i < 99999 + length + 5; i++) {
        var role = {};
        role.role_id = i;
        role.active_date = $formatHelper.formatDate($appHelper.today(-1));
        groupRoles.push(role);
      }
      $timeout(function() {
        for (var i = 99999 + length; i < 99999 + length + 5; i++) {
          new FooPicker({
            id: 'roleactive' + i,
            dateFormat: user.date_format
          });
          new FooPicker({
            id: 'roleinactive' + i,
            dateFormat: user.date_format
          });
        }
      }, 100);
      $scope.groupRoles = groupRoles;
      $timeout(function() {
        loadRoles();
      }, 1000);
    };


    // Delete rows from users table
    $scope.deleteUsers = function(user) {
      for (var i = 0; i < groupUsers.length; i++) {
        if (user.user_id === groupUsers[i].user_id) {
          groupUsers.splice(i, 1);
          break;
        }
      }
    };

    $scope.roleSelected = function(event, role) {
      event.stopPropagation();
      try {
        if (event.target.nodeName === 'INPUT') {
          if (event.target.checked) {
            roleIds.push(role.role_id);
            $scope.roleCheckedCount += 1;
          } else {
            var sIndex = roleIds.indexOf(role.role_id);
            if (sIndex > -1) {
              roleIds.splice(sIndex, 1);
            }
            $scope.roleCheckedCount -= 1;
          }
        }
      } catch (e) {
        $scope.notifications.push({
          status: 1,
          msg: e.message,
          details: '<pre>' + e.stack + '</pre>'
        });
      }
    };

    $scope.cancel = function() {
      $state.go('app.groups');
    };

    // Delete rows from roles table
    $scope.deleteRoles = function(role) {
      for (var i = 0; i < groupRoles.length; i++) {
        if (role.role_id === groupRoles[i].role_id) {
          groupRoles.splice(i, 1);
          break;
        }
      }
    };

    function validation() {
      var count = 0;
      if (!$scope.groupCode) {
        $scope.focusCode = false;
        count = count + 1;
      }
      if (!$scope.groupName) {
        $scope.focusName = false;
        count = count + 1;
      }
      if (!$scope.groupDescription) {
        $scope.focusDesc = false;
        count = count + 1;
      }
      var flag = count === 0 ? true : false;
      return flag;
    }

    // This method is called to create a group
    $scope.createGroup = function() {
      var val = validation();
      if (val) {
        if ($scope.allowed) {
          $scope.pageDim = true;
          var groupObj = {};
          if (editGroup) {
            groupObj.group_id = parseInt(editGroup);
          }
          groupObj.group_code = $scope.groupCode;
          groupObj.group_name = $scope.groupName;
          groupObj.group_description = $scope.groupDescription;
          if (!editGroup) {
            groupObj.create_date = $appHelper.today(0);
            groupObj.created_user_id = user.user_id;
          }
          groupObj.recent_update_date = $appHelper.today(0);
          groupObj.recent_updated_user_id = user.user_id;
          var users = [],
            roles = [],
            i, tmp;
          for (i = 0; i < groupUsers.length; i++) {
            var groupUser = {};
            tmp = groupUsers[i];
            if (tmp.user_name) {
              if (tmp.group_id) {
                groupUser.user_id = parseInt(tmp.user_id);
              } else {
                groupUser.user_id = parseInt(tmp.user_name);
              }
              groupUser.active_date = tmp.active_date !== '' ? $formatHelper.parseDate(tmp.active_date) : '';
              groupUser.inactive_date = tmp.inactive_date !== '' ? $formatHelper.parseDate(tmp.inactive_date) : '';
              if (!tmp.group_id) {
                groupUser.create_date = $appHelper.today(0);
                groupUser.created_user_id = user.user_id;
              }
              groupUser.recent_update_date = $appHelper.today(0);
              groupUser.recent_updated_user_id = user.user_id;
              users.push(groupUser);
            }
          }
          for (i = 0; i < groupRoles.length; i++) {
            var groupRole = {};
            tmp = groupRoles[i];
            if (tmp.role_name) {
              if (tmp.group_id) {
                groupRole.role_id = parseInt(tmp.role_id);
              } else {
                groupRole.role_id = parseInt(tmp.role_name);
              }
              groupRole.active_date = tmp.active_date !== '' ? $formatHelper.parseDate(tmp.active_date) : '';
              groupRole.inactive_date = tmp.inactive_date !== '' ? $formatHelper.parseDate(tmp.inactive_date) : '';
              if (!tmp.group_id) {
                groupRole.create_date = $appHelper.today(0);
                groupRole.created_user_id = user.user_id;
              }
              groupRole.recent_update_date = $appHelper.today(0);
              groupRole.recent_updated_user_id = user.user_id;
              roles.push(groupRole);
            }
          }
          groupObj.users = users;
          groupObj.roles = roles;
          var button, method;
          if (editGroup) {
            button = $('#update-group');
            method = 'PUT';
          } else {
            method = 'POST';
            button = $('#create-group');
          }
          var endPoint = '/groups/';
          $httpHelper.httpRequest(method, endPoint, groupObj, function(data) {
            try {
              if (data === null || data === undefined) {
                throw new Error('Server Error');
              } else {
                if (data.status === 0) {
                  $appHelper.group_status = data.status;
                  $appHelper.group_msg = data.msg;
                  $state.go('app.groups');
                } else {
                  $scope.pageDim = false;
                  $scope.msg = data.msg;
                  $scope.status = 1;
                  $scope.notifications.push({
                    status: 1,
                    msg: data.msg,
                  });
                }
              }
            } catch (e) {
              $scope.notifications.push({
                status: 1,
                msg: e.message,
                details: '<pre>' + e.stack + '</pre>'
              });
            }
          });
        }
      }
    };

    $scope.close = function() {
      $scope.msg = null;
      $scope.status = null;
    };

    // This method is used to check if all mandatory
    // fields are filled
    $scope.onMandatoryChange = function() {
      var flag = true;
      var mandatory = document.getElementsByClassName('mandatory');
      if (mandatory) {
        for (var i = 0; i < mandatory.length; i++) {
          if (!mandatory[i].value) {
            flag = false;
            break;
          }
        }
      }
      if (flag) {
        $('#create-group').removeAttr('disabled');
        $scope.allowed = true;
      } else {
        $('#create-group').attr('disabled', 'disabled');
        $scope.allowed = false;
      }
    };

    $('.scroll-top').click(function() {
      $appHelper.scrollTop();
    });

    $scope.$watch(function() {
      return $scope.msg;
    }, function(newValue) {
      if (newValue) {
        $timeout(function() {
          $scope.msg = null;
          $scope.status = null;
        }, 5000);
      }
    });

    $scope.compareDates = function(obj, which) {
      var startDate, endDate, activeDate, inactiveDate, index;
      try {
        if (obj) {
          if (which === 'users') {
            index = groupUsers.indexOf(obj);
          } else {
            index = groupRoles.indexOf(obj);
          }
          if (obj.active_date) {
            if (which === 'users') {
              activeDate = $formatHelper.formatDate(obj.active_date);
            } else {
              activeDate = $formatHelper.formatDate(obj.active_date);
            }
          }
          if (obj.inactive_date) {
            if (which === 'users') {
              inactiveDate = $formatHelper.formatDate(obj.inactive_date);
            } else {
              inactiveDate = $formatHelper.formatDate(obj.inactive_date);
            }
          }
        } else {
          if ($scope.activeDate) {
            activeDate = $formatHelper.formatDate($scope.activeDate);
          }
          if ($scope.inactiveDate) {
            inactiveDate = $formatHelper.formatDate($scope.inactiveDate);
          }
        }

        startDate = $formatHelper.dateInMillis($formatHelper.parseDate(activeDate));
        endDate = $formatHelper.dateInMillis($formatHelper.parseDate(inactiveDate));

        if (activeDate === inactiveDate) {
          $scope.allowed = true;
        } else {
          if (startDate > 0 && endDate > 0) {
            if (startDate <= endDate) {
              $scope.allowed = true;
            } else {
              $scope.allowed = false;
              $scope.msg = 'Active date should be less then Inactive date';
              $scope.status = 1;
            }
          } else if ((!startDate && !endDate) || (startDate && !endDate)) {
            $scope.allowed = true;
          }
        }

        if ($scope.allowed) {
          if (obj) {
            if (which === 'users') {
              groupUsers[index].active_date = activeDate;
              groupUsers[index].inactive_date = inactiveDate;
            } else {
              groupRoles[index].active_date = activeDate;
              groupRoles[index].inactive_date = inactiveDate;
            }
          } else {
            $scope.activeDate = activeDate;
            $scope.inactiveDate = inactiveDate;
          }
        } else {
          if (obj) {
            if (which === 'users') {
              groupUsers[index].active_date = activeDate;
              groupUsers[index].inactive_date = null;
              $scope.msg = 'Active date should be less then Inactive date';
              $scope.status = 1;
            } else {
              groupRoles[index].active_date = activeDate;
              groupRoles[index].inactive_date = null;
              $scope.msg = 'Active date should be less then Inactive date';
              $scope.status = 1;
            }
          } else {
            $scope.activeDate = activeDate;
            $scope.inactiveDate = null;
          }
        }
        $scope.groupUsers = groupUsers;
        $scope.groupRoles = groupRoles;
      } catch (e) {
        $scope.notifications.push({
          status: 1,
          msg: e.message,
          details: '<pre>' + e.stack + '</pre>'
        });
      }
    };
  }
})();
