/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 17-10-2018
 */

(function() {
  'use strict';

  angular.module('scorpion')
    .directive('groupdetails', GroupDetails);

  // Directive used to create dynamic child tables
  function GroupDetails() {
    return {
      restrict: 'E',
      transclude: true,
      templateUrl: 'app/modules/usermanagement/groupdetails.html'
    };
  }
})();
