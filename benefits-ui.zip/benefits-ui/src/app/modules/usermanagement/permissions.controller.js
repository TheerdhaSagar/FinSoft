/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 17-10-2018
 */

(function() {
  'use strict';

  angular.module('scorpion')
    .controller('PermissionsController', PermissionsController);

  function PermissionsController($scope, $window, $location, $cacheHelper, $state,
    $httpHelper, $formatHelper, $filter, $appHelper, $rootScope, $timeout) {

    var user;
    $cacheHelper.getUser(function(data) {
      if (!data) {
        $state.go('login');
      } else {
        if (!$cacheHelper.user) {
          $cacheHelper.initialize(data);
        }
        user = data;
        if ($appHelper.permission_msg) {
          $scope.msg = $appHelper.permission_msg;
          $scope.status = $appHelper.permission_status;
          $appHelper.permission_msg = null;
          $appHelper.permission_status = null;
          $scope.notifications.push({
            status: 0,
            msg: $scope.msg
          });
        }
        loadPermissions();
      }
    });

    $scope.$watch(function() {
      return $scope.msg;
    }, function(newValue) {
      if (newValue) {
        $timeout(function() {
          $scope.msg = null;
          $scope.status = null;
        }, 5000);
      }
    });

    $scope.close = function() {
      $scope.msg = null;
      $scope.status = null;
    };

    $scope.toggleFilter = $appHelper.toggleFilter();

    // Table sorting
    $scope.predicate = 'f_create_date';
    $scope.desc = true;

    $scope.sort = function(key) {
      if ($scope.predicate === key) {
        $scope.desc = !$scope.desc;
      } else {
        $scope.predicate = key;
      }
    };

    function loadPermissions() {
      $scope.showSpinner = true;
      var endPoint = '/permission/';
      $httpHelper.httpRequest('GET', endPoint, null, function(data) {
        try {
          if (data === null || data === undefined) {
            throw new Error('Server Error');
          } else {
            for (var i = 0; i < data.length; i++) {
              data[i].f_create_date = $formatHelper.dateInMillis(data[i].created_date);
            }
            $scope.permissions = data;
            $scope.showSpinner = false;
          }
        } catch (e) {
          $scope.notifications.push({
            status: 1,
            msg: e.message,
            details: '<pre>' + e.stack + '</pre>'
          });
        }
      });
    }

    $scope.permissionDetails = function(permission_id) {
      $appHelper.permission_id = permission_id;
      $state.go('app.editPermission');
    };

    $scope.cretaePermission = function() {
      $state.go('app.createPermission');
    };

    $('.scroll-top').click(function() {
      $appHelper.scrollTop();
    });
    
    // Exports the table data into spreadsheet
    $scope.export = function() {
      $scope.toggleFilter();
      var data = $filter('orderBy')($scope.permissions, $scope.predicate, $scope.desc);
      var tableData = {};
      var tmpReports = [];
      try {
        for (var i = 0; i < data.length; i++) {
          var tmpReport = {};
          tmpReport.Code = {
            data: data[i].permission_code ? data[i].permission_code : ''
          };
          tmpReport.Name = {
            data: data[i].permission_name ? data[i].permission_name : ''
          };
          tmpReport.Description = {
            data: data[i].permission_description ? data[i].permission_description : ''
          };
          tmpReport.ActiveDate = {
            data: data[i].active_date ? data[i].active_date : ''
          };          
          tmpReports.push(tmpReport);
        }
        tableData.data = tmpReports;
        $appHelper.tableToExcel('Permissions', tableData, 'export-data');
      } catch (e) {
        $scope.notifications.push({
          status: 1,
          msg: e.message,
          details: '<pre>' + e.stack + '</pre>'
        });
      }
    };
  }
})();
