/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 17-10-2018
 */
(function () {
  'use strict';
  angular.module('scorpion')
    .controller('ManageUserController', ManageUserController);

  function ManageUserController($scope, $window, $location, $cacheHelper, $appHelper, $formatHelper, $timeout,
    $state, $httpHelper, $rootScope) {


    var user, userDetails, editUser = false,
      deletedRoles = [],
      allRoles = [], _this = this;
    $scope.notvalidCC = false;
    $scope.notvalidBCC = false;
    $scope.pageDim = false;
    $scope.disableFields = false;
    $scope.userRoles = [];
    $scope.manageUser = {
      userExists: false,
      msg: '',
      showError: false,
      showSuccess: false,
      password: '',
      rePassword: '',
      generatePwd: true,
      debugFlag: false,
      showDialog: false,
      phoneErr: false,
      userMsg: '',
      passMsg: '',
      rePassMsg: ''
    };

    $scope.date_format = 'DD-MON-YYYY';

    //regular exp for phone number
    var regX = /^[0-9]*$/gm;

    $cacheHelper.getUser(function (data) {
      if (!data) {
        $state.go('login');
      } else {
        user = data;
        if (!$cacheHelper.user) {
          $cacheHelper.initialize(user);
        }

        loadRoles();
        loadTeams();
        if ($appHelper.editUser) {
          editUser = $appHelper.editUser;
          $appHelper.editUser = null;
          $scope.disableFields = true;
          $scope.pageDim = true;
          loadUserDetails();

        }

        new FooPicker({
          id: 'activeDateCal',
          dateFormat: user.date_format
        });

        new FooPicker({
          id: 'inactiveDateCal',
          dateFormat: user.date_format
        });

        $scope.date_format = user.date_format;
        for (var i = 99999; i < 100004; i++) {
          var role = {};
          role.roleId = i;
          role.active_date = $formatHelper.formatDate($appHelper.today(-1));
          $scope.userRoles.push(role);
        }

        $timeout(function () {
          for (var j = 0; j < $scope.userRoles.length; j++) {
            new FooPicker({
              id: 'active_date_' + $scope.userRoles[j].roleId,
              dateFormat: $scope.date_format
            });
            new FooPicker({
              id: 'inactive_date_' + $scope.userRoles[j].roleId,
              dateFormat: $scope.date_format
            });
            //$('#foopicker-active_date_'+ $scope.userRoles[j].roleId).addClass('foopickerheight');
            //$('#foopicker-inactive_date_'+ $scope.userRoles[j].roleId).addClass('foopickerheight');
          }
        }, 50);
      }
    });

    // Load all roles
    function loadRoles() {
      var endPoint = '/roles/';
      $httpHelper.httpRequest('GET', endPoint, null, function (data) {
        try {
          if (data === null || data === undefined) {
            throw new Error('Server Error');
          } else {
            $scope.autoRoles = data;
            allRoles = data;
            //$cacheHelper.setRolesData(data);
          }
        } catch (e) {
          $scope.notifications.push({
            status: 1,
            msg: e.message,
            details: '<pre>' + e.stack + '</pre>'
          });
        }
      });
    }

    // Load all teams
    function loadTeams() {
      var endPoint = '/teams/';
      $httpHelper.httpRequest('GET', endPoint, null, function (data) {
        try {
          if (data === null || data === undefined) {
            throw new Error('Server Error');
          } else {
            $scope.teams = data.result;
          }
        } catch (e) {
          $scope.notifications.push({
            status: 1,
            msg: e.message,
            details: '<pre>' + e.stack + '</pre>'
          });
        }
      });
    }

    // Load user details based on user id
    function loadUserDetails() {
      var endPoint = '/users/id/' + editUser + '/';
      $scope.pageDim = true;
      $httpHelper.httpRequest('GET', endPoint, null, function (data) {
        try {
          if (data === null || data === undefined) {
            throw new Error('Server Error');
          } else {
            _this.loadUserData(data);
          }
          $scope.pageDim = false;
        } catch (e) {
          $scope.pageDim = false;
          $scope.notifications.push({
            status: 1,
            msg: e.message,
            details: '<pre>' + e.stack + '</pre>'
          });
        }
      });
    }

    _this.loadUserData = function (data) {
      try {
        userDetails = data.user_details[0];
        $scope.username = userDetails.user_name;
        $scope.knownAs = userDetails.first_name;
        $scope.email = userDetails.email_address;
        $scope.phoneNo = userDetails.telephone;
        $scope.password = '';        
        if (userDetails.active_date) {
          $scope.activeDate = $formatHelper.formatDate(userDetails.active_date);
        }
        if (userDetails.inactive_date) {
          $scope.inactiveDate = $formatHelper.formatDate(userDetails.inactive_date);
        }
        $scope.team_id = parseInt(userDetails.team);
        $scope.manageUser.debugFlag = userDetails.debug_flag === 'Y' ? true : false;
        $scope.manageUser.generatePwd = false;
        $scope.homepage = '';
        $scope.userRoles = data.roles;
        var ids = 99999;
        for (var i = 0; i < $scope.userRoles.length; i++) {
          $scope.userRoles[i].roleId = ids + i;
          if ($scope.userRoles[i].active_date) {
            $scope.userRoles[i].active_date = $formatHelper.formatDate($scope.userRoles[i].active_date);
          }
          if ($scope.userRoles[i].inactive_date) {
            $scope.userRoles[i].inactive_date = $formatHelper.formatDate($scope.userRoles[i].inactive_date);
          }
        }
        $timeout(function () {
          if (allRoles) {
            $scope.autoRoles = [];
            for (var i = 0; i < $scope.userRoles.length; i++) {
              var index = allRoles.map(function (x) {
                return x.role_id;
              }).indexOf(parseInt($scope.userRoles[i].role_id));
              if (index !== -1) {
                deletedRoles.push(allRoles[index]);
                var role_name = allRoles[index].role_name;
                var id = 'role_name_' + $scope.userRoles[i].roleId;
                document.getElementById(id).value = role_name;
              }
            }
            for (i = 0; i < allRoles.length; i++) {
              var index1 = deletedRoles.map(function (x) {
                return x.role_id;
              }).indexOf(allRoles[i].role_id);
              if (index1 !== -1) {
                continue;
              }
              $scope.autoRoles[i] = allRoles[i];
            }
          } else {
            loadRoles();
          }
        }, 1000);
      } catch (e) {
        $scope.pageDim = false;
        $scope.notifications.push({
          status: 1,
          msg: e.message,
          details: '<pre>' + e.stack + '</pre>'
        });
      }
    };

    // Check if the username already exists or not
    $scope.checkUser = function () {
      $scope.focusUser = false;
      $scope.manageUser.userMsg = "Username is required";
      if ($scope.username) {
        var endPoint = '/users/validate/' + $scope.username + '/';
        $httpHelper.httpRequest('GET', endPoint, null, function (data) {
          try {
            if (data === null || data === undefined) {
              throw new Error('Server Error');
            } else {
              if (data.status === 1) {
                $scope.username = '';
                $scope.focusUser = false;
                $scope.notifications.push({
                  status: 1,
                  msg: 'Username already exists'
                });
              }
            }
          } catch (e) {
            $scope.notifications.push({
              status: 1,
              msg: e.message,
              details: '<pre>' + e.stack + '</pre>'
            });
          }
        });
      }
    };

    // Add empty rows to roles table
    $scope.addRoles = function () {
      var length = $scope.userRoles.length;
      for (var i = 99999 + length; i < 99999 + length + 5; i++) {
        var role = {};
        role.roleId = i;
        role.active_date = $formatHelper.formatDate($appHelper.today(-1));
        $scope.userRoles.push(role);
      }
      $timeout(function () {
        for (var j = 0; j < $scope.userRoles.length; j++) {
          new FooPicker({
            id: 'active_date_' + $scope.userRoles[j].roleId,
            dateFormat: $scope.date_format
          });
          new FooPicker({
            id: 'inactive_date_' + $scope.userRoles[j].roleId,
            dateFormat: $scope.date_format
          });
        }
      }, 50);
    };

    // Delete rows from roles table
    $scope.deleteRow = function () {
      deletedRoles = [];
      $scope.userRoles.splice($scope.selectedRow, 1);
      var length = $scope.userRoles.length;
      var ids = 99999;
      $timeout(function () {
        for (var i = 0; i < length; i++) {
          $scope.userRoles[i].roleId = i + ids;
        }
      }, 10);
      $timeout(function () {
        for (var i = 0; i < $scope.userRoles.length; i++) {
          if ($scope.userRoles[i].role_id) {
            var role_name = $scope.userRoles[i].role_name;
            var id = 'role_name_' + $scope.userRoles[i].roleId;
            document.getElementById(id).value = role_name;
          }
        }
      }, 10);
      for (var i = 0; i < $scope.userRoles.length; i++) {
        var index = allRoles.map(function (x) {
          return x.role_id;
        }).indexOf(parseInt($scope.userRoles[i].role_id));
        if (index !== -1) {
          var delRole = {
            'role_id': allRoles[index].role_id,
            'role_name': allRoles[index].role_name,
            'role_description': allRoles[index].role_description,
            'role_code': allRoles[index].role_code
          };
          deletedRoles.push(delRole);
          //break;
        }
      }
      for (i = 0; i < allRoles.length; i++) {
        var index1 = deletedRoles.map(function (x) {
          return x.role_id;
        }).indexOf(allRoles[i].role_id);
        if (index1 !== -1) {
          deletedRoles.splice(index1, 1);
          continue;
        }
        $scope.autoRoles[i] = allRoles[i];
      }
      $scope.selectedRow = '';
      $scope.manageUser.showDialog = false;
    };

    $scope.selectedrow = function (index) {
      $scope.manageUser.showDialog = true;
      $scope.selectedRow = index;
    };

    $scope.cancelModal = function () {
      $scope.selectedRow = '';
      $scope.manageUser.showDialog = false;
    };

    $scope.cancel = function () {
      $state.go('app.users');
    };

    $scope.showCCList = function () {
      $scope.show_cc_llist = true;
    };

    $scope.hideCCList = function () {
      $scope.show_cc_llist = false;
    };

    $scope.checkCCDetails = function (str) {
      if (str) {
        var tmp_cc = str.split(",");
        for (var i = 0; i < tmp_cc.length; i++) {
          var result = checkEmail(tmp_cc[i]);
          if (result === false) {
            $scope.show_cc_llist = false;
            $scope.cc = null;
            $scope.notifications.push({ msg: 'Not a valid CC' });
            break;
          }
        }
      }
    };

    $scope.checkBCCDetails = function (str) {
      if (str) {
        var tmp_bcc = str.split(",");
        for (var i = 0; i < tmp_bcc.length; i++) {
          var result = checkEmail(tmp_bcc[i]);
          if (result === false) {
            $scope.show_cc_llist = false;
            $scope.bcc = null;
            $scope.notifications.push({ msg: 'Not a valid BCC' });
            break;
          }
        }
      }
    };

    //email Validation
    $scope.emailValid = function () {
      $scope.focusEmail = false;
      if (!$scope.email) {
        $scope.email = '';
      }
    };

    //phone number validation
    $scope.phoneValid = function () {
      if ($scope.phoneNo && !$scope.phoneNo.match(regX)) {
        $scope.phoneNo = '';
      }
    };

    //check manadatory fields
    function validations() {
      if (!$scope.username) {
        $scope.focusUser = false;
        $scope.manageUser.userMsg = "Username is required";
        return false;
      } else if (!$scope.knownAs) {
        $scope.focusKnown = false;
        return false;
      } else if (!$scope.email) {
        $scope.email = '';
        $scope.focusEmail = false;
        return false;
      } else if (!$scope.activeDate) {
        $scope.focusActive = false;
        return false;
      } else if (!$scope.manageUser.generatePwd && !editUser) {
        if (!$scope.manageUser.password || !$scope.manageUser.rePassword) {
          if (!$scope.manageUser.password && !$scope.manageUser.rePassword) {
            $scope.focusPassword = false;
            $scope.focusRePassword = false;
            $scope.manageUser.passMsg = "Password is required";
            $scope.manageUser.rePassMsg = "Retype Password is required";
          } else if (!$scope.manageUser.password) {
            $scope.focusPassword = false;
            $scope.manageUser.passMsg = "Password is required";
          } else if (!$scope.manageUser.rePassword) {
            $scope.focusRePassword = false;
            $scope.manageUser.rePassMsg = "Retype Password is required";
          }
          $scope.manageUser.rePassword = '';
          return false;
        } else if ($scope.manageUser.password !== $scope.manageUser.rePassword) {
          $scope.manageUser.rePassword = '';
          $scope.focusRePassword = false;
          $scope.manageUser.rePassMsg = "passwords doesn't match";
          return false;
        }
      } else if (!$scope.manageUser.generatePwd && editUser) {
        if ($scope.manageUser.password) {
          if (!$scope.manageUser.rePassword) {
            $scope.focusRePassword = false;
            $scope.manageUser.rePassMsg = "Retype Password is required";
            return false;
          } else if ($scope.manageUser.password !== $scope.manageUser.rePassword) {
            $scope.manageUser.rePassword = '';
            $scope.focusRePassword = false;
            $scope.manageUser.rePassMsg = "passwords doesn't match";
            return false;
          }
        }
      }
      return true;
    }

    // This method is called to create a user
    $scope.createUser = function () {
      if (validations()) {
        $scope.pageDim = true;
        var userObj = {};
        if (editUser) {
          userObj.user_id = parseInt(editUser);
        }
        userObj.user_name = $scope.username;
        userObj.first_name = $scope.knownAs;
        userObj.email_address = $scope.email;
        userObj.telephone = $scope.phoneNo ? $scope.phoneNo : '';   
        if ($scope.activeDate) {
          userObj.active_date = $formatHelper.parseDate($scope.activeDate);
        }
        if ($scope.inactiveDate) {
          userObj.inactive_date = $formatHelper.parseDate($scope.inactiveDate);
        }
        userObj.team = $scope.team_id ? $scope.team_id : '';
        userObj.default_org_id = $scope.team_id ? $scope.team_id : '';
        if (!$scope.manageUser.generatePwd && $scope.manageUser.password) {
          userObj.encrypted_password = $scope.manageUser.password;
        } else {
          if (!editUser) {
            userObj.encrypted_password = '';
          }
        }
        userObj.debug_flag = $scope.manageUser.debugFlag ? 'Y' : 'N';
        userObj.created_date = $appHelper.today(0);
        userObj.additional_info1 = user.user_id;
        userObj.recent_update_date = $appHelper.today(0);
        var roles = [];
        for (var i = 0; i < $scope.userRoles.length; i++) {
          var role = {};
          var tmp = $scope.userRoles[i];
          if (tmp.role_id) {
            if (tmp.active_date) {
              role.role_id = parseInt(tmp.role_id);
              role.role_code = tmp.role_name;
              role.active_date = $formatHelper.parseDate(tmp.active_date);
              if (tmp.inactive_date) {
                role.inactive_date = $formatHelper.parseDate(tmp.inactive_date);
              }
              role.create_date = $appHelper.today(0);
              role.created_id = user.user_id;              
              role.recent_update_date = $appHelper.today(0);
              roles.push(role);
            } else {
              $scope.manageUser.showError = true;
              $scope.pageDim = false;
              $scope.notifications.push({
                status: 1,
                msg: 'Active from date is mandatory'
              });
              return;
            }
          }
        }
        userObj.roles = roles;        
        var method;
        var successMsg = {};
        if (editUser) {
          method = 'PUT';
          successMsg.msg = "updated";
        } else {
          method = 'POST';
          successMsg.msg = "created";
        }
        var endPoint = '/users/';
        $httpHelper.httpRequest(method, endPoint, userObj, function (data) {
          try {
            if (data === null || data === undefined) {
              throw new Error('Server Error');
            } else {
              if (data.status === 0) {
                successMsg.username = $scope.username;
                $appHelper.userSuccess = successMsg;
                $state.go('app.users');
              } else {
                $scope.manageUser.showError = true;
                $scope.manageUser.msg = data.msg;
                $scope.notifications.push({
                  status: 1,
                  msg: data.msg
                });
                $scope.pageDim = false;
              }
            }
          } catch (e) {
            $scope.pageDim = false;
            $scope.notifications.push({
              status: 1,
              msg: e.message,
              details: '<pre>' + e.stack + '</pre>'
            });
          }
        });
      }
    };

    //passwords check
    $scope.passwordEnter = function () {
      $scope.focusRePassword = false;
      if ($scope.manageUser.password && $scope.manageUser.rePassword) {
        if ($scope.manageUser.password !== $scope.manageUser.rePassword) {
          $scope.manageUser.rePassword = '';
          $scope.focusRePassword = false;
          $scope.manageUser.rePassMsg = "Password doesn't match";
        }
      }
    };

    //compare active and inactive dates
    $scope.compareDates = function (role) {
      var startDate, endDate, index, fromdate, todate;
      try {
        if (role) {
          index = $scope.userRoles.indexOf(role);
          if (index !== -1 && role.active_date && role.inactive_date) {
            startDate = $formatHelper.dateInMillis($formatHelper.parseDate(role.active_date));
            endDate = $formatHelper.dateInMillis($formatHelper.parseDate(role.inactive_date));
            if (startDate > 0 && endDate > 0) {
              if (startDate > endDate) {
                $scope.userRoles[index].inactive_date = null;
                $scope.manageUser.showError = true;
                $scope.manageUser.msg = "Invalid Inactive Date Selection";
              }
            } else {
              $scope.userRoles[index].inactive_date = null;
              $scope.manageUser.showError = true;
              $scope.manageUser.msg = "Invalid Dates";
            }
          }
        } else {
          if ($scope.activeDate && $scope.inactiveDate) {
            fromdate = $formatHelper.dateInMillis($formatHelper.parseDate($scope.activeDate));
            todate = $formatHelper.dateInMillis($formatHelper.parseDate($scope.inactiveDate));
            if (fromdate > 0 && todate > 0) {
              if (fromdate > todate) {
                $scope.inactiveDate = '';
                $scope.focusInactive = false;
              }
            } else {
              $scope.inactiveDate = '';
              $scope.manageUser.showError = true;
              $scope.manageUser.msg = "Invalid Dates";
            }
          }
        }
      } catch (e) {
        $scope.notifications.push({
          status: 1,
          msg: e.message,
          details: '<pre>' + e.stack + '</pre>'
        });
      }
    };

    //validating selected roles
    $scope.onSelectRoles = function (role, lineIndex) {
      $scope.autoRoles = [];
      var i, index;
      for (i = 0; i < $scope.userRoles.length; i++) {
        index = allRoles.map(function (x) {
          return x.role_id;
        }).indexOf(parseInt($scope.userRoles[i].role_id));
        if (index !== -1) {
          var delRole = {
            'role_id': allRoles[index].role_id,
            'role_name': allRoles[index].role_name,
            'role_description': allRoles[index].role_description,
            'role_code': allRoles[index].role_code
          };
          deletedRoles.push(delRole);
          //break;
        }
      }
      for (i = 0; i < allRoles.length; i++) {
        index = deletedRoles.map(function (x) {
          return x.role_id;
        }).indexOf(allRoles[i].role_id);
        if (index !== -1) {
          deletedRoles.splice(index, 1);
          continue;
        }
        $scope.autoRoles[i] = allRoles[i];
      }
      $timeout(function () {
        for (i = 0; i < $scope.userRoles.length; i++) {
          index = allRoles.map(function (x) {
            return x.role_id;
          }).indexOf(parseInt($scope.userRoles[i].role_id));
          if (index !== -1) {
            var role_name = allRoles[index].role_name;
            $scope.userRoles[i].role_name = role_name;
            var id = 'role_name_' + lineIndex;
            document.getElementById(id).value = role_name;
          }
        }
      }, 10);
    };

    function checkEmail(email) {
      var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

      if (!filter.test(email)) {
        return false;
      } else {
        return true;
      }
    }

    $('.scroll-top').click(function () {
      $appHelper.scrollTop();
    });

    $scope.$watch(function () {
      return $rootScope.team_id;
    }, function (newValue, oldValue) {
      if (newValue !== oldValue) {
        $state.go($state.current, {}, {
          reload: true
        });
      }
    });
  }
})();
