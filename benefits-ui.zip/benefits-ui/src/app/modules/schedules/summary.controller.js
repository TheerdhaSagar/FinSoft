/*
 * Author: Theerdha sagar Nimmagadda
 * Date: 24-10-2018
 */

(function () {
  'use strict';

  angular.module('scorpion')
    .controller('ScheduleSummaryController', ScheduleSummaryController);

  function ScheduleSummaryController($scope, $window, $location, $cacheHelper, $state,
    $appHelper, $httpHelper, $filter, $formatHelper,$rootScope) {

    // google analytics code
    $scope.$on('$viewContentLoaded', function () {
      $window.ga('send', 'pageview', {
        page: $location.url()
      });
    });

    var deleteLine, allSchedules = [], pageSize = $appHelper.pageSize, sortData = [];
    $scope.toggleFilter = $appHelper.toggleFilter();
    $scope.schedules = [];
    $scope.predicate = ['schedule_header_id'];
    $scope.desc = true;
    var _this = this;

    // get user
    $cacheHelper.getUser(function (data) {
      if (!data) {
        $state.go('login');
      } else {
        if ($appHelper.scheduleSave) {
          $scope.notifications.push({ status: 0, msg: $appHelper.scheduleSave });
          $appHelper.scheduleSave = null;
        }
        schedules();
      }
    });

    function schedules() {
      var endPoint = '/schedules/summary/' + $rootScope.orgId + '/';
      $scope.pageDim = true;
      try {
        $httpHelper.httpRequest('GET', endPoint, null, function (data) {
          if (data === null || data === undefined) {
            throw new Error("Server Error");
          } else {
            if (data.status === 1) {
              $scope.notifications.push({ status: 1, msg: data.msg });
            } else {
              _this.formatData(data);
            }
          }
        });
      } catch (e) {
        $scope.notifications.push({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    }

    _this.formatData = function (data) {
      for (var i = 0; i < data.length; i++) {
        data[i].f_frequency = data[i].frequency === 's1' ? '1' : data[i].frequency === 's2' ? 2 : data[i].frequency === 's3' ? 3 : data[i].frequency === 's4' ? 4 : '';
        data[i].s_date = $formatHelper.formatDate(data[i].date_from);
        data[i].e_date = $formatHelper.formatDate(data[i].date_to);
        data[i].s_date_millis = $formatHelper.dateInMillis(data[i].date_from);
        data[i].e_date_millis = $formatHelper.dateInMillis(data[i].date_to);
      }
      $scope.schedules = data;
      allSchedules = data;
      $scope.currentPage = 1;
      sortData = $filter('orderBy')(data, $scope.predicate, $scope.desc);
      $scope.schedules = sortData.slice($scope.currentPage - 1, pageSize);
      $scope.pageDim = false;
    };

    $scope.copy = function (schedule, type) {
      $scope.pageDim = true;      
      var endPoint = '/schedules/' + schedule.schedule_header_id + '/';
      try {
        $httpHelper.httpRequest('GET', endPoint, null, function (data) {
          if (data === null || data === undefined) {
            throw new Error("Server Error");
          } else {
            var copy = [];
            copy.push(data);
            copy.push(type);
            if (data) {
              $appHelper.scheduleCopy = copy;
              $state.go('app.scheduleCreate');
            }
            $scope.pageDim = false;
          }
        });
      } catch (e) {
        $scope.notifications.push({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    };

    $scope.delete = function (schedule) {
      deleteLine = schedule.schedule_header_id;
      $scope.showDialog = true;
    };

    $scope.deleteRow = function () {
      $scope.showDialog = false;
      $scope.showSpinner = true;
      try {
        var endPoint = '/schedules/' + deleteLine + '/';
        $httpHelper.httpRequest("DELETE", endPoint, null, function (data) {
          if (data === null || data === undefined) {
            throw new Error("Server Error");
          } else {
            if (data.status === 0) {
              var index = $scope.schedules.map(function (x) { return x.schedule_header_id; }).indexOf(deleteLine);
              if (index !== -1) {
                $scope.schedules.splice(index, 1);
              }
            } else if (data.status === 1) {
              $scope.notifications.push({ status: 1, msg: data.msg });
            }
            $scope.showSpinner = false;
          }
        });
      } catch (e) {
        $scope.notifications.push({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    };

    //sort Functionality
    $scope.sort = function (key) {
      $scope.desc = !$scope.desc;
      $scope.predicate = key;
      sortData = $filter('orderBy')($scope.schedules, $scope.predicate, $scope.desc);
      $scope.currentPage = 1;
      $scope.creditNotes = sortData.slice($scope.currentPage - 1, pageSize);
    };

    // Load more creidtnotes when the page is scrolled down
    $scope.loadMore = function () {
      try {
        var page = $scope.currentPage + 1;
        var startIndex = (page - 1) * pageSize;
        var endIndex = page * pageSize;
        $scope.currentPage = page;
        if (sortData) {
          var tempData = sortData.slice(startIndex, endIndex);
          for (var i = 0; i < tempData.length; i++) {
            $scope.schedules.push(tempData[i]);
          }
        }
      } catch (e) {
        $scope.notifications.push({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    };

    $scope.cancelModal = function () {
      deleteLine = '';
      $scope.showDialog = false;
    };

    // goto schedule create page
    $scope.create = function () {
      $state.go('app.scheduleCreate');
    };

    $(window).scroll(function () {
      $('.scroll-table thead').css({
        top: (window.scrollY - 71) + 'px'
      });
    });
  }
})();
