/**
 * Author Theerdha Sagar Nimmagadda
 */

(function() {
  'use strict';

  angular.module('scorpion')
    .controller('ScheduleCreateController', ScheduleCreateController);

  function ScheduleCreateController($scope, $window, $location, $state, $cacheHelper, $formatHelper,
                                    $appHelper, $timeout, $httpHelper, $filter, $rootScope) {

    // google analytics code
    $scope.$on('$viewContentLoaded', function() {
      $window.ga('send', 'pageview', {
        page: $location.url()
      });
    });

    var user;
    var _this = this;
    $scope.scheduleTime = {
      'slot1': null,
      'slot2': null,
      'slot3': null
    };
    var count = 0,creation_date,gotoState = false;
    $scope.type = '';
    $scope.checkedCount = 0;
    var allSchedules = [],
      deletedRows = [];
    $scope.weekends = 'exclude';
    $scope.frequency = 's1';
    $scope.schedules = [];
    $scope.time = [];
    $scope.tasks = [];
    $scope.focusZone = false;
    $scope.zonesIds = [];
    $scope.zonesNames = [];
    $scope.user_id = '';
    $scope.zone = '';
    $scope.isEdit = false;
    $scope.employees = [];
    $scope.scheduleName = '';
    $scope.selectedZones = [];
    $scope.task_header_name = '';
    $scope.selectedTask = null;
    $scope.task_header_id = null;
    $scope.leave_details = null;
    var allSlots = [];
    var weekday = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    $scope.nLine = false;

    //get user
    $cacheHelper.getUser(function(data) {
      if (!data) {
        $state.go('login');
      } else {
        user = data;
        if (!user.date_format) {
          user.date_format = 'dd-MMM-yyyy';
        }
        new FooPicker({
          id: 'fromDateCal',
          dateFormat: user.date_format
        });
        new FooPicker({
          id: 'toDateCal',
          dateFormat: user.date_format
        });

        $scope.filterMonth = [];
        var month1 = {
          'id': 'All'
        };
        $scope.filterMonth.push(month1);
        $scope.selectedMonth = $scope.filterMonth[0];
        for (var j = 0; j < months.length; j++) {
          var month = {
            'id': months[j]
          };
          $scope.filterMonth.push(month);
        }
        $timeout(function() {
          new FooPicker({
            id: 'dateId',
            dateFormat: user.date_format
          });
          new FooPicker({
            id: 'gldateId',
            dateFormat: user.date_format
          });
        }, 10);
        loadTasks();
        loadEmployees();
        loadZones();
        if ($appHelper.scheduleCopy) {
          $scope.isEdit = true;
          copySchedule();
        }
      }
    });

    var mins = ['00', '30'];
    for (var i = 0; i < 24; i++) {
      for (var k = 0; k < mins.length; k++) {
        allSlots.push({tick: i + '.' + mins[k]});
      }
    }
    $scope.time = allSlots;

    function loadZones() {
      $scope.all_zones = [{
        category_id: '1',
        zone_name: 'ALL',
        brand_code:'ALL'
      }, {
        category_id: '2',
        zone_name: 'CHIC',
        brand_code: 'CHIC'
      }, {
        category_id: '3',
        zone_name: 'CLEV',
        brand_code: 'CLEV'
      }, {
        category_id: '4',
        zone_name: 'DALL',
        brand_code: 'DALL'
      }, {
        category_id: '5',
        zone_name: 'STLO',
        brand_code: 'STLO'
      }, {
        category_id: '6',
        zone_name: 'BOST',
        brand_code: 'BOST'
      }, {
        category_id: '7',
        zone_name: 'CLI2',
        brand_code: 'CLI2'
      }, {
        category_id: '8',
        zone_name: 'CLIF',
        brand_code: 'CLIF'
      }, {
        category_id: '9',
        zone_name: 'LONG',
        brand_code: 'LONG'
      }, {
        category_id: '10',
        zone_name: 'PITT',
        brand_code: 'PITT'
      }, {
        category_id: '11',
        zone_name: 'ATLA',
        brand_code: 'ATLA'
      }, {
        category_id: '12',
        zone_name: 'BALT',
        brand_code: 'BALT'
      }, {
        category_id: '13',
        zone_name: 'CHAR',
        brand_code: 'CHAR'
      }, {
        category_id: '14',
        zone_name: 'MIAM',
        brand_code: 'MIAM'
      }, {
        category_id: '15',
        zone_name: 'PHIL',
        brand_code: 'PHIL'
      }, {
        category_id: '16',
        zone_name: 'LOS2',
        brand_code: 'LOS2'
      }, {
        category_id: '17',
        zone_name: 'LOSA',
        brand_code: 'LOSA'
      }, {
        category_id: '18',
        zone_name: 'PHOE',
        brand_code: 'PHOE'
      }, {
        category_id: '19',
        zone_name: 'SANF',
        brand_code: 'SANF'
      }, {
        category_id: '20',
        zone_name: 'SEAT',
        brand_code: 'SEAT'
      }, {
        category_id: '21',
        zone_name: 'NCN2',
        brand_code: 'NCN2'
      }, {
        category_id: '22',
        zone_name: 'NCN3',
        brand_code: 'NCN3'
      }, {
        category_id: '23',
        zone_name: 'NCT2',
        brand_code: 'NCT2'
      }, {
        category_id: '24',
        zone_name: 'NCT3',
        brand_code: 'NCT3'
      }, {
        category_id: '25',
        zone_name: 'NCTS',
        brand_code: 'NCTS'
      }, {
        category_id: '26',
        zone_name: 'ZHIC',
        brand_code: 'ZHIC'
      }, {
        category_id: '27',
        zone_name: 'ZLI2',
        brand_code: 'ZLI2'
      }, {
        category_id: '28',
        zone_name: 'ZCN2',
        brand_code: 'ZCN2'
      }, {
        category_id: '29',
        zone_name: 'ZCN3',
        brand_code: 'ZCN3'
      }, {
        category_id: '30',
        zone_name: 'ZOS2',
        brand_code: 'ZOS2'
      }, {
        category_id: '31',
        zone_name: 'ZOST',
        brand_code: 'ZOST'
      }, {
        category_id: '32',
        zone_name: 'NCNP',
        brand_code: 'NCNP'
      }, {
        category_id: '33',
        zone_name: 'ZCNP',
        brand_code: 'ZCNP'
      }, {
        category_id: '34',
        zone_name: 'NAP2',
        brand_code: 'NAP2'
      }, {
        category_id: '35',
        zone_name: 'TORO',
        brand_code: 'TORO'
      }];
    }


    function loadTasks() {
      var endPoint = '/tasks/headers/' + $rootScope.orgId + '/';
      $scope.showSpinner = true;
      try {
        $httpHelper.httpRequest('GET', endPoint, null, function (data) {
          if (data === null || data === undefined) {
            throw new Error("Server Error");
          } else {
            if (data.status === 1) {
              $scope.notifications.push({ status: 1, msg: data.msg });
            } else {
              $scope.tasks = data.result;
            }
          }
        });
      } catch (e) {
        $scope.notifications.push({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    }

    function loadEmployees() {
      var endPoint = '/calendar/all/' + $rootScope.orgId + '/';
      try {
        $httpHelper.httpRequest('GET', endPoint, null, function (data) {
          $scope.showSpinner = false;
          if (data === null || data === undefined) {
            throw new Error("Server Error");
          } else {
            if (data.status === 1) {
              $scope.notifications.push({ status: 1, msg: data.msg });
            } else {
              $scope.employees = data.result;
            }
            $timeout(function() {
            }, 1500);
          }
        });
      } catch (e) {
        $scope.notifications.push({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    }

    $scope.searchZone = function(brand) {
      var i;
      var zonesList, zoneLiNames = [], zoneLiIds = [];
      zonesList = $scope.all_zones;
      zoneLiIds = [];
      zoneLiNames = [];
      if (brand.brand_code === 'ALL' && !brand.checked) {
        zoneLiIds = [];
        zoneLiNames = [];
        for (i = 0; i < zonesList.length; i++) {
          zonesList[i].checked = false;
        }
      } else {
        for (i = 0; i < zonesList.length; i++) {
          if ((brand.brand_code === 'ALL' && brand.checked) || zonesList[i].checked) {
            if (zoneLiIds.indexOf(zonesList[i].category_id) === -1 && zonesList[i].brand_code !== 'ALL') {
              zoneLiIds.push(parseInt(zonesList[i].category_id));
              zoneLiNames.push(zonesList[i].zone_name);
              zonesList[i].checked = brand.brand_code === 'ALL' && brand.checked ? true : zonesList[i].checked;
            }
          }
        }
      }

      $scope.zonesIds = zoneLiIds;
      $scope.zonesNames = zoneLiNames;

    };



    $scope.deleteZone = function(index) {
      var brandIndex, zoneLiIds, zoneLiNames;

      zoneLiNames = $scope.all_zones;
      zoneLiIds = $scope.zonesIds;

      brandIndex = zoneLiNames.map(function(x) {
        return parseInt(x.category_id);
      }).indexOf(parseInt(zoneLiIds[index]));
      if (brandIndex !== -1) {
        zoneLiNames[brandIndex].checked = false;
      }
      $scope.zonesIds.splice(index, 1);
      $scope.zonesNames.splice(index, 1);

    };

    $scope.calculateTaskTime = function() {
      if (!$scope.task_header_name) {
        $scope.task_header_name = '';
        return;
      }
      var index = $scope.tasks.map(function(x) {
        return parseInt(x.task_header_id);
      }).indexOf(parseInt($scope.task_header_name));

      if (index !== -1) {
        $scope.selectedTask = index;
      }

    };


    function copySchedule() {
      var tempScheduleLines = [];
      $scope.type = $appHelper.scheduleCopy[1];
      var details = $appHelper.scheduleCopy[0];
      $appHelper.scheduleCopy = null;
      $scope.scheduleName = details.schedule_name;
      $scope.fromDate = $formatHelper.formatDate(details.date_from);
      $scope.toDate = $formatHelper.formatDate(details.date_to);
      $scope.frequency = details.frequency;
      $scope.weekends = details.exclude_weekend;
      $scope.task_header_id = details.task_id;
      $scope.task_header_name = details.task_header_name;
      $scope.scheduleTime.slot1 = details.time_slot1;
      $scope.scheduleTime.slot2 = details.time_slot2 ? details.time_slot2 : '';
      $scope.scheduleTime.slot3 = details.time_slot3 ? details.time_slot3 : '';
      $scope.scheduleTime.slot4 = details.time_slot4 ? details.time_slot4 : '';
      creation_date = details.creation_date;
      for (var k = 0; k < details.lines.length; k++) {
        var toArr = details.lines[k].run_date.split('-');
        toArr[1] = stringFormatter(toArr[1]);
        var mnth;
        for (var l = 0; l < months.length; l++) {
          if (toArr[1] === months[l]) {
            mnth = l;
          }
        }
        var fromDa = new Date(parseInt(toArr[2]), mnth, parseInt(toArr[0]));
        var week = weekday[fromDa.getDay()];
        var schedule = {
          'RUN_DATE': $formatHelper.formatDate(details.lines[k].run_date),
          'DAY': week,
          'TIME_SLOT': details.lines[k].time_slot,
          'ZONE': details.lines[k].zone,
          'GL_DATE': $formatHelper.formatDate(details.lines[k].gl_date),
          'FROM_DATE': $formatHelper.formatDate(details.lines[k].gl_date),
          'TODAY': '',
          'STATUS': details.lines[k].status || 'Open',
          'USER_ID': details.lines[k].user_id,
          'first_name':details.lines[k].first_name,
          'ParseDate': $formatHelper.parseDate(details.lines[k].run_date),
          'uniqueLineId': k,
          'date_in_millis' : $formatHelper.dateInMillis(details.lines[k].run_date)
        };
        if(!$scope.selectedZones.includes(details.lines[k].zone)){
          var index = $scope.all_zones.map(function(x) {
            return x.zone_name;
          }).indexOf(details.lines[k].zone);

          $scope.all_zones[index].checked = true;
          $scope.selectedZones.push(details.lines[k].zone);
          $scope.zonesIds.push($scope.all_zones[index].category_id);
          $scope.zonesNames.push($scope.all_zones[index].zone_name);
        }
        $scope.task_header_id = details.task_id;
        if ($scope.type === 'edit') {
          schedule.schedule_line_id = details.lines[k].schedule_line_id;
        }
        tempScheduleLines.push(schedule);
      }
      allSchedules = $filter('orderBy')(tempScheduleLines, 'date_in_millis', false);
      $scope.schedules = allSchedules;
      $scope.zonesNames = $scope.selectedZones;
      if ($scope.type === 'edit') {
        $scope.schedule_header_id = details.schedule_header_id;
      }
    }

    // formats month
    function stringFormatter(string) {
      string = string.toLowerCase();
      return string.charAt(0).toUpperCase() + string.slice(1);
    }

    //calculate days
    function daysDifference(todate, fromdate) {
      var day = 24 * 60 * 60 * 1000;
      var toDate = new Date(todate.yr, todate.m, todate.d);
      var fromDate = new Date(fromdate.yr, fromdate.m, fromdate.d);
      $scope.diffDays = Math.round(Math.abs((toDate.getTime() - fromDate.getTime()) / (day)));
    }

    // include/Exclude weekends
    function countWeekends(todate, fromDate) {
      var count = 0;
      if ($scope.weekends === 'include') {
        count = 0;
        for (var i = 0; i <= $scope.diffDays; i++) {
          var fromDa = new Date(fromDate.yr, fromDate.m, fromDate.d + i);
          var res = fromDa.toString().split(' ');
          var week = weekday[fromDa.getDay()];
          var parsedate = res[2] + '-' + res[1] + '-' + res[3];
          var fromdate = $formatHelper.formatDate(parsedate);
          var newDate = new Date();
          var result = newDate.toString().split(' ');
          var todayParse = result[2] + '-' + result[1] + '-' + result[3];
          var today = $formatHelper.formatDate(todayParse);
          var freqCount = parseInt($scope.frequency.replace("s", ""));
          var zoneCount = $scope.zonesIds.length;
          for (var j = 0; j < freqCount; j++) {
            var slot = j === 0 ? $scope.scheduleTime.slot1 : j === 1 ? $scope.scheduleTime.slot2 : j === 2 ? $scope.scheduleTime.slot3 : $scope.scheduleTime.slot4;
            for(var k = 0; k < zoneCount; k++)
            {
              var schedule = {
                'RUN_DATE': fromdate,
                'DAY': week,
                'TIME_SLOT': slot,
                'ZONE': $scope.zonesNames[k],
                'GL_DATE': fromdate,
                'FROM_DATE': fromdate,
                'TODAY': today,
                'STATUS': 'Open',
                'USER_ID': null,
                'ParseDate': $formatHelper.parseDate(fromdate),
                'uniqueLineId': count
              };
              $scope.schedules.push(schedule);
              count++;
            }
          }
        }
      } else {
        count = 0;
        for (var l = 0; l <= $scope.diffDays; l++) {
          var fromDa1 = new Date(fromDate.yr, fromDate.m, fromDate.d + l);
          var res1 = fromDa1.toString().split(' ');
          var week1 = weekday[fromDa1.getDay()];
          if (week1 === 'Saturday' || week1 === 'Sunday') {
            continue;
          }
          var parsedate1 = res1[2] + '-' + res1[1] + '-' + res1[3];
          var fromdate1 = $formatHelper.formatDate(parsedate1);
          var newDate1 = new Date();
          var result1 = newDate1.toString().split(' ');
          var todayParse1 = result1[2] + '-' + result1[1] + '-' + result1[3];
          var today1 = $formatHelper.formatDate(todayParse1);
          var freqCount1 = parseInt($scope.frequency.replace("s", ""));
          var zoneCount1 = $scope.zonesNames.length;
          for (var p = 0; p < freqCount1; p++) {
            var slot1 = p === 0 ? $scope.scheduleTime.slot1 : p === 1 ? $scope.scheduleTime.slot2 : p === 2 ? $scope.scheduleTime.slot3 :  $scope.scheduleTime.slot4;
            for(var q = 0; q < zoneCount1; q++ )
            {
              var schedule1 = {
                'RUN_DATE': fromdate1,
                'DAY': week1,
                'TIME_SLOT': slot1,
                'ZONE': $scope.zonesNames[q],
                'GL_DATE': fromdate1,
                'FROM_DATE': fromdate1,
                'TODAY': today1,
                'USER_ID': null,
                'STATUS': 'Open',
                'ParseDate': $formatHelper.parseDate(fromdate1),
                'uniqueLineId': count
              };
              $scope.schedules.push(schedule1);
              count++;
            }
          }
        }
      }
      allSchedules = $scope.schedules;
      $scope.selectedMonth = $scope.filterMonth[0];
      $scope.notifications.push({status:0,msg:"Schedule lines are generated. You can add lines further"});
      //  $timeout(function () {
      //
      //     for(var m=0;m<$scope.schedules.length;m++) {
      //        new FooPicker({
      //           id: 'date_'+ m,
      //           dateFormat: user.dateFormat
      //        });
      //     }
      //  }, 10);
    }

    //clear lines on edit
    function clearLines() {
      if($scope.type === 'edit') {
        var i;
        for (i = 0; i < allSchedules.length; i++) {
          allSchedules[i].checked = true;
        }
        $scope.checkedCount = allSchedules.length;
        for (i = 0; i < allSchedules.length; i++) {
          if (allSchedules[i].checked === true) {
            if (allSchedules[i].hasOwnProperty('schedule_line_id')) {
              count = 1;
              deletedRows.push(allSchedules[i].schedule_line_id);
            }
            $scope.checkedCount += 1;
          }
        }
        deleteId();
        $scope.cancelModal();
      }
      return true;
    }

    $scope.addEmployee = function(index,employee){
      allSchedules[index].USER_ID = employee;
      $scope.schedules[index].USER_ID = employee;
    };

    $scope.addEmployeeLine = function(user_id){
      $scope.user_id = user_id;
    };


    // delete generated lines
    $scope.GenerateLines = function() {
      gotoState = false;
      $scope.showSpinner = true;
      if(allSchedules.length > 0 && $scope.schedules.length > 0) {
        $scope.showDialog = true;
        $scope.nLine = true;
      } else {
        $scope.generateSchedules();
      }
      loadLeaveDetails();
      $timeout(function() {
        $scope.showSpinner = false;
      }, 500);
    };

    function loadLeaveDetails() {
      $scope.holidaysList = [];
      var endPoint = '/hcm/leavemanagement/leaves/schedule/';
      var requestObj = {
        org_id: $scope.orgId || $rootScope.orgId,
        start_date: $formatHelper.parseDate($scope.fromDate),
        end_date: $formatHelper.parseDate($scope.toDate)
      };
      $httpHelper.httpRequest('POST', endPoint, requestObj, function(data) {
        if (data === null || data === undefined) {
          $scope.notifications.push({msg: 'Server Error - getLeaveDetails()', status: 1});
        } else {
          if (data.status === 1) {
            $scope.notifications.push({msg: data.msg, status: data.status});
          } else {
            $scope.leave_details = data.result;
          }
        }
      });
    }

    //generate Schedules
    $scope.generateSchedules = function() {
      if (validations() && clearLines()) {
        clear();
        var toArr = $formatHelper.parseDate($scope.toDate).split('-');
        var fromArr = $formatHelper.parseDate($scope.fromDate).split('-');
        var to = {
          'd': parseInt(toArr[0]),
          'yr': parseInt(toArr[2])
        };
        var from = {
          'd': parseInt(fromArr[0]),
          'yr': parseInt(fromArr[2])
        };
        for (var i = 0; i < months.length; i++) {
          if (toArr[1] === months[i]) {
            to.m = i;
          }
          if (fromArr[1] === months[i]) {
            from.m = i;
          }
        }
        daysDifference(to, from);
        countWeekends(to, from);
        // $scope.save();
      }
      $scope.showDialog = false;
      $scope.nLine = false;
    };

    //validations
    function validations() {
      var flag = 0, index, index1, index2, index3;
      if (!$scope.scheduleName) {
        $scope.focusName = true;
        flag = 1;
        $scope.notifications.push({
          status: 1,
          msg: 'Name is mandatory'
        });
        if(!$scope.task_header_name){
          $scope.focusTask = true;
          flag = 1;
          $scope.notifications.push({
            status: 1,
            msg: 'A Task has to be mapped'
          });
        }
      }
      if (!$scope.fromDate) {
        $scope.focusFromDate = true;
        flag = 1;
        $scope.notifications.push({
          status: 1,
          msg: 'From Date is mandatory'
        });
      }
      if (!$scope.toDate) {
        $scope.focusToDate = true;
        flag = 1;
        $scope.notifications.push({
          status: 1,
          msg: 'To Date is mandatory'
        });
      }
      if ($scope.frequency === 's1' && !$scope.scheduleTime.slot1) {
        $scope.focusSlot1 = true;
        flag = 1;
        $scope.notifications.push({
          status: 1,
          msg: 'slot1 is mandatory'
        });
      }
      if ($scope.frequency === 's2' && (!$scope.scheduleTime.slot1 ||
        !$scope.scheduleTime.slot2)) {
        if (!$scope.scheduleTime.slot1) {
          $scope.focusSlot1 = true;
          $scope.notifications.push({status: 1,msg: 'slot1 is mandatory'});
        }
        if (!$scope.scheduleTime.slot2) {
          $scope.focusSlot2 = true;
          $scope.notifications.push({status: 1,msg: 'slot2 is mandatory'});
        }
        flag = 1;
      }
      if ($scope.frequency === 's3' && (!$scope.scheduleTime.slot1 ||
        !$scope.scheduleTime.slot2 || !$scope.scheduleTime.slot3)) {
        if (!$scope.scheduleTime.slot1) {
          $scope.focusSlot1 = true;
          $scope.notifications.push({status: 1,msg: 'slot1 is mandatory'});
        }
        if (!$scope.scheduleTime.slot2) {
          $scope.focusSlot2 = true;
          $scope.notifications.push({status: 1,msg: 'slot2 is mandatory'});
        }
        if (!$scope.scheduleTime.slot3) {
          $scope.focusSlot3 = true;
          $scope.notifications.push({status: 1,msg: 'slot3 is mandatory'});
        }
        flag = 1;
      }
      if ($scope.frequency === 's4' && (!$scope.scheduleTime.slot1 ||
        !$scope.scheduleTime.slot2 || !$scope.scheduleTime.slot3 || !$scope.scheduleTime.slot4)) {
        if (!$scope.scheduleTime.slot1) {
          $scope.focusSlot1 = true;
          $scope.notifications.push({status: 1,msg: 'slot1 is mandatory'});
        }
        if (!$scope.scheduleTime.slot2) {
          $scope.focusSlot2 = true;
          $scope.notifications.push({status: 1,msg: 'slot2 is mandatory'});
        }
        if (!$scope.scheduleTime.slot3) {
          $scope.focusSlot3 = true;
          $scope.notifications.push({status: 1,msg: 'slot3 is mandatory'});
        }
        if (!$scope.scheduleTime.slot4) {
          $scope.focusSlot4 = true;
          $scope.notifications.push({status: 1,msg: 'slot4 is mandatory'});
        }
        flag = 1;
      }

      if($scope.frequency === 's1'){
        if($scope.scheduleTime.slot1){
          index = allSlots.map(function(x){return x.tick;}).indexOf($scope.scheduleTime.slot1);
          if(index === -1) {
            $scope.focusSlot1 = true;
            $scope.notifications.push({status: 1,msg: 'Slot1 is invalid'});
            $scope.scheduleTime.slot1 = '';
            flag =1;
          }
        }
      }
      if($scope.frequency === 's2') {
        if($scope.scheduleTime.slot1 && $scope.scheduleTime.slot2) {
          index = allSlots.map(function(x){return x.tick;}).indexOf($scope.scheduleTime.slot1);
          index1 = allSlots.map(function(x){return x.tick;}).indexOf($scope.scheduleTime.slot2);
          if(index === -1){
            $scope.focusSlot1 = true;
            $scope.notifications.push({status: 1,msg: 'Slot1 is invalid'});
            $scope.scheduleTime.slot1 = '';
            flag =1;
          }
          if(index1 === -1) {
            $scope.focusSlot2 = true;
            $scope.notifications.push({status: 1,msg: 'Slot2 is invalid'});
            $scope.scheduleTime.slot2 = '';
            flag =1;
          }
          if(index !== -1 && index1!== -1 && (index === index1)) {
            $scope.notifications.push({status: 1,msg: 'Slots cannot be same. Select different slot'});
            flag =1;
          }
        }
      }
      if($scope.frequency === 's3') {
        if($scope.scheduleTime.slot1 && $scope.scheduleTime.slot2 && $scope.scheduleTime.slot3) {
          index = allSlots.map(function(x){return x.tick;}).indexOf($scope.scheduleTime.slot1);
          index1 = allSlots.map(function(x){return x.tick;}).indexOf($scope.scheduleTime.slot2);
          index2 = allSlots.map(function(x){return x.tick;}).indexOf($scope.scheduleTime.slot3);
          if(index === -1) {
            $scope.focusSlot1 = true;
            $scope.notifications.push({status: 1,msg: 'Slot1 is invalid'});
            $scope.scheduleTime.slot1 = '';
            flag =1;
          }
          if(index1 === -1) {
            $scope.focusSlot2 = true;
            $scope.notifications.push({status: 1,msg: 'Slot2 is invalid'});
            $scope.scheduleTime.slot2 = '';
            flag =1;
          }
          if(index2 === -1) {
            $scope.focusSlot3 = true;
            $scope.notifications.push({status: 1,msg: 'Slot3 is invalid'});
            $scope.scheduleTime.slot3 = '';
            flag =1;
          }
          if(index !== -1 && index1!== -1 && index2 !== -1 && ((index === index1) || (index === index2) || (index2 === index1))) {
            $scope.notifications.push({status: 1,msg: 'Slots cannot be same. Select different slot'});
            flag =1;
          }
        }
      }
      if($scope.frequency === 's4') {
        if($scope.scheduleTime.slot1 && $scope.scheduleTime.slot2 && $scope.scheduleTime.slot3) {
          index = allSlots.map(function(x){return x.tick;}).indexOf($scope.scheduleTime.slot1);
          index1 = allSlots.map(function(x){return x.tick;}).indexOf($scope.scheduleTime.slot2);
          index2 = allSlots.map(function(x){return x.tick;}).indexOf($scope.scheduleTime.slot3);
          index3 = allSlots.map(function(x){return x.tick;}).indexOf($scope.scheduleTime.slot4);
          if(index === -1) {
            $scope.focusSlot1 = true;
            $scope.notifications.push({status: 1,msg: 'Slot1 is invalid'});
            $scope.scheduleTime.slot1 = '';
            flag =1;
          }
          if(index1 === -1) {
            $scope.focusSlot2 = true;
            $scope.notifications.push({status: 1,msg: 'Slot2 is invalid'});
            $scope.scheduleTime.slot2 = '';
            flag =1;
          }
          if(index2 === -1) {
            $scope.focusSlot3 = true;
            $scope.notifications.push({status: 1,msg: 'Slot3 is invalid'});
            $scope.scheduleTime.slot3 = '';
            flag =1;
          }
          if(index3 === -1) {
            $scope.focusSlot4 = true;
            $scope.notifications.push({status: 1,msg: 'Slot4 is invalid'});
            $scope.scheduleTime.slot4 = '';
            flag =1;
          }
          if(index !== -1 && index1!== -1 && index2 !== -1 && index3 !== -1 && ((index === index1) || (index === index2) || (index2 === index1) || (index === index3))) {
            $scope.notifications.push({status: 1,msg: 'Slots cannot be same. Select different slot'});
            flag =1;
          }
        }
      }
      if($scope.zonesNames.length === 0) {
        $scope.notifications.push({status: 1,msg: 'At least one Zone needs to be selected'});
        $scope.focusZone = true;
        flag =1;
      }
      if (flag === 1) {
        return false;
      } else {
        return true;
      }
    }

    //compare from and to dates
    $scope.compareDates = function() {
      if ($scope.fromDate && $scope.toDate) {
        var startDate = $formatHelper.dateInMillis($formatHelper.parseDate($scope.fromDate));
        var endDate = $formatHelper.dateInMillis($formatHelper.parseDate($scope.toDate));
        if (startDate > 0 && endDate > 0) {
          if (startDate <= endDate) {} else {
            $scope.toDate = null;
            $scope.focusToDate = true;
            $scope.notifications.push({
              status: 1,
              msg: 'To Date must be greater than From Date'
            });
          }
        }
      } else if (!$scope.fromDate) {
        $scope.focusFromDate = true;
      } else if (!$scope.toDate) {
        $scope.focusToDate = true;
      }
    };

    $scope.slotValid = function() {
      var slots = [$scope.scheduleTime.slot1,$scope.scheduleTime.slot2,$scope.scheduleTime.slot3,$scope.scheduleTime.slot4];
      $scope.time = [];
      for(var i=0;i<allSlots.length;i++) {
        var count = 0;
        for(var j=0;j<slots.length;j++) {
          if(slots[j] && slots[j] === allSlots[i].tick){
            count=1;
            break;
          }
        }
        if(count === 1){
          continue;
        }
        $scope.time.push(allSlots[i]);
      }
    };

    //clear
    function clear() {
      $scope.schedules = [];
      $scope.focusName = false;
      $scope.focusFromDate = false;
      $scope.focusToDate = false;
      $scope.focusSlot1 = false;
      $scope.focusSlot2 = false;
      $scope.focusSlot3 = false;
    }

    // day for selected date
    $scope.lineDay = function() {
      // $scope.date = document.getElementById('dateId').value;
      $scope.gldate = $scope.date;
      var toArr = $formatHelper.parseDate($scope.date).split('-');
      var mnth;
      for (var i = 0; i < months.length; i++) {
        if (toArr[1] === months[i]) {
          mnth = i;
        }
      }
      var fromDa = new Date(parseInt(toArr[2]), mnth, parseInt(toArr[0]));
      $scope.day = weekday[fromDa.getDay()];
    };

    $scope.glDateChange = function() {
      $scope.gldate = document.getElementById('gldateId').value;
    };

    // line validation
    _this.lineValidation = function() {
      var flag = 0;
      if (!$scope.date) {
        $scope.focusDate = true;
        flag = 1;
      }
      if (!$scope.timeslot) {
        $scope.focusSlot = true;
        flag = 1;
      } else if($scope.timeslot) {
        var index = $scope.time.map(function(x){return x.tick;}).indexOf($scope.timeslot);
        if(index === -1) {
          $scope.focusSlot = true;
          $scope.timeslot = '';
          $scope.notifications.push({status:1, msg:'Enter valid data'});
          flag = 1;
        }
      }
      if($scope.date && $scope.timeslot){
        for(var i=0;i<allSchedules.length;i++) {
          var datemillis = $formatHelper.dateInMillis($formatHelper.parseDate(allSchedules[i].RUN_DATE));
          var timeslots = allSchedules[i].TIME_SLOT;
          var seldate = $formatHelper.dateInMillis($formatHelper.parseDate($scope.date));
          if(datemillis === seldate && timeslots === $scope.timeslot){
            $scope.notifications.push({status:1, msg:'Line already exists'});
            flag = 1;
          }
        }
      }
      if (!$scope.gldate) {
        $scope.focusglDate = true;
        flag = 1;
      }
      if (flag === 1) {
        return false;
      } else {
        return true;
      }
    };

    //add line to schedules
    $scope.addLine = function() {
      window.scrollTo(0,document.body.scrollHeight);
      if (_this.lineValidation()) {
        var len = allSchedules.length;
        var schedule = {
          'RUN_DATE': $scope.date,
          'DAY': $scope.day,
          'TIME_SLOT': $scope.timeslot,
          'ZONE':$scope.zone,
          'GL_DATE': $scope.gldate,
          'USER_ID':$scope.user_id,
          'FROM_DATE': $scope.date,
          'STATUS': 'Open',
          'ParseDate': $formatHelper.parseDate($scope.date),
          'uniqueLineId': len
        };
        var id = $scope.selectedMonth.id;
        if (id === 'All') {
          allSchedules.push(schedule);
          $scope.schedules = allSchedules;
        } else {
          allSchedules.push(schedule);
          for (var p = 0; p < allSchedules.length; p++) {
            var pdate = allSchedules[p].ParseDate;
            var index = pdate.search(id);
            if (index !== -1) {
              $scope.schedules.push(allSchedules[p]);
            }
          }
        }
        $scope.lineClear();
      }
    };

    $scope.timeslotchange = function(time) {
      $scope.timeslot = time;
    };

    $scope.zonechange = function(zone) {
      $scope.zone = zone;
    };

    $scope.monthLine = function() {
      var id = $scope.selectedMonth.id;
      var tempSchedules = allSchedules;
      $scope.schedules = [];
      if (id === 'All') {
        $scope.schedules = allSchedules;
      } else {
        for (var p = 0; p < tempSchedules.length; p++) {
          var pdate = tempSchedules[p].ParseDate;
          var temp = pdate.split('-');
          temp[1] = stringFormatter(temp[1]);
          pdate = temp.join('-');
          var index = pdate.search(id);
          if (index !== -1) {
            $scope.schedules.push(tempSchedules[p]);
          }
        }
      }
    };

    //clear line
    $scope.lineClear = function() {
      $scope.date = null;
      $scope.day = null;
      $scope.timeslot = null;
      $scope.zone = null;
      $scope.gldate = null;
      $scope.focusSlot = false;
      $scope.focusDate = false;
      $scope.focusSlot = false;
      $scope.focusglDate = false;
    };

    //go to previous state
    $scope.goToPrevious = function() {
      $state.go('app.scheduleSummary');
    };

    //Select all check box
    $scope.selectAll = function() {
      var i;
      if($scope.selectAllSchedules) {
        for (i = 0; i < $scope.schedules.length; i++) {
          $scope.schedules[i].checked = true;
        }
        $scope.checkedCount = $scope.schedules.length;
      } else {
        for (i = 0; i < $scope.schedules.length; i++) {
          $scope.schedules[i].checked = false;
        }
        $scope.checkedCount = 0;
      }
      $scope.multipleCheckbox();
    };

    //multiple checkbox selection
    $scope.multipleCheckbox = function() {
      $scope.checkedCount = 0;
      for (var i = 0; i < $scope.schedules.length; i++) {
        if ($scope.schedules[i].checked === true) {
          if ($scope.schedules[i].hasOwnProperty('schedule_line_id')) {
            count = 1;
            deletedRows.push($scope.schedules[i].schedule_line_id);
          }
          $scope.checkedCount += 1;
        }
      }
    };

    //delete checkbox
    $scope.delete = function() {
      if ($scope.checkedCount > 0) {
        $scope.showDialog = true;
      }
    };

    // delete schedule lines
    function deleteLine(ids) {
      var endPoint = '/schedules/lines/';
      try {
        $httpHelper.httpRequest("POST", endPoint, ids, function(data) {
          if (data === null || data === undefined) {
            throw new Error('Server Error');
          } else {
            $scope.showSpinner = false;
            if (data.status === 1) {
              $scope.notifications.push({
                status: 1,
                msg: data.msg
              });
            }
            $scope.cancelModal();
          }
        });
      } catch (e) {
        $scope.showSpinner = false;
        $scope.notifications.push({
          status: 1,
          msg: e.message,
          details: '<pre>' + e.stack + '</pre>'
        });
      }
    }

    // delete schedule
    $scope.deleteRow = function() {
      var id = $scope.selectedMonth.id;
      if (id === 'All' && $scope.checkedCount > 0) {
        var lines = allSchedules;
        $scope.schedules = [];
        for (var i = 0; i < lines.length; i++) {
          if (lines[i].checked !== true) {
            $scope.schedules.push(lines[i]);
          }
        }
        allSchedules = $scope.schedules;
      } else if($scope.checkedCount > 0){
        var schedule_lines = $scope.schedules;
        $scope.schedules = [];
        for (var j = 0; j < schedule_lines.length; j++) {
          if (schedule_lines[j].checked !== true) {
            $scope.schedules.push(schedule_lines[j]);
          } else if (schedule_lines[j].checked === true) {
            var ind = allSchedules.map(function(x) {
              return x.uniqueLineId;
            }).indexOf(schedule_lines[j].uniqueLineId);
            if (ind !== -1) {
              allSchedules.splice(ind, 1);
            }
          }
        }
      }
      deleteId();
      $scope.cancelModal();
    };

    $scope.cancelModal = function() {
      $scope.showDialog = false;
      $scope.checkedCount = 0;
      deletedRows = [];
      $scope.nLine = false;
    };

    $('.scroll-top').click(function() {
      $appHelper.scrollTop();
    });

    function deleteId() {
      if (count === 1) {
        $scope.showSpinner = true;
        deleteLine(deletedRows);
      }
      return true;
    }

    // bottom line details
    function checkAddedLine() {
      if($scope.date && $scope.timeslot) {
        $scope.addLine();
      } else if($scope.date || $scope.timeslot) {
        window.scrollTo(0,document.body.scrollHeight);
        _this.lineValidation();
        return false;
      }
      return true;
    }

    $scope.copy = function (schedule, type) {
      $scope.pageDim = true;
      var endPoint = '/schedules/' + parseInt(schedule.header_id) + '/';
      $httpHelper.httpRequest('GET', endPoint, null, function(data) {
        if(data === null || data === undefined) {
          throw new Error("Server Error");
        } else {
          var copy = [];
          copy.push(data);
          copy.push(type);
          if(data) {
            $appHelper.scheduleCopy = copy;
            //$state.go('app.scheduleCreate');
            $state.go($state.current, {}, {
              reload: true
            });
          }
          $scope.pageDim = false;
        }
      });
    };


    // save schedule or update schedule
    $scope.save = function() {
      if (validations() && allSchedules.length > 0 && checkAddedLine()) {
        $scope.showSpinner = true;
        var schedule = {
          'SCHEDULE_NAME': $scope.scheduleName,
          'FREQUENCY': $scope.frequency,
          'EXCLUDE_WEEKEND': $scope.weekends,
          'DATE_FROM': $formatHelper.parseDate($scope.fromDate),
          'DATE_TO': $formatHelper.parseDate($scope.toDate),
          'TIME_SLOT1': $scope.scheduleTime.slot1,
          'TIME_SLOT2': $scope.scheduleTime.slot2 ? $scope.scheduleTime.slot2 : "",
          'TIME_SLOT3': $scope.scheduleTime.slot3 ? $scope.scheduleTime.slot3 : "",
          'TIME_SLOT4': $scope.scheduleTime.slot4 ? $scope.scheduleTime.slot4 : "",
          'CREATED_BY': user.user_id,
          'ORG_ID': $rootScope.orgId,
          'LAST_UPDATE_DATE': $appHelper.today(0)
        };
        if ($scope.type === 'edit') {
          schedule.SCHEDULE_HEADER_ID = $scope.schedule_header_id;
          schedule.CREATION_DATE = creation_date;
          schedule.TASK_ID = parseInt($scope.task_header_id);
        } else {
          schedule.CREATION_DATE = $appHelper.today(0);
          schedule.TASK_ID = parseInt($scope.task_header_name);
        }
        var lines = [];
        for (var i = 0; i < allSchedules.length; i++) {
          var line = {
            'RUN_DATE': $formatHelper.parseDate(allSchedules[i].RUN_DATE),
            'TIME_SLOT': allSchedules[i].TIME_SLOT,
            'GL_DATE': $formatHelper.parseDate(allSchedules[i].GL_DATE),
            'STATUS': allSchedules[i].STATUS,
            'ZONE': allSchedules[i].ZONE,
            'USER_ID':allSchedules[i].USER_ID,
            'CREATED_BY': user.user_id,
            'LAST_UPDATE_DATE': $appHelper.today(0)
          };
          if ($scope.type === 'edit') {
            line.SCHEDULE_LINE_ID = allSchedules[i].schedule_line_id;
            line.CREATION_DATE = creation_date;
          } else {
            line.CREATION_DATE = $appHelper.today(0);
          }
          lines.push(line);
        }
        schedule.lines = lines;
        var endPoint = '/schedules/';
        var method;
        var msg;
        if ($scope.type === 'edit') {
          method = 'PUT';
          msg = 'updated';
        } else {
          method = 'POST';
          msg = 'created';
        }
        $httpHelper.httpRequest(method, endPoint, schedule, function(data) {
          try {
            if (data === null || data === undefined) {
              throw new Error('Server Error');
            } else {
              $scope.showSpinner = false;
              if (data.status === 0) {
                if(gotoState) {
                  gotoState = false;
                  $scope.copy(data,'edit');
                } else {
                  $appHelper.scheduleSave = 'Schedule ' + $scope.scheduleName + ' ' + msg +' successfully';
                  $state.go('app.scheduleSummary');
                }
              } else {
                $scope.notifications.push({
                  status: 1,
                  msg: data.msg
                });
              }
            }
          } catch (e) {
            $scope.showSpinner = false;
          }
        });
      }
    };
  }
})();
