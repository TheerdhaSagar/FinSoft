/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 16-10-2018
 */

(function () {
    'use strict';

    angular.module('scorpion')
        .controller('DashboardController', DashboardController);

    function DashboardController($scope, $rootScope, $state, $cacheHelper, $window,
                                 $location, $httpHelper) {

        // google analytics code
        $scope.$on('$viewContentLoaded', function () {
            $window.ga('send', 'pageview', {page: $location.url()});
        });

        var user;
        $cacheHelper.getUser(function (data) {
            if (!data) {
                $state.go('login');
            } else {
                user = data;
                $scope.cards = [];                
                


                if ($rootScope.isAdmin || $rootScope.isDcOrgUI || $rootScope.isBenefitsOrgUI) {
                    $scope.cards.push({
                        name: 'Notifications', state: 'app.notifications', icon: 'notifications.png',
                        key: 'KEY_NOTIFICATIONS', title: 'KEY_NOTIFICATIONS_TITLE'
                    });
                }

                /*
                if (($rootScope.isAdmin) || $rootScope.UITasks) {
                    $scope.cards.push({
                        name: 'Tasks', state: 'app.tasksDashboard', icon: 'tasks.png',
                        key: 'KEY_TASKS', title: 'KEY_TASKS_TITLE'
                    });
                } */

                if ($rootScope.isAdmin || $rootScope.isUIBenefitsManager) {
                    $scope.cards.push({
                        name: 'Objectives', state: 'app.summarytasks', icon: 'objectives.png',
                        key: 'KEY_OBJECTIVES', title: 'KEY_OBJECTIVES_TITLE'
                    });
                }
               

                if ($rootScope.isAdmin || $rootScope.UILeaveManagement) {
                    $scope.cards.push({
                        name: 'Leave', state: 'app.leavemanagementdashboard', icon: 'leaves.png',
                        key: 'KEY_LEAVES', title: 'KEY_LEAVES_TITLE'
                    });
                }

                if ($rootScope.isAdmin || $rootScope.isUIBenefitsManager) {
                    $scope.cards.push({
                        name: 'Teams', state: 'app.teams', icon: 'team.png',
                        key: 'KEY_TEAMS', title: 'KEY_TEAMS_TITLE'
                    });
                } 

                if ($rootScope.isAdmin || $rootScope.isUIBenefitsManager) {
                    $scope.cards.push({
                        name: 'Schedules', state: 'app.scheduleSummary', icon: 'schedules.png',
                        key: 'KEY_SCHEDULES', title: 'KEY_SCHEDULES_TITLE'
                    });
                }

                if ($rootScope.isAdmin || $rootScope.isDcOrgUI) {
                    $scope.cards.push({
                        name: 'DC Automations', state: 'app.wfnautomation', icon: 'budget.png',
                        key: 'KEY_DC_WFN_AUTOMATIONS', title: 'KEY_DC_WFN_AUTOMATIONS_TITLE'
                    });
                }                

                if ($rootScope.isAdmin || $rootScope.UIUserManagement) {
                    $scope.cards.push({
                        name: 'User Management', state: 'app.users', icon: 'user_management.png',
                        key: 'KEY_USERMANAGEMENT', title: 'KEY_USERMANAGEMENT_TITLE'
                    });
                }

              if ($rootScope.isAdmin || $rootScope.isDcOrgUI || $rootScope.isBenefitsOrgUI) {
                $scope.cards.push({
                  name: 'Issue Tracker', state: 'app.issues', icon: 'briefcase.png',
                  key: 'KEY_ISSUE_TRACKER', title: 'KEY_ISSUE_TRACKER_TITLE'
                });
              }

              var cardRows = [], row = [];
                for (var i = 0; i < $scope.cards.length; i++) {
                    if (i > 0 && i % 4 === 0) {
                        cardRows.push(row);
                        row = [];
                    }
                    row.push($scope.cards[i]);
                }
                if (row && row.length > 0) {
                    cardRows.push(row);
                }

                $scope.cardRows = cardRows;
                loadNotificationCount();
            }
        });

        $scope.goToState = function (state) {
            if (state) {
                $state.go(state);
            } else {
                $window.open('http://10.6.4.17/DT_India/dc_quickquey_test');
            }
        };

        function loadNotificationCount() {
            var endPoint = '/users/notifications/count/' + user.user_id + '/';
            $httpHelper.httpRequest('GET', endPoint, null, function (data) {
                if (data === null || data === undefined) {
                    throw new Error('Server Error');
                } else {
                    if (data && data.length > 0) {
                        $scope.notificationCount = data[0].open_count;
                    }
                }
            });
        }

    }
})();
