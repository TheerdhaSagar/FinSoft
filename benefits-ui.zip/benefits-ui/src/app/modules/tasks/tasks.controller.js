/*
 * Author: Theerdha sagar Nimmagadda
 * Date: 24-10-2018
 */

(function () {
  'use strict';

  angular.module('scorpion')
    .controller('SummaryTasksController', SummaryTasksController);

  function SummaryTasksController($scope, $window, $location, $cacheHelper, $state,
                                     $appHelper, $httpHelper, $filter, $rootScope) {

    // google analytics code
    $scope.$on('$viewContentLoaded', function () {
      $window.ga('send', 'pageview', {
        page: $location.url()
      });
    });

    var deleteLine, user, sortData = [];
    $scope.tasks = [];
    $scope.predicate = ['task_header_id'];
    $scope.desc = true;

    // get user
    $cacheHelper.getUser(function (data) {
      if (!data) {
        $state.go('login');
      } else {
        if (!$cacheHelper.user) {
          $cacheHelper.initialize(data);
        }
        $scope.toggleFilter = $appHelper.toggleFilter();
        user = data;
        loadTasks();
      }
    });

    $scope.$watch(function() {
      return $rootScope.orgId;
    }, function(newValue, oldValue) {
      if (newValue !== oldValue) {
        $state.go($state.current, {}, {
          reload: true
        });
      }
    });

    function loadTasks() {
      var endPoint = '/tasks/headers/' + $rootScope.orgId + '/';
      $scope.pageDim = true;
      try {
        $httpHelper.httpRequest('GET', endPoint, null, function (data) {
          if (data === null || data === undefined) {
            throw new Error("Server Error");
          } else {
            if (data.status === 1) {
              $scope.notifications.push({ status: 1, msg: data.msg });
            } else {
              $scope.tasks = data.result;
              $scope.pageDim = false;
            }
          }
        });
      } catch (e) {
        $scope.notifications.push({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
        $scope.pageDim = false;
      }
    }

    $scope.editTasks = function(task) {
      $appHelper.taskHeaderId = task.task_header_id;
      $state.go('app.createcustomerobjectives');
    };


    $scope.delete = function (schedule) {
      deleteLine = schedule.task_header_id;
      $scope.showDialog = true;
    };

    $scope.deleteRow = function () {
      $scope.showDialog = false;
      $scope.showSpinner = true;
      try {
        var endPoint = '/tasks/headers/' + deleteLine + '/';
        $httpHelper.httpRequest("DELETE", endPoint, null, function (data) {
          if (data === null || data === undefined) {
            throw new Error("Server Error");
          } else {
            if (data.status === 0) {
              var index = $scope.tasks.map(function (x) { return x.task_header_id; }).indexOf(deleteLine);
              if (index !== -1) {
                $scope.tasks.splice(index, 1);
                $scope.notifications.push({ status: 0, msg: data.msg });
              }
            } else if (data.status === 1) {
              $scope.notifications.push({ status: 1, msg: data.msg });
            }
            $scope.showSpinner = false;
          }
        });
      } catch (e) {
        $scope.notifications.push({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    };

    //sort Functionality
    $scope.sort = function (key) {
      $scope.desc = !$scope.desc;
      $scope.predicate = key;
      sortData = $filter('orderBy')($scope.tasks, $scope.predicate, $scope.desc);
    };

    $scope.cancelModal = function () {
      deleteLine = '';
      $scope.showDialog = false;
    };

    // goto schedule create page
    $scope.create = function () {
      $state.go('app.createcustomerobjectives');
    };

    $(window).scroll(function () {
      $('.scroll-table thead').css({
        top: (window.scrollY - 71) + 'px'
      });
    });
  }
})();
