/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 07-11-2018
 */

(function() {
  'use strict';

  angular.module('scorpion')
    .controller('CreateObjectivesController', CreateObjectivesController);

  function CreateObjectivesController($scope, $state, $appHelper, $cacheHelper, $window,
    $location, $httpHelper, $rootScope, $formatHelper) {

    // google analytics code
    $scope.$on('$viewContentLoaded', function() {
      $window.ga('send', 'pageview', {
        page: $location.url()
      });
    });

    var user;
    var _this = this;
    var sum_hours = 0;
    var deleted_lines = [];
    var deleted_attachments = [];
    $scope.desc = false;
    $scope.attachments = [];
    $scope.budgets = [];
    $scope.budgetDialog = false;
    $scope.focusInvoiceFrequency = false;
    $scope.focusFromPeriod  = false;
    $scope.focusDocumentCreated = false;
    $scope.focusSubtask = false;
    $scope.focusGroup = false;
    $scope.focusTaskTime = false;
    $scope.focusDescription = false;
    $scope.focusTask_weight = false;
    $scope.focusHeader = false;
    $scope.focusHeaderDescription = false;
    $scope.task_header = '';
    $scope.subtask = '';
    $scope.description = '';
    $scope.task_time = '';
    $scope.task_weight = '';
    $scope.total_hours = 0; 
    $scope.total_minutes = 0; 
    $scope.deleteDialog = false;
    $scope.line_number = 0;
    $scope.header_description='';
    $scope.copy_objective = false;
    $scope.edit_objective = false;
    $scope.target_group = 'Yes'; 
    $scope.task_weight_lov = [{
      id: 1,
      label: 'No Priority -1'
    }, {
      id: 2,
      label: 'Low Priority - 2'
      }, {
        id: 3,
        label: 'Medium Priority - 3'
    }, {
      id: 4,
      label: 'High Priority - 4'
      }, {
        id: 5,
        label: 'Urgent - 5'
      }];

    $scope.$watch(function() {
      return $rootScope.orgId;
    }, function(newValue, oldValue) {
      if (newValue !== oldValue) {
        if ($scope.edit_objective || $scope.copy_objective) {
          $state.go('app.customerobjectives');
        }
        $scope.currentStep = 1;
      }
    });

    $cacheHelper.getUser(function(data) {
      if (!data) {
        $state.go('login');
      } else {
        if (!$cacheHelper.user) {
          $cacheHelper.initialize(data);
        }
        user = data;
        $scope.toggleFilter = $appHelper.toggleFilter();
        $scope.userDateFormat = user.date_format;
        if (user.number_format) {
          $scope.no_format = user.number_format;
        } else {
          $scope.no_format = '999,999.99';
        }
        if ($rootScope.fromState && $rootScope.fromState.name === 'app.summarytasks') {
          var task_header_id;
          if ($appHelper.taskHeaderId) {
            task_header_id = $appHelper.taskHeaderId;
            $appHelper.taskHeaderId = '';
            $scope.showSpinner = true;
            $scope.edit_objective = true;
            editObjective(task_header_id);
          }
        }
        $scope.stepCount = 3;
        $scope.currentStep = 1;
        $scope.steps = [
          {
            step_number: 1,
            step_name: 'Task Header'
          },
          {
            step_number: 2,
            step_name: 'Sub Task'
          },
          {
            step_number: 3,
            step_name: 'Preview & Save'
          }
        ];
        // $scope.showSpinner = true;
      }
    });

    $scope.moveToSummary = function() {
      $state.go('app.customerobjectives');
    };

    _this.setDescription = function(data, key, type) {
      var index;
      if (data.length > 0) {
        index = data.map(function(x) {
          if (type === 'targets') {
            return parseInt(x.target_base_header_id);
          } else {
            return x.detail_name;
          }
        }).indexOf(key);
        return index;
      } else {
        return -1;
      }
    };

    function editObjective(task_header_id) {
      var i;
      var endPoint = '/tasks/lines/' + task_header_id + '/';
      $httpHelper.httpRequest('GET', endPoint, null, function(data) {
        try {
          if (data === null || data === undefined) {
            throw new Error('Server Error');
          } else {
            $scope.showSpinner = false;
            if (data.status === 1) {
              $scope.notifications.push({msg: data.msg, status: data.status});
            } else {
              data = data.result[0];
              $scope.task_header_id = data.task_header_id;
              $scope.attachments = [];
              if (data.attachments.length > 0) {
                for (i = 0; i < data.attachments.length; i++) {
                  var attachment = {};
                  attachment.base64 = data.attachments[i].file_data;
                  attachment.filetype = data.attachments[i].file_content_type;
                  attachment.filename = data.attachments[i].file_name;
                  attachment.file_id = data.attachments[i].file_id;
                  $scope.attachments.push(attachment);
                }
              }
              if (data.task_lines.length > 0) {
                $scope.budgets = [];
                for (i = 0; i < data.task_lines.length; i++) {
                  var budget = {};
                  $scope.task_header = data.task_header_name;
                  $scope.header_description=data.task_header_desc;
                  budget.line_id=data.task_lines[i].task_line_id;
                  budget.subtask=data.task_lines[i].task_name;
                  budget.description=data.task_lines[i].task_description;
                  budget.task_hours=data.task_lines[i].task_hours;
                  budget.task_minutes=data.task_lines[i].task_minutes;
                  budget.task_time=parseInt(data.task_lines[i].task_hours) + (parseInt(data.task_lines[i].task_minutes)) / 100;
                  budget.task_weight=data.task_lines[i].task_weight ? parseInt($formatHelper.formatNumber(data.task_lines[i].task_weight)) : '';
                  $scope.budgets.push(budget);
                }
              }
              $scope.showSpinner = false;
            }
          }
        } catch (e) {
          $scope.notifications.push({msg: e.message, status: 1, details: '<pre>' + e.stack + '</pre>'});
        }
      });
    }
    loadHoursMinutes();

    $scope.closeDialog = function() {
      $scope.focusSubtask = false;
      $scope.focusSubTask = false;
      $scope.focusDescription = false;
      $scope.focusTaskTime = false;
      $scope.subtask = '';
      $scope.budget_description = '';
      $scope.sub_task = '';
      $scope.target_base_id = '';
      $scope.description = '';
      $scope.task_time = '';
      $scope.bonus_reimburse_type = '';
      $scope.subTask = false;
      $scope.edit = false;
      $scope.index = '';
    };

    $scope.uploadAttachment = function(attachment) {
      $scope.attachments.push(attachment);
    };

    $scope.delete = function(index, type) {
      if (index !== '' && index !== undefined) {
        $scope.line_index = index;
        $scope.type = type;
        $scope.deleteDialog = true;
      } else {
            if ($scope.type === 'line') {
          if ($scope.budgets[$scope.line_index].line_id) {
            deleted_lines.push($scope.budgets[$scope.line_index]);
          }

          if ($scope.total_minutes > $scope.budgets[$scope.line_index].task_minutes) {
            $scope.total_hours = $scope.total_hours - $scope.budgets[$scope.line_index].task_hours;
            $scope.total_minutes = $scope.total_minutes - $scope.budgets[$scope.line_index].task_minutes;
          }
          else {
            $scope.total_hours = $scope.total_hours - $scope.budgets[$scope.line_index].task_hours -1 ;
            $scope.total_minutes = $scope.total_minutes + 60 - $scope.budgets[$scope.line_index].task_minutes;
          }


          $scope.budgets.splice($scope.line_index, 1);
        } else if ($scope.type === 'attachment') {
          if ($scope.attachments[$scope.line_index].file_id) {
            deleted_attachments.push({file_id: $scope.attachments[$scope.line_index].file_id});
          }
          $scope.attachments.splice($scope.line_index, 1);
        }
        $scope.deleteDialog = false;
      }
    };

    function validateStepOne() {
      if (!$scope.task_header) {
        $scope.focusHeader = true;
        $scope.notifications.push({ msg: 'Enter Task Name', status: 1 });
        return false;
      }
      if (!$scope.header_description) {
        $scope.focusHeaderDescription = true;
        $scope.notifications.push({ msg: 'Enter Task Description', status: 1 });
        return false;
      }      
      return true;      
    }

    function validateStepTwo() {
      if ($scope.budgets.length === 0) {
        $scope.notifications.push({msg: 'Add atleast one sub task', status: 1});
        return false;
      }
        return true;
    }

    $scope.changeStep = function(step_number) {
/*      if (($scope.edit_objective || $scope.copy_objective)) {
        return;
      }*/
      if (step_number && $scope.currentStep > step_number) {
        $scope.currentStep = step_number;
        return;
      }
      if ($scope.currentStep === 1) {
        if (!validateStepOne()) {
          return;
        }
      } else if ($scope.currentStep === 2) {
        if (!validateStepTwo()) {
          return;
        }
      }

//      obj.task_minutes = $scope.task_minutes;
      if (step_number === 3 || $scope.currentStep === 2) {
        var i, sum_mins, task_mins_quotent, task_mins_reminder;
        sum_hours = 0;
        sum_mins = 0;
        task_mins_reminder = 0;
        task_mins_quotent = 0;
        for (i = 0; i < $scope.budgets.length; i++) {
          sum_hours = parseInt($scope.budgets[i].task_hours) + sum_hours;
          sum_mins = parseInt($scope.budgets[i].task_minutes) + sum_mins;
        }

        if (sum_mins > 60){
          task_mins_quotent = parseInt(sum_mins/60);
          task_mins_reminder = sum_mins % 60;
        }
        else{
          task_mins_reminder = sum_mins;
        }
        $scope.total_hours = sum_hours + task_mins_quotent;
        $scope.total_minutes = task_mins_reminder;
      }

      if (step_number) {
        if (step_number === 3 && $scope.budgets.length === 0) {
          $scope.notifications.push({msg: 'Add atleast one budget in step 2', status: 1});
          return;
        }
        $scope.currentStep = step_number;
      } else {
        $scope.currentStep = $scope.currentStep + 1;
      }
    };

    function validateBudget() {
      if (!$scope.subtask) {
        $scope.focusSubtask = true;
      }

      if (!$scope.description) {
        $scope.focusBudgetDescription = true;
      }

      if (!$scope.task_weight) {
        $scope.focusTask_weight = true;
      }
      return ($scope.subtask && $scope.description && $scope.task_weight);
    }    


    $scope.validateNumber = function () {
      if ($scope.task_time) {
        $scope.task_time = $formatHelper.numberParser($scope.task_time);
      }
    };
    $scope.addBudget = function() {
      var obj = {};
      if (validateBudget()) {
        if ($scope.edit && ($scope.index !== '' || $scope.index !== undefined)) {
          $scope.budgets[$scope.index].subtask = $scope.subtask;
          $scope.budgets[$scope.index].description = $scope.description; //detail_description
          $scope.budgets[$scope.index].task_weight = $scope.task_weight; //task weight
          $scope.budgets[$scope.index].task_hours = $scope.task_hours; //task hours
          $scope.budgets[$scope.index].task_minutes = $scope.task_minutes; //task weight
          $scope.budgets[$scope.index].task_time = parseInt($scope.task_hours) + (parseInt($scope.task_minutes)) / 100;
          $scope.index = '';
          $scope.edit = false;
        } else {
          for(var i =0; i < $scope.budgets.length; i++){
            if($scope.budgets[i].subtask === $scope.subtask){
              $scope.notifications.push({msg: 'Cannot have same sub-task name', status: 1});
              return;
            }
          }
          obj.subtask = $scope.subtask;
          obj.description = $scope.description;
          obj.task_time = $scope.task_time;
          obj.task_hours = $scope.task_hours;
          obj.task_minutes = $scope.task_minutes;
          obj.task_time = parseInt($scope.task_hours) + (parseInt($scope.task_minutes))/100; 
          obj.task_weight = $scope.task_weight;
          $scope.budgets.push(obj);
        }
        $scope.closeDialog();
      }
    };    

    $scope.editBudget = function(index) {
      $scope.openDialog();
      $scope.subtask = $scope.budgets[index].subtask;
      $scope.description = $scope.budgets[index].description;
      $scope.task_hours = $scope.budgets[index].task_hours.toString();
      $scope.task_minutes = $scope.budgets[index].task_minutes.toString();
      $scope.task_time = parseInt($scope.task_hours) + (parseInt($scope.task_minutes)) / 100;
      $scope.task_weight = $scope.budgets[index].task_weight;
      $scope.edit = true;
      $scope.index = index;
      $scope.budgetDialog = true;
    };

    $scope.saveObjective = function() {
      var result = {};
      var i;
      if ($scope.edit_objective) {
        result.deleted_lines = deleted_lines;
        result.deleted_attachments = deleted_attachments;
        result.task_header_id = $scope.task_header_id;
       }
       if ($scope.budgets.length === 0) {
         $scope.notifications.push({msg: 'Add atleast one budget in step 2', status: 1});
         return;
       }

       result.total_time = $scope.total_hours * 60 + $scope.total_minutes;
       result.task_header = $scope.task_header;
       result.status = 'A';
       result.team_id = $rootScope.orgId;
       result.user_id = user.user_id;
       result.header_description = $scope.header_description;
       result.attachments = [];
       if($scope.attachments.length > 0) {
         for (i = 0; i < $scope.attachments.length; i++) {
           if ($scope.edit_objective && $scope.attachments[i].file_id) {
             continue;
           }
           var attachment = {};
           attachment.file_blob = $scope.attachments[i].base64;
           attachment.title = $scope.task_header;
           attachment.file_name = $scope.attachments[i].filename;
           attachment.content_type = $scope.attachments[i].filetype;
           attachment.entity_name = 'tasks';
           attachment.category_name = 'internal';
           attachment.description = 'task manager';
           result.attachments.push(attachment);
         }
       }
      result.org_id = $rootScope.orgId.toString();
      if (!$scope.edit_objective) {
        result.created_by = user.user_id;
        result.creation_date = $appHelper.today(0);
      }
      result.last_updated_date = $appHelper.today(0);
      result.last_updated_by = user.user_id;


      result.budget = [];
      for (i = 0; i < $scope.budgets.length; i++) {
        var line = {};
        line.line_id=$scope.budgets[i].line_id;
        line.subtask = $scope.budgets[i].subtask;
        line.description = $scope.budgets[i].description;
        line.task_hours = $scope.budgets[i].task_hours;
        line.task_minutes = $scope.budgets[i].task_minutes;        
        line.task_weight = $scope.budgets[i].task_weight;

        if (!$scope.edit_objective) {
          line.creation_date = $appHelper.today(0);
          line.created_by = user.user_id;
        }
        line.last_updated_date = $appHelper.today(0);
        line.last_updated_by = user.user_id;
        line.start_date = $scope.budgets[i].start_date ? $formatHelper.parseDate($scope.budgets[i].start_date) : '';
        line.end_date = $scope.budgets[i].end_date ? $formatHelper.parseDate($scope.budgets[i].end_date) : '';
        result.budget.push(line);
      }      
      $scope.showSpinner = true;
      var endPoint = '/tasks/header/add/';
      var method = $scope.edit_objective ? 'PUT' : 'POST';
      $httpHelper.httpRequest(method, endPoint, result, function (data){
        try {
          if (data === null || data === undefined) {
            throw new Error('Server Error');
          } else {
            if (data.status === 1) {
              $scope.notifications.push({msg: data.msg, status: data.status});
            }
            else{
              $scope.notifications.push({msg: data.msg, status: data.status});
              $state.go('app.summarytasks');
            }

          }
          $scope.showSpinner = false;
        } catch (e) {
            $scope.notifications.push({msg: e.message, status: 1, details: '<pre>' + e.stack + '</pre>'});
            $scope.showSpinner = false;
        }
      });
    };

    $scope.moveToSummary = function() {
      $state.go('app.summarytasks');
    };

    $scope.openDialog = function() {
      $scope.subTask = true;
      $scope.target_group = 'Yes';
      $scope.from_date = $scope.from_period || '';
      $scope.to_date = $scope.to_period || '';
      $scope.subtask = '';
      $scope.description = '';
      $scope.task_hours = '';
      $scope.task_minutes = '';
      $scope.task_weight = '';   
    };

    $scope.downloadAttachment = function(attachment) {
      var blobFile = $formatHelper.base64ToBlob(attachment.base64 || attachment.file_content),
        url;
      if (blobFile) {
        var a = document.createElement('a');
        document.body.appendChild(a);
        url = $window.URL.createObjectURL(blobFile);
        a.href = url;
        a.download = attachment.filename || attachment.file_name;
        a.click();
        $window.URL.revokeObjectURL(url);
      }
    };

    $scope.onDownload = function(attachment, event) {
      event.stopPropagation();
      if (attachment.file_content) {
        $scope.downloadAttachment(attachment);
        return;
      }
      $scope.showSpinner = false;
      /* to service */
      if (attachment.file_id) {
        var endPoint = '/tasks/attachment/' + attachment.file_id + '/';
        $httpHelper.httpRequest('GET', endPoint, null, function (data) {
          try {
            if (data === null || data === undefined) {
              $scope.notifications.push({msg: data.msg, status: data.status});
            } else {
              if (data.status === 1) {
                $scope.notifications.push({msg: data.msg, status: data.status});
              } else {
                attachment.base64 = data[0].file_content;
                $scope.downloadAttachment(attachment);
              }
            }
            $scope.showSpinner = false;
          } catch (e) {
            $scope.notifications.push({msg: e.message, status: 1, details: '<pre>' + e.stack + '</pre>'});
          }
        });
      }
    };

    function loadHoursMinutes() {
      var i;
      $scope.minutes = ['00', '10', '20', '30', '40', '50'];

      // No.of hours LOV
      $scope.hours = [];

      for (i = 0; i < 20; i++) {
        $scope.hours.push(i.toString());
      }


    }

  }
})();
