/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 10-10-2018
 */

(function() {
  'use strict';

  describe('controller ConversionController', function() {
    var $cacheHelper, $controller, $rootScope, $scope;

    beforeEach(module('scorpion'));
    beforeEach(inject(function(_$cacheHelper_, _$controller_, _$rootScope_) {
      $cacheHelper = _$cacheHelper_;
      $controller = _$controller_;
      $rootScope = _$rootScope_;
      $scope = $rootScope.$new();
      $controller = $controller('ConversionController', {
        $scope: $scope
      });

      $cacheHelper.setUser({
        user_id: 1,
        user_name: 'Reddy',
        user_description: 'Reddy Bhimireddy',
        number_format: '999,999.99',
        date_format: 'dd/MM/yyyy'
      });
    }));

    it('should be defined', function() {
      expect($controller).toBeDefined();
    });

    describe('$scope.validateRate function', function() {
      it ('should set focusRate to true if entered rate is not in number_format', function() {
        $scope.rate = '1,23';
        $scope.validateRate();
        expect($scope.focusRate).toBeTruthy();
        expect($scope.rate).toEqual('');
      });
    });

    describe('checkDuplicate function', function() {
      var result;
      var year = 2016;
      var currency = "CAD";

      it ('should return true if exchange with same currency and year already exist', function() {
        $scope.conversion = [
          { "currency_code": "USD", "rate": 1.116, "year": 2016 },
          { "currency_code": "GBP", "rate": 0.778, "year": 2016 },
          { "currency_code": "CHF", "rate": 1.096, "year": 2016 },
          { "currency_code": "CAD", "rate": 1.09, "year": 2016 }
        ];
        result = $controller.checkDuplicate(year, currency);
        expect(result).toBeTruthy();
      });
    });

  });
})();
