/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 10-10-2018
 */

(function() {
  'use strict';

  angular.module('scorpion')
    .controller('ConversionController', ConversionController);

  function ConversionController($scope, $window, $location, $cacheHelper, $state,
    $httpHelper, $formatHelper, $filter, $appHelper, $rootScope) {

    // google analytics code
    $scope.$on('$viewContentLoaded', function() {
      $window.ga('send', 'pageview', {
        page: $location.url()
      });
    });

    var user;
    var _this = this;
    $scope.deleteCurrency = false;


    $cacheHelper.getUser(function(data) {
      if (!data) {
        $state.go('login');
      } else {
        if (!$cacheHelper.user) {
          $cacheHelper.initialize(data);
        }
        user = data;
        if (user.number_format) {
          $scope.no_format = user.number_format;
        } else {
          $scope.no_format = '999,999.99';
        }

        $scope.$watch(function() {
          return $rootScope.orgId;
        }, function(newValue, oldValue) {
          if (newValue !== oldValue) {
            $scope.conversion = '';
            loadLov();
          }
        });
        loadLov();
      }
    });


    function loadLov() {
      $scope.showSpinner = true;
      var endPoint = '/utilities/currencies/';
      $httpHelper.httpRequest('GET', endPoint, null, function(data) {
        try {
          if (data === null || data === undefined) {
            throw new Error('Server Error');
          } else {
            $scope.currencies = data;
          }
          loadData();

        } catch (e) {
          $scope.showSpinner = false;
          $scope.notifications.push({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>'
          });
        }
      });
    }

    _this.checkDuplicate = function(year, currency) {
      if ($scope.conversion.length > 0) {
        for (var i = 0; i < $scope.conversion.length; i++) {
          if (parseInt($scope.conversion[i].year) === parseInt(year) && $scope.conversion[i].currency_code === currency &&
              (!$scope.edit || !($scope.edit && i === parseInt($scope.index)))) {
            return true;
          }
        }
      } else {
        return false;
      }
      return false;
    };

    function loadData() {
      $scope.showSpinner = true;
      var endPoint = '/utilities/exchange/';
      $httpHelper.httpRequest('GET', endPoint, null, function(data) {
        try {
          if (data === null || data === undefined) {
            throw new Error('Server Error');
          } else {
            if (data) {
              for (var i = 0; i < data.length; i++) {
                data[i].f_rate = $formatHelper.formatNumber(data[i].rate, 3);
              }
              $scope.conversion = data;
              $scope.showSpinner = false;
            }
          }
        } catch (e) {
          $scope.showSpinner = false;
          $scope.notifications.push({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>'
          });
        }
      });
    }

    $scope.$watch('year', function(year) {
      $scope.year = parseInt(year) > 0 ? parseInt(year) : '';
    });

    $scope.newCurrency = function() {
      $scope.showExchangeDialog = true;
      $scope.edit = false;
      $scope.dialogmsg = '';
      $scope.year = '';
      $scope.rate = '';
      $scope.f_rate = '';
      $scope.currency = '';
    };

    $scope.validateRate = function() {
      var result = $formatHelper.validatePattern($scope.rate.toString(), 3);
      if (result) {
        $scope.f_rate = $formatHelper.parseNumber($scope.rate);
      } else {
        $scope.rate = '';
        $scope.f_rate = '';
        $scope.rate_msg = 'Enter rate in ' + $scope.no_format + ' format';
        $scope.focusRate = true;
      }
    };

    $scope.onDelete = function(d) {
      $scope.deleteCurrency = true;
      $scope.deleteYear = d.year;
      $scope.deletecurrency = d.currency_code;
    };

    $scope.onDeleteCurrency = function() {
      $scope.showSpinner = true;
      $scope.deleteCurrency = false;
      var dict = {};
      dict.year = parseInt($scope.deleteYear);
      dict.currency = $scope.deletecurrency;
      var endPoint = '/utilities/exchange/';
      $httpHelper.httpRequest('DELETE', endPoint, dict, function(data) {
        try {
          if (data === null || data === undefined) {
            $scope.showSpinner = false;
            throw new Error('Server Error');
          } else {
            if (data.hasOwnProperty('status')) {
              $scope.notifications.push({status: data.status, msg: data.msg});
              if (data.status === 0) {
                $scope.deletecurrency = '';
                $scope.deleteYear = '';
                loadLov();
              } else {
                $scope.showSpinner = false;
              }
            }
          }
        } catch (e) {
          $scope.showSpinner = false;
          $scope.notifications.push({status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>'});
        }
      });
    };

    $scope.onEdit = function(d) {
      $scope.dialogmsg = '';
      $scope.year = d.year;
      $scope.currency = d.currency_code;
      $scope.rate = d.f_rate;
      $scope.f_rate = d.rate;
      $scope.showExchangeDialog = true;
      $scope.edit = true;
      $scope.index = $scope.conversion.indexOf(d);
    };

    $scope.onUpdate = function() {
      $scope.showSpinner = true;
      var dict = {};
      dict.condition = $scope.currency;
      if ($scope.rate && $scope.year) {
        dict.year = $scope.year;
        dict.rate = $scope.f_rate;
      } else {
        if (!$scope.year) {
          $scope.focusYear = true;
        }
        if (!$scope.rate) {
          $scope.focusRate = true;
          $scope.rate_msg = 'Rate is required';
        }
        $scope.showSpinner = false;
        return;
      }
      var validate_update = _this.checkDuplicate($scope.year, $scope.currency);
      if (!validate_update) {
        $scope.showExchangeDialog = false;
          var endPoint = '/utilities/exchange/';
          $httpHelper.httpRequest('PUT', endPoint, dict, function(data) {
            try {
              if (data === null || data === undefined) {
                $scope.showSpinner = false;
                throw new Error('Server Error');
              } else {
                if (data.hasOwnProperty('status')) {
                  $scope.notifications.push({status: data.status, msg: data.msg});
                  updateVariables();
                  if (data.status === 0) {
                    loadLov();
                  }
                }
              }
            } catch (e) {
              $scope.showSpinner = false;
              $scope.notifications.push({status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>'});
            }
          });
        } else {
          $scope.year = '';
          $scope.focusYear = true;
          $scope.dialogmsg = 'Exchange with same year and currency are not allowed';
          $scope.status = 1;
          $scope.showSpinner = false;
          return false;
        }
    };

    function updateVariables () {
      $scope.year = '';
      $scope.currency = '';
      $scope.rate = '';
      $scope.f_rate = '';
      $scope.focusYear = false;
      $scope.focusRate = false;
      $scope.rate_msg = '';
      $scope.focusCurrency = false;
      $scope.edit = false;
      $scope.dialogmsg = '';
      $scope.showExchangeDialog = false;
    }

    $scope.onCancel = function() {
      updateVariables();
    };


    $scope.onSave = function() {
      $scope.showSpinner = true;
      var dict = {};
      var currencyflag;
      var j;
      if ($scope.year && $scope.currency && $scope.rate) {
        dict.year = parseInt($scope.year);
        if ($scope.currency) {
          currencyflag = 0;
          for (j = 0; j < $scope.currencies.length; j++) {
            if ($scope.currency === $scope.currencies[j].currency_code) {
              currencyflag = 1;
              break;
            }
          }
          if (currencyflag === 0) {
            $scope.focusCurrency = true;
            $scope.currency = '';
            $scope.showSpinner = false;
            return;
          }
        }
        dict.currency = $scope.currency;
        dict.rate = $scope.f_rate;


      } else {
        if (!$scope.year) {
          $scope.focusYear = true;
        }
        if (!$scope.rate) {
          $scope.focusRate = true;
          $scope.rate_msg = 'Rate is required';
        }

        if (!$scope.currency) {
          $scope.focusCurrency = true;
        }
        $scope.showSpinner = false;
        return;
      }
      var tmp_duplicate = _this.checkDuplicate($scope.year, $scope.currency);
      if (!tmp_duplicate) {
        $scope.showExchangeDialog = false;
        var endPoint = '/utilities/exchange/';
        $httpHelper.httpRequest('POST', endPoint, dict, function(data) {
          try {
            if (data === null || data === undefined) {
              $scope.showSpinner = false;
              throw new Error('Server Error');
            } else {
              if (data.hasOwnProperty('status')) {
                $scope.notifications.push({status: data.status, msg: data.msg});
                updateVariables();
                if (data.status === 0) {
                  loadLov();
                }
              }
            }
          } catch (e) {
            $scope.showSpinner = false;
            $scope.notifications.push({status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>'});
          }
        });
      } else {
        $scope.year = '';
        $scope.currency = '';
        $scope.focusYear = true;
        $scope.focusCurrency = true;
        $scope.dialogmsg = 'Exchange with same year and currency not allowed';
        $scope.status = 1;
        $scope.showSpinner = false;
      }
    };

    $scope.toggleFilter = $appHelper.toggleFilter();

    $scope.predicate = 'year';
    $scope.desc = true;

    // Table sorting
    $scope.sort = function(key) {
      if ($scope.predicate === key) {
        $scope.desc = !$scope.desc;
      } else {
        $scope.predicate = key;
      }
      if ($scope.searchQuery && $scope.searchQuery.length > 0) {
        var tmpData = $filter('orderBy')($scope.conversion, $scope.predicate, $scope.desc);
        $scope.conversion = tmpData;
      } else {
        $scope.conversion = $filter('orderBy')($scope.conversion, $scope.predicate, $scope.desc);
      }
    };

    // Exports the table data into spreadsheet
    $scope.export = function() {
      $scope.toggleFilter();
      var data = $filter('orderBy')($scope.conversion, $scope.predicate, $scope.desc);
      var tableData = {};
      var tmpData = [];
      for (var i = 0; i < data.length; i++) {
        var tmpObj = {};
        tmpObj.Year = {
          data: data[i].year
        };
        tmpObj.Currency = {
          data: data[i].currency_code
        };
        tmpObj.Rate = {
          data: data[i].rate,
          align: 'right'
        };
        tmpData.push(tmpObj);
      }
      tableData.data = tmpData;
      $appHelper.tableToExcel('Exchange', tableData, 'export-data');
    };

  }

})();
