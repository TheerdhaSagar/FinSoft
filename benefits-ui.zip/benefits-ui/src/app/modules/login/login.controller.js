/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 10-10-2018
 */

(function () {
  "use strict";
  angular.module("scorpion").controller("LoginController", LoginController);

  function LoginController(
    $scope,
    $window,
    $location,
    $httpHelper,
    $state,
    $cacheHelper,
    $rootScope,
    $compile,
    $stateParams,
    $appHelper
  ) {
    // google analytics code
    $scope.$on("$viewContentLoaded", function () {
      $window.ga("send", "pageview", {
        page: $location.url(),
      });

      $scope.isChrome = $appHelper.isChrome();
    });

    $scope.loginContainer = true;
    // Token will be passed as parameter for reset password state
    var token = $stateParams.token,
      user;
    // If there is token in request then get the user details based on token
    if (token) {
      $scope.loginContainer = false;
      $scope.resetContainer = true;
      $scope.passwordPolicy = true;
      $httpHelper.postRequest(
        "/login/details/",
        { key_val: token },
        function (data) {
          if (data && data.status === 0) {
            user = data;
          }
        }
      );
    }

    $scope.login = function () {
      if ($scope.username && $scope.password) {
        var endPoint = "/login/";

        var credentials = {
          user_name: $scope.username.trim(),
          password: $scope.password.trim(),
          source: "C",
        };

        // adds a loading indicator to login button
        $("#login").html($compile("<spinner></spinner>")($scope));

        $httpHelper.postRequest(endPoint, credentials, function (data) {
          try {
            if (data === null || data === undefined) {
              throw new Error("Server Error");
            } else {
              if (data.hasOwnProperty("status")) {
                $scope.status = data.status;
                $scope.msg = data.msg;
                $("#login").html("LOGIN");
                return;
              }

              $scope.change_flag = data.result.password_change_on_login;

              // Store user related data in localStorage
              $cacheHelper.setUser(data.result);
              // Store the Auth token and refresh token
              // in cookies
              $cacheHelper.setToken(data.token);
              $cacheHelper.setRefreshToken(data.refresh_token);

              // Store user organizations
              $cacheHelper.setOrgList(data.result.organizations);
              $cacheHelper.setTimeZone(data.result.time_zone);
              $cacheHelper.setGroupList(data.result.groups);
              if (
                data.result.organizations &&
                data.result.organizations.length > 0
              ) {
                var defaultOrg = data.result.default_org_id;
                if (defaultOrg === null) {
                  $cacheHelper.setOrgId(
                    data.result.organizations[0].organization_id
                  );
                } else {
                  $cacheHelper.setOrgId(data.result.default_org_id);
                }
                $cacheHelper.setOldOrgId($cacheHelper.getOrgId());
                $rootScope.ledger_id =
                  data.result.organizations[0].set_of_books_id;
              }
              if ($scope.change_flag === "Y") {
                $scope.loginContainer = false;
                $scope.resetContainer = true;
                $("#login").html("LOGIN");
                return;
              }

              $scope.clear();
              var index = -1,
                redirectUri;
              if (
                $location.search() &&
                $location.search().hasOwnProperty("redirectUri")
              ) {
                redirectUri = $location.search().redirectUri;
                if (redirectUri === "app.manageapplication") {
                  $appHelper.requestHeaderId = $location.search().id;
                  $state.go(redirectUri);
                  return;
                }
              } else if (data.result.permissions) {
                index = data.result.permissions.indexOf("OTHER-UI-CEO");
                if (index !== -1) {
                  $state.go("app.ceodashboard");
                  return;
                }

                index = data.result.permissions.indexOf("OTHER-SUPPLIER");
                if (index !== -1) {
                  $state.go("app.supplierdashboard");
                  return;
                }

                index = data.result.permissions.indexOf(
                  "OTHER-UI-OUTOFDOOR-REPORTS"
                );
                if (index !== -1) {
                  index = data.result.permissions.indexOf("OTHER-GENERIC-USER");
                  if (index !== -1) {
                    $state.go("app.dashboard");
                  } else {
                    $state.go("app.mainoutofdoor");
                  }
                  return;
                }

                index = data.result.permissions.indexOf("OTHER-UI-HOSTESS");
                if (index !== -1) {
                  $state.go("app.hostessreport");
                  return;
                }

                index = data.result.permissions.indexOf("OTHER-EVENTS-AGENCY");
                if (index !== -1) {
                  $state.go("app.eventsummary");
                  return;
                }
              }
              if (index === -1) {
                $state.go("app.dashboard");
              }
            }
          } catch (e) {
            $("#login").html("LOGIN");
          }
        });
      }
    };

    // clears the scope values
    $scope.clear = function () {
      $rootScope.logout = false;
      $scope.username = null;
      $scope.password = null;
      $("#login").html('LOGIN <i class="icon-arrow-right icon"></i>');
    };

    $scope.reset = function () {
      if ($scope.username) {
        var req = { user_name: $scope.username };
        $("#reset").html($compile("<spinner></spinner>")($scope));
        $httpHelper.postRequest("/login/reset/", req, function (data) {
          try {
            if (data === null || data === undefined) {
              throw new Error("Server Error");
            } else {
              $("#reset").html("RESET MY PASSWORD");
              $scope.status = data.status;
              $scope.msg = data.msg;
              $scope.loginContainer = true;
              $scope.clear();
            }
          } catch (e) {
            //TODO error
          }
        });
      }
    };

    $scope.changePassword = function () {
      $scope.passwordPolicy = true;
      var password = $scope.change_password;
      var rePassword = $scope.change_rePassword;
      var lowerCaseLetters = /[a-z]/g,
        upperCaseLetters = /[A-Z]/g,
        numbers = /[0-9]/g,
        specialCharacter = /[-!$%^&*()_+|~=`{}[:;<>?,.@#\]]/g;
      $scope.conditions = {
        pwd_length: {
          val: false,
          text: "Length should be at-least 8 characters",
        },
        pwd_uppercase: {
          val: false,
          text: "Should contain at-least one Uppercase letter [A-Z]",
        },
        pwd_lowercase: {
          val: false,
          text: "Should contain at-least one Lowercase letter [a-z]",
        },
        pwd_number: {
          val: false,
          text: "Should contain at-least one Number [0-9]",
        },
        pwd_specialChar: {
          val: false,
          text: "Should contain at-least one Special Character [~,!,@,#,$,%,^,&,*]",
        },
      };
      $scope.conditions.pwd_length.val = false;
      $scope.conditions.pwd_uppercase.val = false;
      $scope.conditions.pwd_lowercase.val = false;
      $scope.conditions.pwd_number.val = false;
      $scope.conditions.pwd_specialChar.val = false;
      if (password === rePassword) {
        if (password) {
          $scope.conditions.pwd_length.val = password.length >= 8;
          $scope.conditions.pwd_uppercase.val =
            !!password.match(upperCaseLetters);
          $scope.conditions.pwd_lowercase.val =
            !!password.match(lowerCaseLetters);
          $scope.conditions.pwd_number.val = !!password.match(numbers);
          $scope.conditions.pwd_specialChar.val =
            !!password.match(specialCharacter);
        }
        if (
          !$scope.conditions.pwd_length.val ||
          !$scope.conditions.pwd_uppercase.val ||
          !$scope.conditions.pwd_lowercase.val ||
          !$scope.conditions.pwd_number.val ||
          !$scope.conditions.pwd_specialChar.val
        ) {
          $scope.status = 1;
          $scope.msg = "Your Password policy is not met.";
          $scope.passwordPolicy = false;
          return;
        }
        var req = {
          user_name: $scope.username,
          new_password: password,
        };
        $("#reset-pwd").html($compile("<spinner></spinner>")($scope));
        $httpHelper.postRequest("/login/passwdchanged/", req, function (data) {
          try {
            if (data === null || data === undefined) {
              throw new Error("Server Error");
            } else {
              $("#reset-pwd").html("RESET MY PASSWORD");
              $scope.status = data.status;
              $scope.msg = data.msg;
              $scope.resetContainer = false;
              $scope.loginContainer = true;
              $scope.clear();
            }
          } catch (e) {
            //TODO error
          }
        });
      }
    };

    // When user press enter with cursor in password field then
    // login will be called. Code 13 is for 'Enter'
    $("#password").bind("keyup", function (event) {
      if (event.which === 13) {
        $scope.login();
      }
    });
  }
})();
