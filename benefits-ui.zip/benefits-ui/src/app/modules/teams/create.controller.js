/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 16-11-2018
 */

(function() {
  'use strict';

  angular.module('scorpion')
    .controller('TeamCreateController', TeamCreateController);

  function TeamCreateController($scope, $appHelper, $window, $location, $cacheHelper,
    $state, $rootScope, $httpHelper) {

    // google analytics code
    $scope.$on('$viewContentLoaded', function() {
      $window.ga('send', 'pageview', {
        page: $location.url()
      });
    });

    var user;
    $scope.selectAll = false;
    $scope.showDetails = false;
    $scope.predicate = 'ID';
    $scope.desc = true;
    $scope.employeeLines = [];
    $scope.showSpinner = true;
    $scope.workCalendarName = '';
    $scope.focusWorkCalendar = true;
    $scope.focusTeam = true;
    $scope.team_name = '';
    $scope.focusLogIn = true;
    $scope.selectedLogIn = '';
    $scope.focusLogOut = true;
    $scope.selectedLogout = '';
    $scope.focusWeek = true;
    $scope.monday = false;
    $scope.tuesday = false;
    $scope.wednesday = false;
    $scope.thursday = false;
    $scope.friday = false;
    $scope.saturday = false;
    $scope.sunday = false;
    $scope.editWorkCalendar = false;
    $scope.selectedContacts = [];
    $scope.employees = [];



    $scope.log_timings = ['00:00', '00:30', '01:00', '01:30','02:00', '02:30','03:00', '03:30','04:00', '04:30','05:00', '05:30',
                        '06:00', '06:30', '07:00', '07:30','08:00', '08:30','09:00', '09:30','10:00', '10:30',
                            '11:00', '11:30','12:00', '12:30','13:00', '13:30','14:00', '14:30','15:00', '15:30',
                            '16:00', '16:30','17:00', '17:30','18:00', '18:30','19:00', '19:30','20:00', '20:30','21:00', '21:30',
                              '22:00', '22:30','23:00', '23:30'];

    $cacheHelper.getUser(function(data) {
      if (!data) {
        $state.go('login');
      } else {
        if (!$cacheHelper.user) {
          $cacheHelper.initialize(data);
        }
        user = data;
        if($appHelper.WorkCalendarId){
          $scope.WorkCalendarId = $appHelper.WorkCalendarId;
          $scope.editWorkCalendar = true;
          $scope.showSpinner = true;
          $scope.deleteIds = [];
          loadDetails();
        }
        loadEmployees();
      }
    });

    $scope.$watch(function() {
      return $rootScope.orgId;
    }, function(newValue, oldValue) {
      if (newValue !== oldValue) {
        $state.go('app.createteam');
      }
    });

    $scope.goToSummary = function() {
      $state.go('app.teams');
    };


    $scope.addEmployeesList = function(){
      $scope.showDetails = false;
      for(var i = 0; i < $scope.selectedContacts.length; i++) {
        $scope.employeeLines.push($scope.selectedContacts[i]);
      }
    };

    $scope.addEmployees = function() {
      var error = false;
      if (!$scope.workCalendarName) {
        $scope.focusWorkCalendar = false;
        error = true;
      }
      if (!$scope.team_name) {
        $scope.focusTeam = false;
        error = true;
      }
      if (!$scope.selectedLogIn) {
        $scope.focusLogIn = false;
        error = true;
      }
      if (!$scope.selectedLogout) {
        $scope.focusLogOut = false;
        error = true;
      }

      if(!($scope.monday || $scope.tuesday || $scope.wednesday || $scope.thursday || $scope.friday ||
         $scope.saturday || $scope.sunday)) {
          $scope.focusWeek = false;
        error = true;
      }
      if (error) { return; }
      $scope.focusWeek = true;
      $scope.showDetails = true;
      $scope.selectAll = false;

    };

    $scope.checkAll = function() {
      for(var i = 0; i < $scope.employees.length; i++) {
        $scope.employees[i].checked = $scope.selectAll;
      }
      $scope.count = $scope.selectAll ? $scope.employees.length : 0;
      $scope.selectedContacts = $scope.selectAll ? $scope.employees : [];
    };

    $scope.checkEach = function() {
      var i, index;
      $scope.selectedContacts = [];
      $scope.count = 0;
      for(i = 0; i < $scope.employees.length; i++) {
        if ($scope.employees[i].checked) {
          index = $scope.employees.map(function(x) {
            return x.user_id;
          }).indexOf($scope.selectedContacts.user_id);
          if (index === -1) {
            $scope.selectedContacts.push($scope.employees[i]);
          }
          $scope.count++;
        }
      }
    };


    function loadDetails() {
      var endPoint = '/calendar/details/' + $scope.WorkCalendarId + '/', data, weekOffs;
      $httpHelper.httpRequest('GET', endPoint, null, function(CalendarData) {
        if (CalendarData === null || CalendarData === undefined) {
          $scope.notifications.push({msg: 'Server Error - loadDetails()', status: 1});
        } else {
          if (CalendarData.status === 1) {
            $scope.notifications.push({msg: CalendarData.msg, status: CalendarData.status});
          } else {
            data = CalendarData.result[0];
            $scope.workCalendarName = data.calendar_name;
            $scope.selectedLogIn = data.log_in_time;
            $scope.selectedLogout = data.log_out_time;
            weekOffs = data.week_offs;
            if (weekOffs.includes('mon')){
              $scope.monday = true;
            }
            if (weekOffs.includes('tue')){
              $scope.tuesday = true;
            }
            if (weekOffs.includes('wed')){
              $scope.wednesday = true;
            }
            if (weekOffs.includes('thu')){
              $scope.thursday = true;
            }
            if (weekOffs.includes('fri')){
              $scope.friday = true;
            }
            if (weekOffs.includes('sat')){
              $scope.saturday = true;
            }
            if (weekOffs.includes('sun')){
              $scope.sunday = true;
            }

            $scope.employeeLines = data.employee_list;

            $scope.selectedContacts = $scope.employeeLines;


          }
          $scope.showSpinner = false;
        }
      });
    }



    $scope.createWorkCalendar = function(){
      var endPoint, req_obj = {}, week_offs = '', user_ids = [];

      $scope.showSpinner = true;
      req_obj.calendar_name = $scope.workCalendarName;
      req_obj.team_id = $rootScope.orgId;
      req_obj.log_in_time = $scope.selectedLogIn;
      req_obj.log_out_time = $scope.selectedLogout;
      req_obj.user_id = user.user_id;

      for (var i = 0; i < $scope.employeeLines.length; i++) {
        user_ids.push($scope.employeeLines[i].user_id);
      }
      req_obj.employee_ids = user_ids;

      if ($scope.monday){
        week_offs = week_offs.concat('mon,');
      }
      if ($scope.tuesday){
        week_offs = week_offs.concat('tue,');
      }
      if ($scope.wednesday){
        week_offs = week_offs.concat('wed,');
      }
      if ($scope.thursday){
        week_offs = week_offs.concat('thu,');
      }
      if ($scope.friday){
        week_offs = week_offs.concat('fri,');
      }
      if ($scope.saturday){
        week_offs = week_offs.concat('sat,');
      }
      if ($scope.sunday){
        week_offs = week_offs.concat('sun,');
      }
      week_offs = week_offs.replace(/,\s*$/, "");
      req_obj.week_offs = week_offs;

      if($scope.editWorkCalendar){
        req_obj.work_calendar_id = $scope.WorkCalendarId;
      }

      endPoint = '/calendar/';
      endPoint += $scope.editWorkCalendar ? 'update/' : 'add/';
      $httpHelper.httpRequest('POST', endPoint, req_obj, function(data) {
        if (data === null || data === undefined) {
          $scope.notifications.push({msg: 'Server Error - applyLeave()', status: 1});
        } else {
          $scope.notifications.push({status: data.status, msg: data.msg});
          if (data.status === 0) {
            $state.go('app.teams');
            $scope.editWorkCalendar = false;
          }
        }
        $scope.showSpinner = false;
      });
    };

    $scope.deleteLine = function(line) {
      $scope.columnname = 'delete';
      if (line) {
        $scope.selectedLine = line;
        $scope.showDialog = true;
      } else {
        var index = $scope.employeeLines.map(function(x) {
          return x.user_id;
        }).indexOf($scope.selectedLine.user_id);
        if (index !== -1) {
          //$scope.employees[index].checked = false;
          $scope.employeeLines.splice(index, 1);
          $scope.showDialog = false;
        }
      }
    };

    $scope.editEmployeeDetails = function(employeeIndex, colname) {
      if (colname !== 'delete') {

      }else {
        $scope.showDetails = false;
      }
    };

    $scope.closeDetailsDialog = function() {
      $scope.showDetails = false;
      $scope.selectAll = false;
      $scope.checkAll();
    };

    $scope.sort = function(key) {
      $scope.predicate = key;
      $scope.desc = !$scope.desc;
    };

    function loadEmployees() {
      var endPoint = '/calendar/users/' + $rootScope.orgId + '/';
      $httpHelper.httpRequest('GET', endPoint, null, function(data) {
        $scope.showSpinner = false;
        try {
          if (data === null || data === undefined) {
            throw new Error('Server Error');
          } else {
            if (data.status === 1) {
              $scope.notifications.push({msg: data.msg, status: data.status});
            } else {
              for (var i = 0; i < data.result.length; i++) {
                $scope.employees = data.result;
                $scope.team_name = data.result[0].team_name;
              }
            }
          }
        } catch (e) {
          $scope.notifications.push({msg: e.message, status: 1, details: '<pre>'+ e.stack + '</pre>'});
        }
      });
    }

  }
})();
