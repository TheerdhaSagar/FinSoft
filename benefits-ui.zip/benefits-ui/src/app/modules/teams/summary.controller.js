/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 16-11-2018
 */

(function() {
  'use strict';

  angular.module('scorpion')
    .controller('TeamSummaryController', TeamSummaryController);

  function TeamSummaryController($scope, $window, $location, $cacheHelper, $httpHelper,
    $state, $appHelper, $formatHelper, $filter, $rootScope) {

    // google analytics code
    $scope.$on('$viewContentLoaded', function() {
      $window.ga('send', 'pageview', {
        page: $location.url()
      });
    });

    var user, selectedLine;
    $scope.selectedTemplate = 'generic';
    $scope.selectedFormat = 'Generic';
    $scope.focus = false;
    $scope.showDialog = false;
    $scope.pageDim = false;
    $scope.workCalendars = '';



    $scope.$watch(function() {
      return $rootScope.orgId;
    }, function(newValue, oldValue) {
      if (newValue !== oldValue) {
        $state.go($state.current, {}, {
          reload: true
        });
      }
    });

    $scope.toggleFilter = $appHelper.toggleFilter();

    $cacheHelper.getUser(function(data) {
      if (!data) {
        $state.go('login');
      } else {
        if (!$cacheHelper.user) {
          $cacheHelper.initialize(data);
        }
        user = data;
      }
      loadData();
    });

    $scope.deleteWorkCalendar = function(line) {
      if (line) {
        selectedLine = line.work_calendar_id;
        $scope.showCalendarDialog = true;
      } else {
        $scope.showCalendarDialog = false;
      }
    };


    $scope.deleteRow = function () {
      $scope.showCalendarDialog = false;
      $scope.pageDim = true;
      try {
        var endPoint = '/calendar/delete/' + selectedLine + '/';
        $httpHelper.httpRequest("DELETE", endPoint, null, function (data) {
          if (data === null || data === undefined) {
            throw new Error("Server Error");
          } else {
            if (data.status === 0) {
              var index = $scope.workCalendars.map(function (x) { return x.work_calendar_id; }).indexOf(selectedLine);
              if (index !== -1) {
                $scope.workCalendars.splice(index, 1);
                $scope.notifications.push({ status: 0, msg: data.msg });
              }
            } else if (data.status === 1) {
              $scope.notifications.push({ status: 1, msg: data.msg });
            }
            $scope.pageDim = false;
          }
        });
      } catch (e) {
        $scope.notifications.push({ status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>' });
      }
    };

    function loadData() {
      var endPoint = '/calendar/' + $rootScope.orgId + '/';
      $scope.pageDim = true;
      var req = {};
      req.org_id = $rootScope.orgId;
      $httpHelper.httpRequest('GET', endPoint, req, function(data) {
        $scope.pageDim = false;
        try {
          if (data === null || data === undefined) {
            throw new Error('Server Error');
          } else {
            $scope.workCalendars = data.result;
            if(data.result.length > 0){
              $scope.team_name = data.result[0].team_name;
            }
          }
        } catch (e) {
          $scope.notifications.push({status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>'});
        }
      });
    }


    $scope.closeDialog = function() {
      $scope.enterDetails = false;
      $scope.missingdata = [];
      $scope.selectedTemplate = 'generic';
      $scope.selectedFormat = 'Generic';
      $scope.cardAttachment = '';
      $scope.pageDim = false;
    };


    $scope.createWorkCalendar = function() {
      $appHelper.WorkCalendarId = '';
      $state.go('app.createteam');
    };


    $scope.predicate = 'report_header_id';
    $scope.desc = true;

    // Table sorting
    $scope.sort = function(key) {
      if ($scope.predicate === key) {
        $scope.desc = !$scope.desc;
      } else {
        $scope.predicate = key;
      }
      if ($scope.searchQuery && $scope.searchQuery.length > 0) {
        var tmpData = $filter('orderBy')($scope.expenses, $scope.predicate, $scope.desc);
        $scope.expenses = tmpData;
      } else {
        $scope.expenses = $filter('orderBy')($scope.expenses, $scope.predicate, $scope.desc);
      }
    };

    $scope.editWorkCalendar = function(workCal) {
      $appHelper.WorkCalendarId = workCal.work_calendar_id;
      $state.go('app.createteam');
    };

    // Exports the table data into spreadsheet
    $scope.export = function() {
      $scope.toggleFilter();
      var exportdata = $filter('orderBy')($scope.expenses, $scope.predicate, $scope.desc);
      var tableData = {};
      var tmpData = [];
      for (var i = 0; i < exportdata.length; i++) {
        var tmpObj = {};
        tmpObj['Report #'] = { data: exportdata[i].report_header_id };
        tmpObj['Employee Name'] = { data: exportdata[i].employee_name };
        tmpObj.Description = { data: exportdata[i].description };
        tmpObj['Created On'] = { data: exportdata[i].f_created_on };
        tmpObj['Created By'] = { data: exportdata[i].user_description };
        tmpObj['Current Approver'] = { data: exportdata[i].approver };
        tmpObj.Amount = { data: exportdata[i].amount, align: 'right' };
        tmpObj.Currency = { data: exportdata[i].default_currency_code };
        tmpObj.Status = { data: exportdata[i].exp_status };

        tmpData.push(tmpObj);
      }
      tableData.data = tmpData;
      $appHelper.tableToExcel('Expenses', tableData, 'expenses');
    };


  }
})();
