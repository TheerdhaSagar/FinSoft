/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 17-10-2018
 */

(function() {
  'use strict';

  angular.module('scorpion')
    .service('$cacheHelper', CacheHelper);

  function CacheHelper($appHelper, $httpHelper, $state, $rootScope) {

    this.setUser = function(user) {
      this.user = user;
      // Creates a cookie called USER_ID and stores the logged in user id
      if (!user.user_id) { return; }
      $appHelper.createCookie('USER_ID', user.user_id, 1);
    };

    this.getUser = function(callback) {
      // If user is null then call the web service and load user details
      // only if there is a valid USER_ID in cookie else redirect to login page
      if (this.user === null || this.user === undefined) {
        var USER_ID = $appHelper.readCookie('USER_ID');
        if (USER_ID) {
          var endPoint = '/preferences/details/' + USER_ID + '/';
          $httpHelper.httpRequest('GET', endPoint, null, function(data) {
            callback(data);
          });
        } else {
          this.clear();
          $state.go('login');
        }
      } else {
        callback(this.user);
      }
    };

    this.setToken = function(token) {
      this.token = token;
      $appHelper.createCookie('AUTH_TOKEN', token, 1);
    };

    this.getToken = function() {
      return this.token;
    };

    this.setRefreshToken = function(refreshToken) {
      $appHelper.createCookie('REFRESH_TOKEN', refreshToken, 1);
    };

    this.setOrgList = function(orgList) {
      this.orgList = orgList;
    };

    this.getOrgList = function() {
      return this.orgList;
    };

    this.setTimeZone = function(timeZone) {
      this.timeZone = timeZone;
    };

    this.getTimeZone = function() {
      return this.timeZone;
    };

    this.setGroupList = function(groupList) {
      this.groupList = groupList;
    };

    this.getGroupList = function() {
      return this.groupList;
    };

    this.setOrgId = function(orgId) {
      this.orgId = orgId;
    };

    this.getOrgId = function() {
      return this.orgId;
    };

    this.setOldOrgId = function(oldOrgId) {
      this.oldOrgId = oldOrgId;
    };

    this.getOldOrgId = function() {
      return this.oldOrgId;
    };

    this.setCustomers = function(customers) {
      this.customers = customers;
    };

    this.getCustomers = function() {
      return this.customers;
    };

    this.setCreditNotes = function(creditNotes) {
      this.creditNotes = creditNotes;
    };

    this.getCreditNotes = function() {
      return this.creditNotes;
    };

    this.setCreditNote = function(creditNote) {
      this.creditNote = creditNote;
    };

    this.getCreditNote = function() {
      return this.creditNote;
    };

    this.setInvoiceDetails = function(invoiceDetails) {
      this.invoiceDetails = invoiceDetails;
    };

    this.getInvoiceDetails = function() {
      return this.invoiceDetails;
    };

    this.setColumnNames=function(columnNames){
      this.columnNames=columnNames;
    };

    this.getColumnNames=function(){
      return this.columnNames;
    };

    this.setTransactionRegisterData = function(transactionRegister) {
      this.transactionRegister = transactionRegister;
    };

    this.getTransactionRegisterData = function() {
      return this.transactionRegister;
    };

    this.setBudgetData = function(budgetData) {
      this.budgetData = budgetData;
    };

    this.getBudgetData = function() {
      return this.budgetData;
    };

    this.setPODetails = function(poDetails) {
      this.poDetails = poDetails;
    };

    this.getPODetails = function() {
      return this.poDetails;
    };

    this.setSupplierTransactionData = function(supplierTransaction) {
      this.supplierTransaction = supplierTransaction;
    };

    this.getSupplierTransactionData = function() {
      return this.supplierTransaction;
    };

    this.setSupplierTransactionInvoice = function(suppliertransactioninvoice) {
      this.suppliertransactioninvoice = suppliertransactioninvoice;
    };

    this.getSupplierTransactionInvoice = function() {
      return this.suppliertransactioninvoice;
    };

    this.setTransactionColumnNames = function(columnNames) {
      this.columnNames = columnNames;
    };

    this.getTransactionColumnNames = function() {
      return this.columnNames;
    };

    this.setAssetBalanceData = function(assetBalances) {
      this.assetBalances = assetBalances;
    };

    this.getAssetBalanceData = function() {
     return this.assetBalances;
    };

    this.setLiabilityData = function(liabilityBalances) {
     this.liabilityBalances = liabilityBalances;
    };

    this.getLiabilityData = function() {
     return this.liabilityBalances;
    };

    this.setRevenueData = function(revenueBalances) {
     this.revenueBalances = revenueBalances;
    };

    this.getRevenueData = function() {
      return this.revenueBalances;
    };

    this.setStatus = function (status) {
      this.status=status;
    };

    this.getStatus = function () {
      return this.status;
    };

    this.setPersonsData = function(persons) {
      this.persons = persons;
    };

    this.getPersonsData = function() {
      return this.persons;
    };

    this.setAmbassadorSummary = function(visitdata) {
      this.visitdata = visitdata;
    };

    this.getAmbassadorSummary = function() {
      return this.visitdata;
    };

    this.setEventData = function(events) {
      this.events = events;
    };

    this.getEventData = function() {
      return this.events;
    };

    this.setExpenseData=function(expenses){
      this.expenses = expenses;
    };

    this.getExpenseData=function(){
      return this.expenses;
    };

    this.setRolesData = function(roles){
      this.roles = roles;
    };

    this.getRolesData = function() {
      return this.roles;
    };

    this.setCategories = function(categories) {
      this.categories = categories;
    };

    this.getCategories = function() {
      return this.categories;
    };

    this.setLanguages = function(languages) {
      this.languages = languages;
    };

    this.getLanguages = function() {
      return this.languages;
    };

    this.setFieldsData = function(fields_data) {
      this.fields_data = fields_data;
    };

    this.getFieldsData = function() {
      return this.fields_data;
    };

    this.setDonationApplications = function (applications) {
      this.donationApplications = applications;
    };

    this.getDonationApplications = function () {
      return this.donationApplications;
    };

    this.setInvoices = function (invoices) {
        this.invoices = invoices;
    };

    this.getInvoices = function () {
        return this.invoices;
    };

    this.setInvoiceStatus = function (status) {
        this.invoiceStatus = status;
    };

    this.getInvoiceStatus = function () {
        return this.invoiceStatus;
    };

    // Initialize user object and other user defaults
    this.initialize = function(user) {
      if (!user.user_id) { return; }
      this.setUser(user);
      this.setOrgList(user.organizations);
      this.setGroupList(user.groups);
      if (user.organizations && user.organizations.length > 0) {
        var defaultOrg = user.default_org_id;
        if (defaultOrg === null) {
          this.setOrgId(user.organizations[0].organization_id);
        } else {
          this.setOrgId(user.default_org_id);
        }
        this.setOldOrgId(this.getOrgId());
        $rootScope.ledger_id = user.organizations[0].set_of_books_id;
      }
    };

    // Clears all data from CacheService and removes
    // USER_ID and AUTH_TOKEN cookies
    this.clear = function() {
      $appHelper.eraseCookie('USER_ID');
      $appHelper.eraseCookie('AUTH_TOKEN');
      $appHelper.eraseCookie('REFRESH_TOKEN');
      $appHelper.clear();

      this.user = null;
      this.orgList = null;
      this.groupList = null;
      this.orgId = null;
      this.oldOrgId = null;
      this.customers = null;
      this.creditNotes = null;
      this.creditNote = null;
      this.invoiceDetails = null;
      this.columnNames = null;
      this.budgetData = null;
      this.status = null;
      this.persons = null;
      this.roles = null;
      this.languages = null;
      this.donationApplications = null;
      this.invoices = null;
      this.invoiceStatus = null;
      this.associations = null;
      this.donationShops = null;
      this.donationUserType = null;

      this.periods = null;
      this.selectedYear = null;
      this.selectedGroup = null;
      this.salesGroups = null;
      this.agents = null;
      this.reportCustomers = null;
      this.selectedAgent = null;
      this.selectedAgentId = null;
      this.selectedCustomer = null;
      this.selectedCustomerName = null;
      this.selectedCustomerNumber = null;
      this.ceoDashboard = null;

      this.clearReportsData();
      this.clearAgentReportsData();
      this.clearCustReportsData();
    };

    // Clear reports data cache

    this.clearReportsData = function() {
        this.monthTurnover = null;
        this.monthGrossRevenue = null;
        this.monthNetRevenue = null;
        this.monthData = null;
        this.segmentData = null;
        this.itemsData = null;
        this.revenueCustomerData = null;
        this.revenueClassData = null;
        this.revenueTypeData = null;
        this.revenueBrandData = null;
        this.formatsData = null;
        this.macroData = null;

        // revenue 360 report data
        this.customerDetails360 = null;
        this.turnover360 = null;
        this.grossRevenue360 = null;
        this.netRevenue360 = null;
        this.classData360 = null;
        this.typeData360 = null;
        this.brandData360 = null;
        this.segmentData360 = null;
        this.itemsData360 = null;
        this.customerData360 = null;
        this.macroData360 = null;
        this.qualiData = null;
        this.itemsQuarterData360 = null;
        this.shiptoData360 = null;
    };

    this.clearAgentReportsData = function() {
        this.agentMonthTurnover = null;
        this.agentMonthGrossRevenue = null;
        this.agentMonthNetRevenue = null;
        this.agentMonthData = null;
        this.agentZoneGrossData = null;
        this.agentZoneNetData = null;
        this.agentSegmentData = null;
        this.agentItemsData = null;
        this.agentRevenueCustomerData = null;
        this.agentRevenueBrandData = null;
        this.agentFormatsData = null;
        this.agentMacroData = null;

        this.agentCustomerDetails360 = null;
        this.agentTurnover360 = null;
        this.agentGrossRevenue360 = null;
        this.agentNetRevenue360 = null;
        this.agentClassData360 = null;
        this.agentTypeData360 = null;
        this.agentBrandData360 = null;
        this.agentSegmentData360 = null;
        this.agentItemsData360 = null;
        this.agentCustomerData360 = null;
        this.agentMacroData360 = null;
        this.agentQualiData = null;
        this.agentItemsQuarterData360 = null;
        this.agentShiptoData360 = null;
    };

    this.clearCustReportsData = function() {
        this.custMonthTurnover = null;
        this.custMonthGrossRevenue = null;
        this.custMonthNetRevenue = null;
        this.custMonthData = null;
        this.custSegmentData = null;
        this.custItemsData = null;
        this.custRevenueCustomerData = null;
        this.custRevenueClassData = null;
        this.custRevenueBrandData = null;
        this.custFormatsData = null;
        this.custMacroData = null;

        // revenue 360 report data
        this.custCustomerDetails360 = null;
        this.custTurnover360 = null;
        this.custGrossRevenue360 = null;
        this.custNetRevenue360 = null;
        this.custClassData360 = null;
        this.custTypeData360 = null;
        this.custBrandData360 = null;
        this.custSegmentData360 = null;
        this.custItemsData360 = null;
        this.custCustomerData360 = null;
        this.custMacroData360 = null;
        this.custQualiData = null;
        this.custItemsQuarterData360 = null;
        this.custShiptoData360 = null;
    };

  }
})();
