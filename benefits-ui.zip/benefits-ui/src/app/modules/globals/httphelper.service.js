/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 10-10-2018
 */

(function () {
  "use strict";

  angular.module("scorpion").service("$httpHelper", HttpHelper);

  function HttpHelper($http, $state, base64, URL, $appHelper) {
    this.httpRequest = function (method, endPoint, data, callback) {
      genericHttpRequest(method, endPoint, data, callback);
    };

    // Generic HTTP request used to call the web services with Authorization header
    // method can be any of (GET, PUT, POST, DELETE etc)
    // endPoint of the target resource relative to Base URL
    // callback is called when the request is finished
    function genericHttpRequest(method, endPoint, data, callback) {
      // Read the token from cookie
      var token = $appHelper.readCookie("AUTH_TOKEN");
      var userId = $appHelper.readCookie("USER_ID");

      if (
        token === null ||
        token === undefined ||
        userId === null ||
        userId === undefined
      ) {
        $state.go("login");
        return;
      }

      // Build the request object
      var request = {
        method: method,
        url: URL + endPoint,
        data: data,
        headers: {
          withCredentials: true,
          "Content-Type": "application/json",
          Authorization: "Basic " + base64.encode(token + ":" + userId),
        },
      };

      $http(request)
        .success(function (response) {
          callback(response);
        })
        .error(function (response, status) {
          if (response) {
            console.log(
              "Error in HttpService - httpRequest: " + response.message
            );
          }

          // If the token is expired or request is unauthorized then clear the data
          // and go to login page
          if (status === 401) {
            getAuthToken(method, endPoint, data, callback);
          } else if (status === 408 || status === 504) {
            genericHttpRequest(method, endPoint, data, callback);
          } else {
            callback(null);
          }
        });
    }

    function getAuthToken(method, endPoint, data, callback) {
      var request = {};
      request.refresh_token = $appHelper.readCookie("REFRESH_TOKEN");
      $http
        .post(URL + "/login/re-requesttoken/", request)
        .success(function (response) {
          $appHelper.createCookie("AUTH_TOKEN", response.token, 1);
          retryRequest(method, endPoint, data, callback);
        })
        .error(function (response, status) {
          console.log("Error in HttpService - postRequest: " + response);
          if (status === 401) {
            $state.go("login");
          } else {
            callback(null);
          }
        });
    }

    function retryRequest(method, endPoint, data, callback) {
      genericHttpRequest(method, endPoint, data, callback);
    }

    // Method used to handle HTTP GET request
    this.getRequest = function (endPoint, callback) {
      $http
        .get(URL + endPoint)
        .success(function (data) {
          callback(data);
        })
        .error(function (data) {
          console.log("Error in HttpService - getRequest: " + data);
          callback(null);
        });
    };

    // Method used to handle HTTP GET request
    this.getRequestURL = function (URL, callback) {
      $http
        .get(URL)
        .success(function (data) {
          callback(data);
        })
        .error(function (data) {
          console.log("Error in HttpService - getRequestURL: " + data);
          callback(null);
        });
    };

    // // Method used to handle HTTP POST request
    // this.postRequest = function (endPoint, postBody, callback) {
    //   $http
    //     .post(URL + endPoint, postBody)
    //     .success(function (data) {
    //       callback(data);
    //     })
    //     .error(function (data) {
    //       console.log("Error in HttpService - postRequest: " + data);
    //       callback(null);
    //     });
    // };

    // Method used to handle HTTP POST request
    this.postRequest = function (endPoint, postBody, callback) {
      $http({
        method: "POST",
        url: URL + endPoint,
        data: postBody,
      }).then(
        function successCallback(data) {},
        function errorCallback(data) {}
      );
    };

    // Method used to handle HTTP DELETE request
    this.deleteRequest = function (endPoint, callback) {
      $http
        .delete(URL + endPoint)
        .success(function (data) {
          callback(data);
        })
        .error(function (data) {
          console.log("Error in HttpService - deleteRequest: " + data);
          callback(null);
        });
    };

    // Method used to handle HTTP PUT request
    this.putRequest = function (endPoint, putBody, callback) {
      $http
        .put(URL + endPoint, putBody)
        .success(function (data) {
          callback(data);
        })
        .error(function (data) {
          console.log("Error in HttpService - putRequest: " + data);
          callback(null);
        });
    };
  }
})();
