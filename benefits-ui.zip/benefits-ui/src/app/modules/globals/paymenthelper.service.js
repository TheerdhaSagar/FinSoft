/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 10-10-2018
 */

(function() {
  'use strict';

  angular.module('scorpion')
    .service('$paymentHelper', PaymentHelper);

  function PaymentHelper() {

    // Download xml
    this.downloadXML = function(text, filename, type) {
      var link = document.createElement("a"); //set up anchor
      type = type || "text/xml";
      link.setAttribute("target", "_blank");
      if (Blob !== undefined) {
        var blob = new Blob([text], {
          type: type
        });
        link.setAttribute("href", window.URL.createObjectURL(blob));
      } else {
        link.setAttribute("href", "data:text/xml," + encodeURIComponent(text));
      }
      link.setAttribute("download", filename);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    };
  }

})();
