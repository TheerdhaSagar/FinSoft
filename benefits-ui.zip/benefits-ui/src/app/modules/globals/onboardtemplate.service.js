/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 10-10-2018
 */

(function() {
  'use strict';

  angular.module('scorpion')
    .service('$onBoardHelper', onBoardHelper);

  function onBoardHelper($httpHelper) {

    this.getDocDefinition = function() {
      var data = this.onBoardHelperData;
      var tableHead = this.tableHeaders;
      //table rows
      function insideTable(data) {
        var insideTableBody = [];
        // table header
        var bodyData = [
          [{
            text: ''
          }, {
            text: tableHead.articleno,
            style: 'tableHeader'
          }, {
            text: tableHead.barcode,
            style: 'tableHeader'
          }, {
            text: tableHead.ean,
            style: 'tableHeader'
          }, {
            text: tableHead.weight,
            style: 'tableHeader'
          }, {
            text: tableHead.units,
            style: 'tableHeader'
          }]
        ];

        // row data and image for every product
        for (var i = 0; i < data.length; i++) {
          var inside = [{
            text: "",
            rowSpan: 2,
            stack: [{
              image: data[i].base64,
              fit: [80, 60],
              alignment: 'center'
            }]
          }, {
            text: data[i].product_id || " " ,
            style: 'tableRow'
          }, {
            text: data[i].barCode || " ",
            style: 'tableRow'
          }, {
            text: data[i].iBan || " ",
            style: 'tableRow'
          }, {
            text: data[i].weight || " ",
            style: 'tableRow'
          }, {
            text: data[i].UnitsPerCase || " ",
            style: 'tableRow'
          }];
          var otherInside = [{
            text: ''
          }, {
            text: [{
              text: tableHead.ingredients + ' : ',
              style: 'contextHeader'
            }, {
              text: data[i].ingredients + '\n',
              style: 'contentText'
            }, {
              text: tableHead.analysis + ' : ',
              style: 'contextHeader'
            }, {
              text: data[i].gauranteedAnalysis,
              style: 'contentText'
            }],
            colSpan: 5
          }];
          bodyData.push(inside);
          bodyData.push(otherInside);
        }

        var multipleTables = [{
          table: {
            headers: 1,
            widths: [140, 55, 85, 95, 70, 55],
            body: bodyData,
          },
          layout: {
            hLineWidth: function() {
              return 0.5;
            },
            vLineWidth: function() {
              return 0.5;
            },
            // hLineColor: function(i, node) {
            //         return (i === 0 || i === node.table.body.length) ? 'black' : 'gray';
            // },
            // vLineColor: function(i, node) {
            //         return (i === 0 || i === node.table.widths.length) ? 'black' : 'gray';
            // },
            // paddingLeft: function(i, node) { return 4; },
            // paddingRight: function(i, node) { return 4; },
            // paddingTop: function(i, node) { return 2; },
            // paddingBottom: function(i, node) { return 2; }
          }
        }];
        insideTableBody.push(multipleTables);
        return insideTableBody;
      }

      //top portion of page brand name to left and scorpion logo to right
      function headerImages() {
        var mainContent = [];
        for (var i = 0; i < data.length; i++) {
          var insideContent = [{
            table: {
              widths: [500],
              headers: 1,
              body: [
                [{
                  columns: [{
                    alignment: 'left',
                    text: [{
                      text: data[i][0].brand_name + '\n',
                      style: 'mainHeader'
                    }, {
                      text: data[i][0].segment_name,
                      style: 'subHeader'
                    }],

                  }, {
                    image: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKwAAABbCAYAAADupm55AAAAhnpUWHRSYXcgcHJvZmlsZSB0eXBlIGV4aWYAAHjaVY7RDYAwCAX/mcIRKFAo42hTEzdwfCHVNN4HvLyQCzDu64QtKUgg1Zq6Kgbi4rRHaDhhxEJYcsecvJtLJFo1MM2g3gxlHcrbf1TWpqeJmVbt2insNJiYYqYorZhv+JLs/fvo39fjL4cHUgwspnYk5aQAAAoEaVRYdFhNTDpjb20uYWRvYmUueG1wAAAAAAA8P3hwYWNrZXQgYmVnaW49Iu+7vyIgaWQ9Ilc1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCI/Pgo8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJYTVAgQ29yZSA0LjQuMC1FeGl2MiI+CiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogIDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiCiAgICB4bWxuczpleGlmPSJodHRwOi8vbnMuYWRvYmUuY29tL2V4aWYvMS4wLyIKICAgIHhtbG5zOnRpZmY9Imh0dHA6Ly9ucy5hZG9iZS5jb20vdGlmZi8xLjAvIgogICBleGlmOlBpeGVsWERpbWVuc2lvbj0iMTcyIgogICBleGlmOlBpeGVsWURpbWVuc2lvbj0iOTEiCiAgIHRpZmY6SW1hZ2VXaWR0aD0iMTcyIgogICB0aWZmOkltYWdlSGVpZ2h0PSI5MSIKICAgdGlmZjpPcmllbnRhdGlvbj0iMSIvPgogPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4KICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgIAo8P3hwYWNrZXQgZW5kPSJ3Ij8+pI4guQAAAARzQklUCAgICHwIZIgAAB5NSURBVHja7Z13eBVV+sc/M7ff9EKAUEOXIl2KHYKCgOBPirKuwIprXdtaUARBRGQRRRfLioCgYAF2QUWlFykiTTpJSEgCoaQTkpvbZub3x4UbbmZySRA0wLzPk+fJnXrOe77nPW877wiKoijopNMVQqLOAp10wOqkkw5YnXTSAauTDliddLp8ZNRZ8DvJ60DJ+RUl51coSkEpzgR3ISgyCCKYIxBC6kJ4U4TYjghx3cAUpvPtIknQ3VoXSWeOIKfMRTm+BqTSKqxpJoTatyE0HoYQ1Vrnow7Yy0zOXOT901GOLf/9zK91M2Kb58Eer/NVB+ylJ+X4auRdE8FbcukearAgtnkeocFAncE6YC8ZVJEPfoSSPOfyDUTDexCvH+3Te3XSAft7SN4zBeXIoss/GHV6IXZ8QwdtMBNAZ8EFZGvSp38IWAGUrJXIe9/Wma4D9iIBlP0L8qFP/th3HlmIcvRHnfk6YKtI3hLkneOBP15jkve8Bc5cfQx0wFYBNEmfgivvT5osDuT97+mDoAO2kuTKR0n75s9VR44th+IMfSx0wFYCLOn/Bdn9Z7cCOe0rfTB0wFZCHTj6Q/WYOFkrQPbqA6IDNggVp0PJ0erRFncRSv5ufUx0wAaRark7q1eD8nbpg6IDNghgi1KrWXsO64OiAzYIVRd14Bw5jutjogM2CHkd1UvCeor0MTmP9B0H5UnyATbHYCHTVovjlmhOCibyFDiteCiSSvEqCm7Zg4CA1WBCAGyCCQEFm2jCCthRsKFgUxTssge77CLEW0qI10GY7CJMkYhUJOyKfAHEyvqY6IAtt+p6HaSeTiHldDIptniOYMIhOX0nXacrxhIKpZLPX+ugEn5bg833dx6ZRSNRooVYQaSm7KKGt5iargLqyS5iZS8I+hCdT9dceqGsyJxwHCf1dAqpRYdJOZ1EVvExFKofG+yiiXqmCBJqdqVpRFOaRjQn0hKlA/Zq7ZxTcpJ6OoWjxRkcKz7KCcdxMoozcEuuK7ZPtey1aRPdls5xXUgIb4zFYNEBeyWTgsK+vD2szlrBnrzf8F6lkaJW0W3ILM6gfmh92sZ0oEONTsTZauqAvZJoZ+52/pu2kMwz6dfkctk6+nq61bqRBmEJ1A9toAO2utKJkiw+T/6Mffl7dKvkLDUMS6BLze7cXicRu9GuA7Y6kFf2suTIYpZlLEVSpD/03VaDjRhrDAbBoD5ntCEKInaDHUEQsRltGAQDVoM14DqP7MEtu3F4Sij2FlPkPk2uM+eSqjHR1hhq2+O5qfYtdInrjlE06oD9Myir5Bgf7XufzMuYM2o2WGgW0Zymkc2paatFuDmcKEs0kZYoQowhl0cHVxQKXPnkOXM54z2DoijYjDZCjaGEnq0Yk1qUws6cHezO20XPundwQ1xXduZs46fMZRhFEy7JhVOjuEeEOYLEur3pUbcXYVdo9ZkrErBuycULW56mwFVwyZ9tEk20i+1I15rdaRvbHrNorrZ8kBSJjDPpFLlPYxLNRFoiibJEk34mjaPFmTQKa0xqUQqL0r7xe0YEQaBLXDfqhtbn9jqJVxxwLy9gFQXX/77A+9uvGFu2xTLkbyD+/mjwtuyt/HvvO5W+3iAYaBzRlNr2eNyym2PFmRwrOYqiKAgIxIfUoXFEU9rHdqBNdFvMV5mrKN+Vx9ZTWyhwFVDgyie3NJt6ofWJD6lD7/r9rqi+XFaFxv3jYpxzP/Dpm7u3gcGIZfCI3/1cuQr6au/6fenXYADh5giVdPLK3mvCjxltiaFPOWBKisRJxwlkRUa8guogXNaWen5eVe73ykvy3DYx7YgoB0BVxwSRjjVuYGDCIBVYz0nda83pXr7/dULqXlFgvewSViktCfr7YslutPNS+7G8t+dtTpWeDDiXEN6InnXvpGONzpfNMKru5Fn7I67vv0GIjMb28HOItepcNX27Yn0cdUPrMbnrNPbk/0bmmXTMBgutotrQIKwh1zJJqUk4pk/w/3bk5xD67jwdsNWi8aKRDrGd6BDbCZ185N2+KRDAacnI+bmI0bFXRf/0BO6rjJQz6nRI5XT+VdM/HbA6XX0qgZyfi3frBqSMw+B2IYSGY2jaEmP7rgihl87xLJ86jnwsHbnQFxAQwiMwNmmBEBW4nCkFuUhHDqO4zzrDLVYMDZsgRMVUUeHzImWkoeRlg82OoX4jhPDI39kJGSn9MHL2CZSSYgSrFTG2JoaEZmCufBBCPpmFZ+sG5IzDKLKMYLVhaNwCU5dbfn8bL0o5lsBgqKSx7UA5cxoxKhZMpoofmZGKdGgvcn4uQkgoxmatMDRvDYJwcYBVnKU4Z7+Pe+VSkDW2apjNWAYMw3r/KDBcpDqsKLjXLMO1aB7y8UztRrbtjPWBR5EL8nB9PQspNUnbVdO0Jdb7HsLY6cbgr3SU4Fo0F/fy/6EUnyk7IQgYr++EddjfMbRoU0WPiAPXwjm4f1qCUnJGdV4wWzDdnIjlL48ixtQIuqSXznwHz4YVoBHTKf3kbSwD/4L1vlGVBpBr/icIkdEYGrfAfOdAEEXkU8dx/GsMUmoSps43YntuAoLNrtkex9RX8e7ehrF1e+wvT0EIDa/A4DuEc8FMvLu2guRFsNqwjnoWc6+7A687tJfSWdORkverx7DJddgeeR5Ds1aa76gw0qWcLqRk7BNIGRfe9my8vhMhY99RSZDiZ/6KdCSlTP+Iq0XYzCUBYHW8Ox7P+kp8L0AQNAdQi6zD/o5l6N8qnNWOSS8gnzoe9F3WvzxS6SCHnJ9LydgnkI9dOK9BiIgiZPx7GBo1Uz8nL5uSVx5DPpl1YZ53vomQ0ZPBGCjBnJ++i+u7ryvmzcinsAwchuON5/Fs21h2/P5RWO4bpZ4gM9/B/X1ZnTFz38HY/v5P1arinDsD19Kv1HvQzGbC5/6AYA/1TZ4lC3B+NiP4XjWDAdsjL/gmV6V0WEnCMeXlSoEVwLtnO6WfvlNl4er67qvKgfUsuCtLzgWf4N2xRQ2I7BOUjH0yOFjPvsv5xce4FlfOHVQ6fUKlwOoTBAU4prwMXk/gCbfbN5EqAVYA77aNlM75d9W9CPt8hUK8yfsCh/zwIW0oHNob+HvvDtU1jvdex7VkgTYI3W7kjDTfvz8swjnn/QtvrJQkSj98C8/mNZUDrHv5//Dur1rFEffyJRUu1Zrk8eBaOPeyqVzOL2eqQOiYNg7ldOUTZpyff4yUtC84b5P3+8LOVVFzT2bhLjdRXUsXVI1/gHvZQuSjR6pmZYdF+FfQQJWmpEI9P1BNDNwG71n7I551PwVfVcIjkI9lUDq7aiVESz94S6VeqQHr9eD8eraGmDZiuuVOLINHYLjuem2J+e2XlZ/ph/agFBWql7qWbbH/cwLWh55BrFGr4lUjoSm2J1/B9o8xiPUS1HxOOYBSUFYU2LNxlUpaAAj2EIzXd0Ksq5Ghr8iUzpoefN5t3aB53NyzL/ZnXsMy4H5N/d573n2KsxTXfz9Xt81ixZzYH8vQv2nr1IoSdPlXgTU6FvPAYZfUEHN+9WnFQLWH+iJtdRrgnP8xeAJXFWOr9oROnUX4gpWETv9cZXsoxUW4f1gc3OjybN+EUpivMhhCJs4IYJpzzvu+ZeD8Qfj1Z9+MrIQBJiUfUIOwcQtCJs7w62WmrrdR/MRQvzfAz/gatQh56xMEq+3sdbdy5on7VO32Jh/A1OUW32T6Xl3v1dihK/bnJyKE+DwdnvXLfVGi8wxMKWkfUsoBDE1bavfj8EHVMcvAYVhHPuVr2+19EOslUDrjzQrv82xag+IoUQ12yFv/wdCgse/A/Q/jnDVdBVDPL+uxPfZi0A95hIx7B7FhE1/w4BLmDnj379JUYQSrDcug4Zj7DkKwhyLn5+LZsj5wrJu1IuT19/1jbUgII2TMVErGPulXWwDca38MsCVEtW60ST0AGjPcOvxJlVRSHCWaQNTU5QrV1a3N/YcEGBFiXC2MN9ykus7Us58frABCaDjmxP7qd+Tn+t1l5aWrEBWD/YVJfrACmG69E8u9D6qlaBA9W2uVMA8IlGLmHn0RwgITcOTzHPzeHZvVxtGDj5eB9ZwhOPIfiHG1VTqxlB68/pYQHYsYE3fJv07j3am2E8SYOELf+wLL4BF+Q8u7dYNKb7Xe/3CgwShJSCkHEMpF5Mp7jkQt10Rgb0XMvQZorC8i5sS71RLnWHql3UAqCVu/kfpYgyYaxxprqAhqq1vxuP2SQAWqOwYi2NXJMZb+Q1UDG0yfV0qKy+lrkeowqMGAoV5DlTFSoZQ2mTDd3kdTLTP37KvWiauox14yjSBT/V6rRrKN98BulQQW4+vhXrYQx7RxFD/1F04PvpXiF0f53Hnl+BlUJZBPHAvEZd0GCBHajmpjy7bqAczLrlxvzerUvvOlXRkHbJqTRd2YitUQOTNNLaXbd6nQ7WRIaIKUlnyeKywtyMyTyw2GVfu5IRUHWOTsE6rJJ2j1GzC0bKe+v7DgTwFseawIVhsmjRVRPhFYYE+RvJx5bLC2b788THrfE1zCKs7AvUBibMV73QWNc4rTWanOClqgEy9PpFhr2Q6WcifWrqeylBVH8e9rRAV9UxzFKpedGBsXxHCqcUEp/0eRUhJYqE6sl6Bpv6j47/FUCqymrrdhHTIyuIRVOeiD+cxkjcz/8v7FakCKR6NNwaJEWuc8l6lfWgaqJAUR6NIFXU9/GF+Ly7mcKgqNBwnPak7K+PpY7v0r5p79VGFaFbeE0PCAjJ9gTvbySxmA4nJWO8BqhRLlvGwMFcTklfwc9TPCIi5P2yxW34CeNyGC8VzROucs/XMYW35iVZADEIx3gtmC2Lg5hvqNMSQ0xdCyraaNUiFgxbhaSOcD9sQx5OyTiHFqn6h393YNCVv9SgOVt6wBpIN7NA013G6klIMqy/dyqSu+9sUjZ2WcpzOnohTmI0RGa/B826WZKPaQAFea4tauvljR8SotIvH1kA4GFjkRIqOxP/UqxnZdKp0ToanDaiUduP73BVq6rnvFEvXxaljP1KgR6HCv+FZT3XFvWK5aJQzXtbm87WveujwTtXleVIh79TL18YtSCQKloZabEUlCyTmpeZ+Wl6dCwF6nNs6NrTtg7Ni9SmDVBKypY3f1IP64GPfKbwPAWjptHEqBRicdJdUOsIam16k8HdKRZJzzA78jKx9Lx6kRn79Q9tfvBqwGz11Lv8K99ocAfdEx5RVN4+9ijK7ymVly9kmVe82zY7MqaCOEhVdsv1TUvw7dVK5Cz6Y1vihWOYNTcZbiWvw5Z54YiuPNF1UTw6jFPDGmBnJeTsCML53xJq4l8xHjaiMlH0Ap1i5lLueeovoh1oi51wBciwJzF1wLP0PavwtD6w4oBXl4fl6p8pIIoeGYb0y8rM0zdb0FISIyML6vyJROfx3XN3MQo2OR0pJV0TD/pXk5VVdDatVBLueCdLwzHvuLkzA0bIJ0aC/Oj/+lvq9G7aq/K6YGpht74Nm4KrB//5mK64dFmNp3RQgNRT51As8v6/35A/KxDMTF87A+8GgQL4EoYhk8klKNxsrHMi6YlSRlpKEUn7mkid2Xgix334/7x/+qkim8B3arHNsB9w0eETzx2my9BCLWhGXQCJwaeQvy8aPIx4N/KERKOYDiLK3Qd6s5h1u2VQVE5KwMip9+wKevV+B2MrRuf1FdtD74ON7tm1QCQT56BFeQwIeUlhRcJQAw9x6IsW3nSq4tgsqt5Vn/U9Xvq+gyo+mCy5nvOmPQe4WISGxPvlw1HLVuj+Xu+4K3r7zLRjRcFN8s/YZgrCwYyhmAisuJZ9Pqs8/V8m+r22RO7K/KpS1DkVyhGmE+F4HTcsdZKp68Ys14bP8YU/W5XC5Qom36CiL20ZNVF6s63XewZgzffTa8Vj6L6vzfYnz9cg8zI0aq/Xhi7brqY3Xqa/ju6qmPlQuHmrr3uGCiiF+StGiDfczUC3oHyrdFq73nluCA55cPQ4si9jFTK8yE82Ni6EOYbu6lOn4upCnWrK0aS7FGTc32WIc/XgWlV8T21Kt+F6Fgtak8R1qh9QD+35ToSzaq5Epg6n47lnLZZWLFbo9QQt6YgXXEkwgRUeX0ujCsw5/A9vBzWP/2tFoan1WkLYOG+0OSgsWKdehDZY25rXfA4Fru+avm0mu8vlNAdr7p5l6a0Tcxvj6mG3uW3de2s6bEMvf+P0Le/Egz4//cQFjuG0XopA/9yRtBATTwLwjnwswGo2byDIC5z71luQuCgKVcBOccz0MnfYj1wSfUPI+KxfbYi1iHPYztkecxtu6gKXVNN/cKiL+be/SpsB+Wu+/H/sxrF/QxizFxhIx9G1P3HoHL/AOP+Se/WLuu5g4BFQhv7kXov7/E3OtubeAaTRjb3YD91bexv6TeUVG5YnDnNtblnkKMiNLcUCcl70fOy0EIi8DYrJX/vFJUiJR6CEPDpqpNgoqjBO+OzQhRsUGXQ8XlxLtjC4LFgrF914qlniLj2b4ZvF5MnW+seMk71+bUJKSDe5CLChFMJsR6CRjb3VAlXRB8QQhp/y4MjZoj1m0Y5LocpP07MSQ008zhVfE8Mw2lIA8hPBJDwyYqF5CUcgC5MB8xPBJD4+b+/srZJ/BsWIEQEYW5x10XTPdUXE682zbhPbgbJTcbpeQMQlg4Ys14DK3aY2rXpcJolXwyC/lkFoYWbarMNySvr4/5eSCKCJFRGOo0DGozXHNfkdHpyia9LoFOOmB10kkHrE466YC9skk+lu6L3l1D36PVP2R6hZLn55U4532AnH0SY4duFbrpdAmr059O3n27cC2eh3X4kwAqn60OWJ2qDSkuJ6UzJmF77CXk40cR6zQIWqtLB+wVSI4SB1eLu9k1/z8Ymvqq/Hm2b9IM0+qArabkdruZM3s2c2bP5uSJk6rzaWlp3NGjJ9e3akWLJk05c+bMZWnH2jVraN/mem7pfnnzZqWMVNw//hfrg48hpR9GOpKMpdyuUt3oqsbkdDqZ9PpEAFq2bEmt2oHJGPM//5y0tDQMBgPNmjVDvEzbXLxe72WbDAH9nfsBptvvQqxRC8fMF7EMGFb1mrg6YC8ebEfS0rBYrdhtdjZu/BmTycStt95KZFSZEeHxeFi/bh2HDx/GbrPTI7EndevWRZKkAJCUlDgodTiw2e1nf5eQn+crXZTYqxeT/zUFm80X69726zYO7N+Py+WiZauWdOveHcN5cXqPx8O6tWvJSM/AZDLRqXMnWrUO3MaSkpzML1t+oUZcDRS5curGsKH38ejjj3HLrbdWeM2B/fv5ZcsWiouLiYmJ4faePYmPj0dK2kfm4RSyW3Wl5drl5KWlstZWizpLl9K3bz/279/P5s2bsFlt3NWvLzVqlOm1hw4dYsO69eRkZxNftw6JiYnUq+/LMsvMyCApKYmwsDBat2nDpo0bub1HD8xmM8lJyaxZs5q8nFwaNWlM3379CA8P/1MB+6flEhw8cID+d/UlPDwct9uN82w9g/DwcGZ9Nof2HTqQk5PD8AceIDmprKiFwWBgwsSJtG3Xlv53BVZBSezVi49n+ra99O9zFwcPBm75WL5qJRMnTGDjzxsDjl/XsiVz5s0lNjaWjPQMRg4fTmZGYKJ6v/79mTb9XQwGA18uWMC4Ma/69eKQkBBKSkoICwtj196KvyjepGECU96eyr2DBmme/2LePMaPey3gmMlkYvbcz2i76Qe++HUH725PYnSrOqwpVtiU7qtrVa9+fY5mlpX0qVGjBqvXrcMeYuf96dN5f3pg1UCD0cDENyYx5L6hzJk9m0mvTyQiIgJFUSgqKmLnnt0s+uYb3npzMvJ5ubExMTEs+PorGjdpcu3qsEVFRbRu05pP58ymR88eFBUV8dLzL6AoCq+PH09yUjKt27RhwddfMWbcWCRJ4rVxYzEajUyb/q7/OU8/+yzDR47w/37muefo2Mn3dZmOnTox5e2pLJg/n40/b8RqtfLc8/9k3PjxxMTEcPDAAV59+RUA/vnss2RmZFCnTh3Gvz6Bfzz9FAajge+/+445s2aTl5fHGxNeR1EUEnv14r0Z/yYy8tKUcF+0cBFhYWHcN+x+tu/aSZeuXfF4PPzw9Vd4tqxjT4GDEe2aIsXU5NYHRhBX05dmeTQzk78/+gh3D/CVlMrJyeHAgQP8unWrH6yDhwxhxkcf0rtPHySvxNgxY0g/ku5/9+nTp/F4vXTt1o2srCymTH4LWZZ55dUxLF+1ksRevcjLy+O1seN0Hfb1NybRrHkzWrS4jjWru5GWlkZKcgorlvuKsHXq3ImjR48SHh5ObGwsubm5bN60mXvu/b/zpGsi17UsqzDYs1ciy3/6iR3bt9OgQQPuHTSIaVPfBuBvo0bx+JM+H2ZkVCTPPf0Mq1etIulQEr/t8m0beWPym9x8i6/yYW5OLl8uWMC3S5dSO742LpcLURSZ+s40wsLCKCku4ZXRozX79ujDfw/4PXfOZ6xc7ku2HjJ0KD0Sy3J4l3z3LY4SB79s2cKsT2eRdcxXCqh+4SkEi5VCxUvL3OOE/98LDPrrg+TnF/Dxhx/SoGEDXhw9mqKiIr5dutRnoElelv/k2/nRqFEj3pzyFoIg0DMxkV86b6GwsJDlP/2E2eJL5TObzWzYuJGo6Cg++uADJEkiMioKQRTZsGED8XXiAdj6yy8UFhZeskl6RQK2UWNfpnqt2rUQRRFZljl06CCS17cz87PZc1T3ZGZW/bPz2adO+Q20c9SseXOff1NR2Hvecn4++Fu0vA6A41lZZGf7Nu7ViIsjLMyXnF6nbt1LJGEXMmHca5SWlmIwGgg5m/BdwwiGhi25Jf9XVjlDGBVX8yzIfDmq9rNbhsrrl8ezfEU3mjRtinB2S47JZKJBgwYUFhZyPCuLho0S/GpEVLTPdjh61LeHrLCgwG/U+v3AisLRzKPXNmCzs7OJj4/nxIkTfp2p7nkg+ODjj+jW3bcVOi01FYvFQsOEBDznV0upRK2myKgoCgsKSE0tK4V//FhZfdOEhLKk6rTUVGJjY/1L7jlpHBriA1F+Xh5utxuz2eyfCFp0Tqc+p8MOHzlCU4fNyclhzMsvI3klHnviCR56eBQvvfACa1euQnGcwbs3i2xbJDuTkvzguxDVPKsypB4+7PtyuSAgeSWysnx9jonV9jBEnTV6ExISWLm2rGz7zxs20PmGG7BarX8aVqqFH3bKm5M5dOgQkydNAiA+Pp527dvTvIVP+n36yUyysrLYt3cvzz/3HPfcPYAd23cEWPbzPpvLr1u3Bn1PrzvuAGDWzJksXbKENavXMGXyZL+e26FjRxo18kn7ca+OZd3atSxauJAF8+cD0Lt3H7p1744gCHg8Hj7+8COSDiUx+9NPfzcPTp446V9R2rZry4b161m/dh2NY6NAljH3uIvFqYFliqzu4GWhet15pw+wqalMnDCBLZs388ro0eTm5iIIAnf07q15X/cbfRUIjxw5wgf/nkHq4cN88vF/GPngcO66szfuS1AN5oqWsMu+/55l33/vt2DHTRiPKIq8/sYbjBw+nF07d9K/z13+6/vffTfdunfDYDDQtFkzUpKTWbxoEWHhYdzQpUuF73nxpZfYt2cPBw8e5J/PPOs/Hhsby6TJbyIIAlPffYeHRozkcEoKo0aWfYmmfYcOPP7kk9hD7Dzy6KN8/NFHZy3w6RiNlWPjDV26BLibzqcW17WgYUJD0o+k+/Vem91OpzpxoODbA/afr/zXu777mqbHg3805aabb2LkQw8xZ9Ys5n02l3mfldVleHH0aFq0aMGWzepiyjfedCP3DhrE4kWLeHfaNN6dNg0Ai8XCK6+OwVyF741ddW4tgJmzZ7Fn925MJhOJve6gWfOyzKPjx4/z9Zdfkn4knYiICG7r0YPbe9zuXxYLCwpYsXwFDoeD9h070LZtWVmc7du2k5GRToMGDenUuZPfx/rDsmXs2rkLWZJo2qwZA+4ZGKD/FeQX8O3SpaSkJGM2m+nYqRO9e/fBYCyT6GtWr2HD+vVER0dxZ+8+7Nu3F5PJ5LfUL4by8vKY//kX5GRn065De9oZZXKWLcLqdtFm3BS+2rIdt9tN72g7EQd3kXznUHb99hvR0dEMGOjbADhntu/7FH363OUPpOzauZPVK1eRm5tLXM2a9O7Tm5atWvn9vlu3biU0NJTBQ4YE6KprVq1m9epVFBUV0ahRY+4dNIgGDRtc235YgHUbfw7QWXXyfUrKOe9DzH3upfT9iZj7DcY26lncK75FStqL7fHRF9xkeTWSng9bDUk+mYX7p/8RMuZfCGEReDavwb1iKVLKQSz9hmB7auw1yxt916xOVxTp+bA66YDVSScdsDrppANWpyuN/h828PjGOXyRegAAAABJRU5ErkJggg==',
                    fit: [120, 120],
                    alignment: 'right',
                    margin: [0, -18, -25, 20],
                  }]
                }]
              ]
            },
            // page break for every new brand upto last but one page
            pageBreak: i === data.length - 1 ? '' : 'after',
            layout: 'noBorders'
          }];
          var insertRow = insideTable(data[i]);
          insideContent[0].table.body.push(insertRow);
          mainContent.push(insideContent);
        }
        return mainContent;
      }

      // main content with page margins, table header and body styles
      var dd = {
        pageMargins: [20, 30, 0, 0],
        content: [{
          table: {
            body: headerImages()
          },
          layout: 'noBorders'
        }],
        styles: {
          tableHeader: {
            bold: true,
            fontSize: 8,
            color: '#303030',
            alignment: 'center',
            fillColor: '#E0E0E0 '
          },
          tableRow: {
            fontSize: 8,
            color: '#303030',
            bold: true,
            alignment: 'center'
          },
          mainHeader: {
            fontSize: 28,
            color: '#ffb400',
            bold: true,
          },
          contentText: {
            fontSize: 8,
            color: '#585858',
          },
          contextHeader: {
            fontSize: 8,
            bold: true,
            color: '#303030'
          },
          subHeader: {
            fontSize: 16,
            bold: true,
            color: '#989898'
          }
        }
      };

      return dd;
    };

    this.exportProductOverview = function(endPoint, callback) {
      $httpHelper.httpRequest('GET', endPoint, null, function(data) {
        callback(data);
      });
    };
  }
})();
