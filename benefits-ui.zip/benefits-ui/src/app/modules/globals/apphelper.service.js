/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 06-11-2018
 */

(function () {
    'use strict';

    angular.module('scorpion')
        .service('$appHelper', AppHelper);

    function AppHelper($window, URL) {

        this.pageSize = 25; // default page size for pagenated tables

        // Clears the global values
        this.clear = function () {
            this.editQuote = null;
            this.quoteHeader = null;
            this.editCredit = null;
            this.copyQuote = null;
            this.editCreditHeader = null;
            this.trx_id = null;
            this.invoice_number = null;
            this.customer_number = null;
            this.sales_group = null;
            this.year = null;
            this.saved_group = null;
            this.customer_name = null;
            this.fromPo = null;
            this.fromEditQuote = null;
            this.createInvoiceData = null;
            this.loadData = null;
            this.selectedAgent = null;
            this.selectedCustomer = null;
            this.selectedCustomerName = null;
            this.statusMsg = null;
            this.reservation_id = null;
            this.editBooking = null;
            this.stand_id = null;
            this.bookingStatus = null;
            this.bookingMsg = null;
            this.report_id = null;
            this.hostessStatus = null;
            this.hostessMsg = null;
            this.salesChannel = null;
            this.copyCredit = null;
            this.copyCreditHeader = null;
            this.emptyBillTo = null;
            this.editUser = null;
            this.permission_status = null;
            this.permission_msg = null;
            this.role_status = null;
            this.role_msg = null;
            this.userSuccess = null;
            this.vendor_id = null;
            this.registerStatus = null;
            this.registerMsg = null;
            this.customerOrg = null;
            this.customerProfile = null;
            this.lovData = null;
            this.wfUserKey = null;
            this.wfType = null;
            this.wfItemKey = null;
            this.wfUsername = null;
            this.procReqId = null;
            this.procLines = null;
            this.order_id = null;
            this.order_org = null;
            this.categories = null;
            this.successProc = null;
            this.scheduleCopy = null;
            this.scheduleSave = null;
            this.po_details = null;
            this.byReport = null;
            this.disputeSaveMsg = null;
            this.byReport = null;
            this.viewProduct = null;
            this.editBrand = null;
            this.segName = null;
            this.prodName = null;
            this.onBoardBrands = null;
            this.onBoardSegments = null;
            this.pindex = null;
            this.sindex = null;
            this.category = null;
            this.disputeSaveMsg = null;
            this.onBoard_ids = null;
            this.productSaveSuccess = null;
            this.segmentSaveSuccess = null;
            this.managerNumber = null;
            this.forecastItems = null;
            this.forecastSuppliers = null;
            this.forecastVendorId = null;
            this.forecastSegmentId = null;
            this.forecastWeeks = null;
            this.requestHeaderId = null;
            this.selectedGrp = null;
            this.addpage = null;
            this.editPage = null;
            this.fromDonation = null;
            this.adoptionId = null;
        };

        // Creates a cookie with given name and value, which expires
        // in given no. of days
        this.createCookie = function (name, value, days) {
            var expires;
            if (days) {
                var date = new Date();
                date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
                expires = '; expires=' + date.toGMTString();
            } else {
                expires = '';
            }
            document.cookie = name + '=' + value + expires + '; path=/';
        };

        // Returns a cookie that matches with the given name
        this.readCookie = function (name) {
            var nameEQ = name + '=';
            var ca = document.cookie.split(';');
            for (var i = 0; i < ca.length; i++) {
                var c = ca[i];
                while (c.charAt(0) === ' ') {
                    c = c.substring(1, c.length);
                }
                if (c.indexOf(nameEQ) === 0) {
                    return c.substring(nameEQ.length, c.length);
                }
            }
            return null;
        };

        // Deletes a cookie from browser that matches with given name
        this.eraseCookie = function (name) {
            this.createCookie(name, '', -1);
        };

        // Call this method to scroll to top of the page
        this.scrollTop = function () {
            $('html, body').animate({
                scrollTop: 0
            }, 500, 'linear');
        };

        // Checks if the brosers is IE or not
        this.isIE = function () {
            var browser = window.navigator.appVersion;
            return ((browser.indexOf('Trident') !== -1 && browser.indexOf('rv:11') !== -1) ||
                (browser.indexOf('MSIE 10') !== -1));
        };

        // Checks if the browser is Safari or not
        this.isSafari = function () {
            var userAgent = window.navigator.userAgent.toLowerCase();
            return userAgent.indexOf('safari') !== -1 && userAgent.indexOf('chrome') === -1;
        };

        // Check if the browser is Chrome is not
        this.isChrome = function () {
            var isChromium = window.chrome, winNav = window.navigator;
            var isOpera = typeof window.opr !== 'undefined';
            var isIEedge = winNav.userAgent.indexOf('Edge') > -1;
            var isIOSChrome = winNav.userAgent.match('CriOS');

            if (isIOSChrome) {
                return true;
            } else if (isChromium !== null && typeof isChromium !== 'undefined' &&
                winNav.vendor === 'Google Inc.' && isOpera === false && isIEedge === false) {
                return true;
            }

            return false;
        };

        // Export table data to excel
        this.tableToExcel = function (name, data, link, className) {
            var uri = 'data:application/vnd.ms-excel;base64,',
                template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><meta http-equiv="content-type" content="application/vnd.ms-excel; charset=UTF-8"><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>',
                base64 = function (s) {
                    return window.btoa(unescape(encodeURIComponent(s)));
                },
                format = function (s, c) {
                    return s.replace(/{(\w+)}/g, function (m, p) {
                        return c[p];
                    });
                };

            var dummyTable = getExportTable(data);
            if (dummyTable) {
                var ctx = {
                    worksheet: name,
                    table: dummyTable
                };

                var browser = window.navigator.appVersion;
                // If browser is IE then export as Blob
                if ((browser.indexOf('Trident') !== -1 && browser.indexOf('rv:11') !== -1) ||
                    (browser.indexOf('MSIE 10') !== -1)) {
                    var builder = new window.MSBlobBuilder();
                    builder.append(uri + format(template, ctx));
                    var blob = builder.getBlob('data:application/vnd.ms-excel');
                    window.navigator.msSaveBlob(blob, name + '.xls');
                } else {
                    var element;
                    if (className) {
                        var elementList = document.getElementsByClassName(className);
                        if (elementList && elementList.length > 0) {
                            element = elementList[elementList.length - 1];
                        }
                    } else if (link) {
                        element = document.getElementById(link);
                    } else {
                        element = document.createElement('a');
                    }
                    element.href = uri + base64(format(template, ctx));
                    element.download = name + '.xls';
                    if (!link) {
                        document.body.appendChild(element);
                        element.click();
                        document.body.removeChild(element);
                    }
                }
            }
            // if (window.navigator.userAgent.indexOf('Mac') !== -1) {
            //   this.exportToCSV(name, data, link);
            // } else {
            // }

            clearLink(link);
        };

        this.exportToCSV = function (name, data, link) {
            var csvData = getExportCSV(data);
            var browser = window.navigator.appVersion;
            var uri = 'data:attachment/csv;base64,',
                base64 = function (s) {
                    return window.btoa(unescape(encodeURIComponent(s)));
                };

            // If browser is IE then export as Blob
            if ((browser.indexOf('Trident') !== -1 && browser.indexOf('rv:11') !== -1) ||
                (browser.indexOf('MSIE 10') !== -1)) {
                var blob = new Blob([csvData], {
                    type: "text/csv;charset=utf-8;"
                });
                window.navigator.msSaveBlob(blob, name + ".csv");
            } else if (this.isSafari()) {
                var fileData = {};
                fileData.file_name = name + '.csv';
                fileData.file_data = base64(csvData);
                fileData.content_type = 'text/csv';
                this.downloadFile(fileData);
            } else {
                var element;
                if (link) {
                    element = document.getElementById(link);
                } else {
                    element = document.createElement('a');
                }

                element.href = uri + base64(csvData);
                element.download = name + '.csv';
                if (!link) {
                    element.click();
                }
            }

        };

        // Build html table from the data
        function getExportTable(tableData) {
            var data = tableData.data;
            if (data && data.length > 0) {
                var i, text, align;
                var tableMarkup = '<thead><tr>';
                var keys = Object.keys(data[0]);
                for (i = 0; i < keys.length; i++) {
                    tableMarkup += '<th style="background-color: #ddd" nowrap>' + keys[i] + '</th>';
                }
                tableMarkup += '</tr></thead><tbody>';
                for (i = 0; i < data.length; i++) {
                    tableMarkup += '<tr>';
                    for (var column in data[i]) {
                        if (data[i].hasOwnProperty(column)) {
                            text = data[i][column].data || '';
                            align = data[i][column].hasOwnProperty('align') ? data[i][column].align : 'left';
                            tableMarkup += '<td align="' + align + '" nowrap>' + text + '</td>';
                        }
                    }
                    tableMarkup += '</tr>';
                }
                if (tableData.hasOwnProperty('footer')) {
                    var footer = tableData.footer;
                    tableMarkup += '<tr>';
                    for (i = 0; i < footer.length; i++) {
                        text = footer[i].data || '';
                        align = footer[i].hasOwnProperty('align') ? footer[i].align : 'left';
                        tableMarkup += '<td align="' + align + '" style="background-color: #ddd" nowrap><b>' + text + '</b></td>';
                    }
                    tableMarkup += '</tr>';
                }
                tableMarkup += '</tbody>';
                return tableMarkup;
            }
            return '<tbody><tr><td colspan="10">No data found for selected parameters</td></tr></tbody>';
        }

        function getExportCSV(tableData) {
            var data = tableData.data;
            if (data && data.length > 0) {
                var i, text, row;
                var csvData = '';
                var keys = Object.keys(data[0]);
                for (i = 0; i < keys.length - 1; i++) {
                    csvData += '"' + keys[i] + '",';
                }
                csvData += '"' + keys[keys.length - 1] + '"\n';
                for (i = 0; i < data.length; i++) {
                    row = '';
                    for (var column in data[i]) {
                        if (data[i].hasOwnProperty(column)) {
                            text = data[i][column].data;
                            row += '"' + text + '",';
                        }
                    }
                    row = row.substring(0, row.length - 1);
                    csvData += row + '\n';
                }
                if (tableData.hasOwnProperty('footer')) {
                    var footer = tableData.footer;
                    row = '';
                    for (i = 0; i < footer.length; i++) {
                        text = footer[i].data;
                        row += '"' + text + '",';
                    }
                    row = row.substring(0, row.length - 1);
                    csvData += row + '\n';
                }
                return csvData;
            }
            return null;
        }

        // Export table directly from html
        this.exportUITable = function (table, name, link) {
            var uri = 'data:application/vnd.ms-excel;base64,',
                template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>',
                base64 = function (s) {
                    return window.btoa(unescape(encodeURIComponent(s)));
                },
                format = function (s, c) {
                    return s.replace(/{(\w+)}/g, function (m, p) {
                        return c[p];
                    });
                };
            var dummyTable = document.getElementsByClassName(table);
            if (dummyTable && dummyTable.length > 0) {
                var ctx = { worksheet: name, table: dummyTable[0].innerHTML };

                var browser = window.navigator.appVersion;
                if ((browser.indexOf('Trident') !== -1 && browser.indexOf('rv:11') !== -1) ||
                    (browser.indexOf('MSIE 10') !== -1)) {
                    var builder = new window.MSBlobBuilder();
                    builder.append(uri + format(template, ctx));
                    var blob = builder.getBlob('data:application/vnd.ms-excel');
                    window.navigator.msSaveBlob(blob, name + '.xls');
                } else if (this.isSafari()) {
                    var fileData = {};
                    fileData.file_name = name + '.xls';
                    fileData.file_data = base64(format(template, ctx));
                    fileData.content_type = 'application/vnd.ms-excel';
                    this.downloadFile(fileData);
                } else {
                    var element = document.getElementById(link);
                    // element.href = uri + base64(format(template, ctx));
                    var xData = new Blob([format(template, ctx)], { type: 'application/vnd.ms-excel' });
                    element.href = $window.URL.createObjectURL(xData);
                    element.download = name + '.xls';
                }
            }
            clearLink(link);
        };

        // Export multiple tables into single excel file
        this.exportMultiTable = function (name, list, link) {
            var uri = 'data:application/vnd.ms-excel;base64,',
                template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>',
                base64 = function (s) {
                    return window.btoa(unescape(encodeURIComponent(s)));
                },
                format = function (s, c) {
                    return s.replace(/{(\w+)}/g, function (m, p) {
                        return c[p];
                    });
                };
            var dummyTable = '';
            if (list) {
                var span, data, title, colspan;
                for (var i = 0; i < list.length; i++) {
                    data = list[i].tableData;
                    if (data.data[0]) {
                        span = Object.keys(data.data[0]);
                    }
                    title = list[i].title;
                    colspan = list[i].span ? list[i].span : span.length;
                    dummyTable += '<tr>';
                    dummyTable += '<td colspan="' + colspan + '" align="left" style="font-size: 16px;"><b>' + title + '</b></td>';
                    dummyTable += '</tr>';
                    dummyTable += '<tr><td colspan="' + colspan + '"><table>';
                    dummyTable += getExportTable(data);
                    dummyTable += '</td></table>';
                    dummyTable += '</tr>';
                }
            }
            if (dummyTable) {
                var ctx = { worksheet: name, table: dummyTable };

                var browser = window.navigator.appVersion;
                if ((browser.indexOf('Trident') !== -1 && browser.indexOf('rv:11') !== -1) ||
                    (browser.indexOf('MSIE 10') !== -1)) {
                    var builder = new window.MSBlobBuilder();
                    builder.append(uri + format(template, ctx));
                    var blob = builder.getBlob('data:application/vnd.ms-excel');
                    window.navigator.msSaveBlob(blob, name + '.xls');
                } else if (this.isSafari()) {
                    var fileData = {};
                    fileData.file_name = name + '.xls';
                    fileData.file_data = base64(format(template, ctx));
                    fileData.content_type = 'application/vnd.ms-excel';
                    this.downloadFile(fileData);
                } else {
                    var element;
                    element = document.getElementById(link);
                    element.href = uri + base64(format(template, ctx));
                    element.download = name + '.xls';
                }
            }

            clearLink(link);
        };

        // Returns date after the no. of days passed as param
        this.today = function (days) {
            var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug',
                'Sep', 'Oct', 'Nov', 'Dec'
            ];
            var date = new Date();
            if (days) {
                date.setDate(date.getDate() + days);
            }
            return date.getDate() + '-' + months[date.getMonth()] + '-' + date.getFullYear();
        };

        this.replaceAll = function (str, src, tgt) {
            var index = str.indexOf(src);
            while (index !== -1) {
                str = str.replace(src, tgt);
                index = str.indexOf(src);
            }
            return str;
        };

        // Use to toggle filter
        this.toggleFilter = function () {
            return function (e) {
                if (e) {
                    e.preventDefault();
                }
                var left;
                if (!$('.filter ').hasClass('active')) {
                    $('.filter').addClass('active');
                    $('.filter-container').show();
                    $('.filter-container').css({ left: '0px' });
                    left = '0px';
                } else {
                    $('.filter').removeClass('active');
                    left = '-350px';
                }


                $('.filter-wrapper').animate({
                    left: left
                }, 500, 'linear', function () {
                    if (left === '-350px') {
                        $('.filter-container').hide();
                        $('.filter-container').css({ left: '-102%' });
                    }
                });

                $('.filter-wrapper').click(function (e) {
                    e.stopPropagation();
                });

                $('.filter-container').click(function () {
                    $('.filter-wrapper').animate({
                        left: '-350px'
                    }, 500, 'linear', function () {
                        $('.filter').removeClass('active');
                        $('.filter-container').hide();
                        $('.filter-container').css({ left: '-102%' });
                    });
                });

            };
        };

        this.validateEmail = function (email, extn) {
            var dotLastIndex = -1, atIndex, atCount = 0, i;
            for (i = 0; i < email.length; i++) {
                if (email[i] === '@') {
                    atCount++;
                }
                if (email[i] === '.') {
                    dotLastIndex = i;
                }
            }

            if (atCount > 1) {
                return false;
            }
            atIndex = email.indexOf('@');
            if (atIndex === -1) {
                return false;
            }
            if (dotLastIndex === -1) {
                return false;
            }
            if (atIndex > dotLastIndex) {
                return false;
            }
            if (dotLastIndex === email.length - 1) {
                return false;
            }
            if (dotLastIndex === atIndex + 1) {
                return false;
            }
            if (email[atIndex + 1] === '.') {
                return false;
            }
            var gTLD = email.substring(dotLastIndex + 1, email.length);
            if (gTLD.length < 2) {
                return false;
            }

            if (extn) {
                var mailArr = email.split('@');
                if (mailArr[1] !== extn) {
                    return false;
                }
            }

            return true;
        };

        this.hexToRgb = function (hex) {
            var shortHand = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
            hex = hex.replace(shortHand, function (m, r, g, b) {
                return r + r + g + g + b + b;
            });

            var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
            return result ? {
                r: parseInt(result[1], 16),
                g: parseInt(result[2], 16),
                b: parseInt(result[3], 16)
            } : null;
        };

        this.isMobile = function () {
            var mobile = {
                Windows: function () {
                    return /IEMobile/i.test(window.navigator.userAgent);
                },
                Android: function () {
                    return /Android/i.test(window.navigator.userAgent);
                },
                BlackBerry: function () {
                    return /BlackBerry/i.test(window.navigator.userAgent);
                },
                iOS: function () {
                    return /iPhone|iPad|iPod/i.test(window.navigator.userAgent);
                }
            };

            return (mobile.Android() || mobile.BlackBerry() || mobile.iOS() || mobile.Windows());
        };

        this.downloadFile = function (data) {
            var form = document.createElement('form');
            form.id = 'file-download-form';
            form.action = URL + '/login/filedownload/';
            form.method = 'POST';
            form.innerHTML = '<input type="hidden" name="file_name" value="' + data.file_name + '">' +
                '<input type="hidden" name="content_type" value="' + data.content_type + '">' +
                '<input type="hidden" name="file_data" value="' + data.file_data + '">';
            document.body.appendChild(form);
            form.submit();
            window.setTimeout(function () {
                document.body.removeChild(form);
            }, 1000);
        };

    }

    function clearLink(link) {
        window.setTimeout(function () {
            var aLink = document.getElementById(link);
            if (aLink) {
                aLink.href = 'javascript:void(0)';
            }
        }, 3000);
    }

})();
