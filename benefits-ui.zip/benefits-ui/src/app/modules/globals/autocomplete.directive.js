/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 10-10-2018
 */

(function () {
    'use strict';

    angular.module('scorpion')
        .directive('fdAutocomplete', fdAutoComplete);

    function fdAutoComplete() {
        return {
            restrict: 'A',
            require: 'ngModel',
            scope: {
                items: '=',
                onSelect: '&'
            },
            link: function (scope, elem, attrs, ngModel) {
                var bind = attrs.bind, label = attrs.label, sublabel = attrs.sublabel,
                    autoWidth = attrs.autowidth, autoShow = attrs.autoshow;
                var isSelected = false, element = elem[0].parentElement;
                var rect = elem[0].getBoundingClientRect();

                scope.$watch(function () {
                    return ngModel.$modelValue;
                }, function (value, oldValue) {
                    if (!isSelected) {
                        if (value !== oldValue) {
                            if (value && typeof value === 'string') {
                                buildSuggestions(value.toLowerCase());
                            } else {
                                removeSuggestions();
                            }
                        }
                    } else {
                        isSelected = false;
                    }
                });

                scope.$watch(function () {
                    return attrs.updateValue;
                }, function (value) {
                    window.setTimeout(function () {
                        updateValue(value);
                    }, 1250);
                });

                if (autoShow) {
                    elem[0].addEventListener('focus', function () {
                        buildSuggestions('%');
                    });
                }

                // removes auto suggestions
                function removeSuggestions() {
                    var container = element.getElementsByClassName('fd-suggestions')[0];
                    if (container) {
                        element.removeChild(container);
                    }
                }

                // This is called when an item from suggestions is selected
                function onItemSelect(event) {
                    var value;
                    if (bind && label) {
                        value = event.target.dataset.value;
                    } else {
                        value = event.target.dataset.label;
                    }
                    elem.val(event.target.dataset.label);
                    scope.$apply(function () {
                        isSelected = true;
                        ngModel.$setViewValue(value);
                        removeSuggestions();
                        scope.onSelect();
                    });
                }

                function updateValue(value) {
                    if (scope.items && value && value.length > 0) {
                        var index = scope.items.map(function (x) {
                            return x[bind] + '';
                        }).indexOf(value);
                        if (index !== -1) {
                            var labelValue = scope.items[index][label];
                            elem.val(labelValue);
                            scope.$apply(function () {
                                isSelected = true;
                                ngModel.$setViewValue(value);
                                //scope.onSelect();
                            });
                        }
                    }
                }

                // Build the auto suggestions from the array of values
                function buildSuggestions(value) {
                    var container = element.getElementsByClassName('fd-suggestions')[0];
                    if (container) {
                        element.removeChild(container);
                    }
                    if (value.length > 0 && scope.items) {
                        var i, items = scope.items;
                        container = document.createElement('div');
                        container.className = 'fd-suggestions';
                        if (!autoWidth) {
                            container.style.width = '99%';
                            container.style.top = (rect.height + 2) + 'px';
                        }

                        var template = '', results = [];
                        if (value === '%') {
                            results = items;
                        } else if (value.indexOf('%') === value.length - 1) {
                            var substr = value.substring(0, value.length - 1);
                            matchItems(substr, true);
                        } else {
                            matchItems(value, true);
                        }

                        var count;
                        if (value === '%' || value.indexOf('%') === value.length - 1) {
                            count = results.length;
                        } else {
                            count = results.length > 10 ? 10 : results.length;
                            // count = results.length;
                        }
                        for (i = 0; i < count; i++) {
                            if (bind && label) {
                                template += '<div class="fd-suggestion-item" data-value="' + results[i][bind] +
                                    '" data-label="' + results[i][label] + '">';
                                if (sublabel) {
                                    template += results[i][label] + ', ' + results[i][sublabel];
                                } else {
                                    template += results[i][label];
                                }
                                template += '</div>';
                            } else {
                                template += '<div class="fd-suggestion-item" data-label="' + results[i] + '">' + results[i] + '</div>';
                            }
                        }

                        element.appendChild(container);
                        container.innerHTML = template;

                        var elems = element.getElementsByClassName('fd-suggestion-item');
                        for (i = 0; i < elems.length; i++) {
                            if (window.addEventListener) {
                                elems[i].addEventListener('click', onItemSelect, false);
                            } else {
                                elems[i].attachEvent('onclick', onItemSelect, false);
                            }
                        }
                    }

                    function matchItems(value, anyIndex) {
                        var index;
                        for (i = 0; i < items.length; i++) {
                            if (bind && label) {
                                if (items[i] && items[i].hasOwnProperty(label)) {
                                    index = items[i][label].toLowerCase().indexOf(value);
                                    if ((anyIndex && index !== -1) || index === 0) {
                                        results.push(items[i]);
                                    }
                                }
                            } else {
                                if (items[i]) {
                                    index = items[i].toLowerCase().indexOf(value);
                                    if ((anyIndex && index !== -1) || index === 0) {
                                        results.push(items[i]);
                                    }
                                }
                            }
                        }
                    }

                }

                // Add click event listener to suggested items
                document.addEventListener('click', function (e) {
                    var container = element.querySelector('.fd-suggestions');
                    if (elem[0] !== document.activeElement) {
                        if (e && e.target) {
                            var target = e.target;
                            while (target.parentNode) {
                                if (target !== container) {
                                    removeSuggestions();
                                    return;
                                }
                                target = target.parentNode;
                            }
                        }
                    }
                });

            }
        };

    }
})();
