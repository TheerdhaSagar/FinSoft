/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 10-10-2018
 */

(function() {
  'use strict';

  angular.module('scorpion')
    .directive('addressbook', AddressBook);

  // Directive used to create dynamic child tables
  function AddressBook() {
    return {
      restrict: 'E',
      transclude: true,
      templateUrl: 'app/modules/supplier/supplieraddressbookdetails.html'
    };
  }
})();
