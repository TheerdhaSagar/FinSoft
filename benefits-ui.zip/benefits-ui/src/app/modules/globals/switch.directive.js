/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 10-10-2018
 */


(function() {
  'use strict';

  angular.module('scorpion')
    .directive('toggleswitch', toggleSwitch);

  function toggleSwitch() {
    return {
      restrict: 'A',
      require: 'ngModel',
      scope: {},
      link: function(scope, elem, attrs, ngModel) {
        scope.$watch(function() {
          return ngModel.$modelValue;
        }, function(value, oldValue) {
          if (value !== oldValue) {
            if (elem[0].parentElement.classList.contains('toggle')) {
              elem[0].parentElement.onclick = toggle;
            } else {
              elem[0].parentElement.onclick = changeToggle;
            }
          }
        });

        if (elem[0].parentElement.classList.contains('toggle')) {
          elem[0].parentElement.onclick = toggle;
        } else {
          elem[0].parentElement.onclick = changeToggle;
        }


        //invoked when clicked on toggle component
        function toggle(event) {
          event.stopPropagation();
          var switchType = elem[0].parentElement.getAttribute('data-switch');
          var listofclasses = elem[0].parentElement.classList;
          if (!ngModel.$modelValue) {
            //switch on
            elem[0].ngChecked = true;
            listofclasses.remove('toggle__off');
            listofclasses.add('toggle__on');
            listofclasses.add('toggle__on--' + switchType);
            ngModel.$setViewValue(true);
          } else {
            //switch off
            elem[0].ngChecked = false;
            listofclasses.remove('toggle__on');
            listofclasses.remove('toggle__on--' + switchType);
            listofclasses.add('toggle__off');
            ngModel.$setViewValue(false);
          }
        }

        //invoked when clicked on toggle component of type rectangular switch
        function changeToggle(event) {
          event.stopPropagation();
          var childElement = elem[0].parentElement.querySelector('.switch__rectangle');
          var targetClasslist = childElement.classList;
          if (!ngModel.$modelValue) {
            elem[0].ngChecked = true;
            targetClasslist.remove('switch__rectangle--off');
            targetClasslist.add('switch__rectangle--on');
            ngModel.$setViewValue(true);
          } else {
            elem[0].ngChecked = false;
            targetClasslist.remove('switch__rectangle--on');
            targetClasslist.add('switch__rectangle--off');
            ngModel.$setViewValue(false);
          }
        }
      }
    };
  }
})();
