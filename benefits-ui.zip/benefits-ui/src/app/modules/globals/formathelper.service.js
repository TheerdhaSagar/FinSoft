/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 10-10-2018
 */

(function() {
  'use strict';

  angular.module('scorpion')
    .service('$formatHelper', FormatHelper);

  function FormatHelper($cacheHelper) {

    var seperators = ['.', '-', '/']; // default seperators used in date formats
    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep',
      'Oct', 'Nov', 'Dec'
    ];

    var weekDays = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

    var currencies = { 'USD': '$', 'EUR': '€', 'GBP': '£' };

    // Formats and returns used based time zone

    this.formatTimeZone = function(time, from_time_zone, to_time_zone) {
      var formattedTime;
      if (to_time_zone === 'CST' && from_time_zone === 'EST') {
        formattedTime = parseInt(time) - 1;
      } else if(to_time_zone === 'EST' && from_time_zone === 'CST') {
        formattedTime = parseInt(time) + 1;
      } else if(to_time_zone === 'PST' && from_time_zone === 'EST') {
        formattedTime = parseInt(time) - 3;
      } else if(to_time_zone === 'EST' && from_time_zone === 'PST') {
        formattedTime = parseInt(time) + 3;
      } else if(to_time_zone === 'CST' && from_time_zone === 'PST') {
        formattedTime = parseInt(time) + 2;
      } else if(to_time_zone === 'PST' && from_time_zone === 'CST') {
        formattedTime = parseInt(time) - 2;
      }
      return formattedTime;
    };

    // Formats and returns date based on user preferences
    this.formatDate = function(date, format) {
      var seperator, formattedDate;
      var dateFormat;

      if (format) {
        dateFormat = format;
      } else {
        $cacheHelper.getUser(function(data) {
          if (!$cacheHelper.user) {
            $cacheHelper.initialize(data);
          }
          dateFormat = data.date_format;
        });
      }

      if (!dateFormat || date === null || date === undefined) { return date; }

      for (var i = 0; i < seperators.length; i++) {
        if (dateFormat.indexOf(seperators[i]) > 0) {
          seperator = seperators[i];
          break;
        }
      }

      var dayIndex = dateFormat.indexOf('dd');
      var monthIndex = dateFormat.indexOf('MMM');
      var yearIndex = dateFormat.indexOf('yyyy');

      if (!this.isDateFormattable(date)) { return date; }

      try {
        var dateArray = date.split('-');
        var day = dateArray[0].length === 1 ? '0' + dateArray[0] : dateArray[0];
        var month = dateArray[1];
        var year = dateArray[2];

        var alphaMonth = month.charAt(0).toUpperCase() +
          month.slice(1).toLowerCase();

        month = months.indexOf(alphaMonth) + 1;

        if (month < 10) { month = '0' + month; }

        if (monthIndex !== -1) { // This case will be true for alphabetic month
          if (dayIndex < yearIndex) {
            formattedDate = day + seperator + alphaMonth + seperator + year;
          } else {
            formattedDate = year + seperator + alphaMonth + seperator + day;
          }
        } else { // This case will be true for numeric month
          monthIndex = dateFormat.indexOf('MM');
          if ((monthIndex < dayIndex) && (dayIndex < yearIndex)) {
            formattedDate = month + seperator + day + seperator + year;
          } else if ((dayIndex < monthIndex) && (monthIndex < yearIndex)) {
            formattedDate = day + seperator + month + seperator + year;
          } else {
            formattedDate = year + seperator + month + seperator + day;
          }
        }
      } catch (err) {
        return date;
      }

      return formattedDate;
    };

    // Parse the given date and return a new date in dd-MMM-yyyy format
    this.parseDate = function(date, format) {
      var seperator, parsedDate;
      var dateFormat;

      if (format) {
        dateFormat = format;
      } else {
        $cacheHelper.getUser(function(data) {
          if (!$cacheHelper.user) {
            $cacheHelper.initialize(data);
          }
          dateFormat = data.date_format;
        });
      }

      if (!dateFormat) { return date; }

      for (var i = 0; i < seperators.length; i++) {
        if (dateFormat.indexOf(seperators[i]) > 0) {
          seperator = seperators[i];
          break;
        }
      }

      var dayIndex = dateFormat.indexOf('dd');
      var monthIndex = dateFormat.indexOf('MMM');
      var yearIndex = dateFormat.indexOf('yyyy');

      try {
        var dateArray = date.split(seperator);
        var alphaMonth;

        if (monthIndex === -1) { // This case will be true for numeric month
          monthIndex = dateFormat.indexOf('MM');

          if ((monthIndex < dayIndex) && (dayIndex < yearIndex)) {
            alphaMonth = months[parseInt(dateArray[0] - 1)];
            parsedDate = dateArray[1] + '-' + alphaMonth + '-' + dateArray[2];
          } else if ((dayIndex < monthIndex) && (monthIndex < yearIndex)) {
            alphaMonth = months[parseInt(dateArray[1] - 1)];
            parsedDate = dateArray[0] + '-' + alphaMonth + '-' + dateArray[2];
          } else {
            alphaMonth = months[parseInt(dateArray[1] - 1)];
            parsedDate = dateArray[2] + '-' + alphaMonth + '-' + dateArray[0];
          }
        } else { // This case will be true for alphabetic month
          if ((monthIndex < dayIndex) && (dayIndex < yearIndex)) {
            alphaMonth = dateArray[0].charAt(0).toUpperCase() +
              dateArray[0].slice(1).toLowerCase();
            parsedDate = dateArray[1] + '-' + alphaMonth + '-' + dateArray[2];
          } else if ((dayIndex < monthIndex) && (monthIndex < yearIndex)) {
            alphaMonth = dateArray[1].charAt(0).toUpperCase() +
              dateArray[1].slice(1).toLowerCase();
            parsedDate = dateArray[0] + '-' + alphaMonth + '-' + dateArray[2];
          } else {
            alphaMonth = dateArray[1].charAt(0).toUpperCase() +
              dateArray[1].slice(1).toLowerCase();
            parsedDate = dateArray[2] + '-' + alphaMonth + '-' + dateArray[0];
          }
        }
      } catch (err) {
        return date;
      }

      return parsedDate;
    };

    // Checks whether the given date is formattable or not
    this.isDateFormattable = function(date) {
      try {

        var splitDate = date.split('-');
        var alphaMonth = splitDate[1].charAt(0).toUpperCase() +
          splitDate[1].slice(1).toLowerCase();

        if (date.indexOf('-') > 0 &&
          (parseInt(splitDate[0]) < parseInt(splitDate[2])) &&
          months.indexOf(alphaMonth) !== -1) {
          return true;
        }

      } catch (err) {
        return false;
      }

      return false;
    };

    // Formats the given number based on user preferences
    this.formatNumber = function(number, decimals, noDecimal) {
      var fixedNum;
      var format, user;
      $cacheHelper.getUser(function(data) {
        user = data;
        if (!$cacheHelper.user) {
          $cacheHelper.initialize(data);
        }
      });

      format = user.number_format;

      var num;
      if (number === null || number === undefined ||
        isNaN(number) || number === '') {
        num = '0';
      } else {
        if (decimals >= 0) {
          num = mathRound(parseFloat(number), decimals).toString();
        } else {
          num = mathRound(parseFloat(number), 2).toString();
        }
      }

      fixedNum = num.split('.');
      if (format && format === '999.999,99') {
        num = numberWithDots(fixedNum[0]) + ',';
      } else {
        num = numberWithCommas(fixedNum[0]) + '.';
      }

      if (!noDecimal) {
        if (fixedNum.length > 1) {
          switch (fixedNum[1].length) {
            case 0:
              fixedNum[1] = '00';
              break;
            case 1:
              fixedNum[1] += '0';
              break;
          }
          num += fixedNum[1];
        } else {
          num += '00';
        }
      } else {
        num = num.slice(0, num.length - 1);
      }

      return num;
    };

    // Formats the given number based on user preferences
    this.formatNumberInput = function(number, decimals) {
      var fixedNum;
      var format, user;
      $cacheHelper.getUser(function(data) {
        user = data;
        if (!$cacheHelper.user) {
          $cacheHelper.initialize(data);
        }
      });

      format = user.number_format;

      var num;
      if (number === null || number === undefined ||
        isNaN(number) || number === '') {
        num = '0';
      } else {
        if (decimals) {
          num = mathRound(parseFloat(number), decimals).toString();
        } else {
          num = mathRound(parseFloat(number), 2).toString();
        }
      }

      fixedNum = num.split('.');

      if (format && format === '999.999,99') {
        num = fixedNum[0] + ',';
      } else {
        num = fixedNum[0] + '.';
      }

      if (fixedNum.length > 1) {
        switch (fixedNum[1].length) {
          case 0:
            fixedNum[1] = '00';
            break;
          case 1:
            fixedNum[1] += '0';
            break;
        }
        num += fixedNum[1];
      } else {
        num += '00';
      }

      return num;
    };

    // Converts number from user preferred format
    this.parseNumber = function(number, numFormat) {
      var format, user;
      $cacheHelper.getUser(function(data) {
        user = data;
        if (!$cacheHelper.user) {
          $cacheHelper.initialize(data);
        }
      });

      if (user.number_format) {
        format = numFormat || user.number_format;
      } else {
        format = numFormat || '999,999.99';
      }

      var num, tmpNum;
      if (number === null || number === undefined ||
        number === '' || !number) {
        num = number;
      } else {
        number += '';
        if (format) {
          if (format === '999.999,99') {
            tmpNum = (number.indexOf('0.') !== 0 && number.indexOf(',') !== -1) ? replaceAll(number, '.', '') : number;
            num = parseFloat(tmpNum.replace(',', '.'));
          } else {
            tmpNum = replaceAll(number, ',', '');
            num = parseFloat(tmpNum);
          }
        } else {
          num = parseFloat(number);
        }
      }

      return num;
    };

    this.dateInMillis = function(date) {
      var dt, days, month, year, leapYears, i;
      var calDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
      if (date === null || date === undefined) {
        return 0;
      }

      dt = date.split('-');
      if (dt.length !== 3) { return 0 ;}
      days = dt[0];
      month = dt[1].charAt(0).toUpperCase() + dt[1].slice(1).toLowerCase();
      year = dt[2];

      var numMonths = months.indexOf(month) + 1,
        noOfDays = 0,
        noOfYears;

      if (numMonths > 1) {
        for (i = 0; i < numMonths - 1; i++) {
          noOfDays += calDays[i];
        }
        noOfDays += parseInt(days);
      } else {
        noOfDays = parseInt(days);
      }

      noOfYears = parseInt(year) - 1970;
      leapYears = numMonths > 2 ? parseInt(year) : parseInt(year) - 1;
      for (i = 1971; i < leapYears; i++) {
        if (((i % 4 === 0) && (i % 100 !== 0)) || (i % 400 === 0)) {
          noOfDays = noOfDays + 1;
        }
      }
      noOfDays += noOfYears * 365;

      return noOfDays * 24 * 60 * 60 * 1000;
    };

    // Round the given number to 2 decimal places
    var mathRound = function(value, decimals) {
      decimals = decimals || 0;
      return Number(Math.round(value + 'e' + decimals) + 'e-' + decimals);
    };

    this.round = function(value, decimals) {
        decimals = decimals || 2;
        return mathRound(value, decimals);
    };

    // Returns a comma seperated number
    function numberWithCommas(x) {
      return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    }

    // Returns a dot seperated number
    function numberWithDots(x) {
      return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    }

    function replaceAll(str, src, tgt) {
      str += '';
      var index = str.indexOf(src);
      while (index !== -1) {
        str = str.replace(src, tgt);
        index = str.indexOf(src);
      }
      return str;
    }

    this.formatColumnName = function(name) {
      var formattedName = '';
      if (name) {
        var nameSplit = name.split('_');
        for (var i = 0; i < nameSplit.length; i++) {
          formattedName += nameSplit[i].charAt(0).toUpperCase() +
            nameSplit[i].slice(1, nameSplit[i].length) + ' ';
        }
      }
      return formattedName.trim();
    };

    this.getCurrencyCode = function(currency) {
      return currencies[currency] || currency;
    };

    this.base64ToBlob = function(base64, type) {
      if (base64) {
        var byteString = atob(base64);
        // Convert text into a byte array.
        var ab = new ArrayBuffer(byteString.length);
        var ia = new Uint8Array(ab);
        for (var i = 0; i < byteString.length; i++) {
          ia[i] = byteString.charCodeAt(i);
        }

        // Blob for saving.
        var fileType = type || 'application/octet-stream';
        var dataBlob = new Blob([ia], {
          type: fileType
        });
        if (dataBlob) {
          return dataBlob;
        }
      }
      return null;
    };

    this.validatePattern = function(value, decimal, ignore) {
      decimal = decimal || 2;
      var format, user;
      $cacheHelper.getUser(function(data) {
        user = data;
        if (!$cacheHelper.user) {
          $cacheHelper.initialize(data);
        }
      });

      format = user.number_format;
      if (!format) { format = '999,999.99'; }
      if (!value) { return false; }

      var numArr, returnValue;
      if (format === '999.999,99') {
        if (value.indexOf(',') !== -1) {
          if (value.indexOf('.') !== -1 && value.indexOf(',') - value.lastIndexOf('.') !== 4) { return false; }

          numArr = value.split(',');
          if (numArr.length > 2) { return false; }
          if (numArr[1].length > decimal && !ignore) { return false; }

          returnValue = checkNumber(numArr, '.');
          if (!returnValue) { return false; }
        } else {
          returnValue = checkNumber(value, '.');
          if (!returnValue) { return false; }
        }
        return true;
      } else {
        if (value.indexOf('.') !== -1) {
          if (value.indexOf(',') !== -1 && value.indexOf('.') - value.lastIndexOf(',') !== 4) { return false; }

          numArr = value.split('.');
          if (numArr.length > 2) { return false; }
          if (numArr[1].length > decimal && !ignore) { return false; }

          returnValue = checkNumber(numArr, ',');
          if (!returnValue) { return false; }
        } else {
          returnValue = checkNumber(value, ',');
          if (!returnValue) { return false; }
        }
        return true;
      }
    };

    function checkNumber (number, seperator) {
      var i, returnValue;
      if (Array.isArray(number)) {
        for (i = 0; i < number.length; i++) {
          returnValue = validateNumber(number[i], seperator);
          if (!returnValue) { return false; }
        }
      } else {
        returnValue = validateNumber(number, seperator);
        if (!returnValue) { return false; }
      }
      return true;
    }

    function validateNumber(number, seperator) {
      var i, tmpArr;
      if (number.indexOf(seperator) === -1) {
        if (isNaN(number)) { return false; }
      } else {
        tmpArr = number.split(seperator);
        if (tmpArr[0].length === 0 || tmpArr[0].length > 3) { return false; }
        for (i = 0; i < tmpArr.length; i++) {
          if (i !== 0) {
            if (tmpArr[i].length !== 3) { return false; }
          }
          if (isNaN(tmpArr[i])) { return false; }
        }
      }
      return true;
    }

    this.convertNumber = function(value) {
      var format, user;
      $cacheHelper.getUser(function(data) {
        user = data;
        if (!$cacheHelper.user) {
          $cacheHelper.initialize(data);
        }
      });

      format = user.number_format;
      if (!format) { return parseFloat(value); }
      if (!value) { return value; }
      if (!isNaN(value)) { return parseFloat(value); }

      var numArr;
      if (format === '999.999,99') {
        if (value.indexOf(',') !== -1) {
          numArr = value.split(',');
          return parseFloat(numArr[0] + '.' + numArr[1]);
        }
        return parseFloat(value);
      } else {
        return parseFloat(value);
      }
    };

    // Returns date after the no. of days passed as param
    this.today = function(days) {
      var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug',
        'Sep', 'Oct', 'Nov', 'Dec'
      ];
      var date = new Date();
      if (days > 0) {
        date.setDate(date.getDate() + days);
      }
      return date.getDate() + '-' + months[date.getMonth()] + '-' + date.getFullYear();
    };

    this.getTimeStamp = function() {
      var date = this.formatDate(this.today(0));
      var timestamp = new Date().toLocaleString();
      var datestamp = [];
      if (timestamp.indexOf(',') !== -1) {
        datestamp = timestamp.split(',');
      }
      if (datestamp.length === 2) {
        return (date + datestamp[1]);
      }
      return date;
    };

    this.numberParser = function(number, decimals) {
      var numStr = number + '', i, validDigits = '', user, format;

      $cacheHelper.getUser(function(data) {
        user = data;
        if (!$cacheHelper.user) {
          $cacheHelper.initialize(data);
        }
      });

      format = user.number_format || '999,999.99';

      decimals = decimals || 2;
      for (i = 0; i < numStr.length; i++) {
        if (numStr[i] === '.' || numStr[i] === ',' || !isNaN(numStr[i])) {
          validDigits += numStr[i];
        }
      }

      if (validDigits.indexOf('.') === 0 || validDigits.indexOf(',') === 0) {
        return this.formatNumber(0);
      }

      if (this.validatePattern(validDigits, decimals, true)) {
        return this.formatNumber(this.parseNumber(validDigits), decimals);
      }

      if (format === '999,999.99') {
        return this.formatNumber(this.parseNumber(validDigits, '999.999,99'), decimals);
      }

       return this.formatNumber(this.parseNumber(validDigits, '999,999.99'), decimals);
    };

    this.getWeekNumber = function(d) {
      d = new Date(+d);
      d.setHours(0,0,0);
      d.setDate(d.getDate() + 4 - (d.getDay()||7));
      var yearStart = new Date(d.getFullYear(),0,1);
      var weekNo = Math.ceil(( ( (d - yearStart) / 86400000) + 1)/7);
      return [d.getFullYear(), weekNo];
    };

    this.weeksInYear = function(year) {
      var d = new Date(year, 11, 31);
      var week = this.getWeekNumber(d)[1];
      return week === 1 ? this.getWeekNumber(d.setDate(24))[1] : week;
    };

    this.monthNumber = function(month) {
      return months.indexOf(month);
    };

    this.getMonth = function(monthIndex) {
      return months[monthIndex];
    };

    function isLeapYear(year) {
      return year % 100 === 0 ? year % 400 === 0 ? true : false : year % 4 === 0;
    }

    this.isValidDate = function(date) {
      var seperator, dateFormat, i;

      $cacheHelper.getUser(function(data) {
        if (!$cacheHelper.user) {
          $cacheHelper.initialize(data);
        } else {
          dateFormat = data.date_format;
        }
      });
      dateFormat = dateFormat || 'dd-MMM-yyyy';

      for (i = 0; i < seperators.length; i++) {
        if (dateFormat.indexOf(seperators[i]) !== -1) {
          seperator = seperators[i];
          break;
        }
      }

      var dateArray = date.split(seperator);

      if (dateArray.length !== 3) {
        return false;
      } else if (dateArray[0] === '' || dateArray[1] === '' || dateArray[2] === '') {
        return false;
      }

      return true;
    };

    // validate date
    this.validateDate = function(date) {
      var seperator, f_date, dateFormat, f_dateFormat, dateIndex, yearIndex,
      monthIndex, month, alphaMonth, daysInMonth, day, year, i, days,
      monthInNum, yearInNum, dayInNum;
      $cacheHelper.getUser(function(data) {
        if (!$cacheHelper.user) {
          $cacheHelper.initialize(data);
        } else {
          dateFormat = data.date_format;
        }
      });
      dateFormat = dateFormat || 'dd-MMM-yyyy';

      for (i = 0; i < seperators.length; i++) {
        if (dateFormat.indexOf(seperators[i]) !== -1) {
          seperator = seperators[i];
          break;
        }
      }

      // split expense date
      f_date = date.split(seperator);

      f_dateFormat = dateFormat.split(seperator);
      if (f_date.length !== 3) {
        return false;
      }

      dateIndex = f_dateFormat.indexOf('dd');
      yearIndex = f_dateFormat.indexOf('yyyy');
      year = f_date[yearIndex];
      day = f_date[dateIndex];
      yearInNum = parseInt(year);
      dayInNum = parseInt(day);
      if (!year || !day || isNaN(year) || isNaN(day) || isNaN(yearInNum) || isNaN(dayInNum) ||
          year.length !== 4 || !yearInNum || day.length > 2 || !dayInNum) {
        return false;
      }

      days = [31, isLeapYear(year) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

      monthIndex = f_dateFormat.indexOf('MM');
      if (monthIndex === -1) {
        monthIndex = f_dateFormat.indexOf('MMM');
        month = f_date[monthIndex];
        month = month.charAt(0).toUpperCase() + month.substr(1).toLowerCase();
        f_date[monthIndex] = month;
        alphaMonth = months.indexOf(month);
        if (alphaMonth === -1 || alphaMonth > 11) {
          return false;
        }
        daysInMonth = days[alphaMonth];
      } else {
        month = f_date[monthIndex];
        monthInNum = parseInt(month);
        if (!month || isNaN(month) || monthInNum < 1 || monthInNum > 12 || isNaN(monthInNum) || month.length > 2) {
          return false;
        }
        daysInMonth = days[monthInNum - 1];
        if (month.length === 1) {
          month = "0" + month;
          f_date[monthIndex] = month;
        }
      }


      if (dayInNum < 1 || dayInNum > daysInMonth) {
        return false;
      }

      if (day.length === 1) {
        day = "0" + day;
        f_date[dateIndex] = day;
      }
      date = f_date.join(seperator);
      return date;
    };

    this.getWeekDay = function(date) {
      return weekDays[date.getDay()];
    };

  }
})();
