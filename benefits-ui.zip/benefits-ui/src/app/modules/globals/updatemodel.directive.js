/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 10-10-2018
 */

(function() {
  'use strict';

  angular.module('scorpion')
    .directive('updateModel', updateModel);

    function updateModel() {
      return {
        restrict: 'A',
        require: 'ngModel',
        link: function(scope, elem, attrs, ngModel) {
          // This is called when model is updated
          window.setTimeout(function() {
            var element = elem[0];
            if (element) {
              element.addEventListener('blur', function() {
                window.setTimeout(function() {
                  scope.$apply(function() {
                    ngModel.$setViewValue(element.value);
                  });
                }, 200);
              });
            }
          }, 20);
        }
      };

    }
})();
