/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 10-10-2018
 */

 (function() {
   'use strict';

   angular.module('scorpion')
     .directive('stringToNum', stringToNum);

   function stringToNum() {
     return {
       require: 'ngModel',
       link: function(scope, element, attrs, ngModel) {
         scope.$watch(attrs.ngModel, function(newValue) {
           ngModel.$setViewValue(parseInt(newValue));
           ngModel.$render();
         });
       }
     };
   }
 })();
