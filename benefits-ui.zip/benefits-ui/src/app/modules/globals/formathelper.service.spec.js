/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 10-10-2018
 */

(function() {
	'use strict';

	describe('service $formatHelper', function() {
		var $formatHelper, $cacheHelper, format = 'dd/MM/yyyy';

		beforeEach(module('scorpion'));
		beforeEach(inject(function(_$formatHelper_, _$cacheHelper_) {
			$formatHelper = _$formatHelper_;
			$cacheHelper = _$cacheHelper_;
			$cacheHelper.setUser({ 
				user_id: 1, 
				user_name: 'Reddy', 
				user_description: 'Reddy Bhimireddy',
				number_format: '999,999.99'
			});
		}));

		it('should be registered', function() {
			expect($formatHelper).not.toEqual(null);
		});

		describe('formatDate function', function() {
			it('should exist', function() {
				expect($formatHelper.formatDate).not.toEqual(null);
			});

			it('should return the formatted date based on given date format', function() {
				var date = '05-NOV-2016';
				var formattedDate = $formatHelper.formatDate(date, format);
				expect(formattedDate).toEqual('05/11/2016');
			});

		});

		describe('parseDate function', function() {
			it('should exist', function() {
				expect($formatHelper.parseDate).not.toEqual(null);
			});

			it('should return date in DD-MON-YYYY format', function() {
				var date = '05/11/2016';
				var parsedDate = $formatHelper.parseDate(date, format);
				expect(parsedDate).toEqual('05-Nov-2016');
			});
		});

		describe('isDateFormattable function', function() {
			it('should exist', function() {
				expect($formatHelper.isDateFormattable).not.toEqual(null);
			});

			var date, isDateFormattable;
			it('should return true if date is formattable to DD-MON-YYYY format', function() {
				date = '05-NOV-2016';
				isDateFormattable = $formatHelper.isDateFormattable(date);
				expect(isDateFormattable).toBeTruthy();
			});

			it('should return false if date is not formattable', function() {
				date = '05-11-2016';
				isDateFormattable = $formatHelper.isDateFormattable(date);
				expect(isDateFormattable).toBeFalsy();
			});
		});

		describe('formatNumber function', function() {
			it('should exist', function() {
				expect($formatHelper.formatNumber).not.toEqual(null);
			});

			var formattedNumber;
			it('should format given number as per user number format', function() {
				formattedNumber = $formatHelper.formatNumber(32.5);
				expect(formattedNumber).toEqual('32.50');
			});

			it('should truncate invalid digits', function() {
				formattedNumber = $formatHelper.formatNumber(32,5);
				expect(formattedNumber).toEqual('32.00');
			});

			it('should return 0 if number is null', function() {
				formattedNumber = $formatHelper.formatNumber(null);
				expect(formattedNumber).toEqual('0.00');
			});

			it('should return 0 if number is undefined', function() {
				formattedNumber = $formatHelper.formatNumber(undefined);
				expect(formattedNumber).toEqual('0.00');
			});

			it('should return 0 if number is empty string', function() {
				formattedNumber = $formatHelper.formatNumber('');
				expect(formattedNumber).toEqual('0.00');
			});

			it('should return 0 if number is NaN', function() {
				formattedNumber = $formatHelper.formatNumber(NaN);
				expect(formattedNumber).toEqual('0.00');
			});
		});

		describe('formatNumberInput function', function() {
			it('should exist', function() {
				expect($formatHelper.formatNumberInput).not.toEqual(null);
			});
		});

		describe('parseNumber function', function() {
			it('should exist', function() {
				expect($formatHelper.parseNumber).not.toEqual(null);
			});

			var formattedNumber;
			it('should return given number in . format', function() {
				formattedNumber = $formatHelper.parseNumber('32.5');
				expect(formattedNumber).toEqual(32.5);
			});

			it('should return NaN if number is NaN', function() {
				formattedNumber = $formatHelper.parseNumber(NaN);
				expect(formattedNumber).toEqual(NaN);
			});

			it('should return in . format if user number format is null', function() {
				$cacheHelper.user.number_format = null;
				formattedNumber = $formatHelper.parseNumber('32,5');
				expect(formattedNumber).toEqual(32);
			});
		});

		describe('dateInMillis function', function() {
			it('should exist', function() {
				expect($formatHelper.dateInMillis).not.toEqual(null);
			});

			it('should return number of milliseconds from 1970 to given date', function() {
				var date = '05-NOV-2016';
				expect($formatHelper.dateInMillis(date)).toEqual(jasmine.any(Number));
			});

			it('should return 0 if date is not in DD-MON-YYYY format', function() {
				expect($formatHelper.dateInMillis('05/11/2016')).toBe(0);
			});
		});

	});
})();