/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 06-11-2018
 */

(function() {
    'use strict';

    angular.module('scorpion')
        .controller('HcmDashboardController', HcmDashboardController);

    function HcmDashboardController($scope, $location, $cacheHelper, $window, $state) {

      $scope.$on('viewContentLoaded', function () {
          $window.ga('send', 'pageview', {
              page: $location.url()
          });
      });

      $cacheHelper.getUser(function (data) {
          if (!data) {
              $state.go('app.login');
          } else {
              if (!$cacheHelper.user) {
                  $cacheHelper.initialize(data);
              }
          }
      });

      $scope.moveTo = function (stateName) {
          $state.go(stateName);
      };

    }

})();
