/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 06-11-2018
 */

(function() {
  'use strict';

  angular.module('scorpion')
    .directive('leavetypehistory', LeaveTypeHistory);

  // Directive used to create dynamic child tables
  function LeaveTypeHistory() {
    return {
      restrict: 'E',
      transclude: true,
      templateUrl: 'app/modules/hcm/leavemanagement/leavetypehistory.html'
    };
  }
})();
