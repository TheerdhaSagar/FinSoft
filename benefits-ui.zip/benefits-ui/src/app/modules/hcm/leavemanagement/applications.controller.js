/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 06-11-2018
 */

(function() {
    'use strict';

    angular.module('scorpion')
        .controller('LeaveApplicationsController', LeaveApplicationsController);

    function LeaveApplicationsController($scope, $cacheHelper, $window, $state,
      $location, $httpHelper, $formatHelper, $appHelper, $timeout, $rootScope) {

      $scope.$on('viewContentLoaded', function () {
          $window.ga('send', 'pageview', {
              page: $location.url()
          });
      });

      $scope.$watch(function() {
        return $rootScope.orgId;
      }, function(newValue, oldValue) {
        if (newValue !== oldValue) {
          loadLeaves();
        }
      });

      var user, dateFormat;
      $scope.toggleFilter = $appHelper.toggleFilter();
      $cacheHelper.getUser(function (data) {
          if (!data) {
              $state.go('app.login');
          } else {
              if (!$cacheHelper.user) {
                  $cacheHelper.initialize(data);
              }
              user = data;
              dateFormat = user.date_format || 'dd-MM-yyyy';
              $scope.showSpinner = true;
              $scope.selectedStatus = $rootScope.UILeaveManagementConfigure ? 'A' : 'P';
              loadLeaves();

              $timeout(function() {
                new FooPicker({
                  id: 'from-date',
                  dateFormat: dateFormat
                });

                new FooPicker({
                  id: 'to-date',
                  dateFormat: dateFormat
                });
              });
          }
      });

      // load leave requests assigned to logged in manager
      // If user has role UILeaveManagementConfigure show all leave requests irrespective of manager
      function loadLeaves() {
        $scope.leaveStatus = angular.copy($scope.selectedStatus);
        var endPoint = '/hcm/leavemanagement/leaves/summary/';
        var requestObj = {
          user_id: '',
          manager_user_id: $rootScope.UILeaveManagementConfigure ? '' : user.user_id,
          status: $scope.selectedStatus || '',
          from_date: $scope.fromDateFilter ? $formatHelper.parseDate($scope.fromDateFilter, dateFormat) : '',
          to_date: $scope.toDateFilter ? $formatHelper.parseDate($scope.toDateFilter, dateFormat) : '',
          org_id: ''
        };

        $httpHelper.httpRequest('POST', endPoint, requestObj, function(data) {
          if (data === null || data === undefined) {
            $scope.notifications.push({msg: 'Server Error - loadLeaves()', status: 1});
          } else {
            if (data.status === 1) {
              $scope.notifications.push({msg: data.msg, status: 1});
            } else {
              $scope.leavesSummary = [];
              for(var i = 0; i < data.length; i++) {
                data[i].f_from_date = $formatHelper.formatDate(data[i].from_date, dateFormat);
                data[i].from_date_millis = $formatHelper.dateInMillis(data[i].from_date);
                data[i].f_upto_date = $formatHelper.formatDate(data[i].upto_date, dateFormat);
                data[i].upto_date_millis = $formatHelper.dateInMillis(data[i].upto_date);
              }
              $scope.predicate = 'leave_id';
              $scope.desc = true;
              $scope.leavesSummary = data;
            }
          }
          $scope.showSpinner = false;
        });
      }

      $scope.applyFilter = function() {
        $scope.showSpinner = true;
        $scope.toggleFilter();
        $scope.leavesSummary = [];
        loadLeaves();
      };

      $scope.editLeave = function(leave) {
        $appHelper.leaveId = leave.leave_id;
        $appHelper.leaveAppliedBy = leave.applied_by;
        $appHelper.leaveAppliedOrgId = leave.org_id;
        $state.go('app.applyleave');
      };

      $scope.sort = function(key) {
        if ($scope.predicate === key) {
          $scope.desc = !$scope.desc;
        } else {
          $scope.predicate = key;
          $scope.desc = false;
        }
      };

    }

})();
