/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 06-11-2018
 */

(function() {
    'use strict';

    angular.module('scorpion')
        .controller('ConfigureLeavesController', ConfigureLeavesController);

    function ConfigureLeavesController($scope, $window, $location, $state, $cacheHelper,
      $appHelper, $httpHelper, $timeout, $rootScope, $formatHelper) {

      $scope.$on('viewContentLoaded', function () {
          $window.ga('send', 'pageview', {
              page: $location.url()
          });
      });

      var user, dateFormat;
      $cacheHelper.getUser(function (data) {
          if (!data) {
              $state.go('app.login');
          } else {
              if (!$cacheHelper.user) {
                  $cacheHelper.initialize(data);
              }
              user = data;
              dateFormat = user.date_format || 'dd-MM-yyyy';
              $scope.showSpinner = true;

              loadYears();
              loadHolidays();
              loadLeaveTypes();

              $timeout(function() {
                new FooPicker({
                  id: 'holiday-date',
                  dateFormat: dateFormat
                });

                new FooPicker({
                  id: 'holiday-to-date',
                  dateFormat: dateFormat
                });
              });
          }
      });

      $scope.$watch(function() {
        return $rootScope.orgId;
      }, function(newValue, oldValue) {
        if (newValue !== oldValue) {
          $state.go($state.current, {}, {
            reload: true
          });
        }
      });

      $scope.toggleFilter = $appHelper.toggleFilter();
      $scope.configureType = 'holiday';
      $scope.showAddNewDialog = false;
      $scope.leave_type_error_msg = false;
      $scope.allowHourly = 'Y';

      $scope.addNew = function(type) {
        $scope.addNewType = type;
        $scope.showAddNewDialog = true;
        $scope.leave_type_error_msg = false;
        $scope.isLeaveCountRequired = 'N';
        $scope.alertShown = false;
      };

      $scope.cancel = function() {
        $scope.showAddNewDialog = false;
        $scope.holiday_date = '';
        $scope.name_of_leavetype = '';
        $scope.description = '';
        $scope.leaves_count = '';
        $scope.focusAddNew = false;
        $scope.leave_type_error_msg = false;
        $scope.selectedYear = $scope.currentYear;
        $scope.edit = false;
        $scope.addNewType = '';
        $scope.id = '';
        $scope.deleteLine = '';
        $scope.deleteDialog = false;
        $scope.isLeaveCountRequired = 'N';
        $scope.alertShown = false;
        $scope.allowHourly = 'Y';
        $scope.holiday_to_date = '';
      };

      $scope.editLine = function(record) {
        $scope.alertShown = false;
        $scope.name_of_leavetype = $scope.configureType === 'leave' ? record.leave_type : record.holiday_name;
        $scope.description = record.description || '';
        $scope.holiday_date = $scope.configureType === 'leave' ? '' : record.f_holiday_date;
        $scope.leaves_count = $scope.configureType === 'leave' ? record.leave_count : '';
        $scope.allowHourly = $scope.configureType === 'leave' ? record.allow_hourly : '';
        $scope.selectedYear = record.year;
        $scope.edit = true;
        $scope.addNewType = $scope.configureType;
        $scope.showAddNewDialog = true;
        $scope.id = $scope.configureType === 'leave' ? record.leave_type_id : record.holiday_id;
        if ($scope.configureType === 'leave') {
          $scope.isLeaveCountRequired = record.leave_count !== null && record.leave_count !== undefined ? 'Y' : 'N';
        }
      };

      $scope.applyFilter = function() {
        $scope.toggleFilter();
        $scope.showSpinner = true;
        loadHolidays();
      };

      function checkLeaveName(data, column, columnId, value) {
        var index = data.map(function(x) {
          return x[column].toLowerCase();
        }).indexOf(value.toLowerCase());
        if (index === -1 || (index !== -1 && $scope.edit && ($scope.id === data[index][columnId] || data[index][column].toLowerCase() === value.toLowerCase()))) {
          return -1;
        }
        return index;
      }

      $scope.saveHoliday = function() {
        if (!$scope.name_of_leavetype || !$scope.description ||
          ($scope.addNewType === 'holiday' && !$scope.holiday_date) ||
          ($scope.addNewType === 'leave' && $scope.isLeaveCountRequired === 'Y' &&
          ($scope.leaves_count === null || $scope.leaves_count === undefined || $scope.leaves_count === ''))) {
          $scope.focusAddNew = true;
          return;
        }

        var endPoint, index, dates = [],
        months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug',
          'Sep', 'Oct', 'Nov', 'Dec'],
        requestObj = {
          user_id: user.user_id,
          description: $scope.description,
          org_id: $rootScope.orgId
        };

        if ($scope.addNewType === 'leave') {
          requestObj.leave_type = $scope.name_of_leavetype;
          requestObj.year = new Date($appHelper.today(0)).getFullYear();
          requestObj.leave_count = $scope.isLeaveCountRequired === 'Y' ? $scope.leaves_count : null;
          if ($scope.edit) {
            requestObj.leave_type_id = $scope.id;
          }
          requestObj.allow_hourly = $scope.allowHourly;
        } else {
          requestObj.holiday_date = $formatHelper.parseDate($scope.holiday_date, dateFormat);
          requestObj.holiday_to_date = $scope.holiday_to_date ? $formatHelper.parseDate($scope.holiday_to_date, dateFormat) : '';
          requestObj.holiday_name = $scope.name_of_leavetype;
          requestObj.year = new Date($formatHelper.parseDate($scope.holiday_date, dateFormat)).getFullYear();
          if ($scope.edit) {
            requestObj.holiday_id = $scope.id;
          }

          // if holiday is more than one day divide each day into single record
          if ($scope.holiday_date && $scope.holiday_to_date)  {
            var startDate, endDate, noOfDays, j,
            oneDay = 1000 * 60 * 60 * 24, holidayDate, date;
            dates = [];
            startDate = new Date($formatHelper.parseDate($scope.holiday_date, dateFormat)).getTime();
            endDate = new Date($formatHelper.parseDate($scope.holiday_to_date, dateFormat)).getTime();
            noOfDays = (endDate - startDate) / oneDay;
            for (j = 0; j <= noOfDays; j++) {
              holidayDate = new Date($formatHelper.parseDate($scope.holiday_date, dateFormat));
              holidayDate.setDate(holidayDate.getDate() + j);
              date = (parseInt(holidayDate.getDate()) < 10 ? '0' + holidayDate.getDate() : holidayDate.getDate()) + '-' + months[holidayDate.getMonth()] + '-' + holidayDate.getFullYear();
              dates.push(date);
            }
          } else {
            dates.push($formatHelper.parseDate($scope.holiday_date, dateFormat));
          }
          requestObj.dates = dates;
        }

        if ($scope.addNewType === 'leave') {
          index = checkLeaveName($scope.leaveTypes, 'leave_type', 'leave_type_id', $scope.name_of_leavetype);
        } else {
          index = checkLeaveName($scope.holidaysList, 'holiday_date', 'holiday_id', $formatHelper.parseDate($scope.holiday_date, dateFormat));
        }

        // Check if newly entered leave / holiday name already exixts
        if (index !== -1 && (!$scope.alertShown || $scope.addNewType === 'leave')) {
          $scope.leave_type_error_msg = true;
          $scope.alertShown = $scope.addNewType === 'holiday' ? true : false;
          return;
        }

        endPoint = '/hcm/leavemanagement/';
        endPoint += $scope.addNewType === 'leave' ? 'leave/type/' : 'holiday/';
        endPoint += $scope.edit ? 'update/' : 'add/';

        $scope.showAddNewDialog = false;
        $scope.showSpinner = true;

        $httpHelper.httpRequest('POST', endPoint, requestObj, function(data) {
          if (data === null || data === undefined) {
            $scope.notifications.push({msg: 'Server Error: addLeave()', status: 1});
          } else {
            $scope.notifications.push({msg: data.msg, status: data.status});
            $scope.showSpinner = false;
            if (data.status === 0) {
              // To insert new record or update exixsting record if it is update
              updateData(data, dates);
              $scope.showAddNewDialog = false;
              $scope.showSpinner = false;
              $scope.cancel();
            }
          }
        });
      };

      function updateData(result, dates) {
        var data, typeId, index, i, datesLength, holidayIds;
        data = $scope.addNewType === 'leave' ? $scope.leaveTypes : $scope.holidaysList;
        typeId = $scope.addNewType === 'leave' ? 'leave_type_id' : 'holiday_id';
        dates = $scope.addNewType === 'leave' ? [] : dates;
        datesLength = $scope.edit || $scope.addNewType === 'leave' ? 1 : dates.length;
        if (!$scope.edit) {
          index = data.length;
          for (i = 0; i < datesLength; i++) {
            data.push({});
          }

          // holiday ids for each date holiday
          holidayIds = result.holiday_ids ? result.holiday_ids.substr(1, result.holiday_ids.length) : '';
          holidayIds = holidayIds ? holidayIds.split(',') : [] ;
        } else {
          index = data.map(function(x) {
            return x[typeId];
          }).indexOf($scope.id);
        }

        if ($scope.addNewType === 'leave') {
          data[index].leave_type = $scope.name_of_leavetype;
          data[index].leave_type_id = parseInt(result.leave_type_id);
          data[index].description = $scope.description;
          data[index].leave_count = $scope.isLeaveCountRequired === 'Y' ? $scope.leaves_count : null;
          data[index].year = $scope.selectedYear;
          data[index].org_id = $rootScope.orgId;
          data[index].allow_hourly = $scope.allowHourly;
          if (!$scope.edit) {
            data[index].leaves_taken = 0;
          }
        } else {
          for (i = 0; i < datesLength; i++) {
            data[index].holiday_name = $scope.name_of_leavetype;
            data[index].holiday_id = $scope.edit ? parseInt(result.holiday_id) : parseInt(holidayIds[i]);
            data[index].year = $scope.selectedYear;
            data[index].description = $scope.description;
            data[index].org_id = $rootScope.orgId;
            data[index].holiday_date = dates[i];
            data[index].f_holiday_date = $formatHelper.formatDate(dates[i], dateFormat);
            data[index].holiday_date_millis = $formatHelper.dateInMillis($formatHelper.parseDate($scope.holiday_date, dateFormat));
            data[index].holiday_day =$formatHelper.getWeekDay(new Date(data[index].holiday_date));
            index = index + 1;
          }
        }
      }

      $scope.delete = function(line) {
        if (line) {
          $scope.deleteLine = line;
          $scope.deleteDialog = true;
        } else {
          $scope.showSpinner = true;
          var endPoint = '/hcm/leavemanagement/', typeId, list, index;
          $scope.deleteDialog = false;
          endPoint += $scope.configureType === 'holiday' ? 'holidays/' + $rootScope.orgId + '/?holiday_id=' + $scope.deleteLine.holiday_id : 'leaves/' + $scope.deleteLine.leave_type_id + '/';
          $httpHelper.httpRequest('DELETE', endPoint, null, function(data) {
            if (data === null || data === undefined) {
              $scope.notifications.push({msg: 'Server Error - delete()', status: 1});
            } else {
              $scope.notifications.push({msg: data.msg, status: data.status});
              if (data.status === 0) {
                typeId = $scope.configureType === 'leave' ? 'leave_type_id' : 'holiday_id';
                list = $scope.configureType === 'leave' ? $scope.leaveTypes : $scope.holidaysList;
                index = list.map(function(x) {
                  return x[typeId];
                }).indexOf($scope.deleteLine[typeId]);
                if (index !== -1){
                  list.splice(index, 1);
                }
              }
            }
            $scope.showSpinner = false;
          });
        }
      };

      // Load years
      function loadYears() {
        var years = [], i;
        var currentYear = new Date().getFullYear();
        for (i = currentYear + 1; i >= 2017; i--) {
          years.push({
            year: i,
            yearCode: '' + i
          });
        }
        $scope.years = years;
        $scope.currentYear = currentYear;
        $scope.selectedYear = currentYear;
      }

      function loadHolidays() {
        var endPoint = '/hcm/leavemanagement/holidays/';
        var requestObj = {
          org_id: $rootScope.orgId,
          year: $scope.selectedYear,
          holiday_id: ''
        };
        $httpHelper.httpRequest('POST', endPoint, requestObj, function(data) {
          if (data === null || data === undefined) {
            $scope.notifications.push({msg: 'Server Error - loadHolidays()', status: 1});
          } else {
            if (data.status === 1) {
              $scope.notifications.push({msg: data.msg, status: data.status});
            } else {
              for (var i = 0; i < data.result.length; i++) {
                data.result[i].f_holiday_date = $formatHelper.formatDate(data.result[i].holiday_date, dateFormat);
                data.result[i].holiday_date_millis = $formatHelper.dateInMillis(data.result[i].holiday_date);
                data.result[i].holiday_day = $formatHelper.getWeekDay(new Date(data.result[i].holiday_date));
              }
              $scope.predicate = 'holiday_date_millis';
              $scope.desc = false;
              $scope.holidaysList = data.result;
            }
          }
          $scope.showSpinner = false;
        });
      }

      $scope.sort = function(key) {
        if ($scope.predicate === key) {
          $scope.desc = !$scope.desc;
        } else {
          $scope.predicate = key;
          $scope.desc = false;
        }
      };

      function loadLeaveTypes() {
        var endPoint = '/hcm/leavemanagement/leave/types/' + $rootScope.orgId + '/';
        $httpHelper.httpRequest('GET', endPoint, null, function(data) {
          if (data === null || data === undefined) {
            $scope.notifications.push({msg: 'Server Error - loadLeaveTypes()', status: 1});
          } else {
            if (data.status === 1) {
              $scope.notifications.push({msg: data.msg, status: data.status});
            } else {
              $scope.predicate = 'leave_type_id';
              $scope.desc = false;
              $scope.leaveTypes = data.result;
            }
          }
        });
      }

    }
})();
