/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 06-11-2018
 */

(function() {
    'use strict';

    angular.module('scorpion')
        .controller('LeavesSummaryController', LeavesSummaryController);

    function LeavesSummaryController($scope, $location, $cacheHelper, $window, $state,
      $httpHelper, $formatHelper, $appHelper, $timeout, $rootScope) {

      $scope.$on('viewContentLoaded', function () {
          $window.ga('send', 'pageview', {
              page: $location.url()
          });
      });

      var user, dateFormat;
      $scope.toggleFilter = $appHelper.toggleFilter();
      $cacheHelper.getUser(function (data) {
          if (!data) {
              $state.go('app.login');
          } else {
              if (!$cacheHelper.user) {
                  $cacheHelper.initialize(data);
              }
              user = data;
              dateFormat = user.date_format || 'dd-MM-yyyy';
              $scope.showSpinner = true;
              $scope.selectedStatus = 'P';
              loadData();

              $timeout(function() {
                new FooPicker({
                  id: 'from-date',
                  dateFormat: dateFormat
                });

                new FooPicker({
                  id: 'to-date',
                  dateFormat: dateFormat
                });
              });
          }
      });

      $scope.$watch(function() {
        return $rootScope.orgId;
      }, function(newValue, oldValue) {
        if (newValue !== oldValue) {
          $state.go($state.current, {}, {
            reload: true
          });
        }
      });

      $scope.todays_date_millis = $formatHelper.dateInMillis($appHelper.today(0));

      function loadData() {
        var endPoint = '/hcm/leavemanagement/leaves/summary/';
        var requestObj = {
          user_id: user.user_id,
          manager_user_id: '',
          status: $scope.selectedStatus || '',
          from_date: $scope.fromDateFilter ? $formatHelper.parseDate($scope.fromDateFilter, dateFormat) : '',
          to_date: $scope.toDateFilter ? $formatHelper.parseDate($scope.toDateFilter, dateFormat): '',
          org_id: $rootScope.orgId
        };
        $httpHelper.httpRequest('POST', endPoint, requestObj, function(data) {
          if (data === null || data === undefined) {
            $scope.notifications.push({msg: 'Server Error - loadData()', status: 1});
          } else {
            if (data.status === 1) {
              $scope.notifications.push({msg: data.msg, status: 1});
            } else {
              for(var i = 0; i < data.length; i++) {
                data[i].f_from_date = $formatHelper.formatDate(data[i].from_date, dateFormat);
                data[i].from_date_millis = $formatHelper.dateInMillis(data[i].from_date);
                data[i].f_upto_date = $formatHelper.formatDate(data[i].upto_date, dateFormat);
                data[i].upto_date_millis = $formatHelper.dateInMillis(data[i].upto_date);
              }
              $scope.predicate = 'leave_id';
              $scope.desc = true;
              $scope.leavesSummary = data;
            }
          }
          $scope.showSpinner = false;
        });
      }

      $scope.applyFilter = function() {
        $scope.toggleFilter();
        $scope.showSpinner = true;
        loadData();
      };

      $scope.recallLeave = function(record) {
        if (record) {
          $scope.comments = '';
          $scope.leave_id = record.leave_id;
          $scope.recallDialog = true;
        } else {
          $scope.showSpinner = true;
          $scope.recallDialog = false;
          var endPoint = '/hcm/leavemanagement/leave/update/status/';
          var requestObj = {
            status: 'C',
            user_id: user.user_id,
            leave_id: $scope.leave_id,
            action: 'cancelled leave on ' + $appHelper.today(0),
            comments: $scope.comments || '',
            send_email: 0
          };

          $httpHelper.httpRequest('POST', endPoint, requestObj, function(data) {
            if (data === null || data === undefined) {
              $scope.notifications.push({msg: 'Server Error - recallLeave()', status: 1});
            } else {
              if (data.status === 0) {
                data.msg = 'Leave cancelled successfully';
                var index = $scope.leavesSummary.map(function(x) {
                  return x.leave_id;
                }).indexOf($scope.leave_id);

                if (index !== -1) {
                  $scope.leavesSummary[index].status = 'C';
                }
              }
              $scope.notifications.push({msg: data.msg, status: data.status});
            }
            $scope.close();
            $scope.showSpinner = false;
          });
        }
      };

      $scope.close = function() {
        $scope.comments = '';
        $scope.leave_id = '';
        $scope.recallDialog = false;
      };

      $scope.applyLeave = function() {
        $appHelper.leaveRecord = '';
        $appHelper.leavesByUser = $scope.leavesHistory;
        $state.go('app.applyleave');
      };

      $scope.sort = function(key) {
        if ($scope.predicate === key) {
          $scope.desc =!$scope.desc;
        } else {
          $scope.predicate = key;
          $scope.desc = false;
        }
      };

      $scope.viewReport = function() {
        $state.go('app.userreport');
      };

      $scope.editLeaveRequest = function(leave) {
        $appHelper.leaveId = leave.leave_id;
        $appHelper.leaveAppliedBy = leave.applied_by;
        $state.go('app.applyleave');
      };
    }
})();
