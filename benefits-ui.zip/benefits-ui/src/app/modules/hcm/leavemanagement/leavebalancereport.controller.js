/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 06-11-2018
 */

(function() {
    'use strict';

    angular.module('scorpion')
        .controller('LeaveBalanceReportController', LeaveBalanceReportController);

    function LeaveBalanceReportController($scope, $location, $cacheHelper, $window, $state,
      $rootScope, $httpHelper, $timeout, $formatHelper, $appHelper) {

      $scope.$on('viewContentLoaded', function () {
          $window.ga('send', 'pageview', {
              page: $location.url()
          });
      });

      var user, dateFormat;
      $cacheHelper.getUser(function (data) {
          if (!data) {
              $state.go('app.login');
          } else {
              if (!$cacheHelper.user) {
                  $cacheHelper.initialize(data);
              }
              user = data;
              dateFormat = user.date_format || 'dd-MM-yyyy';
              $scope.showSpinner = true;

              getLeavesHistory();
          }
      });

      $scope.$watch(function() {
        return $rootScope.orgId;
      }, function(newValue, oldValue) {
        if (newValue !== oldValue) {
          getLeavesHistory();
        }
      });

      $scope.sort = function(key) {
        if ($scope.predicate === key) {
          $scope.desc =!$scope.desc;
        } else {
          $scope.predicate = key;
          $scope.desc = false;
        }
      };

      function getLeavesHistory() {
        $scope.showSpinner = true;
        var endPoint ='/hcm/leavemanagement/leaves/types/count/';
        var requestObj = {
          user_id: '',
          org_id: $rootScope.orgId
        };
        $httpHelper.httpRequest('POST', endPoint, requestObj, function(data) {
          if (data === null || data === undefined) {
            $scope.notifications.push({msg: 'Server Error - getLeavesHistory()', status: 1});
          } else {
            if (data.status === 1) {
              $scope.notifications.push({msg: data.msg, status: data.status});
            } else {
              $scope.leavesHistory = data.result;
              generateReport(data);
              $scope.showSpinner = false;
            }
          }
        });
      }

      function generateReport(data) {
        var i, j, usersIndex, leavesCount = 0, hours, k;
        $scope.leaveTypes = [];
        $scope.usersData = [];

        for (i = 0; i < data.length; i++) {
          // Array of leave types
          $scope.leaveTypes.push({
            leave_type_id: data[i].leave_type_id,
            leave_type: data[i].leave_type,
            leave_count: data[i].leave_count,
            taken: 0,
            available: data[i].leave_count
          });

          // Insert each leave_type for all users
          for (k = 0; k < $scope.usersData.length; k++) {
            $scope.usersData[k].leaves.push({
              leave_type_id: data[i].leave_type_id,
              leave_type: data[i].leave_type,
              leave_count: data[i].leave_count,
              taken: 0,
              available: data[i].leave_count
            });
          }

          // Get array of users with used / available leaves count
          for (j = 0; j < data[i].details.length; j++) {
            usersIndex = -1;
            if ($scope.usersData.length > 0) {
              usersIndex = $scope.usersData.map(function(x) {
                return x.applied_by;
              }).indexOf(data[i].details[j].applied_by);
            }

            // If user is new push all leave types
            if (usersIndex === -1) {
              $scope.usersData.push({
                applied_by: data[i].details[j].applied_by,
                user_name: data[i].details[j].user_name,
                leaves: angular.copy($scope.leaveTypes)
              });
              usersIndex = $scope.usersData.length - 1;
            }

            leavesCount = 0;
            if (data[i].leave_type_id === data[i].details[j].leave_type_id && (data[i].details[j].status === 'A' ||
                (data[i].details[j].status === 'P' && $formatHelper.dateInMillis(data[i].details[j].from_date) > $formatHelper.dateInMillis($appHelper.today(0))))) {
              if (data[i].details[j].full_day !== 'Y') {
                hours = data[i].details[j].leave_hours.split(':');
                data[i].details[j].hours = parseInt(hours[0]);
                data[i].details[j].minutes = parseInt(hours[1]);

                // Calculate part of day used in a full day
                data[i].details[j].no_of_days = (parseInt(hours[0]) + (parseInt(hours[1]) / 60)) / 8;
                leavesCount += data[i].details[j].no_of_days;
              } else {
                data[i].details[j].no_of_days = 1;
                leavesCount += data[i].details[j].no_of_days;
              }
            }
            $scope.usersData[usersIndex].leaves[i].taken += $formatHelper.round(leavesCount, 2);
            $scope.usersData[usersIndex].leaves[i].available = $scope.usersData[usersIndex].leaves[i].leave_count !== null && $scope.usersData[usersIndex].leaves[i].leave_count !== undefined && $scope.usersData[usersIndex].leaves[i].leave_count !== ''  ? $formatHelper.round($scope.usersData[usersIndex].leaves[i].available - leavesCount, 2) : '';
          }
        }
      }

    }
})();
