/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 06-11-2018
 */

(function() {
    'use strict';

    angular.module('scorpion')
        .controller('ApplyLeaveController', ApplyLeaveController);

    function ApplyLeaveController($scope, $location, $cacheHelper, $window, $state,
      $rootScope, $httpHelper, $timeout, $formatHelper, $appHelper) {

      $scope.$on('viewContentLoaded', function () {
          $window.ga('send', 'pageview', {
              page: $location.url()
          });
      });

      var user, dateFormat;
      $cacheHelper.getUser(function (data) {
          if (!data) {
              $state.go('app.login');
          } else {
              if (!$cacheHelper.user) {
                  $cacheHelper.initialize(data);
              }
              user = data;
              $scope.user = user;
              dateFormat = user.date_format || 'dd-MM-yyyy';
              initializeData();

              if ($appHelper.leaveId) {
                $scope.leaveId = $appHelper.leaveId;
                $scope.leaveAppliedBy = $appHelper.leaveAppliedBy;
                $scope.orgId = $appHelper.leaveAppliedOrgId;
                $appHelper.leaveAppliedOrgId = '';
                $appHelper.leaveId = '';
                $scope.isEdit = true;
                $scope.showSpinner = true;
                $scope.deleteIds = [];
                loadDetails();
              }

              getHolidaysList();
              loadManagers();
              loadHoursMinutes();

              loadLeaveBalanceData();

              $scope.fromState = $rootScope.fromState && $rootScope.fromState.name ? $rootScope.fromState.name : '';

              $timeout(function() {
                new FooPicker({
                  id: 'from-date',
                  dateFormat: dateFormat
                });

                new FooPicker({
                  id: 'upto-date',
                  dateFormat: dateFormat
                });
              });
          }
      });

      $scope.$watch(function() {
        return $rootScope.orgId;
      }, function(newValue, oldValue) {
        if (newValue !== oldValue) {
          $scope.leaveDetails = {};
          initializeData();
          getHolidaysList();
          loadLeaveBalanceData();
          loadManagers();
        }
      });

      $scope.todays_date_millis = $formatHelper.dateInMillis($appHelper.today(0));

      function initializeData() {
        $scope.orgId = $rootScope.orgId;
        $scope.leaveId = '';
        $scope.isEdit = false;
        $scope.alertShown = false;
        $scope.dates = [];
        $scope.datesBeforeEdit = [];
        $scope.deleteIds = [];
        $scope.leaveStatus = '';
        $scope.comments = '';
        $scope.selectedLeaveType = '';
        $scope.updateDialog = false;
        $scope.requestLeave = {
          leave_type_id: '',
          from_date: '',
          upto_date: '',
          f_from_date: '',
          f_upto_date: '',
          manager_user_id: '',
          reason: '',
          status: 'P',
          user_id: user.user_id,
          action: '',
          comments: '',
          org_id: ''
        };

        $scope.leaveAppliedBy = user.user_id;
        $scope.focusLeaveRequest = false;
      }

      function bindManagerName() {
        if (!$scope.managers || !$scope.requestLeave.manager_user_id) {
          return;
        }

        var index = $scope.managers.map(function(x) {
          return parseInt(x.employee_number);
        }).indexOf(parseInt($scope.requestLeave.manager_user_id));

        if (index !== -1) {
          $timeout(function() {
            document.getElementById('manager-user-id').value = $scope.managers[index].full_name;
          }, 50);
        }
      }

      function loadDetails() {
        var endPoint = '/hcm/leavemanagement/leaves/details/' + $scope.leaveId + '/',
        i, hours, data;
        $httpHelper.httpRequest('GET', endPoint, null, function(leaveData) {
          if (leaveData === null || leaveData === undefined) {
            $scope.notifications.push({msg: 'Server Error - loadDetails()', status: 1});
          } else {
            if (leaveData.status === 1) {
              $scope.notifications.push({msg: leaveData.msg, status: leaveData.status});
            } else {
              data = leaveData.result;

              for (i = 0; i < leaveData.history.length; i++) {
                leaveData.history[i].f_changed_date = $formatHelper.formatDate(leaveData.history[i].changed_date, dateFormat);
                leaveData.history[i].changed_date_millis = $formatHelper.dateInMillis(leaveData.history[i].changed_date);
              }
              $scope.leaveHistory = leaveData.history;
              data[0].f_from_date = $formatHelper.formatDate(data[0].from_date, dateFormat);
              data[0].from_date_millis = $formatHelper.dateInMillis(data[0].from_date);

              data[0].f_upto_date = $formatHelper.formatDate(data[0].upto_date, dateFormat);
              data[0].upto_date_millis = $formatHelper.dateInMillis(data[0].upto_date);

              for (i = 0; i < data[0].details.length; i++) {
                data[0].details[i].f_leave_date = $formatHelper.formatDate(data[0].details[i].leave_date, dateFormat);
                data[0].details[i].leave_date_millis = $formatHelper.dateInMillis(data[0].details[i].leave_date);
              }

              $scope.requestLeave = {
                leave_type_id: data[0].leave_type_id,
                from_date: data[0].from_date,
                upto_date: data[0].upto_date,
                f_from_date: data[0].f_from_date,
                f_upto_date: data[0].f_upto_date,
                manager_user_id: data[0].manager_user_id,
                reason: data[0].reason,
                status: data[0].status,
                user_id: data[0].applied_by
              };

              bindManagerName();

              $scope.calculateAvailableLeaves();

              for (i = 0; i < data[0].details.length; i++) {
                data[0].details[i].f_leave_date = $formatHelper.formatDate(data[0].details[i].leave_date, dateFormat);
                data[0].details[i].leave_date_millis = $formatHelper.formatDate(data[0].details[i].leave_date, dateFormat);
                if (data[0].details[i].full_day !== 'Y') {
                  hours = data[0].details[i].leave_hours.split(':');
                  data[0].details[i].hours = hours[0];
                  data[0].details[i].minutes = hours[1];
                }
              }

              $scope.predicate = 'changed_date_millis';
              $scope.desc = true;
              $scope.leaveDetails = data[0];
              $scope.leaveDetails.f_created_date = $formatHelper.formatDate($scope.leaveDetails.created_date, dateFormat);
              $scope.dates = $scope.leaveDetails.details;
              $scope.noOfDays = $scope.dates.length;
              $scope.datesBeforeEdit = angular.copy($scope.dates);
            }
          }
          $scope.showSpinner = false;
        });
      }

      function loadLeaveBalanceData() {
        $scope.leaveTypes = '';
        var endPoint ='/hcm/leavemanagement/leaves/types/count/';
        var requestObj = {
          user_id: $scope.leaveAppliedBy,
          org_id: $scope.orgId || $rootScope.orgId
        };
        $httpHelper.httpRequest('POST', endPoint, requestObj, function(data) {
          if (data === null || data === undefined) {
            $scope.notifications.push({msg: 'Server Error - loadLeaveBalanceData', status: 1});
          } else {
            if (data.status === 1) {
              $scope.notifications.push({msg: data.msg, status: data.status});
            } else {

              var i, j, hours, leavesCount = 0;
              for (i = 0; i < data.length; i++) {
                data[i].taken = 0;
                data[i].available = data[i].leavesCount || '';
                leavesCount = 0;
                data[i].leaves = [];
                for (j = 0; j < data[i].details.length; j++) {
                  if(data[i].details[j].status !== 'C' && data[i].details[j].status !== 'R') {
                    if (data[i].details[j].full_day !== 'Y') {
                      hours = data[i].details[j].leave_hours.split(':');
                      data[i].details[j].no_of_days = (parseInt(hours[0]) + (parseInt(hours[1]) / 60)) / 8;
                    } else {
                      data[i].details[j].no_of_days = 1;
                    }
                    leavesCount += data[i].details[j].no_of_days;
                  }
                }

                data[i].taken = $formatHelper.round(leavesCount, 2);
                data[i].available = data[i].leave_count ? $formatHelper.round(data[i].leave_count - leavesCount, 2) : '';
              }

              $scope.leaveTypes = data;
              $scope.calculateAvailableLeaves();
            }
          }
        });
      }

      $scope.deleteDate = function(index) {
        $scope.deleteIds.push({
          leave_detail_id: $scope.dates[index].leave_detail_id,
          leave_id: $scope.leaveId,
          leave_date: $scope.dates[index].leave_date
        });
        $scope.dates.splice(index, 1);
      };

      $scope.updateStatus = function(leaveStatus) {
        if (leaveStatus) {
          $scope.comments = '';
          $scope.leaveStatus = leaveStatus;
          $scope.updateDialog = true;
        } else {
          $scope.showSpinner = true;
          $scope.updateDialog = false;
          var endPoint = '/hcm/leavemanagement/leave/update/status/';

          var noOfDays = 0;

          for (var i = 0; i < $scope.dates.length; i++) {
            if (!$scope.dates[i].isHoliday && $scope.dates[i].day !== 'Saturday' && $scope.dates[i].day !== 'Sunday') {
              noOfDays += 1;
            }
          }

          if ($scope.leaveTypes[$scope.selectedLeaveType].leave_count) {
            $scope.leaveTypes[$scope.selectedLeaveType].available += $scope.leaveStatus === 'R' ? noOfDays : 0;
            $scope.leaveTypes[$scope.selectedLeaveType].taken -= $scope.leaveStatus === 'R' ? noOfDays : 0;
          }

          var requestObj = {
            status: $scope.leaveStatus,
            user_id: user.user_id,
            leave_id: $scope.leaveId,
            action: $scope.leaveStatus === 'A' ? 'approved leave ' : 'rejected leave ',
            comments: $scope.comments || '',
            manager_name: $scope.leaveDetails.manager_name,
            user_name: $scope.leaveDetails.user_name,
            no_of_days: noOfDays,
            from_date: $scope.leaveDetails.from_date,
            upto_date: $scope.leaveDetails.upto_date,
            leave_type: $scope.leaveTypes[$scope.selectedLeaveType].leave_type,
            leaves_used: $scope.leaveTypes[$scope.selectedLeaveType].taken,
            leaves_remaining: $scope.leaveTypes[$scope.selectedLeaveType].available || '-',
            total_leaves: $scope.leaveTypes[$scope.selectedLeaveType].leave_count || '-',
            created_date: $scope.leaveDetails.created_date,
            send_email: 1,
            applied_by: $scope.leaveDetails.applied_by
          };

          requestObj.action += 'on ' + $appHelper.today(0);
          $httpHelper.httpRequest('POST', endPoint, requestObj, function(data) {
            if (data === null || data === undefined) {
              $scope.notifications.push({msg: 'Server Error - updateStatus()', status: 1});
            } else {
              if (data.status === 0) {
                data.msg = 'Leave ';
                data.msg += $scope.leaveStatus === 'R' ? 'rejected ' : 'approved ';
                data.msg += 'successfully';
                $state.go('app.leaveapplications');
              }
              $scope.notifications.push({msg: data.msg, status: data.status});
            }
            $scope.showSpinner = false;
          });
        }
      };

      $scope.updateHours = function(date) {
        if (date.full_day === 'Y') {
          date.leave_from_time = '';
          date.hours = '';
          date.minutes = '';
          date.leave_hours = '';
        }
      };

      $scope.close = function() {
        $scope.leaveStatus = '';
        $scope.updateDialog = false;
        $scope.comments = '';
      };

      $scope.calculateAvailableLeaves = function() {
        if (!$scope.requestLeave.leave_type_id || !$scope.leaveTypes) {
          $scope.selectedLeaveType = '';
          return;
        }
        var index = $scope.leaveTypes.map(function(x) {
          return parseInt(x.leave_type_id);
        }).indexOf(parseInt($scope.requestLeave.leave_type_id));

        if (index !== -1) {
          $scope.selectedLeaveType = index;
        }

        if ($scope.leaveTypes[$scope.selectedLeaveType].allow_hourly !== 'Y') {
          for (var i = 0; i < $scope.dates.length; i++) {
            $scope.dates[i].full_day = 'Y';
            $scope.dates[i].hours = '';
            $scope.dates[i].minutes = '';
            $scope.dates[i].leave_from_time = '';
          }
        }

      };

      $scope.cancel = function() {
        $scope.alertShown = false;
        $scope.editDialog = false;
        $scope.focusLeaveRequest = false;
        $scope.leave_id = '';
        $scope.recallDialog = false;
      };

      function getActions(i) {
        $scope.requestLeave.dates = '';
        var index = $scope.datesBeforeEdit.map(function(x) {
          return parseInt(x.leave_detail_id);
        }).indexOf(parseInt($scope.deleteIds[i].leave_detail_id));
        if (index !== -1) {
          $scope.requestLeave.action += $scope.datesBeforeEdit[index].leave_date + ', ';
          $scope.requestLeave.dates += $scope.datesBeforeEdit[index].leave_date + ', ';
        }
      }

      $scope.applyLeave = function() {
        var i, index, endPoint, noOfDays, availableDays;
        if ($scope.isEdit && $scope.leaveDetails.status === 'A' && $rootScope.UILeaveManagementConfigure && $scope.deleteIds.length === 0) {
          $scope.notifications.push({msg: 'Leave Updated Successfully', status: 0});
          $state.go($scope.fromState || 'app.leavesSummary');
        }
        $scope.requestLeave.from_date = $formatHelper.parseDate($scope.requestLeave.f_from_date, dateFormat);
        $scope.requestLeave.upto_date = $formatHelper.parseDate($scope.requestLeave.f_upto_date, dateFormat);
        $scope.requestLeave.send_email = 0;

        $scope.focusLeaveRequest = false;
        if ($scope.isEdit && $scope.leaveDetails.status === 'A' && $rootScope.UILeaveManagementConfigure && $scope.dates.length === 0) {
          $scope.notifications.push({msg: 'Leave without days is not valid. Click on reset to reset the dates', status: 1});
          return;
        }
        if (!$scope.isEdit || ($scope.isEdit && !($scope.leaveDetails.status === 'A' && $rootScope.UILeaveManagementConfigure))) {
          if (!$scope.requestLeave.leave_type_id || !$scope.requestLeave.f_from_date || !$scope.requestLeave.f_upto_date ||
            !$scope.requestLeave.reason || !$scope.requestLeave.manager_user_id) {
              $scope.focusLeaveRequest = true;
              return;
            }

            $scope.requestLeave.from_date = $formatHelper.parseDate($scope.requestLeave.f_from_date, dateFormat);
            $scope.requestLeave.upto_date = $formatHelper.parseDate($scope.requestLeave.f_upto_date, dateFormat);

            if ($formatHelper.dateInMillis($scope.requestLeave.from_date) > ($formatHelper.dateInMillis($scope.requestLeave.upto_date))) {
              $scope.notifications.push({msg: 'From Date should be greater than to date', status: 1});
              $scope.requestLeave.upto_date = '';
              $scope.requestLeave.f_upto_date = '';
              $scope.focusLeaveRequest = true;
              return;
            }

            noOfDays = 0;
            availableDays = $scope.leaveTypes[$scope.selectedLeaveType].available;

            availableDays += $scope.isEdit ? $scope.noOfDays : 0;

            for (i = 0; i < $scope.dates.length; i++) {
              if (!$scope.dates[i].is_holiday && $scope.dates[i].day !== 'Saturday' && $scope.dates[i].day !== 'Sunday') {
                noOfDays += 1;
              }
            }

            if ($scope.dates.length > 0 && noOfDays === 0) {
              $scope.notifications.push({msg: 'All dates in the leave are either weekends or holidays. Please check leave details below', status: 1});
              return;
            }
            if ($scope.leaveTypes[$scope.selectedLeaveType].available && availableDays < noOfDays && !$scope.alertShown) {
              $scope.notifications.push({msg: 'No of days in applied leave crossed available limit. Do you want to continue?', status: 1});
              $scope.alertShown = true;
              return;
            }

            for (i = 0; i < $scope.dates.length; i++) {
              if ($scope.dates[i].full_day !== 'Y' && !$scope.dates[i].is_holiday && $scope.dates[i].day !== 'Saturday' && $scope.dates[i].day !== 'Sunday' &&
              (!$scope.dates[i].hours || !$scope.dates[i].leave_from_time)) {
                $scope.notifications.push({msg: 'Select from time and no.of hours if your leave is not full day', status: 1});
                $scope.focusTime = true;
                return;
              }
            }
        }

        // To get updated and delete leave detail ids
        if ($scope.isEdit) {
          $scope.requestLeave.user_id = user.user_id;
          $scope.requestLeave.leave_id = $scope.leaveId;
          $scope.requestLeave.deleteIds = getUpdatedDates();
        }

        // If user has role leavemanagement delete - Add deleted dates in history descritpion
        if ($scope.isEdit && $scope.leaveDetails.status === 'A' && $rootScope.UILeaveManagementConfigure && $scope.dates.length > 0) {
          $scope.requestLeave.action = '';

          for (i = 0; i < $scope.deleteIds.length; i++) {
            getActions(i);
          }

          if ($scope.requestLeave.action) {
            $scope.requestLeave.action = $scope.requestLeave.action.substr(0, $scope.requestLeave.action.length - 2);
            $scope.requestLeave.dates = $scope.requestLeave.dates.substr(0, $scope.requestLeave.dates.length - 2);
            $scope.requestLeave.action = 'deleted dates ' + $scope.requestLeave.action;
          }
          $scope.requestLeave.deleteIds = $scope.deleteIds;
          $scope.requestLeave.status = 'A';
          $scope.requestLeave.send_email = 1;
          noOfDays = $scope.datesBeforeEdit.length;
        } else {
          $scope.requestLeave.action = $scope.isEdit ? 'updated leave' : 'applied leave';
        }

        $scope.requestLeave.action += ' on ' + $appHelper.today(0);

        $scope.requestLeave.dates = [];
        for (i = 0; i < $scope.dates.length; i++) {
          $scope.dates[i].minutes = $scope.dates[i].full_day !== 'Y' && !$scope.dates[i].minutes ? $scope.minutes[0] : $scope.dates[i].minutes;
          if (!$scope.dates[i].is_holiday && $scope.dates[i].day !== 'Saturday' && $scope.dates[i].day !== 'Sunday') {
            $scope.requestLeave.dates.push($scope.dates[i]);
          }
        }

        $scope.requestLeave.comments = $scope.requestLeave.comments || '';
        $scope.requestLeave.org_id = $scope.orgId || $rootScope.orgId;
        $scope.requestLeave.no_of_days = noOfDays;
        $scope.requestLeave.total_leaves = $scope.leaveTypes[$scope.selectedLeaveType].leave_count || '-';
        $scope.requestLeave.leaves_used = $scope.leaveTypes[$scope.selectedLeaveType].taken;
        $scope.requestLeave.leaves_remaining = $scope.leaveTypes[$scope.selectedLeaveType].available || '-';
        $scope.requestLeave.leave_type = $scope.leaveTypes[$scope.selectedLeaveType].leave_type || '';
        $scope.requestLeave.applied_by = $scope.isEdit ? $scope.leaveDetails.applied_by : user.user_id;
        $scope.requestLeave.created_date = $scope.isEdit ? $scope.leaveDetails.created_date : $appHelper.today(0);
        $scope.requestLeave.status = $scope.isEdit && user.user_id !== $scope.leaveDetails.manager_user_id && $rootScope.UILeaveManagementConfigure ? $scope.leaveDetails.status : 'P';

        // Get manager name
        index = $scope.managers.map(function(x) {
          return parseInt(x.employee_number);
        }).indexOf(parseInt($scope.requestLeave.manager_user_id));
        if (index !== -1) {
          $scope.requestLeave.manager_name = $scope.managers[index].user_name || '';
        }
        endPoint = '/hcm/leavemanagement/leave/';
        endPoint += $scope.isEdit ? 'update/' : 'add/';
        $scope.showSpinner = true;
        $httpHelper.httpRequest('POST', endPoint, $scope.requestLeave, function(data) {
          if (data === null || data === undefined) {
            $scope.notifications.push({msg: 'Server Error - applyLeave()', status: 1});
          } else {
            if (data.status === 0) {
              $scope.requestLeave = {
                leave_type_id: '',
                from_date: '',
                upto_date: '',
                f_from_date: '',
                f_upto_date: '',
                manager_user_id: '',
                reason: '',
                status: 'P',
                user_id: user.user_id,
                action: '',
                comments: '',
                org_id: ''
              };
              $state.go($scope.fromState || 'app.leavessummary');
              $scope.alertShown = false;
              $scope.focusLeaveRequest = false;
              $scope.dates = [];
              $scope.isEdit = false;
            } else if (data.duplicated_dates) {
              data.msg = '';
              for (var i = 0; i < data.duplicated_dates.length; i++) {
                data.msg += data.duplicated_dates[i].leave_type + ' on ' + data.duplicated_dates[i].date + ', ';
              }
              if (data.msg) {
                data.msg = data.msg.substr(0, data.msg.length - 2);
                data.msg = 'You have already applied for ' + data.msg;
              }
            }
            $scope.notifications.push({msg: data.msg, status:data.status});
          }
          $scope.showSpinner = false;
        });
      };

      $scope.resetDates = function() {
        $scope.dates = angular.copy($scope.datesBeforeEdit);
        $scope.deleteIds = [];
      };

      function getUpdatedDates() {
        var deletedIds = [], index, i;
        for (i = 0; i < $scope.dates.length; i++) {
          index = $scope.datesBeforeEdit.map(function(x) {
            return x.f_leave_date;
          }).indexOf($scope.dates[i].f_leave_date);

          if (index !== -1) {
            $scope.dates[i].leave_detail_id = $scope.datesBeforeEdit[index].leave_detail_id;
          } else {
            $scope.dates[i].leave_detail_id = -1;
          }
        }

        if ($scope.isEdit) {
          for (i = 0; i < $scope.datesBeforeEdit.length; i++) {
            index = $scope.dates.map(function(x) {
              return x.f_leave_date;
            }).indexOf($scope.datesBeforeEdit[i].f_leave_date);
            if (index === -1) {
              deletedIds.push({
                leave_id: $scope.leaveId,
                leave_detail_id: $scope.datesBeforeEdit[i].leave_detail_id,
                leave_date: $scope.datesBeforeEdit[i].leave_date
              });
            }
          }
        }
        return deletedIds;
      }

      $scope.goToSummary = function() {
        $state.go($scope.fromState || 'app.leavessummary');
      };

      $scope.calculateLeavesDates = function() {
        if (!$scope.requestLeave.f_from_date) {
          return;
        }
        var startDate, endDate, noOfDays, oneDay = 1000 * 60 * 60 * 24, i,
        fromDate, date, isHoliday = false, index, day;
        var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug',
                  'Sep', 'Oct', 'Nov', 'Dec'
                ];

        fromDate = new Date($formatHelper.parseDate($scope.requestLeave.f_from_date, dateFormat));
        startDate = new Date($formatHelper.parseDate($scope.requestLeave.f_from_date, dateFormat)).getTime();
        if ($scope.requestLeave.f_upto_date) {
          endDate = new Date($formatHelper.parseDate($scope.requestLeave.f_upto_date, dateFormat)).getTime();
        } else {
          endDate = fromDate;
        }
        if (startDate > endDate) {
          $scope.notifications.push({msg: 'To date should be greater than from date', status: 1});
          $scope.requestLeave.f_from_date = '';
          $scope.requestLeave.from_date = '';
          return;
        }
        $scope.dates = [];
        noOfDays = (endDate - startDate) / oneDay;
        for (i = 0; i <= noOfDays; i++) {
          date = new Date(fromDate);
          date.setDate(fromDate.getDate() + i);
          day = $formatHelper.getWeekDay(date);
          date = (parseInt(date.getDate()) < 10 ? '0' + date.getDate() : date.getDate()) + '-' + months[date.getMonth()] + '-' + date.getFullYear();
          index = $scope.holidaysList.map(function(x) {
            return x.holiday_date.toLowerCase();
          }).indexOf(date.toLowerCase());
          isHoliday = index === -1 ? false : true;
          $scope.dates.push({
            leave_date: date,
            f_leave_date: $formatHelper.formatDate(date, dateFormat),
            leave_date_millis: $formatHelper.dateInMillis(date),
            full_day: 'Y',
            leave_from_time: '',
            hours: '',
            minutes: '',
            day: day,
            is_holiday: isHoliday,
            holiday_name: isHoliday ? $scope.holidaysList[index].holiday_name : ''
          });
        }
      };

      $scope.sort = function(key) {
        if ($scope.predicate === key) {
          $scope.desc = !$scope.desc;
        } else {
          $scope.predicate = key;
          $scope.desc = false;
        }
      };

      function getHolidaysList() {
        $scope.holidaysList = [];
        var endPoint = '/hcm/leavemanagement/holidays/';
        var requestObj = {
          org_id: $scope.orgId || $rootScope.orgId,
          holiday_id: '',
          year: new Date($appHelper.today(0)).getFullYear()
        };
        $httpHelper.httpRequest('POST', endPoint, requestObj, function(data) {
          if (data === null || data === undefined) {
            $scope.notifications.push({msg: 'Server Error - getHolidaysList()', status: 1});
          } else {
            if (data.status === 1) {
              $scope.notifications.push({msg: data.msg, status: data.status});
            } else {
              for(var i = 0; i < data.result.length; i++) {
                data.result[i].f_holiday_date = $formatHelper.formatDate(data.result[i].holiday_date, dateFormat);
                data.result[i].holiday_date_millis = $formatHelper.dateInMillis(data.result[i].holiday_date);
                data.result[i].holiday_day = $formatHelper.getWeekDay(new Date(data.result[i].holiday_date));
              }
              $scope.holidaysList = data.result;
            }
          }
        });
      }

      function loadManagers() {
        $scope.managers = '';
        var endPoint = '/hcm/leavemanagement/managers/';
        endPoint += $scope.orgId + '/';
        $httpHelper.httpRequest('GET', endPoint, null, function(data) {
          if (data === null || data === undefined) {
            $scope.notifications.push({msg: 'Server Error - loadManagers()', status: 1});
          } else {
            if (data.status === 1) {
              $scope.notifications.push({msg: data.msg, status: data.status});
            } else {
              $scope.managers = [];
              for (var i = 0; i < data.length; i++) {
                if (data[i].employee_number !== user.user_id) {
                  $scope.managers.push(data[i]);
                }
              }
              bindManagerName();
            }
          }
        });
      }

      function loadHoursMinutes() {
        var i, j;
        $scope.time = [];
        $scope.minutes = ['00', '30'];

        // Starting time for hourly leave
        for (i = 8; i < 20; i++) {
          for (j = 0; j < $scope.minutes.length; j++) {
            $scope.time.push({tick: i + ':' + $scope.minutes[j]});
          }
        }

        // No.of hours LOV for hourly leave
        $scope.hours = [];

        for (i = 1; i < 8; i++) {
          $scope.hours.push({hour: i.toString()});
        }

      }
    }
})();
