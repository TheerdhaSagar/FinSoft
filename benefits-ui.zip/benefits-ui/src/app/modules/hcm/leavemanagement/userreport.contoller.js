/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 06-11-2018
 */

(function() {
    'use strict';

    angular.module('scorpion')
        .controller('UserReportController', UserReportController);

    function UserReportController($scope, $location, $cacheHelper, $window, $state,
      $rootScope, $httpHelper, $timeout, $formatHelper, $appHelper, $compile) {

      $scope.$on('viewContentLoaded', function () {
          $window.ga('send', 'pageview', {
              page: $location.url()
          });
      });

      var user, dateFormat;
      $cacheHelper.getUser(function (data) {
          if (!data) {
              $state.go('app.login');
          } else {
              if (!$cacheHelper.user) {
                  $cacheHelper.initialize(data);
              }
              user = data;
              dateFormat = user.date_format || 'dd-MM-yyyy';
              $scope.showSpinner = true;
              getLeavesHistory();
          }
      });

      $scope.$watch(function() {
        return $rootScope.orgId;
      }, function(newValue, oldValue) {
        if (newValue !== oldValue) {
          $state.go($state.current, {}, {
            reload: true
          });
        }
      });

      $scope.sort = function(key) {
        if ($scope.predicate === key) {
          $scope.desc =!$scope.desc;
        } else {
          $scope.predicate = key;
          $scope.desc = false;
        }
      };

      $scope.showLeaveTypeHistory = function(row) {
        $('.child-table').remove();
        $('.master-table').find('.child-row').remove();

        if ($('#' + row.leave_type_id).hasClass('expanded')) {
          $('#' + row.leave_type_id).removeClass('expanded');
          $('#' + row.leave_type_id).find('.expand-icon').removeClass('icon-circle-minus');
          $('#' + row.leave_type_id).find('.expand-icon').addClass('icon-plus-circle');
          $scope.isExpanded = false;
        } else {
          $('tr').removeClass('expanded');
          $('tr').find('.expand-icon').removeClass('icon-circle-minus');
          $('tr').find('.expand-icon').addClass('icon-plus-circle');
          var childRow = $('<tr class="child-row"><td colspan="7"></td></tr>');

          childRow.insertAfter($('#' + row.leave_type_id));
          $('#' + row.leave_type_id).addClass('expanded');
          $('#' + row.leave_type_id).find('.expand-icon').removeClass('icon-plus-circle');
          $('#' + row.leave_type_id).find('.expand-icon').addClass('icon-circle-minus');
          $scope.leaveTypeHistory = row.leaves;
          childRow.find('td').append($compile('<leavetypehistory></leavetypehistory>')($scope));
        }
      };

      $scope.goToSummary = function() {
        $state.go('app.leavessummary');
      };

      function getLeavesHistory() {
        $scope.showSpinner = true;
        var endPoint ='/hcm/leavemanagement/leaves/types/count/';
        var requestObj = {
          user_id: user.user_id,
          org_id: $rootScope.orgId
        };
        $httpHelper.httpRequest('POST', endPoint, requestObj, function(data) {
          if (data === null || data === undefined) {
            $scope.notifications.push({msg: 'Server Error - getLeavesHistory()', status: 1});
          } else {
            if (data.status === 1) {
              $scope.notifications.push({msg: data.msg, status: data.status});
            } else {
              generateReport(data);
              $scope.predicate = 'leave_type_id';
              $scope.desc = true;
              $scope.showSpinner = false;
            }
          }
        });
      }

      function generateReport(data) {
        var i, j, hours, leavesCount = 0, index;
        for (i = 0; i < data.length; i++) {
          data[i].taken = 0;
          data[i].available = data[i].leavesCount || '';
          leavesCount = 0;
          data[i].leaves = [];
          for (j = 0; j < data[i].details.length; j++) {
            if (data[i].leave_type_id !== data[i].details[j].leave_type_id) {
              continue;
            }

            index = -1;
            if (data[i].leaves.length > 0) {
              index = data[i].leaves.map(function(x) {
                return x.leave_id;
              }).indexOf(data[i].details[j].leave_id);
            }

            // To get leave details header details
            if (index === -1) {
              data[i].leaves.push({
                reason: data[i].details[j].reason,
                leave_id: data[i].details[j].leave_id,
                from_date: data[i].details[j].from_date,
                f_from_date: $formatHelper.formatDate(data[i].details[j].from_date, dateFormat),
                from_date_millis: $formatHelper.dateInMillis(data[i].details[j].from_date),
                upto_date: data[i].details[j].upto_date,
                f_upto_date: $formatHelper.formatDate(data[i].details[j].upto_date, dateFormat),
                upto_date_millis: $formatHelper.dateInMillis(data[i].details[j].upto_date),
                manager_name: data[i].details[j].manager_name,
                status: data[i].details[j].status
              });
            }

            if (data[i].details[j].status !== 'C' && data[i].details[j].status !== 'R') {
              if (data[i].details[j].full_day !== 'Y') {
                hours = data[i].details[j].leave_hours.split(':');
                data[i].details[j].no_of_days = (parseInt(hours[0]) + (parseInt(hours[1]) / 60)) / 8;
              } else {
                data[i].details[j].no_of_days = 1;
              }
              leavesCount += data[i].details[j].no_of_days;
            }

          }

          data[i].taken = $formatHelper.round(leavesCount, 2);
          data[i].available = data[i].leave_count ? $formatHelper.round(data[i].leave_count - leavesCount, 2) : '';
        }

        $scope.leavesHistory = data;
      }
    }
})();
