/*
 * Author: Theerdha Sagar
 * Date: 23-01-2019
 */

(function() {
  'use strict';

  angular.module('scorpion')
    .controller('IssuesController', IssuesController);

  function IssuesController($scope, $state, $window, $location, $cacheHelper,
                            $appHelper, $httpHelper, $formatHelper, $timeout, $rootScope, $filter) {

    // google analytics code
    $scope.$on('$viewContentLoaded', function() {
      $window.ga('send', 'pageview', { page: $location.url()});
    });

    var user, deleteLine;
    $cacheHelper.getUser(function(data) {
      if (!data) {
        $state.go('login');
      } else {
        if (!$cacheHelper.user) {
          $cacheHelper.initialize(data);
        }
        user = data;


        $scope.issueTypes = [{
          status: 'HR_PR',
          label: 'HR/PR'
        }, {
          status: 'HISTORY',
          label: 'HISTORY'
        }, {
          status: 'WFN',
          label: 'WFN'
        }, {
          status: 'BENEFITS',
          label: 'BENEFITS'
        }];

        $scope.status = 'C';
        $scope.showWaitingColumn = true;
        $scope.edit = false;
        $scope.toggleFilter = $appHelper.toggleFilter();
        // loadIssues();
        loadData();
        $scope.showConversions = false;
      }
    });

    $scope.$watch(function() {
      return $rootScope.orgId;
    }, function(newValue, oldValue) {
      if (newValue !== oldValue) {
        $state.go($state.current, {}, {
          reload: true
        });
      }
    });

    $scope.predicate = 'invite_id';
    $scope.desc = true;
    $scope.sort = function(key) {
      $scope.predicate = key;
      $scope.desc = !$scope.desc;
    };

    function loadData() {
      var endPoint = '/wfn/issues/' + $rootScope.orgId + '/';
      var req = {};
      $scope.showSpinner = true;
      if ($scope.issue_task_filter){
        req.issue_task_filter = $scope.issue_task_filter.status;
      }else {
        req.issue_task_filter = '';
      }
      $httpHelper.httpRequest('POST', endPoint, req, function(data) {
        $scope.showSpinner = false;
        try {
          if (data === null || data === undefined) {
            throw new Error('Server Error');
          } else {
            $scope.list_issues = data.result;
          }
        } catch (e) {
          $scope.notifications.push({status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>'});
        }
      });
    }

    $scope.onIssueTypeChange = function(issueArea) {
      $scope.issueSubType = [];
      $scope.focusconversion = true;
      switch (issueArea) {
        case 'HR_PR':
          $scope.issueSubType = [{
            status: 'PERSONAL_DATA',
            label: 'PERSONAL DATA'
          }, {
              status: 'JOB',
              label: 'JOB'
            },{
              status: 'EMPLOYMENT',
              label: 'EMPLOYMENT'
            },{
            status: 'WS_MANAGER',
            label: 'WS MANAGER'
          }, {
            status: 'REPORTS_TO_ID',
            label: 'REPORTS TO ID'
          }, {
            status: 'TELEPHONE_NBR',
            label: 'TELEPHONE NBR'
          }, {
            status: 'EMERGENCY_CNTCT',
            label: 'EMERGENCY CNTCT'
          }, {
            status: 'CDF_DATA',
            label: 'CDF DATA'
          },{
            status: 'JOB_ADDL_RATES',
            label: 'JOB ADDL RATES'
          },{
            status: 'BEN_PROG_PARTIC',
            label: 'BEN_PROG_PARTIC'
          },{
            status: 'HRUSER_DATA',
            label: 'HRUSER DATA'
          },{
            status: 'PERSONAL_DATA_HIST',
            label: 'PERSONAL DATA HIST'
          },{
            status: 'TAX_DATA',
            label: 'TAX DATA'
          },{
            status: 'W4_DATA',
            label: 'W4 DATA'
          },{
            status: 'DIRECT_DEPOSIT',
            label: 'DIRECT DEPOSIT'
          },{
            status: 'DEDUCTIONS',
            label: 'DEDUCTIONS'
          },{
            status: 'LEIN_DATA',
            label: 'LEIN DATA'
          },{
            status: '5TH_FIELD',
            label: '5TH FIELD'
          },{
            status: 'ALA_DATA',
            label: 'ALA DATA'
          },{
            status: 'BALANCES',
            label: 'BALANCES'
          }];
          break;
        case 'HISTORY':
          $scope.issueSubType = [{
            status: 'JOB_HISTORY',
            label: 'JOB HISTORY'
          }, {
            status: 'CHECK_HISTORY',
            label: 'CHECK HISTORY'
          }];
          break;
        case 'WFN':
          $scope.issueSubType = [{
            status: 'MASTER_FILE',
            label: 'MASTER FILE'
          }, {
            status: 'STATUS',
            label: 'STATUS'
          }, {
            status: 'IS_SUPERVISOR',
            label: 'IS SUPERVISOR'
          }, {
            status: 'REPORTS_TO',
            label: 'REPORTS TO'
          }, {
            status: 'POSITION',
            label: 'POSITION'
          }, {
            status: 'PAYRATE',
            label: 'PAYRATE'
          },{
            status: 'DEDUCTIONS',
            label: 'DEDUCTIONS'
          },{
            status: 'DIRECT_DEPOSITS',
            label: 'DIRECT DEPOSITS'
          },{
            status: 'ADDITIONAL_FIELDS',
            label: 'ADDITIONAL FIELDS'
          },{
            status: 'LIENS',
            label: 'LIENS'
          },{
            status: '5TH_FIELD_EARNINGS',
            label: '5TH FIELD EARNINGS'
          },{
            status: 'ALA',
            label: 'ALA'
          },{
            status: 'EMERGENCY_CONTACT',
            label: 'EMERGENCY CONTACT'
          },{
            status: 'COMPANY_PROPERTY',
            label: 'COMPANY PROPERTY'
          },{
            status: 'ADA',
            label: 'ADA'
          },{
            status: 'FMLA',
            label: 'FMLA'
          },{
            status: 'GOALS',
            label: 'GOALS'
          }];
          break;
        case 'BENEFITS':
          $scope.issueSubType = [{
            status: 'INDICATIVE',
            label: 'INDICATIVE'
          }, {
            status: 'DEPENDENT',
            label: 'DEPENDENT'
          }, {
            status: 'ELECTION',
            label: 'ELECTION'
          }, {
            status: 'BENEFICIARY',
            label: 'BENEFICIARY'
          }];
          break;
      }
    };

    $scope.addIssue = function() {
      var endPoint, req = {};
      if($scope.edit){
        endPoint = '/wfn/issue/edit/';
        req.issue_id = $scope.issue_id;
      }else{
        endPoint = '/wfn/issue/create/';
      }
      var error = false;
      if (!$scope.errorName) { $scope.focuserrorname = false; error = true; }
      if (!$scope.issueArea) { $scope.focusissuearea = false; error = true; }
      if (!$scope.conversion) { $scope.focusconversion = false; error = true; }
      if (!$scope.resolution) { $scope.focusresolution = false; error = true; }

      if (error) { return; }
      req.error_message = $scope.errorName;
      req.issue_task = $scope.issueArea;
      req.issue_sub_task = $scope.conversion;
      req.user_id = user.user_id;
      req.issue_resolution = $scope.resolution;
      req.org_name = $rootScope.orgName || '';
      req.org_id = $rootScope.orgId;
      $scope.pageDim = true;
      $scope.showDialog = false;
      clear();
      $httpHelper.httpRequest('POST', endPoint, req, function (data) {
        $scope.pageDim = false;
        try {
          if (data === null || data === undefined) {
            throw new Error('Server Error');
          } else {
            $scope.notifications.push({status: data.status, msg: data.msg});
            if (data.status === 0) {
              $scope.list_issues = null;
            }
            loadData();
            $scope.inviteId = null;
          }
        } catch (e) {
          $scope.notifications.push({status: 1, msg: e.message, details: '<pre>' + e.stack + '</pre>'});
        }
      });
    };


    $scope.closeDialog = function() {
      clear();
      $scope.view = false;
      $scope.focuserrorname = true;
      $scope.focusissuearea = true;
      $scope.focusconversion = true;
      $scope.focusresolution = true;
      $scope.showDialog = false;
    };

    function clear() {
      $scope.errorName = null;
      $scope.issueArea = null;
      $scope.conversion = null;
      $scope.resolution = null;
      $scope.focuserrorname = true;
      $scope.focusissuearea = true;
      $scope.focusconversion = true;
      $scope.focusresolution = true;
    }

    $scope.applyFilter = function() {
      $scope.toggleFilter();
      $scope.showSpinner = true;
      loadData();
    };

    $scope.editLine = function(record, type) {
      if (type === "edit"){
        $scope.edit = true;
        $scope.view = false;
      } else {
        $scope.edit = false;
        $scope.view = true;
      }
      $timeout(function () {
        $scope.issue_id = record.issue_id;
        $scope.showDialog =  true;
        $scope.errorName = record.error_message;
        $scope.issueArea = record.issue_task;
        $scope.onIssueTypeChange($scope.issueArea);
        $scope.conversion = record.issue_sub_task;
        $scope.resolution = record.issue_resolution;
      }, 350);
    };

    $scope.delete = function(schedule) {
      deleteLine = schedule.issue_id;
      $scope.deleteDialog = true;
    };

    $scope.deleteRow = function() {
        $scope.showSpinner = true;
        var endPoint = '/wfn/issue/delete/' + deleteLine + '/';
        $scope.deleteDialog = false;
        $httpHelper.httpRequest("DELETE", endPoint ,null ,function(data){
          if(data === null || data === undefined){
            throw new Error("Server Error");
          }else {
            if(data.status === 0) {
              var index = $scope.list_issues.map(function(x){return x.issue_id;}).indexOf(deleteLine);
              if(index !== -1) {
                $scope.list_issues.splice(index, 1);
              }
            } else if(data.status === 1) {
              $scope.notifications.push({status:1, msg: data.msg});
            }
            $scope.showSpinner = false;
          }
        });
    };


    $scope.exportData = function() {
      $scope.toggleFilter();
      var exportdata = $filter('orderBy')($scope.list_issues, $scope.predicate, $scope.desc);
      var tableData = {};
      var tmpData = [];
      for (var i = 0; i < exportdata.length; i++) {
        var tmpObj = {};
        tmpObj['Issues #'] = {
          data: exportdata[i].issue_id
        };
        tmpObj['Error Message'] = {
          data: exportdata[i].error_message
        };
        tmpObj['Issue Task'] = {
          data: exportdata[i].issue_task
        };
        tmpObj['Issue Sub Task'] = {
          data: exportdata[i].issue_sub_task,
          align: 'right'
        };
        tmpObj['Issue Resolution'] = {
          data: exportdata[i].issue_resolution
        };
        tmpData.push(tmpObj);
      }
      tableData.data = tmpData;
      $appHelper.tableToExcel('Issue Tracker', tableData, 'exportIssues');
    };


  }

})();
