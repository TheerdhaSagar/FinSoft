/*
 *  Author: Theerdha Sagar Nimmagadda
 *  Date: 16-10-2018
 */

(function() {
  'use strict';

  angular.module('scorpion')
    .controller('TemplateController', TemplateController);

  function TemplateController($scope, $rootScope, $state, $cacheHelper,
    $appHelper, $translate, $formatHelper, $timeout) {

    var user;
    $scope.notifications = [];
    $scope.minimize = true;
    $scope.windowWidth = $(window).width();
    $cacheHelper.getUser(function(data) {
      if (data) {
        user = data;

        if (!$cacheHelper.user) {
          $cacheHelper.initialize(user);
        }

        // If user has debug on then display message below username
        if (user.debug_flag === 'Y') {
          $scope.debugOn = true;
        }

        // This holds the username displayed in the application
        $rootScope.userName = user.user_description;
        $rootScope.currentState = $state.current.name;
        var userOrgs = user.organizations;

        for (var i = 0; i < userOrgs.length; i++) {
          if (userOrgs[i].organization_id === parseInt($cacheHelper.getOrgId())) {
            $rootScope.orgId = userOrgs[i].organization_id;
            $rootScope.orgName = userOrgs[i].name;
            break;
          }
        }

        $scope.organizations = userOrgs;  // Display user organizations list

        var permissions = user.permissions;

        // Identify the user type based on the permissions
        if (permissions) {
          $rootScope.isAdmin = permissions.indexOf('ADMIN') !== -1;
          $rootScope.UILeaveManagementConfigure = permissions.indexOf('UI-LEAVE-MANAGEMENT-CONFIGURE') !== -1;
          $rootScope.UILeaveManagement = permissions.indexOf('UI-LEAVE-MANAGEMENT') !== -1;
          $rootScope.UIforHCM = permissions.indexOf('ADMIN') !== -1;
          $rootScope.UIforLeavesApproval = permissions.indexOf('ADMIN') !== -1;  
          $rootScope.isDcOrgUI = permissions.indexOf('DC-ORG-UI') !== -1;
          $rootScope.isBenefitsOrgUI = permissions.indexOf('BENEFITS-ORG-UI') !== -1;
          $rootScope.isEditIssueTracker = permissions.indexOf('DC-UI-ISSUE-TRACKER') !== -1;
          $rootScope.isUIBenefitsAssociate = permissions.indexOf('BENEFITS-ASSOCIATE-UI') !== -1;
          $rootScope.isUIBenefitsManager = permissions.indexOf('BENEFITS-MANAGER-UI') !== -1;
          $rootScope.UIUserManagement = permissions.indexOf('USER-MANAGEMENT-UI') !== -1;
        }

        $rootScope.isIE = $appHelper.isIE();
        $rootScope.isSafari = $appHelper.isSafari();

      } else {
        $state.go('login');
      }

      $scope.$watch(function() {
        return $scope.notifications.length;
      }, function(newValue, oldValue) {
        if (newValue > oldValue) {
          if ($scope.notifications && $scope.notifications.length > 0) {
            $scope.notifications[newValue - 1].timestamp = $formatHelper.getTimeStamp();
            $scope.notifications[newValue - 1].notification_time = new Date().getTime();
          }
          $scope.minimize = false;

          $timeout(function() {
            $scope.minimize = true;
          }, 5000);
        }
      });

      $scope.appStates = [
        {name: 'Home', state: 'app.dashboard'},
        {name: 'Profile', state: 'app.profile'}
      ];

      if (($rootScope.isAdmin ) || $rootScope.UIUserManagement) {
        $scope.appStates.push({name: 'Users', state: 'app.users'});
        $scope.appStates.push({name: 'Create User', state: 'app.manageuser'});
        $scope.appStates.push({name: 'Groups', state: 'app.groups'});
        $scope.appStates.push({name: 'Create Group', state: 'app.managegroup'});
        $scope.appStates.push({name: 'Roles', state: 'app.roles'});
        $scope.appStates.push({name: 'Create Role', state: 'app.managerole'});
        $scope.appStates.push({name: 'Permissions', state: 'app.permissions'});
        $scope.appStates.push({name: 'Create Permission', state: 'app.createPermission'});
      }

      if (($rootScope.isAdmin && !$rootScope.isCEO) || $rootScope.hasNotifications) {
        $scope.appStates.push({name: 'Notifications', state: 'app.notifications'});
      }

      if (($rootScope.isAdmin && !$rootScope.isCEO) || $rootScope.UISchedules) {
        $scope.appStates.push({name: 'Schedules', state: 'app.scheduleSummary'});
        $scope.appStates.push({name: 'Create Schedule', state: 'app.scheduleCreate'});
      }


    });

    $rootScope.$on('$stateChangeStart', function(event, toState, toParams, fromState) {
      $rootScope.fromState = fromState;
      $rootScope.toState = toState;
    });

    // This method is called when user clicked on logout
    $scope.logout = function () {
      $rootScope.logout = true;
      $cacheHelper.clear(); // Clear all cached data before loggin out
      $state.go('login');
    };

    $scope.profile = function() {
      $state.go('app.profile');
      $('.user-name').click();
    };

    $('.user-avatar, .user-name').click(function() {
      var top;
      if ( !$( '.user-menu ').hasClass('active') ) {
        $( '.user-menu' ).addClass('active');
        if ($scope.windowWidth <= 1024) {
          top = '37px';
        } else {
          top = '45px';
        }
      } else {
        $( '.user-menu' ).removeClass('active');
        top = '-450px';
      }

      $( '.user-menu' ).animate({
        top: top
      }, 500, 'linear');
    });

    $('.burger-menu').click(function() {
      var right;
      if ( !$( '.burger-menu ').hasClass('active') ) {
        $( '.burger-menu' ).addClass('active');
        right = '0px';
      } else {
        $( '.burger-menu' ).removeClass('active');
        right = '-300px';
      }

      $( '.responsive-menu' ).css({display: 'block'});
      $( '.responsive-menu' ).animate({
        right: right
      }, 500, 'linear');
    });

    $(document).mouseup(function(e) {
      e.stopPropagation();
      var container = $('.user-menu');
      var orgMenu = $('.org-container');
      var orgSelector = $('.org-selector');
      if ($('.user-menu').hasClass('active')) {
        if (!container.is(e.target) && container.has(e.target).length === 0) {
          $( '.user-menu' ).removeClass('active');
          $('.user-menu').animate({
            top: '-450px'
          }, 500, 'linear');
        }
      }
      if ($('.org-container').hasClass('active')) {
        if ((!orgMenu.is(e.target) && orgMenu.has(e.target).length === 0) &&
          (!orgSelector.is(e.target) && orgSelector.has(e.target).length === 0)) {
          $('.org-container').removeClass('active');
        }
      }
    });

    $scope.burgerClose = function() {
      $( '.responsive-menu' ).animate({
        right: '-300px'
      }, 500, 'linear', function() {
        $( '.burger-menu' ).removeClass('active');
        $(this).css({display: 'none'});
      });
    };

    $scope.showView = function(view) {
      switch (view) {
        case 'home':
          $state.go('app.ceodashboard');
          $scope.burgerClose();
          break;
      }
    };

    $scope.goToHome = function() {
      if ($rootScope.isB2b) {
        $state.go('app.quotes');
      } else if ($rootScope.isAdmin) {
        $state.go('app.ceodashboard');
      }
    };

    $scope.goToView = function(which) {
      switch (which) {
        case 'home':
          $scope.selectedMenu = 'home';
            $state.go('app.dashboard');
          break;
        case 'users':
          $scope.selectedMenuItem = 'users';
          $scope.selectedMenu = 'usermanagement';
          $state.go('app.users');
          break;
        case 'groups':
          $scope.selectedMenuItem = 'groups';
          $scope.selectedMenu = 'usermanagement';
          $state.go('app.groups');
          break;
        case 'roles':
          $scope.selectedMenuItem = 'roles';
          $scope.selectedMenu = 'usermanagement';
          $state.go('app.roles');
          break;
        case 'permissions':
          $scope.selectedMenuItem = 'permissions';
          $scope.selectedMenu = 'usermanagement';
          $state.go('app.permissions');
          break;          
        default:
      }
    };

    $(window).scroll(function() {
      if (window.scrollY > 10) {
        // $('.nav-header').hide();
        $('.table--fixed, .fixed-table').each(function() {
          $(this).find('thead').addClass('table--fixed--top');
        });
      } else {
        // $('.nav-header').show();
        $('.table--fixed, .fixed-table').each(function() {
          $(this).find('thead').removeClass('table--fixed--top');
        });
        if (window.scrollY === 0) {
          $('.column-fixed').css({top: '105px'});
        }
      }

      $('.column-fixed').css({top: (105 - window.scrollY) + 'px'});

      if (window.scrollY > 250) {
        $('.scroll-top').addClass('active');
      } else {
        $('.scroll-top').removeClass('active');
      }

    });

    $scope.showOrgs = function(e) {
      if ($('.org-container').hasClass('active')) {
        $('.org-container').removeClass('active');
      } else {
        var width = $(window).width();
        var pos = width < 1200 ? width < 900 ?  width < 450 ? 100 : 450 : 650 : e.clientX - 130;
        $('.org-container').css({top: 50, left: pos});
        $('.org-container').addClass('active');
      }
    };

    $scope.changeOrg = function(org) {
      $('.org-container').removeClass('active');
      $cacheHelper.setOldOrgId($rootScope.orgId);
      $rootScope.orgId = org.organization_id;
      $rootScope.orgName = org.name;
      $rootScope.manager_id = org.manager_id;
      $cacheHelper.setOrgId($rootScope.orgId);
    };

    $scope.$on('$viewContentLoaded', function() {
      switch ($state.current.name) {
        
        case 'app.users':
        case 'app.manageuser':
          $scope.selectedMenuItem = 'users';
          $scope.selectedMenu = 'usermanagement';
          break;        
        case 'app.groups':
        case 'app.managegroup':
          $scope.selectedMenuItem = 'groups';
          $scope.selectedMenu = 'usermanagement';
          break;
        case 'app.roles':
        case 'app.managerole':
          $scope.selectedMenuItem = 'roles';
          $scope.selectedMenu = 'usermanagement';
          break;
        case 'app.permissions':
        case 'app.createPermission':
        case 'app.editPermission':
          $scope.selectedMenuItem = 'permissions';
          $scope.selectedMenu = 'usermanagement';
          break;       
        default:
          $scope.selectedMenu = 'home';
          break;
      }
    });

    $scope.clearNotification = function(n) {
      if (n) {
        var index = $scope.notifications.indexOf(n);
        if (index !== -1) {
          $scope.notifications.splice(index, 1);
        }
      }
    };

    $scope.clearAllNotifications = function() {
      $scope.notifications = [];
    };

    $scope.goToState = function() {
      $state.go($scope.searchState);
      $scope.searchState = null;
    };

    $(window).resize(function() {
      $scope.windowWidth = $(window).width();
    });

  }
})();
