(function () {
  "use strict";

  // URL used to connect to Web Services
  angular.module("scorpion").constant("URL", "http://localhost:8000");
})();
