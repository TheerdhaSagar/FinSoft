(function() {
  'use strict';

  angular
    .module('scorpion', ['ngAnimate', 'ngCookies', 'ngTouch', 'ngSanitize',
      'ui.router', 'ab-base64', 'naif.base64', 'pascalprecht.translate',
      'infinite-scroll', 'zingchart-angularjs', 'minicolors']);

})();
