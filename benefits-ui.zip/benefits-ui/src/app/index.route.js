(function () {
  'use strict';

  angular
    .module('scorpion')
    .config(routeConfig);

  /** @ngInject */
  function routeConfig($stateProvider, $urlRouterProvider, $translateProvider) {
    $stateProvider
      .state('login', {
        url: '/login/:token',
        templateUrl: 'app/modules/login/login.html',
        controller: 'LoginController'
      })

      .state('app', {
        url: '/',
        templateUrl: 'app/modules/template/template.html',
        controller: 'TemplateController'
      })

      .state('app.dashboard', {
        url: 'dashboard',
        templateUrl: 'app/modules/dashboard/dashboard.html',
        controller: 'DashboardController'
      })

      .state('app.profile', {
        url: 'profile',
        templateUrl: 'app/modules/profile/profile.html',
        controller: 'ProfileController'
      })         

      .state('app.users', {
        url: 'users',
        templateUrl: 'app/modules/usermanagement/users.html',
        controller: 'UsersController'
      })

      .state('app.summarytasks', {
        url: 'tasks/summary',
        templateUrl: 'app/modules/tasks/tasks.html',
        controller: 'SummaryTasksController'
      })

      .state('app.createcustomerobjectives', {
        url: 'objectives/create',
        templateUrl: 'app/modules/tasks/createtasks.html',
        controller: 'CreateObjectivesController'
      })       

      .state('app.groups', {
        url: 'groups',
        templateUrl: 'app/modules/usermanagement/groups.html',
        controller: 'GroupsController'
      })

      .state('app.roles', {
        url: 'roles',
        templateUrl: 'app/modules/usermanagement/roles.html',
        controller: 'RolesController'
      })

      .state('app.permissions', {
        url: 'permissions',
        templateUrl: 'app/modules/usermanagement/permissions.html',
        controller: 'PermissionsController'
      })

      .state('app.createPermission', {
        url: 'createPermission',
        templateUrl: 'app/modules/usermanagement/createpermission.html',
        controller: 'CreatePermissionController'
      })

      .state('app.editPermission', {
        url: 'editPermission',
        templateUrl: 'app/modules/usermanagement/editpermission.html',
        controller: 'CreatePermissionController'
      })

      .state('app.manageuser', {
        url: 'user',
        templateUrl: 'app/modules/usermanagement/manageuser.html',
        controller: 'ManageUserController'
      })

      .state('app.managerole', {
        url: 'role',
        templateUrl: 'app/modules/usermanagement/managerole.html',
        controller: 'ManageRoleController'
      })

      .state('app.managegroup', {
        url: 'group',
        templateUrl: 'app/modules/usermanagement/managegroup.html',
        controller: 'ManageGroupController'
      })       

      .state('app.leavemanagementdashboard', {
        url: 'hcm/leavemanagement',
        templateUrl: 'app/modules/hcm/leavemanagement/dashboard.html',
        controller: 'LeaveManagementDashboardController'
      })

      .state('app.configureleave', {
        url: 'hcm/leavemanagement/configure',
        templateUrl: 'app/modules/hcm/leavemanagement/configureleaves.html',
        controller: 'ConfigureLeavesController'
      })

      .state('app.leaveapplications', {
        url: 'hcm/leavemanagement/applications',
        templateUrl: 'app/modules/hcm/leavemanagement/applications.html',
        controller: 'LeaveApplicationsController'
      })

      .state('app.holidayslist', {
        url: 'hcm/leavemanagement/list',
        templateUrl: 'app/modules/hcm/leavemanagement/list.html',
        controller: 'HolidaysListController'
      })

      .state('app.leavessummary', {
        url: 'hcm/leavemanagement/leavessummary',
        templateUrl: 'app/modules/hcm/leavemanagement/leavessummary.html',
        controller: 'LeavesSummaryController'
      })

      .state('app.applyleave', {
        url: 'hcm/leavemanagement/applyleave',
        templateUrl: 'app/modules/hcm/leavemanagement/applyleave.html',
        controller: 'ApplyLeaveController'
      })

      .state('app.leavebalancereport', {
        url: 'hcm/leavemanagement/balancereport',
        templateUrl: 'app/modules/hcm/leavemanagement/leavebalancereport.html',
        controller: 'LeaveBalanceReportController'
      })

      .state('app.userreport', {
        url: 'hcm/leavemanagement/userreport',
        templateUrl: 'app/modules/hcm/leavemanagement/userreport.html',
        controller: 'UserReportController'
      })

      .state('app.notifications', {
        url: 'notifications',
        templateUrl: 'app/modules/notifications/notifications.html',
        controller: 'NotificationsController'
      })

      .state('app.scheduleSummary', {
        url: 'schedule/summary',
        templateUrl: 'app/modules/schedules/summary.html',
        controller: 'ScheduleSummaryController'
      })

      .state('app.scheduleCreate', {
        url: 'schedule/create',
        templateUrl: 'app/modules/schedules/createschedule.html',
        controller: 'ScheduleCreateController'
      })

      .state('app.tasksDashboard', {
        url: 'tasks/dashboard',
        templateUrl: 'app/modules/tasks/tasksdashboard.html',
        controller: 'TasksDashboardController'
      })

      .state('app.teams', {
        url: 'teams',
        templateUrl: 'app/modules/teams/summary.html',
        controller: 'TeamSummaryController'
      })

      .state('app.createteam', {
        url: 'create/team',
        templateUrl: 'app/modules/teams/create.html',
        controller: 'TeamCreateController'
      }) 

      .state('app.wfnautomation', {
        url: 'wfn/automation',
        templateUrl: 'app/modules/wfn/wfndashboard.html',
        controller: 'WfnDashboard',
        controllerAs: 'ctrl'
      })

      .state('app.wfnautomationlines', {
        url: 'wfn/automation/lines',
        templateUrl: 'app/modules/wfn/wfnvalidation.html',
        controller: 'WfnValidation',
        controllerAs: 'ctrl'
      })

      .state('app.wfnsourceupload', {
        url: 'wfn/automation/source/upload',
        templateUrl: 'app/modules/wfn/wfnsource.html',
        controller: 'WfnSourceValidation',
        controllerAs: 'ctrl'
      })

      .state('app.issues', {
        url: 'issues/tracker',
        templateUrl: 'app/modules/issues/issues.html',
        controller: 'IssuesController'
      })
      
      .state('app.wfnaddclient', {
        url: 'wfn/automation/add/client',
        templateUrl: 'app/modules/wfn/wfnaddclient.html',
        controller: 'wfnAddClient',
        controllerAs: 'ctrl'
      })          

      .state('app.taskSummary', {
        url: 'tasks/summary',
        templateUrl: 'app/modules/tasks/taskssummary.html',
        controller: 'TasksSummaryContoller'
      })       

;

    $urlRouterProvider.otherwise('/login/');

    $translateProvider.useSanitizeValueStrategy('escaped');
    $translateProvider.useStaticFilesLoader({
      prefix: 'app/locales/locale-',
      suffix: '.json'
    });
    $translateProvider.preferredLanguage('en-US');
  }

})();
