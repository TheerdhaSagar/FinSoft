function AWSHelper() {
    AWS.config.region = 'eu-central-1';

    self = this;
    self.retries = 0;
    self.cognitoUser = null;
    self.poolData = {
        UserPoolId: 'eu-central-1_3mz3nLEKX',
        ClientId: '2ml7vl6v88tumr94noa3k65isd'
    };

    self.getUserPool = function () {
        return new AmazonCognitoIdentity.CognitoUserPool(self.poolData);
    };

    self.getLoggedInUser = function (callback) {
        self.cognitoUser = self.getUserPool().getCurrentUser();
        if (self.cognitoUser !== null) {
            self.cognitoUser.getSession(function (err, session) {
                if (err) {
                    return;
                }

                if (session.isValid()) {
                    AWS.config.credentials = new AWS.CognitoIdentityCredentials({
                        IdentityPoolId: 'eu-central-1:52a2ada2-ee68-49af-aa57-bd91341bd9d2',
                        Logins: {
                            'cognito-idp.eu-central-1.amazonaws.com/eu-central-1_3mz3nLEKX': session.getIdToken().getJwtToken()
                        }
                    });

                    self.cognitoUser.getUserAttributes(function (error, data) {
                        if (error) {
                            return;
                        }

                        callback({status: 'OK', result: data});
                    });
                }
            });
        }
    };

    self.signIn = function (username, password, newPassword, callback) {
        var data = {
            Username: username,
            Password: password
        };

        var authenticationDetails = new AmazonCognitoIdentity.AuthenticationDetails(data);
        var userData = {
            Username: username,
            Pool: self.getUserPool()
        };

        self.cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);
        self.cognitoUser.authenticateUser(authenticationDetails, {
            onSuccess: function (result) {
                AWS.config.credentials = new AWS.CognitoIdentityCredentials({
                    IdentityPoolId: 'eu-central-1:52a2ada2-ee68-49af-aa57-bd91341bd9d2',
                    Logins: {
                        'cognito-idp.eu-central-1.amazonaws.com/eu-central-1_3mz3nLEKX': result.getIdToken().getJwtToken()
                    }
                });

                AWS.config.credentials.refresh(function (error) {
                    if (error) {
                        callback(error);
                    } else {
                        self.cognitoUser.getUserAttributes(function (err, result) {
                            if (err) {
                                return;
                            }

                            callback({status: 'OK', result: result});
                        });
                    }
                });
            },

            onFailure: function (err) {
                callback(err);
            },

            newPasswordRequired: function (userAttributes) {
                if (!newPassword) {
                    callback({status: 'CHANGE_PWD', msg: 'Need to change password'});
                } else {
                    delete userAttributes.email_verified;
                    self.cognitoUser.completeNewPasswordChallenge(newPassword, userAttributes, this);
                }
            }
        });
    };

    self.signOut = function () {
        if (self.cognitoUser) {
            self.cognitoUser.signOut();
        }
    };

    self.adminSignUpUser = function (userDetails, resend) {
        var params = {
            UserPoolId: self.poolData.UserPoolId,
            Username: userDetails.email,
            DesiredDeliveryMediums: ["EMAIL"],
            UserAttributes: [
                {
                    Name: 'name',
                    Value: userDetails.name
                },
                {
                    Name: 'custom:assoc_id',
                    Value: '' + userDetails.assoc_id
                }
            ]
        };

        if (resend) {
            params.MessageAction = 'RESEND';
        }

        AWS.config.credentials = new AWS.CognitoIdentityCredentials({
            IdentityPoolId: 'eu-central-1:52a2ada2-ee68-49af-aa57-bd91341bd9d2',
            RoleArn: 'arn:aws:iam::559217158550:role/Cognito_platformUnauth_Role',
            AccountId: '559217158550'
        });

        AWS.config.credentials.refresh(function (error) {
            if (error) {
                if (error.code === 'NotAuthorizedException' && self.retries < 5) {
                    self.retries += 1;
                    self.adminSignUpUser(userDetails);
                }
                return;
            }
            self.retries = 0;
            var cognitoIdentityServiceProvider = new AWS.CognitoIdentityServiceProvider();
            cognitoIdentityServiceProvider.adminCreateUser(params, function (err, data) {
                if (err) {
                    if (err.code === 'UsernameExistsException') {
                        self.adminSignUpUser(userDetails, true);
                    }
                }
            });
        });
    };

    self.forgotPassword = function (email, callback) {
        var userData = {
            Username: email,
            Pool: self.getUserPool()
        };

        var cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);
        cognitoUser.forgotPassword({
            onSuccess: function (data) {
                callback(data);
            },
            onFailure: function (error) {
                if (error.code === 'InvalidParameterException' && self.retries < 5) {
                    self.retries += 1;
                    self.adminVerifyEmail(email, function (err, data) {
                        if (err) {
                            callback();
                            return;
                        }
                        self.forgotPassword(email, callback);
                    });
                    return;
                }
                self.retries = 0;
                callback(error);
            }
        });
    };

    self.changePassword = function(email, code, password, callback) {
        var userData = {
            Username: email,
            Pool: self.getUserPool()
        };

        var cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);
        cognitoUser.confirmPassword(code, password, {
            onSuccess() {
                callback(null);
            },
            onFailure(err) {
                callback(err);
            }
        })
    };

    self.adminVerifyEmail = function (email, callback) {
        var params = {
            UserAttributes: [{
                Name: 'email_verified',
                Value: 'true'
            }],
            UserPoolId: self.poolData.UserPoolId,
            Username: email
        };

        AWS.config.credentials = new AWS.CognitoIdentityCredentials({
            IdentityPoolId: 'eu-central-1:52a2ada2-ee68-49af-aa57-bd91341bd9d2',
            RoleArn: 'arn:aws:iam::559217158550:role/Cognito_platformUnauth_Role',
            AccountId: '559217158550'
        });

        AWS.config.credentials.refresh(function (error) {
            if (error) {
                if (error.code === 'NotAuthorizedException' && self.retries < 5) {
                    self.retries += 1;
                    self.adminVerifyEmail(email, callback);
                }
                return;
            }
            self.retries = 0;
            var cognitoIdentityServiceProvider = new AWS.CognitoIdentityServiceProvider();
            cognitoIdentityServiceProvider.adminUpdateUserAttributes(params, function (err, data) {
                callback(err, data);
            });
        });
    };
}
