import functools
import os
from scorpionapi.utils import db_util
import ujson
from flask import g, request

from scorpionapi.utils.logdata import logger


class LogUtil:

    def __init__(self):
        pass

    # @staticmethod
    # def send_log(err):
    #     try:
    #         api_key = os.environ['MJ_APIKEY_PUBLIC']
    #         api_secret = os.environ['MJ_APIKEY_PRIVATE']
    #         mailjet = Client(auth=(api_key, api_secret))
    #         strings = db_util.get_strings()
    #         sub = 'Issue: ' + err['source'] + ' in module '
    #         sub += err['module'] + ' for user `' + g.username.lower() + '`'
    #         data = {
    #             'FromEmail': strings['sender_email'],
    #             'FromName': strings['sender_name'],
    #             'Subject': sub,
    #             'MJ-TemplateID': 245644,
    #             'MJ-TemplateLanguage': True,
    #             'MJ-TemplateErrorReporting': 'theerdhasagar.nimmagadda@adp.com',
    #             'Vars': {
    #                 'source': err['source'],
    #                 'module': err['module'],
    #                 'function': err['function'],
    #                 'user': g.username.lower(),
    #                 'error_msg': err['error_msg'],
    #                 'input_data': ujson.dumps(err['input_data'])
    #             },
    #             'To': 'Theerdha Sagar <theerdhasagar.nimmagadda@adp.com>'
    #         }
    #         mailjet.send.create(data=data)
    #     except Exception as e:
    #         logger.dthublog("EXCEPTION while sending log => " + str(e))

    @staticmethod
    def before_request(func):
        @functools.wraps(func)
        def wrapper():
            logger.addinfo('@ [{0}] views - {1}(+)'.format(request.method, request.endpoint))

        return wrapper

    @staticmethod
    def after_request(func):
        @functools.wraps(func)
        def wrapper(response):
            logger.addinfo('@ [{0}] views - {1}(-)'.format(request.method, request.endpoint))
            return response

        return wrapper
