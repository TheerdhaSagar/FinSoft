import cx_Oracle
import os
import yaml

host = 'cdldvddp007or-scan.es.ad.adp.com'
user = 'ETOOLSCONV_DC'
pwd = 'ETOOLSCONV'
db = 'dtl002d_svc1'
port = '1521'
dsn = "(DESCRIPTION= (ADDRESS=(PROTOCOL=tcp)(HOST=" + host + ") \
           (PORT=" + port + ")) (CONNECT_DATA= (SERVICE_NAME=" + db + ")))"

# host = '11.160.12.108'
# user = 'system'
# pwd = 'sagar1990'
# db = 'XEXDB'
# port = '1521'
# dsn = "(DESCRIPTION= (ADDRESS=(PROTOCOL=tcp)(HOST=" + host + ") \
#            (PORT=" + port + ")) (CONNECT_DATA= (SERVICE_NAME=" + db + ")))"

db_pool = None
os.environ['NLS_LANG'] = ".AL32UTF8"


def init_pool():
    return cx_Oracle.SessionPool(user=user, password=pwd, dsn=dsn, min=1,
                                 max=5, increment=1, threaded=True)


def get_connection():
    return db_pool.acquire()


def release_connection(con):
    db_pool.release(con)


def getSqlData():
    fn = os.path.join(os.path.dirname(__file__), 'sql.yaml')
    with open(fn, 'r') as yaml_file:
        sql_file = yaml.safe_load(yaml_file)
    return sql_file


def getusermngSql():
    fn = os.path.join(os.path.dirname(__file__), 'usermngsql.yaml')
    with open(fn, 'r') as yaml_file:
        sql_file = yaml.safe_load(yaml_file)
    return sql_file


def get_strings():
    fn = os.path.join(os.path.dirname(__file__), 'strings.yaml')
    with open(fn, 'r') as yaml_file:
        strings_file = yaml.safe_load(yaml_file)
    return strings_file


def get_sql(filename):
    fn = os.path.join(os.path.dirname(__file__), filename + '.yaml')
    with open(fn, 'r') as yaml_file:
        sql_file = yaml.safe_load(yaml_file)
    return sql_file
