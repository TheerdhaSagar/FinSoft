import hashlib
import base64


def encrypt(source):
    d = hashlib.sha256()
    d.update('UCCDDL4s+GmoVpeEnxxlNg=='.encode('utf-8'))
    d.update(source.encode('utf-8'))
    hashed = bytes(d.digest())
    for i in range(0, 1023):
        d = hashlib.sha256()
        d.update(hashed)
        hashed = bytes(d.digest())
    base64hash = base64.b64encode(hashed)
    return base64hash.decode('utf-8')


def verify(source, target):
    hashed = encrypt(source)
    if hashed == target:
        return True
    return False
