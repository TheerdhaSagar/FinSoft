from enum import Enum


class Status(Enum):
    OK = 0
    ERROR = 1
