from scorpionapi.utils.logdata import logger
import ujson
import cx_Oracle
from flask import Response


class Code_util:

    def __init__(self, **kwargs):
        for name, value in kwargs.items():
            setattr(self, name, value)

    @staticmethod
    def get_fieldtype(fieldnames, field_type):
        logger.addinfo('@ utils - codeutil - get_fieldtype(+)')
        fieldtypes = ""
        my_util = Code_util()
        for index, fn in enumerate(fieldnames):
            type_str = str(field_type[index])
            for ch in ['cx_Oracle', '.', '<', '>', '\'', 'type']:
                if ch in type_str:
                    type_str = type_str.replace(ch, "")
            type_str = type_str.strip()
            setattr(my_util, fn, type_str)
            fieldtypes = my_util
        logger.addinfo('@ utils - codeutil - get_fieldtype(-)')
        return fieldtypes

    @staticmethod
    def iterate_data(cursor):
        field_names = [a[0].lower() for a in cursor.description]
        data = []
        for row in cursor:
            obj = dict()
            for i in range(len(field_names)):
                if type(row[i]) == cx_Oracle.Cursor:
                    obj[field_names[i]] = Code_util.iterate_data(row[i])
                else:
                    obj[field_names[i]] = row[i]
            data.append(obj)
        return data

    @staticmethod
    def pass_error(e):
        final = dict()
        final['msg'] = e.message
        final['status'] = 1
        return Response(ujson.dumps(final), status=200,
                        mimetype='application/json')
