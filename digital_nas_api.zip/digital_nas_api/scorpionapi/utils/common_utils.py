import random
import string
import ujson
import base64
from scorpionapi.utils import db_util
from scorpionapi.sql import sql_util
from scorpionapi.utils.code_util import Code_util
from flask import Response
from scorpionapi.utils.logdata import logger
import hashlib
import openpyxl
import os
from openpyxl.styles import Font


class CommonUtils:
    def __init__(self, **kwargs):
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())
        self.connection = None
        self.cursor = None
        self.is_acquired = False

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()
        self.is_acquired = True

    def release(self):
        if self.cursor:
            self.cursor.close()
            self.is_acquired = False
        db_util.release_connection(self.connection)

    @staticmethod
    def generate_random_string(length):
        return ''.join([random.choice(string.ascii_letters + string.digits[n])
                        for n in range(length)])

    @staticmethod
    def pass_error(module, method, error, is_views=True):
        module_type = 'views' if is_views else 'models'
        message = '@ EXCEPTION {0} - {1} - {2}, {3}'\
            .format(module_type, module, method, str(error))
        logger.dthublog(message)
        return Response(ujson.dumps({
            'status': 1,
            'msg': str(error)
        }), status=200, mimetype='application/json')

    @staticmethod
    def send_response(result):
        return Response(ujson.dumps(result), status=200,
                        mimetype='application/json')

    @staticmethod
    def get_error_message():
        return {
            'status': 'ERROR',
            'msg': 'Unable to process the request!'
        }

    def get_users_with_role(self, role):
        try:
            self.acquire()
            query = self.sql_file['users_with_role_query']
            self.cursor.execute(query, p_role_name=role)
            users = Code_util.iterate_data(self.cursor)
        except Exception as e:
            raise e
        finally:
            if self.is_acquired:
                self.release()
        return users

    def check_params(self, req, param):
        result = {}
        keys = ''
        attributes = self.sql_file[param].split(',')

        for i in range(len(attributes)):
            if attributes[i].strip() not in req:
                keys += attributes[i] + ','

        if keys:
            keys = keys[:-1]
            result['status'] = 'ERROR'
            result['msg'] = 'Missing ' + keys
            result['msg'] += ' parameter(s)'
            return False, result
        return True, result

    @staticmethod
    def decode_credential(encoded):
        decoded = encoded
        for i in range(5):
            decoded = base64.b64decode(decoded)[::-1]

        return decoded

    @staticmethod
    def generate_md5_hash(data):
        md5_hash = hashlib.md5()
        md5_hash.update(data)
        return md5_hash.hexdigest()

    @staticmethod
    def dict_to_excel(data):
        # Create the workbook and sheet for Excel
        filename = '/tmp/' + CommonUtils.generate_random_string(5) + '.xlsx'
        workbook = openpyxl.Workbook()
        sheet = workbook.active
        row = 1
        column = 1
        for key in data[0].keys():
            sheet.cell(row=row, column=column, value=key.upper())
            column += 1
        row = 2
        for i in range(len(data)):
            column = 1
            for element in data[i].values():
                # Put the element in each adjacent column for each element in the tuple
                sheet.cell(row=row, column=column, value=element)
                column += 1
            row += 1
        bold_font = Font(color='FF000000', bold=True, size=12)
        for cell in sheet["1:1"]:
            cell.font = bold_font
        workbook.save(filename=filename)
        excel_base64 = base64.b64encode(open(filename, 'rb').read())
        os.remove(filename)
        return excel_base64
