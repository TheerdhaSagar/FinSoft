from azure_ad_verify_token import verify_jwt, InvalidAuthorizationToken, AzureVerifyTokenError
from jwt import InvalidSignatureError, ExpiredSignature, DecodeError
from requests.exceptions import SSLError
from flask import g
import re


class AzureTokenVerification:

    def __init__(self):
        self.user_name = None
        self.email = None
        self.roles = None
        self.user_description = None
        self.azure_ad_app_id = 'afc5a0ea-c79b-4888-867a-a5f6049b4023'
        self.azure_ad_issuer = 'https://login.microsoftonline.com/4c2c8480-d3f0-485b-b750-807ff693802f/v2.0'
        self.azure_ad_jwks_uri = 'https://login.microsoftonline.com/4c2c8480-d3f0-485b-b750-807ff693802f/discovery/v2.0/keys'

    def verify_azure_token(self, azure_token):
        try:
            verify_token = verify_jwt(
                token=azure_token,
                valid_audiences=[self.azure_ad_app_id],
                issuer=self.azure_ad_issuer,
                jwks_uri=self.azure_ad_jwks_uri,
            )
            network_id = ''
            if 'verified_secondary_email' in verify_token:
                email_list = verify_token['verified_secondary_email']
                for user_id in email_list:
                    if 'ES.AD.ADP.COM' in user_id.upper():
                        network_id = user_id.split('@')[0]
            g.user_description = re.sub(r"(?<=\w)([A-Z])", r" \1", verify_token['email'].split('.')[0])
            g.user_name = network_id
            if 'roles' in verify_token:
                g.roles = verify_token['roles']
            else:
                g.roles = ['generic-user']
            g.email = verify_token['email']
        except InvalidAuthorizationToken:
            return False
        except AzureVerifyTokenError:
            return False
        except InvalidSignatureError:
            return False
        except ExpiredSignature:
            return False
        except DecodeError:
            return False
        except SSLError:
            return False
        except Exception as e:
            raise e
        return True
