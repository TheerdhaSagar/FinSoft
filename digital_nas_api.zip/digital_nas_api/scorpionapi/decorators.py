from flask import request, abort, Response
import functools
from flask import jsonify
from scorpionapi.azure_token_verify import AzureTokenVerification
import ujson


def json(f):
    @functools.wraps(f)
    def wrapped(*args, **kwargs):
        rv = f(*args, **kwargs)
        status_or_headers = None
        headers = None
        if isinstance(rv, tuple):
            rv, status_or_headers, headers = rv + (None,) * (3 - len(rv))
        if isinstance(status_or_headers, (dict, list)):
            headers, status_or_headers = status_or_headers, None
        if not isinstance(rv, dict):
            rv = rv.to_json()
        rv = jsonify(rv)
        if status_or_headers is not None:
            rv.status_code = status_or_headers
        if headers is not None:
            rv.headers.extend(headers)
        return rv
    return wrapped


def azure_login_required(f):
    @functools.wraps(f)
    def secure_connection(*args, **kwargs):
        if request.method == 'OPTIONS':
            resp = {'status': 200}
        else:
            if 'Authorization' not in request.headers:
                resp = {'status': 401,
                        'msg': 'Authorization attribute missing in requests header'}
                abort(Response(ujson.dumps(resp), status=401,
                               mimetype='application/json'))
            token_header = request.headers['Authorization']
            if len(token_header.split()) != 2:
                resp = {'status': 401,
                        'msg': 'Unauthorized! Wrong notation for Authorization header'}
                abort(Response(ujson.dumps(resp), status=401,
                               mimetype='application/json'))
            auth_token = token_header.split(maxsplit=1)[1]
            azure_token_obj = AzureTokenVerification()
            if not azure_token_obj.verify_azure_token(auth_token):
                resp = {'status': 401,
                        'msg': 'Unauthorized! Please authenticate with'
                        ' microsoft Azure AD credentials'}
                abort(Response(ujson.dumps(resp), status=401,
                               mimetype='application/json'))
        return f(*args, **kwargs)
    return secure_connection
