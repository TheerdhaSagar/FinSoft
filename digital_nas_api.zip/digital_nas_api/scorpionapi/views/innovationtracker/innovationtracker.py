from flask import Blueprint, Response, request
from scorpionapi.models.innovationtracker.innovationtracker import Innovations
from scorpionapi.utils.common_utils import CommonUtils
import ujson
from scorpionapi.utils.log_util import LogUtil
from scorpionapi.decorators import azure_login_required

innovations = Blueprint('innovations', __name__, url_prefix='/api/innovations')


@innovations.route('/sync/adpworks/<int:load_flag>/', methods=['GET'])
def sync_innovations_with_adp_works(load_flag=None):
    try:
        innovation_tracker_obj = Innovations()
        result = innovation_tracker_obj.sync_adpworks_innovation_tracker(load_flag)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('innovations', 'sync_innovations_with_adp_works', e)
    return response


@innovations.route('/summary/<int:user_id>/', methods=['GET'])
@innovations.route('/summary/', methods=['GET'])
def get_innovations_summary(user_id=None):
    try:
        reporting_level = request.args.get('reporting_level')
        innovation_tracker_obj = Innovations()
        result = innovation_tracker_obj.get_innovations_summary(user_id, 'Y')
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('innovations', 'get_innovations_summary', e)
    return response


@innovations.route('/significant/ideas/summary/', methods=['GET'])
def get_significant_ideas_summary():
    try:
        innovation_tracker_obj = Innovations()
        result = innovation_tracker_obj.get_significant_ideas_summary()
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('innovations', 'get_significant_ideas_summary', e)
    return response


@innovations.route('/non/adp/users/summary/', methods=['GET'])
def get_non_adp_users_summary():
    try:
        innovation_tracker_obj = Innovations()
        result = innovation_tracker_obj.get_non_adp_users_summary()
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('innovations', 'get_non_adp_users_summary', e)
    return response


@innovations.route('/nas/adp/users/summary/', methods=['GET'])
def get_adp_nas_users_list():
    try:
        innovation_tracker_obj = Innovations()
        result = innovation_tracker_obj.get_adp_nas_users_list()
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('innovations', 'get_adp_nas_users_list', e)
    return response


@innovations.route('/update/idea/owner/', methods=['POST'])
def update_idea_owner():
    data = ujson.loads(request.data)
    try:
        innovation_tracker_obj = Innovations()
        result = innovation_tracker_obj.update_idea_owner(data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('innovations', 'update_idea_owner', e)
    return response


@innovations.route('/update/idea/status/', methods=['POST'])
def update_idea_status():
    data = ujson.loads(request.data)
    try:
        innovation_tracker_obj = Innovations()
        result = innovation_tracker_obj.update_idea_status(data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('innovations', 'update_idea_owner', e)
    return response


@innovations.route('/report/status/changes/', methods=['GET'])
def get_report_status_changes():
    try:
        innovation_tracker_obj = Innovations()
        result = innovation_tracker_obj.get_report_status_changes()
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('innovations', 'get_report_status_changes', e)
    return response


@innovations.route('/report/front/managers/', methods=['GET'])
def get_report_front_line_managers():
    try:
        innovation_tracker_obj = Innovations()
        result = innovation_tracker_obj.get_report_front_line_managers()
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('innovations', 'get_report_front_line_managers', e)
    return response


@innovations.route('/idea/details/', methods=['POST'])
def add_idea_details():
    data = ujson.loads(request.data)
    try:
        innovation_tracker_obj = Innovations()
        result = innovation_tracker_obj.add_idea_details(data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('innovations', 'add_idea_details', e)
    return response


@innovations.route('/add/comments/', methods=['POST'])
def add_idea_comments():
    data = ujson.loads(request.data)
    try:
        innovation_tracker_obj = Innovations()
        result = innovation_tracker_obj.add_idea_comments(data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('innovations', 'add_idea_comments', e)
    return response


@innovations.route('/dashboard/<int:year>/', methods=['GET'])
@innovations.route('/dashboard/', methods=['GET'])
def get_innovations_dashboard(year=None):
    try:
        innovation_tracker_obj = Innovations()
        result = innovation_tracker_obj.get_innovations_dashboard(year)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('innovations', 'get_innovations_dashboard', e)
    return response


@innovations.route('/add/notification/', methods=['POST'])
def add_idea_notifications():
    data = ujson.loads(request.data)
    try:
        innovation_tracker_obj = Innovations()
        result = innovation_tracker_obj.add_idea_notifications(data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('innovations', 'add_idea_notifications', e)
    return response


@innovations.route('/update/notification/', methods=['POST'])
def update_idea_notifications():
    data = ujson.loads(request.data)
    try:
        innovation_tracker_obj = Innovations()
        result = innovation_tracker_obj.update_idea_notifications(data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('innovations', 'update_idea_notifications', e)
    return response


# to delete notifications/reminders
@innovations.route('/notification/delete/<int:notification_id>/', methods=['DELETE'])
def delete_notification(notification_id=None):
    try:
        innovation_tracker_obj = Innovations()
        result = innovation_tracker_obj.delete_notification(notification_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('innovations', 'delete_notification', e)
    return response


@innovations.route('/load/metadata/', methods=['POST'])
def load_meta_data():
    data = ujson.loads(request.data)
    try:
        innovation_tracker_obj = Innovations()
        result = innovation_tracker_obj.load_meta_data(data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('innovations', 'load_meta_data', e)
    return response


@innovations.route('/add/attachment/', methods=['POST'])
def add_idea_attachment():
    data = ujson.loads(request.data)
    try:
        innovation_tracker_obj = Innovations()
        result = innovation_tracker_obj.add_idea_attachment(data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('innovations', 'add_idea_attachment', e)
    return response


@innovations.route('/add/significant/idea/', methods=['POST'])
def add_significant_idea():
    data = ujson.loads(request.data)
    try:
        innovation_tracker_obj = Innovations()
        result = innovation_tracker_obj.add_significant_idea(data)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('innovations', 'add_significant_idea', e)
    return response


# to delete comments or replies of an idea
@innovations.route('/comments/delete/<int:comment_id>/', methods=['DELETE'])
def delete_comment(comment_id=None):
    try:
        innovation_tracker_obj = Innovations()
        result = innovation_tracker_obj.delete_comment(comment_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('innovations', 'delete_comment', e)
    return response


# to delete attachments of an idea
@innovations.route('/attachment/delete/<int:attachment_id>/', methods=['DELETE'])
def delete_attachment(attachment_id=None):
    try:
        innovation_tracker_obj = Innovations()
        result = innovation_tracker_obj.delete_attachment(attachment_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('innovations', 'delete_attachment', e)
    return response


@innovations.route('/attachment/<int:attachment_id>/', methods=['GET'])
def attachment_data(attachment_id=None):
    try:
        innovation_tracker_obj = Innovations()
        attachments = innovation_tracker_obj.attachment_data(attachment_id)
        response = Response(ujson.dumps(attachments),
                            status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('innovations', 'delete_comment', e)
    return response


@innovations.route('/user/details/<int:user_id>/', methods=['GET'])
def get_user_details(user_id=None):
    try:
        innovation_tracker_obj = Innovations()
        attachments = innovation_tracker_obj.get_user_details(user_id)
        response = Response(ujson.dumps(attachments),
                            status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('innovations', 'delete_comment', e)
    return response


@innovations.route('/idea/<int:idea_id>/', methods=['GET'])
def get_innovations_idea_details(idea_id=None):
    try:
        innovation_tracker_obj = Innovations()
        result = innovation_tracker_obj.get_innovations_idea_details(idea_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('innovations', 'get_innovations_idea_details', e)
    return response


@innovations.route('/metadata/', methods=['GET'])
def get_meta_data_innovation_tracker():
    try:
        innovation_tracker_obj = Innovations()
        result = innovation_tracker_obj.get_meta_data_innovation_tracker()
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('innovations', 'get_meta_data_innovation_tracker', e)
    return response


@innovations.route('/ui/stage/<string:stage>/', methods=['GET'])
def get_ui_stage_fields(stage=None):
    try:
        innovation_tracker_obj = Innovations()
        result = innovation_tracker_obj.get_ui_stage_fields(stage)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('innovations', 'get_ui_stage_fields', e)
    return response


@innovations.route('/load/employees/<string:user_id>/', methods=['GET'])
def load_innovations_all_employees(user_id=None):
    try:
        innovation_tracker_obj = Innovations()
        result = innovation_tracker_obj.get_all_direct_reports(user_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('innovations', 'load_innovations_all_employees', e)
    return response


@innovations.route('/load/direct/employees/<string:user_id>/', methods=['GET'])
def load_innovations_direct_employees(user_id=None):
    try:
        innovation_tracker_obj = Innovations()
        result = innovation_tracker_obj.load_innovations_direct_employees(user_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('innovations', 'load_innovations_direct_employees', e)
    return response


@innovations.before_request
@azure_login_required
@LogUtil.before_request
def before_request():
    pass


@innovations.after_request
@LogUtil.after_request
def after_request(response):
    return response
