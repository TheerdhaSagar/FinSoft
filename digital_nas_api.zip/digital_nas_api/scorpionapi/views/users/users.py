from flask import Blueprint, request, Response
import ujson
from scorpionapi.utils.logdata import logger
from scorpionapi.plugins import auth
from scorpionapi.utils.common_utils import CommonUtils
from scorpionapi.models.usermngmnt.users import Users

users = Blueprint('users', __name__, url_prefix='/api/users')


@users.route('/', methods=['GET'])
def get_users():
    logger.addinfo("@ [GET] views - users - get_users(+)")
    try:
        result = Users.get_users()
        resp = Response(ujson.dumps(result), status=200,
                        mimetype='application/json')
    except Exception as error:
        logger.dthublog("""@ 18 EXCEPTION - views - users -
             get_users """ + str(error))
        final = dict()
        final['status'] = 1
        final['msg'] = str(error)
        response = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
        return response
    logger.addinfo("@ [GET] views - users - get_users(-)")
    return resp


@users.route('/<int:team_id>/', methods=['GET'])
def get_team_users(team_id=None):
    logger.addinfo('@ [GET] views - users - get_team_users(+)')
    try:
        # org_id
        result = Users.get_team_users(team_id)
        response = Response(ujson.dumps(result), status=200,
                            mimetype='application/json')
    except Exception as e:
        return CommonUtils.pass_error('users', 'get_team_users', e)
    logger.addinfo('@ [GET] views - users - get_team_users(+)')
    return response


@users.route('/', methods=['POST'])
def post():
    logger.addinfo("@ [POST] views - users - post(+)")
    user_id = Users.user_id()
    jsond = ujson.loads(request.data)
    roles = []
    if jsond:
        send_email = 'Y'
        roles = jsond['roles']
        del jsond['roles']
        new_user = Users()
        for key, value in jsond.items():
            setattr(new_user, key, value)
        setattr(new_user, 'CHANGE_FLAG', 'Y')
    Users.save_roles(roles, user_id)
    try:
        result = Users.insert_header([new_user], user_id, send_email, jsond)
    except Exception as error:
        logger.dthublog("""@ 50 EXCEPTION - views - users -
             post """ + str(error))
        final = {}
        final['status'] = 1
        final['msg'] = str(error)
        response = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
        return response
    logger.addinfo("@ [POST] views - users - post(-)")
    return ujson.dumps(result)


@users.route('/id/<string:user_id>/', methods=['GET'])
def user_data(user_id):
    logger.addinfo("@ [GET] views - users - user_data(+)")
    try:
        result = Users.get_user_data(user_id)
    except Exception as error:
        logger.dthublog("""@ 69 EXCEPTION - views - users -
             user_data """ + str(error))
        final = dict()
        final['status'] = 1
        final['msg'] = str(error)
        response = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
        return response
    logger.addinfo("@ [GET] views - users - user_data(-)")
    return ujson.dumps(result)


@users.route('/details/<int:user_id>/', methods=['GET'])
def user_roles(user_id):
    logger.addinfo("@ [GET] views - users - user_roles(+)")
    try:
        result = Users.get_user_details(user_id)
    except Exception as error:
        logger.dthublog("""@ 88 EXCEPTION - views - users -
             user_roles """ + str(error))
        final = dict()
        final['status'] = 1
        final['msg'] = str(error)
        response = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
        return response
    logger.addinfo("@ [GET] views - users - user_roles(-)")
    return ujson.dumps(result)


@users.route('/validate/<string:value>/', methods=['GET'])
def user_validation(value=None):
    logger.addinfo("@ [GET] views - users - user_validation(+)")
    try:
        result = Users.validation(value)
        resp = Response(ujson.dumps(result), status=200,
                        mimetype='application/json')
    except Exception as error:
        logger.dthublog("""@ 109 EXCEPTION - views - users -
             user_validation """ + str(error))
        final = dict()
        final['status'] = 1
        final['msg'] = str(error)
        resp = Response(ujson.dumps(final),
                        status=200, mimetype='application/json')
        return ujson.dumps(final)
    logger.addinfo("@ [GET] views - users - user_validation(-)")
    return resp


@users.route('/', methods=['PUT'])
def put():
    logger.addinfo("@ [PUT] views - users - put(+)")
    jsond = ujson.loads(request.data)
    roles = []
    if jsond:
        roles = jsond['roles']
        user_id = jsond['user_id']
        del jsond['roles']
        del jsond['user_id']
        user = Users()
        for key, value in jsond.items():
            setattr(user, key, value)
        Users.update_roles(roles, user_id)
        result_users = Users.update_users(jsond, user_id)
    final = dict()
    if result_users == 'success':
        final['status'] = 0
        final['msg'] = 'User updated successfully'
        return ujson.dumps(final)
    else:
        final['status'] = 1
        final['msg'] = 'Failed to update user'
        logger.addinfo("@ [PUT] views - users - put(-)")
        return ujson.dumps(final)


@users.route('/update/<string:user_id>/', methods=['GET'])
def update_last_logon(user_id):
    logger.addinfo("@ [GET] views - users - update_last_logon(+)")
    final = {}
    try:
        result = Users.update_last_logon(user_id)
    except Exception as error:
        logger.dthublog("""@ 372 EXCEPTION - views - users -
             update_last_logon """ + str(error))
        final['status'] = 1
        final['msg'] = str(error)
        response = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
        return response
    if result == "success":
        final['status'] = 0
        final['msg'] = "Data updated successfully"
    else:
        final['status'] = 1
        final['msg'] = "Data updation failed"
    resp = Response(ujson.dumps(final), status=200,
                    mimetype='application/json')

    logger.addinfo("@ [GET] views - users - update_last_logon(-)")
    return resp


@users.route('/notifications/<string:user_id>/', methods=['GET'])
@users.route('/notifications/<string:user_id>/<string:status>/',
             methods=['GET'])
def get_notifications(user_id, status=None):
    logger.addinfo("@ [GET] views - users - get_notifications(+)")
    try:
        result = Users.get_notifications(user_id, status)
    except Exception as error:
        logger.dthublog("""@ 216 EXCEPTION - views - users -
             get_notifications """ + str(error))
        final = dict()
        final['status'] = 1
        final['msg'] = str(error)
        response = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
        return response
    logger.addinfo("@ [GET] views - users - get_notifications(-)")
    return ujson.dumps(result)


@users.route('/workflow/', methods=['POST'])
def workflow_action():
    logger.addinfo("@ [POST] views - users - workflow_action(+)")
    jsond = ujson.loads(request.data)
    final = {}
    try:
        result = Users.workflow_action(jsond)
    except Exception as error:
        logger.dthublog("""@ 237 EXCEPTION - views - users -
             workflow_action """ + str(error))
        final['status'] = 1
        final['msg'] = str(error)
        response = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
        return response
    logger.addinfo("@ [POST] views - users - workflow_action(-)")
    return ujson.dumps(result)


@users.route('/notifications/count/<string:user_id>/', methods=['GET'])
def get_notification_count(user_id):
    logger.addinfo("@ [GET] views - users - get_notification_count(+)")
    try:
        result = Users.get_notification_count(user_id)
    except Exception as error:
        logger.dthublog("""@ 216 EXCEPTION - views - users -
             get_notification_count """ + str(error))
        final = dict()
        final['status'] = 1
        final['msg'] = str(error)
        response = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
        return response
    logger.addinfo("@ [GET] views - users - get_notification_count(-)")
    return ujson.dumps(result)


@users.route('/persons/', methods=['GET'])
@users.route('/persons/<string:id>/', methods=['GET'])
def user_persons(id=None):
    logger.addinfo("@ [GET] views - users - user_persons(+)")
    try:
        result = Users.get_persons(id)
        resp = Response(ujson.dumps(result), status=200,
                        mimetype='application/json')
    except Exception as error:
        logger.dthublog("""@ 157 EXCEPTION - views - users -
             user_persons """ + str(error))
        final = dict()
        final['status'] = 1
        final['msg'] = str(error)
        resp = Response(ujson.dumps(final),
                        status=200, mimetype='application/json')
        return ujson.dumps(final)
    logger.addinfo("@ [GET] views - users - user_persons(-)")
    return resp


@users.before_request
@auth.login_required
def before_request():
    pass
