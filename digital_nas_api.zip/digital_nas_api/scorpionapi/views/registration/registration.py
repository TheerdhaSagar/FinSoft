from flask import Blueprint, request, Response
import ujson
from scorpionapi.utils.logdata import logger
from scorpionapi.models.usermngmnt.registration import Registration

registration = Blueprint('registration', __name__,
                         url_prefix='/registration')


@registration.route('/users/', methods=['POST'])
def post_users():
    logger.addinfo("@ [POST] views - registration - post_users(+)")
    jsond = ujson.loads(request.data)
    email_address = jsond['user_email']
    name = jsond['first_name'] + ' ' + jsond['last_name']
    try:
        registration_obj = Registration()
        result = registration_obj.insert_user(jsond)
    except Exception as error:
        logger.dthublog("""@ 366 EXCEPTION - views - registration -
             post_users """ + str(error))
        final = dict()
        final['status'] = 1
        final['msg'] = str(error)
        response = Response(ujson.dumps(final), status=200,
                            mimetype='application/json')
        return response
    final = dict()
    subject = 'Benefits Scheduler user Registration'
    """message_body = 'Thank you for registering with us, your temporary password will be sent to email'"""
    if result['status'] == "OK":
        email_data = dict()
        email_data['user_name'] = name
        email_data['email'] = email_address
        email_data['subject'] = subject
        final_result = registration_obj.send_mail(email_data)
        if final_result == 'success':
            final['status'] = 0
            final['msg'] = "User created successfully"
            final['user_id'] = result['user_id']
        else:
            final['status'] = 1
            final['msg'] = "User created but failed to sent an email"
            final['user_id'] = result['user_id']
    else:
        final['status'] = 1
        final['msg'] = "Survey creation failed"
    logger.addinfo("@ [POST] views - registration - post_users(-)")
    return ujson.dumps(final)
