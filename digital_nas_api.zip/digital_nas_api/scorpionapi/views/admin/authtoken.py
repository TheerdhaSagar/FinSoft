from flask import request, Blueprint, g, Response

from scorpionapi.models.admin.user import User
from scorpionapi.decorators import json
import ujson

authtoken = Blueprint('api/authtoken', __name__)


def user_details():
    user_data = dict()
    user_data['user_name'] = g.user.user_name
    return user_data


@authtoken.route('/auth/redirect', methods=['GET'])
def request_azure_token():
    auth_code = request.args.get('code')
    result = User.generate_azure_auth_token(auth_code)
    user_data = User()
    user_data.user_description = g.user_description
    user_data.user_name = g.user_name
    user_data.roles = g.roles
    user_data.email = g.email
    user_data.user_id = g.user_id
    response = Response(ujson.dumps(result), status=200,
                        mimetype='application/json')
    return response
