from __future__ import absolute_import

from scorpionapi.sql import sql_util
from scorpionapi.utils import db_util
from scorpionapi.utils.code_util import Code_util
from scorpionapi.utils.logdata import logger
import requests
import json
import ujson
from requests_ntlm2 import HttpNtlmAuth
import base64
import cx_Oracle
import re
from scorpionapi.utils.constants import Status
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import jinja2
import os
import sys


class Innovations:

    def __init__(self):
        self.strings = db_util.get_strings()
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())
        self.connection = None
        self.cursor = None
        self.is_acquired = False

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()
        self.is_acquired = True

    def release(self):
        if self.cursor:
            self.cursor.close()
            self.is_acquired = False
        db_util.release_connection(self.connection)

    def sync_adpworks_innovation_tracker(self, load_flag):
        logger.addinfo('@ models - innovations - sync_adpworks_innovation_tracker(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            self.cursor.execute(self.sql_file['delete_adpworks_trans_data'])
            self.cursor.execute(self.sql_file['delete_adpworks_data_bkp_data'])
            self.cursor.execute(self.sql_file['insert_adpworks_data_bkp_data'])
            self.connection.commit()
            if load_flag == 1:
                for i in range(1, 7):
                    with open('./adp_works/' + str(i) + '.json', encoding="utf8") as f:
                        data = json.load(f)
                        if data['entities']:
                            self.add_adp_works_data(data['entities'])
            else:
                # prod
                token_url = 'https://adp-api.unily.com/connect/token'
                # UAT
                # token_url = 'https://adp-api-stg.unily.com/connect/token'
                # client (application) credentials on ADP works
                # Prod
                client_id = '9b6b6581-aec8-48f6-9413-5a9c8571386f'
                client_secret = 'U2v-I7oOwNoo9w3QIR-v1w'
                # UAT
                # client_id = '8e78545b-c356-46b4-b66c-ef209bab2013'
                # client_secret = 'OzU2yddsyYUvoMQOUltdYw'
                proxies = {
                    'https': self.sql_file['proxy1_settings']
                }
                print(proxies)
                data = {'grant_type': 'client_credentials'}
                access_token_response = requests.post(url=token_url, data=data, verify=False, proxies=proxies,
                                                      auth=(client_id, client_secret))
                print(access_token_response)
                print(access_token_response.text)
                tokens = json.loads(access_token_response.text)
                print(tokens)
                api_call_headers = {'Authorization': 'Bearer ' + tokens['access_token']}
                url_flag = True
                # Unily.Site
                # prod
                api_url = 'https://adp-api.unily.com/api/v2/workfront/site-ideas?siteId=438571&pageSize=20&page='
                #  UAT
                # api_url = 'https://adp-api-stg.unily.com/api/v2/workfront/site-ideas?siteId=438571&pageSize=20&page='
                counter = 1
                while url_flag:
                    adpworks_api_url = api_url + str(counter)
                    api_call_response = requests.get(adpworks_api_url, headers=api_call_headers, verify=False,
                                                     proxies=proxies)
                    data = ujson.loads(api_call_response.text)
                    self.add_adp_works_data(data['entities'])
                    if len(data['entities']) > 0:
                        counter += 1
                    else:
                        url_flag = False
            result['status'] = 0
            result['msg'] = 'Innovation tracker is now in sync with ADP works'
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - innovations -
                sync_adpworks_innovation_tracker """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - innovations - sync_adpworks_innovation_tracker(-)')
        return result

    def get_all_user_ids(self, data):
        logger.addinfo('@ models - innovations - get_all_user_ids(+)')
        try:
            users = []
            for direct_report in data:
                users.append(direct_report['emplid'])
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - innovations -
                get_all_user_ids """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - innovations - get_all_user_ids(-)')
        return users

    def get_report_status_changes(self):
        logger.addinfo('@ models - innovations - get_report_status_changes(+)')
        try:
            result = dict()
            if not self.is_acquired:
                self.acquire()
            self.cursor.execute(self.sql_file['get_adp_works_status_changes'])
            result['status'] = 0
            result['result'] = Code_util.iterate_data(self.cursor)
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - innovations -
                get_report_status_changes """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - innovations - get_report_status_changes(-)')
        return result

    def get_report_front_line_managers(self):
        logger.addinfo('@ models - innovations - get_report_front_line_managers(+)')
        try:
            result = dict()
            if not self.is_acquired:
                self.acquire()
            self.cursor.execute(self.sql_file['not_logged_in'])
            not_logged_in_until_now = Code_util.iterate_data(self.cursor)
            result['not_logged_in_until_now'] = not_logged_in_until_now
            self.cursor.execute(self.sql_file['not_logged_in_a_month'])
            result['not_logged_in_a_month'] = Code_util.iterate_data(self.cursor)
            self.cursor.execute(self.sql_file['front_line_managers_by_status'])
            result['front_line_managers_by_status'] = Code_util.iterate_data(self.cursor)
            self.cursor.execute(self.sql_file['g5_front_line_leaders'])
            result['g5_front_line_leaders'] = Code_util.iterate_data(self.cursor)
            result['status'] = 0
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - innovations -
                get_report_front_line_managers """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - innovations - get_report_front_line_managers(-)')
        return result

    def send_innovation_reminders(self):
        logger.addinfo('@ models - innovations - send_innovation_reminders(+)')
        try:
            if not self.is_acquired:
                self.acquire()
            self.cursor.execute(self.sql_file['send_reminders'])
            result = Code_util.iterate_data(self.cursor)
            for notification in result:
                self.send_mail(notification)
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - innovations -
                send_innovation_reminders """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - innovations - send_innovation_reminders(-)')
        return 'Reminders sent successfully'

    def load_employee_data(self, data):
        logger.addinfo('@ models - innovations - load_employee_data(+)')
        result = dict()
        try:
            row_data = []
            if not self.is_acquired:
                self.acquire()
            # load direct reports
            employee = None
            sql_data = 'insert into innovations_emp_data_trans ('
            for direct_report in data['value']:
                employee = dict()
                employee['emplid'] = direct_report['emplid']
                employee['emp_name'] = direct_report['name']
                employee['job_title'] = direct_report['job_title']
                employee['email'] = direct_report['email_office']
                if direct_report['orig_hire_dt']:
                    employee['hire_dt'] = direct_report['orig_hire_dt'].split('T')[0]
                else:
                    employee['hire_dt'] = ''
                employee['department'] = direct_report['department']
                employee['vertical'] = direct_report['sbu_division']
                employee['user_name'] = direct_report['sam_account_name']
                employee['reports_to_id'] = direct_report['level1_supervisor_id']
                employee['reports_to_email'] = direct_report['level1_supervisor_email']
                my_data = []
                record = None
                for key, value in employee.items():
                    my_data.append(value)
                    record = tuple(my_data)
                row_data.append(record)
            if len(row_data) > 0:
                for key, value in employee.items():
                    sql_data += str(key)
                    sql_data += ','
                sql_data = sql_data[:-1]
                sql_data += ")\
                                        VALUES ("
                sql_args = ""
                for idx, key in enumerate(employee.items()):
                    sql_args += ":" + str(idx) + ","
                sql_args = sql_args[:-1]
                sql_data += sql_args + ")"
                self.cursor.execute("alter session set NLS_DATE_FORMAT='YYYY-MM-DD'")
                self.cursor.executemany(sql_data, row_data)
                self.connection.commit()
            result['status'] = 0
            result['msg'] = 'Users loaded successfully'
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - innovations -
                load_employee_data """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - innovations - load_employee_data(-)')
        return result

    def add_direct_reports_archive(self):
        logger.addinfo('@ models - innovations - add_direct_reports_archive(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            self.cursor.execute(self.sql_file['delete_direct_reports_arch_data'])
            self.cursor.execute(self.sql_file['insert_direct_reports_archive'])
            self.connection.commit()
            self.cursor.execute(self.sql_file['delete_direct_reports_data'])
            result['status'] = 0
            result['msg'] = 'Users loaded successfully'
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - innovations -
                add_direct_reports_archive """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - innovations - add_direct_reports_archive(-)')
        return result

    def load_innovations_direct_employees(self, user_id):
        logger.addinfo('@ models - innovations - load_innovations_direct_employees(+)')
        result = dict()
        try:
            auth = HttpNtlmAuth('es\\nimmagth', 'ILOvemydad90')
            base64_user_id = base64.b64encode(bytes(user_id, 'utf-8')).decode('utf-8')
            direct_reports_url = "http://dit.peoplesearchapi.adpcorp.com/api/v1/people/DirectReports('" + \
                                 base64_user_id + "')"
            response = requests.get(direct_reports_url, auth=auth)
            data = ujson.loads(response.text)
            if not self.is_acquired:
                self.acquire()
            self.cursor.execute(self.sql_file['delete_direct_reports_data'])
            self.connection.commit()
            load_status = self.load_employee_data(data)
            if load_status['status'] == 0:
                if not self.is_acquired:
                    self.acquire()
                self.cursor.execute(self.sql_file['delete_direct_reports_arch_data'])
                self.cursor.execute(self.sql_file['insert_direct_reports_archive'])
                self.cursor.execute(self.sql_file['delete_employee_data_with_trans'])
                self.cursor.execute(self.sql_file['insert_new_employee_data_with_trans'])
                self.cursor.execute(self.sql_file['update_new_employee_data_with_trans_active'])
                self.connection.commit()
                result['status'] = 0
                result['msg'] = 'Users loaded successfully'
            else:
                result['status'] = 1
                result['msg'] = 'Users failed to load'
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - innovations -
                load_innovations_direct_employees """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - innovations - load_innovations_direct_employees(-)')
        return result

    def get_all_direct_reports(self, user_id):
        logger.addinfo('@ models - innovations - get_all_direct_reports(+)')
        result = dict()
        old_limit = sys.getrecursionlimit()
        sys.setrecursionlimit(1500)
        try:
            self.add_direct_reports_archive()
            auth = HttpNtlmAuth('es\\nimmagth', 'ILOvemydad90')
            base64_user_id = base64.b64encode(bytes(user_id, 'utf-8')).decode('utf-8')
            direct_reports_url = "http://dit.peoplesearchapi.adpcorp.com/api/v1/people/DirectReports('" + \
                                 base64_user_id + "')"
            response = requests.get(direct_reports_url, auth=auth)
            data = ujson.loads(response.text)
            load_status = self.load_employee_data(data)
            users = self.get_all_user_ids(data['value'])
            if len(users) > 0 and load_status['status'] == 0:
                # Next levels of reporting
                self.flatten_users_list(users, auth)
            # load transaction data in to innovations_employee_data
            if not self.is_acquired:
                self.acquire()
            self.cursor.execute(self.sql_file['delete_employee_data_with_trans'])
            self.cursor.execute(self.sql_file['update_new_employee_data_with_trans_inactive'])
            self.cursor.execute(self.sql_file['insert_new_employee_data_with_trans'])
            self.cursor.execute(self.sql_file['update_new_employee_data_with_trans_active'])
            self.connection.commit()
            result['status'] = 0
            result['msg'] = 'Users loaded successfully'
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - innovations -
                get_all_direct_reports """ + str(e))
            raise e
        finally:
            sys.setrecursionlimit(old_limit)
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - innovations - get_all_direct_reports(-)')
        return result

    def flatten_users_list(self, users, auth):
        logger.addinfo('@ models - innovations - get_all_direct_reports(+)')
        result = dict()
        try:
            if len(users) == 0:
                return users
            users.sort(key=len)
            temp_users = []
            temp_users = users
            for user in users:
                if not isinstance(user, list):
                    base64_user_id = base64.b64encode(bytes(user, 'utf-8')).decode('utf-8')
                    direct_reports_url = "http://dit.peoplesearchapi.adpcorp.com/api/v1/people/DirectReports('" + \
                                         base64_user_id + "')"
                    response = requests.get(direct_reports_url, auth=auth)
                    data = ujson.loads(response.text)
                    temp_users.remove(user)
                    if len(data['value']) > 0:
                        users = temp_users
                        self.load_employee_data(data)
                        new_reports = self.get_all_user_ids(data['value'])
                        if len(new_reports) > 0:
                            users.append(new_reports)
                            return self.flatten_users_list(users, auth)
                else:
                    return self.flatten_users_list(Innovations.flatten(users), auth)
            result['status'] = 0
            result['msg'] = 'Users loaded successfully'
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - innovations -
                get_all_direct_reports """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - innovations - get_all_direct_reports(-)')
        return result

    @staticmethod
    def flatten(list_of_lists):
        if len(list_of_lists) == 0:
            return list_of_lists
        if isinstance(list_of_lists[0], list):
            return Innovations.flatten(list_of_lists[0]) + Innovations.flatten(list_of_lists[1:])
        return list_of_lists[:1] + Innovations.flatten(list_of_lists[1:])

    def get_innovations_summary(self, user_id, reporting_level='Y'):
        logger.addinfo('@ models - innovations - get_innovations_summary(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            if user_id:
                if reporting_level == 'Y':
                    self.cursor.execute(self.sql_file['innovation_summary_query_all_reports'], p_emplid=user_id)
                else:
                    self.cursor.execute(self.sql_file['innovation_summary_query_direct_reports'], p_emplid=user_id)
            else:
                self.cursor.execute(self.sql_file['innovation_summary_query_all'])
            report_record_count = Code_util.iterate_data(self.cursor)
            result['status'] = 0
            result['result'] = report_record_count
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - innovations -
                get_innovations_summary """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - innovations - get_innovations_summary(-)')
        return result

    def get_significant_ideas_summary(self):
        logger.addinfo('@ models - innovations - get_significant_ideas_summary(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            self.cursor.execute(self.sql_file['get_significant_ideas_summary'])
            significant_ideas_summary = Code_util.iterate_data(self.cursor)
            result['status'] = 0
            result['result'] = significant_ideas_summary
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - innovations -
                get_significant_ideas_summary """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - innovations - get_significant_ideas_summary(-)')
        return result

    def get_non_adp_users_summary(self):
        logger.addinfo('@ models - innovations - get_non_adp_users_summary(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            self.cursor.execute(self.sql_file['innovation_summary_non_adp_users'])
            report_record_count = Code_util.iterate_data(self.cursor)
            result['status'] = 0
            result['result'] = report_record_count
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - innovations -
                get_non_adp_users_summary """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - innovations - get_non_adp_users_summary(-)')
        return result

    def get_adp_nas_users_list(self):
        logger.addinfo('@ models - innovations - get_adp_nas_users_list(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            self.cursor.execute(self.sql_file['get_adp_nas_users_list'])
            report_record_count = Code_util.iterate_data(self.cursor)
            result['status'] = 0
            result['result'] = report_record_count
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - innovations -
                get_adp_nas_users_list """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - innovations - get_adp_nas_users_list(-)')
        return result

    def get_innovations_dashboard(self, year):
        logger.addinfo('@ models - innovations - get_innovations_dashboard(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            if year:
                self.cursor.execute(self.sql_file['innovations_idea_by_g5s_by_year'], p_year=year)
                innovations_idea_by_g5s = Code_util.iterate_data(self.cursor)
                result['innovations_idea_by_g5s'] = innovations_idea_by_g5s
                self.cursor.execute(self.sql_file['innovations_idea_by_status_year'], p_year=year)
                innovations_idea_by_status = Code_util.iterate_data(self.cursor)
                result['innovations_idea_by_status'] = innovations_idea_by_status
            else:
                self.cursor.execute(self.sql_file['innovations_idea_by_g5s'])
                innovations_idea_by_g5s = Code_util.iterate_data(self.cursor)
                result['innovations_idea_by_g5s'] = innovations_idea_by_g5s
                self.cursor.execute(self.sql_file['innovations_idea_by_status'])
                innovations_idea_by_status = Code_util.iterate_data(self.cursor)
                result['innovations_idea_by_status'] = innovations_idea_by_status
            self.cursor.execute(self.sql_file['innovations_idea_by_product'])
            idea_by_product = Code_util.iterate_data(self.cursor)
            result['idea_by_product'] = idea_by_product
            self.cursor.execute(self.sql_file['innovations_idea_by_sig'])
            innovations_idea_by_sig = Code_util.iterate_data(self.cursor)
            result['innovations_idea_by_sig'] = innovations_idea_by_sig
            self.cursor.execute(self.sql_file['innovations_idea_by_category'])
            innovations_idea_by_category = Code_util.iterate_data(self.cursor)
            result['innovations_idea_by_category'] = innovations_idea_by_category
            result['status'] = 0
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - innovations -
                get_innovations_dashboard """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - innovations - get_innovations_dashboard(-)')
        return result

    def get_user_details(self, user_id):
        logger.addinfo('@ models - innovations - get_user_details(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            self.cursor.execute(self.sql_file['get_user_details'], p_user_id=user_id)
            report_record_count = Code_util.iterate_data(self.cursor)
            result['status'] = 0
            result['result'] = report_record_count
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - innovations -
                get_user_details """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - innovations - get_user_details(-)')
        return result

    def attachment_data(self, attachment_id):
        logger.addinfo("@ models - innovations - attachment_data(+)")
        try:
            self.acquire()
            query = self.sql_file['innovations_attachment_data_query']
            self.cursor.execute(query,
                                p_attachment_id=attachment_id)
            field_data = []
            field_names = [a[0].lower() for a in self.cursor.description]
            for row in self.cursor:
                data = {}
                for index, field in enumerate(field_names):
                    if field == 'file_content':
                        encoded_string = ''
                        if row[index]:
                            encoded_string = row[index].read()
                        data[field] = encoded_string
                    else:
                        data[field] = row[index]
                field_data.append(data)
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - innovations -
                attachment_data """ + str(e))
            raise e
        finally:
            self.release()
        logger.addinfo("@ models - innovations - attachment_data(-)")
        return field_data

    def delete_comment(self, comment_id):
        """ This method is used for deletion of comments or replies in an idea.

            Note: If a comment is deleted, all the replies related to it will be deleted too
        """
        logger.addinfo('@ models - innovations - delete_comment(-)')
        result = {}
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                                begin
                                    NAS_INNOVATION_TRACKER_PKG.delete_comments(
                                :p_comment_id,
                                :x_status_code
                                    );
                                end; """, p_comment_id=comment_id,
                                x_status_code=status_code)
            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = Status.OK.value
                result['msg'] = 'Comment/Reply deleted successfully'
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to delete Comment/Reply'
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - innovations -
                delete_comment """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - innovations - delete_comment(-)')
        return result

    def delete_attachment(self, attachment_id):
        logger.addinfo('@ models - innovations - delete_attachment(-)')
        result = {}
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                                begin
                                    NAS_INNOVATION_TRACKER_PKG.delete_attachment(
                                :p_attachment_id,
                                :x_status_code
                                    );
                                end; """, p_attachment_id=attachment_id,
                                x_status_code=status_code)
            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = Status.OK.value
                result['msg'] = 'Attachment deleted successfully'
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to delete Attachment'
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - innovations -
                delete_attachment """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - innovations - delete_attachment(-)')
        return result

    def get_innovations_idea_details(self, idea_id):
        logger.addinfo('@ models - innovations - get_innovations_idea_details(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            self.cursor.execute(self.sql_file['innovation_idea_query'], p_idea_id=idea_id)
            summary_details = Code_util.iterate_data(self.cursor)
            result['status'] = 0
            result['result'] = summary_details
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - innovations -
                get_innovations_idea_details """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - innovations - get_innovations_idea_details(-)')
        return result

    def load_meta_data(self, data):
        logger.addinfo('@ models - innovations - load_meta_data(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            stage_lines = []
            for meta_data_value in data['result']:
                stage_line_list = []
                stage_line_list.append(meta_data_value['stage_id'])
                stage_line_list.append(meta_data_value['stage_name'])
                stage_line_list.append(meta_data_value['created_id'])
                stage_lines.append(stage_line_list)
            self.cursor.executemany(self.sql_file['insert_statement_meta_data_stage'], stage_lines)
            label_lines = []
            for meta_data_value in data['result']:
                label_line_list = []
                label_line_list.append(meta_data_value['stage_id'])
                label_line_list.append(meta_data_value['label_id'])
                label_line_list.append(meta_data_value['label_name'])
                label_line_list.append(meta_data_value['input_type'])
                label_line_list.append(meta_data_value['position_nbr'])
                label_line_list.append(meta_data_value['created_id'])
                label_lines.append(label_line_list)
            self.cursor.executemany(self.sql_file['insert_statement_meta_data_labels'], label_lines)
            values_lines = []
            for meta_data_value in data['result']:
                for label_values in meta_data_value['label_values']:
                    value_line_list = []
                    value_line_list.append(meta_data_value['stage_id'])
                    value_line_list.append(meta_data_value['label_id'])
                    value_line_list.append(label_values['value'])
                    value_line_list.append(label_values['label'])
                    value_line_list.append(meta_data_value['created_id'])
                    values_lines.append(value_line_list)
            self.cursor.executemany(self.sql_file['insert_statement_meta_data_values'], values_lines)
            self.cursor.execute(self.sql_file['delete_duplicate_stage_values'])
            self.connection.commit()
            result['status'] = Status.OK.value
            result['msg'] = 'Meta data added successfully'
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - innovations -
                load_meta_data """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - innovations - load_meta_data(-)')
        return result

    def update_idea_owner(self, data):
        logger.addinfo('@ models - innovations - update_idea_owner(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                                 begin
                                     NAS_INNOVATION_TRACKER_PKG.update_idea_owner(
                                     :p_idea_id,
                                     :p_user_id,
                                     :p_user_email,
                                     :p_updated_by,
                                     :x_status_code
                                     );
                                 end; """, p_idea_id=data['idea_id'],
                                p_user_id=data['user_id'],
                                p_user_email=data['user_email'],
                                p_updated_by=data['updated_by'],
                                x_status_code=status_code)
            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = Status.OK.value
                result['msg'] = 'Idea owner updated successfully'
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to update idea owner'
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - innovations -
                update_idea_owner """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - innovations - update_idea_owner(-)')
        return result

    def update_idea_status(self, data):
        logger.addinfo('@ models - innovations - update_idea_status(+)')
        result = dict()
        try:
            notification = {}
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                                 begin
                                     NAS_INNOVATION_TRACKER_PKG.update_idea_status(
                                     :p_idea_id,
                                     :p_status,
                                     :p_updated_by,
                                     :x_status_code
                                     );
                                 end; """, p_idea_id=data['idea_id'],
                                p_status=data['status'],
                                p_updated_by=data['updated_by'],
                                x_status_code=status_code)
            status = status_code.getvalue()
            # notification['notification_descr'] = '' + 'Idea status has been updated to ' + data['status']
            # notification['emp_name'] =
            # notification['notification_title'] =
            # notification['email'] =
            if status == 'SUCCESS':
                result['status'] = Status.OK.value
                result['msg'] = 'Idea status updated successfully'
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to update idea status'
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - innovations -
                update_idea_status """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - innovations - update_idea_status(-)')
        return result

    def add_idea_comments(self, data):
        logger.addinfo('@ models - innovations - add_idea_comments(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            comment_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                                begin
                                    NAS_INNOVATION_TRACKER_PKG.add_idea_comments(
                                    :p_idea_id,
                                    :x_comment_id,
                                    :p_comment_descr,
                                    :p_parent_comment_id,
                                    :p_user_id,
                                    :x_status_code
                                    );
                                end; """, p_idea_id=data['idea_id'],
                                x_comment_id=comment_id,
                                p_comment_descr=data['comment_data'],
                                p_parent_comment_id=data['parent_id'],
                                p_user_id=data['created_id'],
                                x_status_code=status_code)
            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = Status.OK.value
                result['msg'] = 'Comment added successfully'
                result['comment_id'] = int(comment_id.getvalue())
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to add comments'
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - innovations -
                add_idea_comments """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - innovations - add_idea_comments(-)')
        return result

    def add_idea_notifications(self, data):
        logger.addinfo('@ models - innovations - add_idea_notifications(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            notification_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                                begin
                                    NAS_INNOVATION_TRACKER_PKG.add_idea_notifications(
                                    :p_idea_id,
                                    :x_notification_id,
                                    :p_notification_title,
                                    :p_notification_date,
                                    :p_notification_descr,
                                    :p_user_id,
                                    :x_status_code
                                    );
                                end; """, p_idea_id=data['idea_id'],
                                x_notification_id=notification_id,
                                p_notification_title=data['notification_title'],
                                p_notification_date=data['notification_date'],
                                p_notification_descr=data['notification_descr'],
                                p_user_id=data['created_id'],
                                x_status_code=status_code)
            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = Status.OK.value
                result['msg'] = 'Reminder added successfully'
                result['notification_id'] = int(notification_id.getvalue())
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to add reminder'
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - innovations -
                add_idea_notifications """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - innovations - add_idea_notifications(-)')
        return result

    def update_idea_notifications(self, data):
        logger.addinfo('@ models - innovations - update_idea_notifications(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                                 begin
                                     NAS_INNOVATION_TRACKER_PKG.update_idea_notifications(
                                     :p_idea_id,
                                     :p_notification_id,
                                     :p_notification_title,
                                     :p_notification_descr,
                                     :p_notification_date,
                                     :p_user_id,
                                     :x_status_code
                                     );
                                 end; """, p_idea_id=data['idea_id'],
                                p_notification_id=data['notification_id'],
                                p_notification_title=data['notification_title'],
                                p_notification_descr=data['notification_descr'],
                                p_notification_date=data['notification_date'],
                                p_user_id=data['updated_by'],
                                x_status_code=status_code)
            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = Status.OK.value
                result['msg'] = 'Reminder updated successfully'
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to update reminder'
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - innovations -
                 update_idea_notifications """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - innovations - update_idea_notifications(-)')
        return result

    def delete_notification(self, notification_id):
        logger.addinfo('@ models - innovations - delete_notification(-)')
        result = {}
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                                begin
                                    NAS_INNOVATION_TRACKER_PKG.delete_notifications(
                                :p_notification_id,
                                :x_status_code
                                    );
                                end; """, p_notification_id=notification_id,
                                x_status_code=status_code)
            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = Status.OK.value
                result['msg'] = 'Reminder deleted successfully'
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to delete Reminder'
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - innovations -
                delete_notification """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - innovations - delete_notification(-)')
        return result

    def add_idea_attachment(self, data):
        logger.addinfo('@ models - innovations - add_idea_attachment(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            attachment_id = self.cursor.var(cx_Oracle.NUMBER)
            self.cursor.setinputsizes(p_file_content=cx_Oracle.BLOB)
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                                begin
                                    NAS_INNOVATION_TRACKER_PKG.add_attachment(
                                    :p_idea_id,
                                    :x_attachment_id,
                                    :p_file_name,
                                    :p_file_type,
                                    :p_file_content,
                                    :p_user_id,
                                    :x_status_code
                                    );
                                end; """, p_idea_id=data['idea_id'],
                                x_attachment_id=attachment_id,
                                p_file_name=data['file_name'],
                                p_file_type=data['file_type'],
                                p_file_content=data['file_content'],
                                p_user_id=data['created_id'],
                                x_status_code=status_code)
            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = Status.OK.value
                result['msg'] = 'Attachment added successfully'
                result['attachment_id'] = int(attachment_id.getvalue())
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to add Attachment'
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - innovations -
                add_idea_attachment """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - innovations - add_idea_attachment(-)')
        return result

    def add_significant_idea(self, data):
        logger.addinfo('@ models - innovations - add_significant_idea(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
                                begin
                                    NAS_INNOVATION_TRACKER_PKG.add_significant_idea(
                                    :p_idea_id,
                                    :p_significant_flag,
                                    :p_user_id,
                                    :x_status_code
                                    );
                                end; """, p_idea_id=data['idea_id'],
                                p_significant_flag=data['significant_flag'],
                                p_user_id=data['created_id'],
                                x_status_code=status_code)
            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = Status.OK.value
                if data['significant_flag'] == 'Y':
                    result['msg'] = 'Idea marked as Significant'
                elif data['significant_flag'] == 'N':
                    result['msg'] = 'Removed from Significant Ideas'
            else:
                result['status'] = Status.ERROR.value
                result['msg'] = 'Failed to modify Idea type'
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - innovations -
                add_significant_idea """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - innovations - add_significant_idea(-)')
        return result

    def add_idea_details(self, data):
        logger.addinfo('@ models - innovations - add_idea_details(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            for label_details in data['idea_details']:
                for i in range(len(label_details['label_values'])):
                    self.cursor.execute(self.sql_file['delete_checkbox_details'], p_label_id=label_details['label_id'],
                                        p_idea_id=data['idea_id'])
            self.connection.commit()
            status_code = self.cursor.var(cx_Oracle.STRING)
            for label_details in data['idea_details']:
                if 'text_value1' not in label_details:
                    text_value1 = ''
                else:
                    text_value1 = label_details['text_value1']
                if 'text_value2' not in label_details:
                    text_value2 = ''
                else:
                    text_value2 = label_details['text_value2']
                if 'text_value3' not in label_details:
                    text_value3 = ''
                else:
                    text_value3 = label_details['text_value3']
                if (len(label_details['label_values']) == 0) and (text_value1 or text_value2 or text_value1):
                    self.cursor.execute("""
                                          begin
                                                NAS_INNOVATION_TRACKER_PKG.add_text_details(
                                                :p_idea_id,
                                                :p_stage_id,
                                                :p_label_id,
                                                :p_tbox_value1,
                                                :p_tbox_value2,
                                                :p_tbox_value3,
                                                :p_created_id,
                                                :p_idea_status,
                                                :x_status_code
                                                );
                                            end; """, p_idea_id=data['idea_id'],
                                        p_stage_id=data['stage_id'],
                                        p_label_id=label_details['label_id'],
                                        p_tbox_value1=text_value1,
                                        p_tbox_value2=text_value2,
                                        p_tbox_value3=text_value3,
                                        p_created_id=data['updated_by'],
                                        p_idea_status=data['idea_status'],
                                        x_status_code=status_code)
                    status = status_code.getvalue()
                    if status == 'SUCCESS':
                        result['status'] = 0
                        result['msg'] = 'Updated idea details'
                    else:
                        result['status'] = 1
                        result['msg'] = status
                for i in range(len(label_details['label_values'])):
                    value_id = label_details['label_values'][i]
                    self.cursor.execute("""
                                          begin
                                                NAS_INNOVATION_TRACKER_PKG.manage_idea_details(
                                                :p_idea_id,
                                                :p_stage_id,
                                                :p_label_id,
                                                :p_value_id,
                                                :p_tbox_value1,
                                                :p_tbox_value2,
                                                :p_tbox_value3,
                                                :p_created_id,
                                                :p_idea_status,
                                                :x_status_code
                                                );
                                            end; """, p_idea_id=data['idea_id'],
                                        p_stage_id=data['stage_id'],
                                        p_label_id=label_details['label_id'],
                                        p_value_id=value_id,
                                        p_tbox_value1=text_value1,
                                        p_tbox_value2=text_value2,
                                        p_tbox_value3=text_value3,
                                        p_created_id=data['updated_by'],
                                        p_idea_status=data['idea_status'],
                                        x_status_code=status_code)
                    status = status_code.getvalue()
                    if status == 'SUCCESS':
                        result['status'] = 0
                        result['msg'] = 'Updated idea details'
                    else:
                        result['status'] = 1
                        result['msg'] = status
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - innovations -
                add_idea_details """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - innovations - add_idea_details(-)')
        return result

    def get_meta_data_innovation_tracker(self):
        logger.addinfo('@ models - innovations - get_meta_data_innovation_tracker(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            self.cursor.execute(self.sql_file['innovation_metadata_query'])
            report_record_count = Code_util.iterate_data(self.cursor)
            result['status'] = 0
            result['result'] = report_record_count
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - innovations -
                get_meta_data_innovation_tracker """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - innovations - get_meta_data_innovation_tracker(-)')
        return result

    def get_ui_stage_fields(self, stage):
        logger.addinfo('@ models - innovations - get_ui_stage_fields(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            self.cursor.execute(self.sql_file['innovation_ui_elements_by_stage'], p_stage=stage)
            report_record_count = Code_util.iterate_data(self.cursor)
            result['status'] = 0
            result['result'] = report_record_count
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - innovations -
                get_ui_stage_fields """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - innovations - get_ui_stage_fields(-)')
        return result

    def update_adp_works_content(self, row_data):
        logger.addinfo('@ models - innovations - update_adp_works_content(+)')
        result = dict()
        try:
            if not self.is_acquired:
                self.acquire()
            for row in row_data:
                if row['content']:
                    content = re.sub(re.compile('<.*?>'), '', row['content'])
                    content = content.replace('\xa0', '').replace('\n', '')
                    encoded_content = content.encode('ascii', 'ignore').decode()
                    translation = {39: None}
                    removing_single_quotes = encoded_content.translate(translation).replace('&#160;', '')\
                        .replace('&nbsp;', '')
                    for i in range(len(removing_single_quotes)//3000 + 1):
                        key = 'content' + str(i+1)
                        if i == 0:
                            start_index = 0
                        else:
                            start_index = (i * 3000) + 1
                        end_index = (i+1) * 3000
                        sql_data = 'update innovation_trckr_adpwrk_trans set ' + key + '=' + "'" + \
                                   str(removing_single_quotes[start_index:end_index]) + "'" + ' where idea_id = ' \
                                   + str(row['idea_id'])
                        self.cursor.execute(sql_data)
            self.cursor.execute(self.sql_file['insert_trans_adpworks_archieve'])
            self.cursor.execute(self.sql_file['update_trans_adpworks_duplicate'])
            self.cursor.execute(self.sql_file['update_trans_adpworks_archieve'])
            self.cursor.execute(self.sql_file['update_trans_adpworks_implemented'])
            self.cursor.execute(self.sql_file['update_trans_adpworks_active'])
            self.cursor.execute(self.sql_file['update_trans_adpworks_active1'])
            self.connection.commit()
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - innovations -
                update_adp_works_content """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.release()
        logger.addinfo('@ models - innovations - update_adp_works_content(-)')
        return result

    def add_adp_works_data(self, data):
        logger.addinfo('@ models - innovations - add_adp_works_data(+)')
        result = {}
        try:
            if not self.is_acquired:
                self.acquire()
            # add ADP works transactional data to innovation tracker tables
            sql_data = 'insert into innovation_trckr_adpwrk_trans ('
            row_data = []
            row_update = []
            row = None
            for idea in data:
                row = dict()
                row['idea_id'] = idea['id']
                row['title'] = idea['title']
                row['url'] = idea['url']
                row['siteId'] = idea['siteId']
                if idea['tags']:
                    row['tags'] = idea['tags']
                else:
                    row['tags'] = ''
                if idea['categories']:
                    row['categories'] = idea['categories']
                else:
                    row['categories'] = ''
                if len(idea['topics']) > 0:
                    row['topics'] = ', '.join(map(str, idea['topics']))
                else:
                    row['topics'] = ''
                row['stage'] = idea['stage']
                row['voteCount'] = idea['voteCount']
                row['social_comm_cnt'] = idea['socialCommentCount']
                row['score'] = idea['score']
                row['views'] = idea['views']
                if idea['datePublished']:
                    row['datePublished'] = idea['datePublished'].split('T')[0]
                else:
                    row['datePublished'] = ''
                if idea['lastActivityDate']:
                    row['lastActivityDate'] = idea['lastActivityDate'].split('T')[0]
                else:
                    row['lastActivityDate'] = ''
                if idea['authorUpn']:
                    row['submitter_id'] = idea['authorUpn'].split('@')[0]
                else:
                    row['submitter_id'] = ''
                row['submitter_email'] = idea['authorEmailAddress']
                row['submitter_name'] = idea['authorDisplayName']
                row['content'] = idea['content']
                my_data = []
                row_update.append({
                    'content': idea['content'],
                    'idea_id': idea['id']
                })
                record = None
                for key, value in row.items():
                    my_data.append(value)
                    record = tuple(my_data)
                row_data.append(record)
            if len(row_data) > 0:
                for key, value in row.items():
                    sql_data += str(key)
                    sql_data += ','
                sql_data = sql_data[:-1]
                sql_data += ")\
                                        VALUES ("
                sql_args = ""
                for idx, key in enumerate(row.items()):
                    sql_args += ":" + str(idx) + ","
                sql_args = sql_args[:-1]
                sql_data += sql_args + ")"
                self.cursor.execute("alter session set NLS_DATE_FORMAT='YYYY-MM-DD'")
                self.cursor.executemany(sql_data, row_data)
                self.connection.commit()
                self.update_adp_works_content(row_update)
            result['status'] = 0
            result['msg'] = 'ADPWorks and Innovation tracker are now in Sync'
            result['report_id'] = data
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - innovations -
                add_adp_works_data """ + str(e))
            raise e
        finally:
            if self.is_acquired:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - innovations - add_adp_works_data(-)')
        return result

    def send_mail(self, notification):
        try:
            req = {}
            msg = notification['notification_descr']
            path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
            path += '/static/email_templates'
            template = jinja2.Environment(
                loader=jinja2.FileSystemLoader(path)
            ).get_template('notification.html').render(
                msg=msg,
                user=notification['emp_name'],
            )
            req['email'] = notification['email']
            req['subject'] = 'NAS I&C - ' + notification['notification_title']
            req['message_template'] = template
            email_status = Innovations.send_smtp_mail(req)
        except Exception as error:
            raise error
        finally:
            if self.is_acquired:
                self.release()
        return email_status

    @staticmethod
    def send_smtp_mail(req_data):
        try:
            strings = db_util.get_strings()
            # req_data['activation_key'] = self.password
            # req_data['user'] = self.user_value
            """message_template = Registration.read_template('email_template_registration.txt')"""
            msg = MIMEMultipart()       # create a message
            # add in the actual person name to the message template
            server = smtplib.SMTP()
            server.connect(strings['mail_server'], 25)
            # message = message_template.substitute(PERSON_NAME=user_name, MESSAGE_BODY=message_body)
            # Prints out the message body for our sake
            # setup the parameters of the message
            msg['From'] = strings['sender_email']
            msg['To'] = req_data['email']
            msg['Subject'] = req_data['subject']
            # add in the message body
            msg.attach(MIMEText(req_data['message_template'], 'html'))
            # send the message via the server set up earlier.
            server.send_message(msg)
            del msg
            server.quit()
            status = 'success'
        except Exception as e:
            status = 'Failure - Failed to send email'
            raise e
        return status
