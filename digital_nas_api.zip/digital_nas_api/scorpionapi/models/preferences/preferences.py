from __future__ import absolute_import
import smtplib
from scorpionapi.utils import db_util
from scorpionapi.utils.logdata import logger
from scorpionapi.utils import auth_util
from scorpionapi.models.login.login import Login
from scorpionapi.models.usermngmnt.users import Users
import random
import string


class Preferences:

    def __init__(self, **kwargs):
        for name, value in kwargs.items():
            setattr(self, name, value)

    @staticmethod
    def reset_password(user_name, password, new_password):
        logger.addinfo("@ models - preference - reset_password(+)")
        gmail_user = 'support@qualitypeopleit.com'
        gmail_pwd = 'Welcome9'
        result = ""
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sqlFile = db_util.getSqlData()
            update = sqlFile['update_password']
            cursor.execute(update, p_user_name=user_name.upper(),
                           p_new_password=password)
            connection.commit()
            password_query = sqlFile['password_query']
            cursor.execute(password_query, p_user_name=user_name.upper())
            data = cursor.fetchone()
            if data[0] == password:
                email = sqlFile['email-query']
                cursor.execute(email, p_user_name=user_name.upper())
                to = cursor.fetchone()
                smtpserver = smtplib.SMTP("smtp.gmail.com", 587)
                smtpserver.ehlo()
                smtpserver.starttls()
                smtpserver.ehlo
                smtpserver.login(gmail_user, gmail_pwd)
                subject = 'Reset Password'
                msg = 'Subject: %s\n\n' % (subject)
                message = msg + """
                New Password: """ + new_password + """
                """
                smtpserver.sendmail(gmail_user, to, message)
                smtpserver.quit()
                result = 'success'
            else:
                result = "fails"
        except Exception as error:
            logger.dthublog("""@ 57 EXCEPTION - models - preference -
                 reset_password """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo("@ models - preference - reset_password(-)")
        return result

    @staticmethod
    # used in cutomer to get ordertypes of organization

    def get_dateformat():
        logger.addinfo('@ models - preference - get_dateformat(+)')
        con = None
        cur = None
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['dateformat_qry']
            cur.execute(query)
        except Exception as error:
            logger.dthublog("""@ 80 EXCEPTION - models - preference -
                 get_dateformat """ + str(error))
            raise error
        else:
            datefrmt_list = []
            field_names = [a[0].lower() for a in cur.description]
            for row in cur:
                preferencedata = Preferences()
                for index, fn in enumerate(field_names):
                    setattr(preferencedata, fn, row[index])
                datefrmt_list.append(preferencedata)
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - preference - get_dateformat(-)')
        return datefrmt_list

    @staticmethod
    def save(preference, usr_id, old_passwd, new_passwd):
        logger.addinfo('@ models - preference - save(+)')
        con = None
        cur = None
        result = ""
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            if old_passwd and new_passwd:
                query = sql_file['password_query_id']
                cur.execute(query, p_user_id=usr_id)
                data = cur.fetchone()
                if data:
                    _value = data[0]
                    real_password = str(_value)
                    setattr(preference, "ENCRYPTED_PASSWORD",
                            auth_util.encrypt(new_passwd))
                    setattr(preference, "ADDITIONAL_INFO2", new_passwd)
                    if auth_util.verify(old_passwd, real_password):
                        sql_data = 'update  nas_users set '
                        for key, value in preference.__dict__.items():
                            sql_data += str(key)+'='+"'"
                            if value is not None:
                                sql_data += str(value)
                            sql_data += "'"+','
                        sql_data = sql_data[:-1]
                        sql_data += str(' '+'where user_id ='+str(usr_id))
                        cur.execute(sql_data)
                        con.commit()
                        result = "success"
                    else:
                        result = "password"
                else:
                    result = "user_id"
            else:
                sql_data = 'update  nas_users set '
                for key, value in preference.__dict__.items():
                    sql_data += str(key)+'='+"'"
                    if value is not None:
                        sql_data += str(value)
                    sql_data += "'"+','
                sql_data = sql_data[:-1]
                sql_data += str(' '+'where user_id ='+str(usr_id))
                cur.execute(sql_data)
                con.commit()
                result = "success"
        except Exception as error:
            logger.dthublog("""@ 147 EXCEPTION - models - preference -
                 save """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - preference - save(-)')
        return result

    @staticmethod
    def reset_passwd(user_name):
        logger.addinfo("@ models - preference - reset_passwd(+)")
        result = ""
        hashval = ''.join(random.choice
                          (string.ascii_uppercase +
                           string.ascii_lowercase +
                           string.digits) for i in range(20))
        encrypted_passwrd = hashPassword(hashval)
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sqlFile = db_util.getSqlData()
            email_qry = sqlFile['email-query']
            cursor.execute(sqlFile['key_save'], pkey=hashval,
                           p_user_name=user_name.upper(), p_encrypted_passwrd=encrypted_passwrd)
            connection.commit()
            cursor.execute(email_qry, p_user_name=user_name.upper())
            to = cursor.fetchone()            
            if to:
                req_data = dict()
                req_data['email'] = to[0]
                req_data['subject'] = 'Reset password - Scorpion'
                req_data['activation_key'] = hashval
                req_data['user_name'] = user_name
                req_data['type'] = 'reset_password'
                result = Users.send_mail(req_data)
                if result != 'success':
                    status = 'Failure - Failed to send email'
                else:
                    status = 'success'
            else:
                status = 'invalid_user'
        except Exception as error:
            logger.dthublog("""@ 218 EXCEPTION - models - preference -
                 reset_passwd """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo("@ models - preference - reset_passwd(-)")
        return status

    #  used in cutomer to get ordertypes of organization
    @staticmethod
    def get_userdetails(user_key):
        logger.addinfo('@ models - preference - get_userdetails(+)')
        con = None
        cur = None
        user_details = ""
        try:
            con = db_util.get_connection()
            cur = con.cursor()
            sql_file = db_util.getSqlData()
            cur.execute(sql_file['user_idqry'], p_key=user_key)
            idval = cur.fetchone()
            if idval:
                user_details = Login.get_user_preferences(idval[0])
            else:
                user_details = "Incorrect Key !!"
        except Exception as error:
            logger.dthublog("""@ 244 EXCEPTION - models - preference -
                 get_userdetails """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - preference - get_userdetails(-)')
        return user_details

    @staticmethod
    def reset_message(user_name, new_passwd):
        logger.addinfo('@ models - preference - reset_message(+)')
        con = None
        cursor = None
        try:
            con = db_util.get_connection()
            cursor = con.cursor()
            sql_file = db_util.getSqlData()
            cursor.execute(sql_file['passwd_change'],
                           p_enpasswd=auth_util.encrypt(new_passwd),
                           p_password=new_passwd,
                           p_user_name=user_name.upper())
            email_qry = sql_file['email-query']
            cursor.execute(email_qry, p_user_name=user_name.upper())
            to = cursor.fetchone()
            if to:
                req_data = dict()
                req_data['email'] = to[0]
                req_data['subject'] = 'Password change - Scorpion'
                req_data['user_name'] = user_name
                req_data['type'] = 'password_change'
                result = Users.send_mail(req_data)
                if result != 'success':
                    status = 'Failure - Failed to send email'
                else:
                    status = 'success'
            else:
                status = 'invalid_user'
            con.commit()
        except Exception as error:
            logger.dthublog("""@ 276 EXCEPTION - models - preference -
                 reset_message """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(con)
        logger.addinfo('@ models - preference - reset_message(-)')
        return status

    @staticmethod
    def get_homepage_Lookup(lookup_id):
        logger.addinfo('@ models - preference - get_homepage_Lookup(+)')
        connection = None
        cursor = None
        try:
            connection = db_util.get_connection()
            cursor = connection.cursor()
            sql_file = db_util.getSqlData()
            query = sql_file['homepage_lookup_code_query']
            cursor.execute(query, p_lookup_id=lookup_id)
        except Exception as error:
            logger.dthublog("""@ 327 EXCEPTION - models - preference -
                 get_homepage_Lookup """ + str(error))
            raise error
        else:
            lookup = []
            fieldnames = [a[0].lower() for a in cursor.description]
            for row in cursor:
                love = Login()
                for index, fn in enumerate(fieldnames):
                    setattr(love, fn, row[index])
                lookup.append(love)
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.addinfo('@ models - preference - get_homepage_Lookup(-)')
        return lookup


# generate encrypted password
def hashPassword(password):
    return auth_util.encrypt(password)