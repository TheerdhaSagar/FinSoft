from __future__ import absolute_import

import cx_Oracle

from scorpionapi.sql import sql_util
from scorpionapi.utils import db_util
from scorpionapi.utils.logdata import logger
from scorpionapi.utils.code_util import Code_util


class Calendar:

    def __init__(self):
        self.strings = db_util.get_strings()
        self.sql_file = sql_util.get_sql(self.__class__.__name__.lower())
        self.connection = None
        self.cursor = None
        self.is_acquired = False

    def acquire(self):
        self.connection = db_util.get_connection()
        self.cursor = self.connection.cursor()
        self.is_acquired = True

    def release(self):
        if self.cursor:
            self.cursor.close()
            self.is_acquired = False
        db_util.release_connection(self.connection)

    def add_calendar(self, data):
        logger.addinfo('@ models - calendar - add_calendar(+)')
        result = dict()
        local_acquire = False
        try:
            if not self.is_acquired:
                self.acquire()
                local_acquire = True
            work_calendar_id = self.cursor.var(cx_Oracle.NUMBER)
            status_code = self.cursor.var(cx_Oracle.STRING)
            if data['employee_ids']:
                employee_list = data['employee_ids']
            else:
                employee_list = -1
            self.cursor.execute("""
            declare\
            p_employee_ids benefits_allocations_pkg.lm_add_employee_details_cover;
            
            type t_work_employee_details_table is table of NUMBER
                            index by binary_integer;\
                            
            add_employee_ids t_work_employee_details_table := :p_employee_list;
                                   
            begin
                for i in 1..add_employee_ids.count
                    LOOP
                        p_employee_ids(i).user_id := add_employee_ids(i);\
                    END LOOP;
            
                BENEFITS_ALLOCATIONS_PKG.add_work_calendar(
                :p_work_calendar_id,
                :p_calendar_name,
                :p_log_in_time,     
                :p_log_out_time,    
                :p_week_offs,  
                :p_team_id,         
                :p_user_id,
                p_employee_ids,        
                :p_status_code
                );
            end; """, p_work_calendar_id=work_calendar_id,
                                p_calendar_name=data['calendar_name'],
                                p_log_in_time=data['log_in_time'],
                                p_log_out_time=data['log_out_time'],
                                p_week_offs=data['week_offs'],
                                p_team_id=data['team_id'],
                                p_user_id=data['user_id'],
                                p_employee_list=employee_list,
                                p_status_code=status_code)
            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'calendar added successfully'
                result['work_calendar_id'] = work_calendar_id.getvalue()
            else:
                result['status'] = 1
                result['msg'] = 'Failed to add calendar - ' + str(status)
                result['work_calendar_id'] = -1
        except Exception as e:
            logger.dthublog("""@ 252 EXCEPTION models - calendar -
                add_calendar """ + str(e))
            raise e
        finally:
            if self.is_acquired and local_acquire:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - calendar - add_calendar(-)')
        return result

    def add_employees_work_calendar(self, data, work_calendar_id):
        logger.addinfo('@ models - calendar - add_employees_work_calendar(+)')
        result = dict()
        local_acquire = False
        try:
            if not self.is_acquired:
                self.acquire()
                local_acquire = True
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                BENEFITS_ALLOCATIONS_PKG.add_employee_work_calendar(
                :p_work_calendar_id,
                :p_employee_id,        
                :p_user_id,        
                :p_status_code
                );
            end; """, p_work_calendar_id=work_calendar_id,
                                p_employee_id=data['employee_id'],
                                p_user_id=data['user_id'],
                                p_status_code=status_code)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'calendar added successfully'
                result['work_calendar_id'] = work_calendar_id.getvalue()
            else:
                result['status'] = 1
                result['msg'] = 'Failed to add calendar - ' + str(status)
                result['work_calendar_id'] = -1
        except Exception as e:
            logger.dthublog("""@ 252 EXCEPTION models - calendar -
                add_employees_work_calendar """ + str(e))
            raise e
        finally:
            if self.is_acquired and local_acquire:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - calendar - add_employees_work_calendar(-)')
        return result

    def update_calendar(self, data):
        logger.addinfo('@ models - calendar - update_calendar(+)')
        result = dict()
        local_acquire = False
        try:
            if not self.is_acquired:
                self.acquire()
                local_acquire = True
            if data['employee_ids']:
                tot_employee_list = data['employee_ids']
            else:
                tot_employee_list = -1
            query = self.sql_file['work_calendar_query_employees']
            self.cursor.execute(query, p_work_calendar_id=data['work_calendar_id'])
            existing_employee_list = [x[0] for x in self.cursor.fetchall()]
            employee_list = list(set(tot_employee_list) - set(existing_employee_list))
            del_employee_list = list(set(existing_employee_list) - set(tot_employee_list))
            status_code = self.cursor.var(cx_Oracle.STRING)
            if len(employee_list) > 0:
                self.cursor.execute("""
                            declare\
                            p_employee_ids benefits_allocations_pkg.lm_add_employee_details_cover;
    
                            type t_work_employee_details_table is table of NUMBER
                                            index by binary_integer;\
    
                            add_employee_ids t_work_employee_details_table := :p_employee_list;
    
                            begin
                                for i in 1..add_employee_ids.count
                                    LOOP
                                        p_employee_ids(i).user_id := add_employee_ids(i);\
                                    END LOOP;
    
                                BENEFITS_ALLOCATIONS_PKG.add_work_employee(
                                :p_work_calendar_id,                                        
                                p_employee_ids,
                                :p_user_id,    
                                :p_status_code
                                );
                            end; """, p_work_calendar_id=data['work_calendar_id'],
                                    p_employee_list=employee_list,
                                    p_user_id=data['user_id'],
                                    p_status_code=status_code)
            self.cursor.execute("""
                                begin
                                    BENEFITS_ALLOCATIONS_PKG.update_work_calendar(
                                    :p_work_calendar_id,
                                    :p_calendar_name,
                                    :p_log_in_time,     
                                    :p_log_out_time,    
                                    :p_week_offs,  
                                    :p_team_id,         
                                    :p_user_id,      
                                    :p_status_code
                                    );
                                end; """, p_work_calendar_id=data['work_calendar_id'],
                                p_calendar_name=data['calendar_name'],
                                p_log_in_time=data['log_in_time'],
                                p_log_out_time=data['log_out_time'],
                                p_week_offs=data['week_offs'],
                                p_team_id=data['team_id'],
                                p_user_id=data['user_id'],
                                p_status_code=status_code)
            status = status_code.getvalue()
            if status == 'SUCCESS':
                for employee in del_employee_list:
                    self.cursor.execute("""
                    begin
                        BENEFITS_ALLOCATIONS_PKG.delete_work_calendar_employees(
                            :p_user_id,
                            :p_status_code
                        );
                    end; """, p_user_id=employee,
                                        p_status_code=status_code)
                status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'calendar updated successfully'
                result['work_calendar_id'] = data['work_calendar_id']
            else:
                result['status'] = 1
                result['msg'] = 'Failed to update calendar - ' + str(status)
                result['work_calendar_id'] = -1
        except Exception as e:
            logger.dthublog("""@ 252 EXCEPTION models - calendar -
                update_calendar """ + str(e))
            raise e
        finally:
            if self.is_acquired and local_acquire:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - calendar - update_calendar(-)')
        return result

    def delete_calendar(self, work_calendar_id):
        logger.addinfo('@ models - calendar - delete_calendar(+)')
        result = dict()
        local_acquire = False
        try:
            if not self.is_acquired:
                self.acquire()
                local_acquire = True
            status_code = self.cursor.var(cx_Oracle.STRING)
            self.cursor.execute("""
            begin
                BENEFITS_ALLOCATIONS_PKG.delete_work_calendar(
                    :p_work_calendar_id,
                    :p_status_code
                );
            end; """, p_work_calendar_id=work_calendar_id,
                                p_status_code=status_code)

            status = status_code.getvalue()
            if status == 'SUCCESS':
                result['status'] = 0
                result['msg'] = 'Work calendar deleted successfully'
                result['work_calendar_id'] = work_calendar_id
            else:
                result['status'] = 1
                result['msg'] = 'Failed to delete calendar - ' + str(status)
                result['work_calendar_id'] = -1
        except Exception as e:
            logger.dthublog("""@ 252 EXCEPTION models - calendar -
                delete_calendar """ + str(e))
            raise e
        finally:
            if self.is_acquired and local_acquire:
                self.connection.commit()
                self.release()
        logger.addinfo('@ models - calendar - delete_calendar(-)')
        return result

    def get_calendar(self, team_id):
        logger.addinfo('@ models - calender - get_calender(+)')
        result = dict()
        try:
            self.acquire()
            query = self.sql_file['work_calendar_query']
            self.cursor.execute(query, p_team_id=team_id)
            work_calendar = Code_util.iterate_data(self.cursor)
            result['status'] = 0
            result['result'] = work_calendar
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - calender -
                get_calender """ + str(e))
            raise e
        logger.addinfo('@ models - calender - get_calender(-)')
        return result

    def get_all_users_calendar(self, team_id):
        logger.addinfo('@ models - calender - get_all_users_calendar(+)')
        result = dict()
        try:
            self.acquire()
            query = self.sql_file['get_calendar_users']
            self.cursor.execute(query, p_team_id=team_id)
            work_calendar = Code_util.iterate_data(self.cursor)
            result['status'] = 0
            result['result'] = work_calendar
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - calender -
                get_all_users_calendar """ + str(e))
            raise e
        logger.addinfo('@ models - calender - get_all_users_calendar(-)')
        return result

    def get_users_calendar(self, team_id):
        logger.addinfo('@ models - calender - get_users_calendar(+)')
        result = dict()
        try:
            self.acquire()
            query = self.sql_file['employee_list_query']
            self.cursor.execute(query, p_org_id=team_id)
            work_calendar = Code_util.iterate_data(self.cursor)
            if not work_calendar:
                query = self.sql_file['get_team_details']
                self.cursor.execute(query, p_org_id=team_id)
                work_calendar = Code_util.iterate_data(self.cursor)
            result['status'] = 0
            result['result'] = work_calendar
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - calender -
                get_users_calendar """ + str(e))
            raise e
        logger.addinfo('@ models - calender - get_users_calendar(-)')
        return result

    def get_calendar_details(self, calendar_id):
        logger.addinfo('@ models - calender - get_calendar_details(+)')
        result = dict()
        try:
            self.acquire()
            query = self.sql_file['work_calendar_details_query']
            self.cursor.execute(query, p_calendar_id=calendar_id)
            work_calendar = Code_util.iterate_data(self.cursor)
            result['status'] = 0
            result['result'] = work_calendar
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - calender -
                get_calendar_details """ + str(e))
            raise e
        logger.addinfo('@ models - calender - get_calendar_details(-)')
        return result
