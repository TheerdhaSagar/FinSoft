from __future__ import absolute_import
import ujson
from scorpionapi.utils.logdata import logger
from scorpionapi.utils import db_util
from scorpionapi.utils import auth_util


class Login:

    def __init__(self, **kwargs):
        for name, value in kwargs.items():
            setattr(self, name, value)

    # used to authenticate user details provided by the user
    @staticmethod
    def authenticate(user_name, password, src):
        logger.dthublog("@ models - login - authenticate(+)")
        connection = db_util.get_connection()
        sql_file = db_util.getSqlData()
        result = ""
        # verified if the user exist or not
        try:
            user_query = sql_file['user_name_query']
            cursor = connection.cursor()
            cursor.execute(user_query, p_user_name=user_name.upper())
            mydata = cursor.fetchone()
            if mydata:
                user_id = mydata[1]
                value = mydata[0]
                if value.upper() == user_name.upper():
                    # check password here
                    query = sql_file['password_query']
                    cursor.execute(query, p_user_name=user_name.upper())
                    data = cursor.fetchone()
                    _value = data[0]
                    real_password = str(_value)
                    msg = "update NAS_USERS set additional_info4 = '"
                    if auth_util.verify(password, real_password):
                        data = Login.get_user_preferences(user_id)
                        result = data
                        cursor.execute(msg +
                                       src + "' where upper(user_name) = '" +
                                       user_name.upper() + "'")
                        connection.commit()
                    elif value != user_name and real_password != password:
                        result = "fails"
                    else:
                        result = "fails"
            else:
                result = "user_name"
        except Exception as error:
            logger.dthublog("""@ 27 EXCEPTION - models - login -
                 authenticate """ + str(error))
            raise error
        finally:
            cursor.close()
            db_util.release_connection(connection)
        logger.dthublog("@ models - login - authenticate(-)")
        return result

    @staticmethod
    def get_user_preferences(user_id):
        logger.dthublog('@ models - login - get_user_preferences(+)')
        try:
            con = db_util.get_connection()
            sqlFile = db_util.getSqlData()
            cur = con.cursor()
            org_query = sqlFile['org_ids_query']
            cur.execute(org_query, p_user_id=user_id)
            org_data = cur.fetchall()
            org_list = []
            org_fieldnames = [a[0].lower() for a in cur.description]
            for org_row in org_data:
                org_names = Login()
                for org_index, org_fn in enumerate(org_fieldnames):
                    setattr(org_names, org_fn, org_row[org_index])
                org_list.append(org_names)
            query = sqlFile['user_details_query']
            cur.execute(query, p_user_id=user_id)
            mydata = cur.fetchall()
            myuserpref_list = []
            fieldnames = [a[0].lower() for a in cur.description]
            for row in mydata:
                myuserpref = Login()
                for index, fn in enumerate(fieldnames):
                    setattr(myuserpref, fn, row[index])
                myuserpref_list.append(myuserpref)
            data = ujson.dumps(myuserpref_list)
            userpref_data = ujson.loads(data)
            list_permission = []
            list_roles = []
            finaluser_pref = dict()
            for userdict in userpref_data:
                for key in userdict.keys():
                    default_org_id = userdict['default_org_id']
                    if key not in finaluser_pref.keys() and key not in ['permission_code', 'role_code']:
                        finaluser_pref[key] = userdict[key]
                    elif key == 'permission_code' and userdict['permission_code'] not in list_permission:
                        permissons = userdict['permission_code']
                        list_permission.append(permissons)
                    elif key == 'role_code' and userdict['role_code'] not in list_roles:
                        roles = userdict['role_code']
                        list_roles.append(roles)
                finaluser_pref['permissions'] = list_permission
                finaluser_pref['roles'] = list_roles
                finaluser_pref["organizations"] = org_list
                if "organization_id" in finaluser_pref:
                    del finaluser_pref["organization_id"]
                finaluser_pref["organization_id"] = default_org_id
        except Exception as error:
            logger.dthublog("""@ 157 EXCEPTION - models - login -
                 get_user_preferences """ + str(error))
            raise error
        finally:
            cur.close()
            db_util.release_connection(con)
        logger.dthublog('@ models - login - get_user_preferences(-)')
        return finaluser_pref

    @staticmethod
    def get_auth_url():
        logger.addinfo('@ models - balances - get_balances_summary(+)')
        result = dict()
        try:
            authorize_url = 'https://login.microsoftonline.com/4c2c8480-d3f0-485b-b750-807ff693802f/oauth2/v2.0/authorize'
            callback_uri = "http://localhost:8008/auth/redirect"
            client_id = 'afc5a0ea-c79b-4888-867a-a5f6049b4023'
            client_secret = 't45EMpb4.4R..B3l0Go.rz83~EZVK.LQ33'
            authorization_redirect_url = authorize_url + '?response_type=code&client_id=' + client_id + '&redirect_uri=' + callback_uri + '&scope=openid'
            result['status'] = 0
            result['result'] = authorization_redirect_url
        except Exception as e:
            logger.dthublog(""" @ EXCEPTION - models - balances -
                get_balances_summary """ + str(e))
            raise e
        logger.addinfo('@ models - balances - get_balances_summary(-)')
        return result
