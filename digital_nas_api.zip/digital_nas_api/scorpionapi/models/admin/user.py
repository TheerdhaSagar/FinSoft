import requests
import json
from scorpionapi.azure_token_verify import AzureTokenVerification
from scorpionapi.utils.common_utils import CommonUtils
from flask import g
from scorpionapi.utils import db_util
from scorpionapi.utils.code_util import Code_util


class User:

    def __init__(self):
        self.user_id = None
        self.user_name = None
        self.email = None
        self.roles = None
        self.user_description = None
        self.connection = None

    # Azure token generation
    @staticmethod
    def generate_azure_auth_token(auth_code, angular_id_token=None):
        res = {}
        con = None
        cur = None
        try:
            if not angular_id_token:
                client_id = 'afc5a0ea-c79b-4888-867a-a5f6049b4023'
                client_secret = 't45EMpb4.4R..B3l0Go.rz83~EZVK.LQ33'
                callback_uri = "http://localhost:8008/auth/redirect"
                token_url = 'https://login.microsoftonline.com/4c2c8480-d3f0-485b-b750-807ff693802f/oauth2/v2.0/token'
                data = {'grant_type': 'authorization_code', 'code': auth_code, 'redirect_uri': callback_uri}
                access_token_response = requests.post(token_url, data=data, verify=False, allow_redirects=False,
                                                      auth=(client_id, client_secret))
                tokens = json.loads(access_token_response.text)
                id_token = tokens['id_token']
            else:
                id_token = angular_id_token
            azure_token_obj = AzureTokenVerification()
            if azure_token_obj.verify_azure_token(azure_token=id_token):
                con = db_util.get_connection()
                sqlFile = db_util.getSqlData()
                cur = con.cursor()
                user_query = sqlFile['user_id_query']
                cur.execute(user_query, p_user_name=g.user_name)
                report_record_count = Code_util.iterate_data(cur)[0]
                g.user_id = report_record_count['emplid']
                cur.execute(sqlFile['add_login_details'], p_emplid=report_record_count['emplid'])
                res['token'] = id_token
                res['user_id'] = g.user_id
                res['user_name'] = g.user_name
                result = {
                    'user_description': g.user_description,
                    'roles': g.roles,
                    'email': g.email,
                    'user_id': g.user_id,
                    'user_name': g.user_name,
                    'job_title': report_record_count['job_title'],
                    'reports_to_id': report_record_count['reports_to_id'],
                    'reports_to_email': report_record_count['reports_to_email'],
                    'business_unit': report_record_count['vertical']
                }
                res['result'] = result
            else:
                res['status'] = 1
                res['msg'] = "Please enter valid credentials"
        except Exception as e:
            print(str(e))
            return CommonUtils.pass_error('innovations', 'sync_innovations_with_adp_works', e)
        finally:
            con.commit()
            cur.close()
            db_util.release_connection(con)
        return res

    def clear(self):
        self.user_name = None
        self.email = None
        self.roles = None
        self.user_description = None

    def as_dict(self):
        return {"user_name": self.user_name,
                "email": self.email,
                "roles": self.roles,
                "user_description": self.user_description}
