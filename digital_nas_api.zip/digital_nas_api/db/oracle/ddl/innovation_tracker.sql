
CREATE TABLE innovation_trckr_adpwrk_trans (
    idea_id              NUMBER,
    title                NVARCHAR2(1000),
    content              CLOB,
    content1             VARCHAR2(4000),
    content2             VARCHAR2(4000),
    content3             VARCHAR2(4000),
    content4             VARCHAR2(4000),
    content5             VARCHAR2(4000),
    content6             VARCHAR2(4000),
    content7             VARCHAR2(4000),
    content8             VARCHAR2(4000),
    content9             VARCHAR2(4000),
    content10            VARCHAR2(4000),
    content11            VARCHAR2(4000),
    url                  NVARCHAR2(500),
    siteId               NUMBER,
    tags                 VARCHAR2(500),
    categories           NVARCHAR2(500),
    topics               NVARCHAR2(500),
    stage                NVARCHAR2(500),
    voteCount            VARCHAR(100),
    social_comm_cnt      VARCHAR(100),
    score                VARCHAR(100),
    views                VARCHAR(100),
    datePublished        DATE,
    lastActivityDate     DATE,
    submitter_id         VARCHAR(100),
    submitter_email      VARCHAR(500),
    submitter_name       VARCHAR(500),
    created_date         DATE DEFAULT SYSDATE,
    recent_update_date   DATE DEFAULT SYSDATE,
    additional_info1     VARCHAR(100),
    additional_info2     VARCHAR(100),
    additional_info3     VARCHAR(100),
    additional_info4     VARCHAR(100),
    additional_info5     VARCHAR(100)
);

create index innovation_trckr_adpwrk_i on innovation_trckr_adpwrk ( idea_id,title);

CREATE TABLE innovation_trckr_adpwrk (
    idea_id              NUMBER,
    title                NVARCHAR2(1000),
    content              CLOB,
    content1             VARCHAR2(4000),
    content2             VARCHAR2(4000),
    content3             VARCHAR2(4000),
    content4             VARCHAR2(4000),
    content5             VARCHAR2(4000),
    content6             VARCHAR2(4000),
    content7             VARCHAR2(4000),
    content8             VARCHAR2(4000),
    content9             VARCHAR2(4000),
    content10            VARCHAR2(4000),
    content11            VARCHAR2(4000),
    url                  NVARCHAR2(500),
    siteId               NUMBER,
    tags                 VARCHAR2(500),
    categories           NVARCHAR2(500),
    topics               NVARCHAR2(500),
    stage                NVARCHAR2(500),
    voteCount            VARCHAR(100),
    social_comm_cnt      VARCHAR(100),
    score                VARCHAR(100),
    views                VARCHAR(100),
    datePublished        DATE,
    lastActivityDate     DATE,
    submitter_id         VARCHAR(100),
    submitter_email      VARCHAR(500),
    submitter_name       VARCHAR(500),
    created_date         DATE DEFAULT SYSDATE,
    recent_update_date   DATE DEFAULT SYSDATE,
    additional_info1     VARCHAR(100),
    additional_info2     VARCHAR(100),
    additional_info3     VARCHAR(100),
    additional_info4     VARCHAR(100),
    additional_info5     VARCHAR(100)
);

CREATE TABLE innovation_trckr_adpwrk_bkp (
    idea_id              NUMBER,
    title                NVARCHAR2(1000),
    content              CLOB,
    content1             VARCHAR2(4000),
    content2             VARCHAR2(4000),
    content3             VARCHAR2(4000),
    content4             VARCHAR2(4000),
    content5             VARCHAR2(4000),
    content6             VARCHAR2(4000),
    content7             VARCHAR2(4000),
    content8             VARCHAR2(4000),
    content9             VARCHAR2(4000),
    content10            VARCHAR2(4000),
    content11            VARCHAR2(4000),
    url                  NVARCHAR2(500),
    siteId               NUMBER,
    tags                 VARCHAR2(500),
    categories           NVARCHAR2(500),
    topics               NVARCHAR2(500),
    stage                NVARCHAR2(500),
    voteCount            VARCHAR(100),
    social_comm_cnt      VARCHAR(100),
    score                VARCHAR(100),
    views                VARCHAR(100),
    datePublished        DATE,
    lastActivityDate     DATE,
    submitter_id         VARCHAR(100),
    submitter_email      VARCHAR(500),
    submitter_name       VARCHAR(500),
    created_date         DATE DEFAULT SYSDATE,
    recent_update_date   DATE DEFAULT SYSDATE,
    additional_info1     VARCHAR(100),
    additional_info2     VARCHAR(100),
    additional_info3     VARCHAR(100),
    additional_info4     VARCHAR(100),
    additional_info5     VARCHAR(100)
);

CREATE TABLE innovation_trckr_adpwrk_hist (
    idea_id               NUMBER,
    user_name              VARCHAR(200),
    action               VARCHAR(200),
    created_date         DATE DEFAULT SYSDATE,
    recent_update_date   DATE DEFAULT SYSDATE,
    additional_info1     VARCHAR(100),
    additional_info2     VARCHAR(100),
    additional_info3     VARCHAR(100),
    additional_info4     VARCHAR(100),
    additional_info5     VARCHAR(100)
);


CREATE TABLE innovations_employee_data (
    emplid               NUMBER,
    user_name            VARCHAR(200),
    emp_name             VARCHAR2(200),
    job_title            VARCHAR2(200),
    email                VARCHAR2(250),
    hire_dt              DATE,
    department           VARCHAR2(200),
    vertical             VARCHAR(200),
    reports_to_id        NUMBER,
    reports_to_email     VARCHAR(250),
    created_date         DATE DEFAULT SYSDATE,
    recent_update_date   DATE DEFAULT SYSDATE,
    additional_info1     VARCHAR(100),
    additional_info2     VARCHAR(100),
    additional_info3     VARCHAR(100),
    additional_info4     VARCHAR(100),
    additional_info5     VARCHAR(100)
);


CREATE TABLE innovations_emp_data_trans (
    emplid               NUMBER,
    user_name            VARCHAR(200),
    emp_name             VARCHAR2(200),
    job_title            VARCHAR2(200),
    email                VARCHAR2(250),
    hire_dt              DATE,
    department           VARCHAR2(200),
    vertical             VARCHAR(200),
    reports_to_id        NUMBER,
    reports_to_email     VARCHAR(250),
    created_date         DATE DEFAULT SYSDATE,
    recent_update_date   DATE DEFAULT SYSDATE,
    additional_info1     VARCHAR(100),
    additional_info2     VARCHAR(100),
    additional_info3     VARCHAR(100),
    additional_info4     VARCHAR(100),
    additional_info5     VARCHAR(100)
);


CREATE TABLE innovations_employee_data_arch (
    emplid               NUMBER,
    user_name            VARCHAR(200),
    emp_name             VARCHAR2(200),
    job_title            VARCHAR2(200),
    email                VARCHAR2(250),
    hire_dt              DATE,
    department           VARCHAR2(200),
    vertical             VARCHAR(200),
    reports_to_id        NUMBER,
    reports_to_email     VARCHAR(250),
    created_date         DATE DEFAULT SYSDATE,
    recent_update_date   DATE DEFAULT SYSDATE,
    additional_info1     VARCHAR(100),
    additional_info2     VARCHAR(100),
    additional_info3     VARCHAR(100),
    additional_info4     VARCHAR(100),
    additional_info5     VARCHAR(100)
);


CREATE TABLE innovations_meta_data_stage (
    stage_id             Number,
    stage_name          VARCHAR2(200),
    created_id           VARCHAR2(200),
    created_date         DATE DEFAULT SYSDATE,
    recent_update_date   DATE DEFAULT SYSDATE,
    additional_info1     VARCHAR(100),
    additional_info2     VARCHAR(100),
    additional_info3     VARCHAR(100),
    additional_info4     VARCHAR(100),
    additional_info5     VARCHAR(100)
);

create sequence innovations_meta_data_stage_s
start with 1
increment by 1
nocache
nocycle;

insert into innovations_meta_data_stage(stage_id, stage_name, created_id) values (1, 'Initial Review', 'nimmagth');

CREATE TABLE innovations_meta_data_labels (
    stage_id             Number,
    label_id             Number,
    label_name           VARCHAR2(200),
    input_type           VARCHAR2(100),
    position_nbr             Number,
    created_id           VARCHAR2(200),
    created_date         DATE DEFAULT SYSDATE,
    recent_update_date   DATE DEFAULT SYSDATE,
    additional_info1     VARCHAR(100),
    additional_info2     VARCHAR(100),
    additional_info3     VARCHAR(100),
    additional_info4     VARCHAR(100),
    additional_info5     VARCHAR(100)
);

insert into innovations_meta_data_labels(stage_id,label_id, label_name,input_type,position_nbr, created_id) values (5, innovations_meta_data_labels_s.Nextval, 'Dollar Savings', 'text', 1, 'nimmagth');

create sequence innovations_meta_data_labels_s
start with 1
increment by 1
nocache
nocycle;

CREATE TABLE innovations_meta_data_values (
    stage_id             Number,
    label_id             Number,
    value_id             NUMBER,
    value_name           VARCHAR2(200),
    created_id           VARCHAR2(200),
    created_date         DATE DEFAULT SYSDATE,
    recent_update_date   DATE DEFAULT SYSDATE,
    additional_info1     VARCHAR(100),
    additional_info2     VARCHAR(100),
    additional_info3     VARCHAR(100),
    additional_info4     VARCHAR(100),
    additional_info5     VARCHAR(100)
);

insert into innovations_meta_data_values (stage_id, label_id,value_name,created_id, value_id) values (3, 17, 'No', 'nimmagth', innovations_meta_data_values_s.nextval)

create sequence innovations_meta_data_values_s
start with 1
increment by 1
nocache
nocycle;

CREATE TABLE innovations_idea_values (
    idea_id              NUMBER,
    stage_id             NUMBER,
    label_id             Number,
    value_id             Number,
    tbox_value1          VARCHAR2(200),
    tbox_value2          VARCHAR2(200),
    tbox_value3          VARCHAR2(200),
    created_id           VARCHAR2(200),
    recent_update_id     VARCHAR2(200),
    created_date         DATE DEFAULT SYSDATE,
    recent_update_date   DATE DEFAULT SYSDATE,
    additional_info1     VARCHAR(100),
    additional_info2     VARCHAR(100),
    additional_info3     VARCHAR(100),
    additional_info4     VARCHAR(100),
    additional_info5     VARCHAR(100)
);

CREATE TABLE innovations_idea_comments (
    idea_id              NUMBER,
    comment_id           NUMBER,
    comments            VARCHAR2(3000),
    parent_comment_id   NUMBER,
    created_id          VARCHAR2(200),
    created_date         DATE DEFAULT SYSDATE,
    recent_update_date   DATE DEFAULT SYSDATE,
    additional_info1     VARCHAR(100),
    additional_info2     VARCHAR(100),
    additional_info3     VARCHAR(100),
    additional_info4     VARCHAR(100),
    additional_info5     VARCHAR(100)
);

create sequence innovations_idea_comments_s
start with 1
increment by 1
nocache
nocycle;


CREATE TABLE innovations_idea_attachments (
    idea_id              NUMBER,
    attachment_id        NUMBER,
    file_name            VARCHAR2(100),
    file_type            VARCHAR2(100),
    file_data            BLOB,
    created_id          VARCHAR2(200),
    created_date         DATE DEFAULT SYSDATE,
    recent_update_date   DATE DEFAULT SYSDATE,
    additional_info1     VARCHAR(100),
    additional_info2     VARCHAR(100),
    additional_info3     VARCHAR(100),
    additional_info4     VARCHAR(100),
    additional_info5     VARCHAR(100)
);

create sequence innovations_idea_attachments_s
start with 1
increment by 1
nocache
nocycle;

CREATE TABLE innovations_idea_notifications (
    idea_id              NUMBER,
    notification_id      NUMBER,
    notification_title   VARCHAR2(700),
    notification_descr   VARCHAR2(3000),
    notification_date   DATE,
    created_id          VARCHAR2(200),
    created_date         DATE DEFAULT SYSDATE,
    recent_update_date   DATE DEFAULT SYSDATE,
    additional_info1     VARCHAR(100),
    additional_info2     VARCHAR(100),
    additional_info3     VARCHAR(100),
    additional_info4     VARCHAR(100),
    additional_info5     VARCHAR(100)
);

create sequence innovations_idea_notify_s
start with 1
increment by 1
nocache
nocycle;

CREATE TABLE innovations_emp_login_history (
    emplid               NUMBER,
    last_login_date      DATE,
    created_date         DATE DEFAULT SYSDATE,
    recent_update_date   DATE DEFAULT SYSDATE,
    additional_info1     VARCHAR(100),
    additional_info2     VARCHAR(100),
    additional_info3     VARCHAR(100),
    additional_info4     VARCHAR(100),
    additional_info5     VARCHAR(100)
);


CREATE TABLE innovations_emp_map_other_mgr (
    emplid               NUMBER,
    user_name            VARCHAR(100),
    manager_id           NUMBER,
    manager_user_name    VARCHAR(100),
    created_date         DATE DEFAULT SYSDATE,
    recent_update_date   DATE DEFAULT SYSDATE,
    additional_info1     VARCHAR(100),
    additional_info2     VARCHAR(100),
    additional_info3     VARCHAR(100),
    additional_info4     VARCHAR(100),
    additional_info5     VARCHAR(100)
);




-------------------



delete from  innovations_idea_values where idea_id = 1017393;

update innovation_trckr_adpwrk set additional_info1 = '' where idea_id = 1017393;