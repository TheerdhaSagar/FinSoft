import requests
import json
import ujson
from requests_ntlm2 import HttpNtlmAuth
import base64
import cx_Oracle
import re
from scorpionapi.utils.constants import Status
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import jinja2
import os
import sys

token_url = 'https://adpworks.adp.com/connect/token'
# UAT
# token_url = 'https://adp-api-stg.unily.com/connect/token'
# client (application) credentials on ADP works
# Prod
client_id = '9b6b6581-aec8-48f6-9413-5a9c8571386f'
client_secret = 'U2v-I7oOwNoo9w3QIR-v1w'

proxies = {
    'https': 'http://40.119.3.108:80'
}
data = {'grant_type': 'client_credentials'}
access_token_response = requests.post(url=token_url, data=data, verify=False, proxies=proxies,
                                      auth=(client_id, client_secret))
print(access_token_response.text)
tokens = json.loads(access_token_response.text)
print(tokens)
api_call_headers = {'Authorization': 'Bearer ' + tokens['access_token']}
url_flag = True
# Unily.Site
# prod
api_url = 'https://adpworks.adp.com/api/v2/workfront/site-ideas?siteId=438571&pageSize=20&page='
#  UAT
# api_url = 'https://adp-api-stg.unily.com/api/v2/workfront/site-ideas?siteId=438571&pageSize=20&page='
counter = 1
while url_flag:
    adpworks_api_url = api_url + str(counter)
    api_call_response = requests.get(adpworks_api_url, headers=api_call_headers, verify=False,
                                     proxies=proxies)
    print(api_call_response)
    data = ujson.loads(api_call_response.text)
    print(data)
    # self.add_adp_works_data(data['entities'])
    if len(data['entities']) > 0:
        counter += 1
    else:
        url_flag = False
