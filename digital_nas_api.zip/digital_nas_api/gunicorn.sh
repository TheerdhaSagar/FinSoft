#!/bin/bash

NAME="SCORPIONAPI"
FLASKDIR=/home/nimmagat/bin/scorpion-api
VENVDIR=/home/nimmagat/anaconda3/envs
USER=nimmagat
NUM_WORKERS=6
# sagar 29-Sep-19 added following to change
# gunicorn default worker class
WORKER_CLASS="eventlet"

echo "Starting $NAME"

# activate the virtualenv
cd $VENVDIR
source bin/activate

export PYTHONPATH=$FLASKDIR:$PYTHONPATH

# Create the run directory if it doesn't exist
RUNDIR=$(dirname $SOCKFILE)
test -d $RUNDIR || mkdir -p $RUNDIR

# Start your unicorn
# sagar 27-Jun-20 added following timeout to increase
# default is 30s
# sai 29-Sep-15 added worker-class to change
# default gunicorn worker class; default is sync
exec gunicorn finapi.wsgi:app -b 127.0.0.1:8008 \
  --name $NAME \
  --workers $NUM_WORKERS \
  --worker-class $WORKER_CLASS \
  --user=$USER --group=$GROUP \
  --log-level=debug \
  --timeout=300 \
  --bind=unix:$SOCKFILE
