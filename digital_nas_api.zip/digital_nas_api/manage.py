from flask_restful import Api
from flask_script import Manager, Server
from scorpionapi.app import create_app

app = create_app()
api = Api(app, prefix='', catch_all_404s=True)
manager = Manager(app)
manager.add_command("run", Server(host="localhost", port=8008, threaded=True))

if __name__ == '__main__':
    manager.run()
